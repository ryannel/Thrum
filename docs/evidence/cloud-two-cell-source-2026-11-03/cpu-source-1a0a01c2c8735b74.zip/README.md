# Two independently evolving formations, one CPU source clock

3November2026. Completed bounded CPU contract slice from exact17f reference source. **No two-cell renderer, GPU/air/fog/environment proof, source-art acceptance, runtime throughput or full P4a pass.** Current v2 inputs remain coupling references; a subsequently qualified rho/d/admission configuration is injectable. ROOT_Y stays1239.2; arbitrary vertical layers/planet mapping are not implemented.

Source/tests are frozen at CPU revision1a0a01c2c8735b74, [pins](SOURCE-PINS.json), [exact delta](implementation.diff), [commission](COMMISSION.md), [preallocation plan](PREFLIGHT.md), [independent review](REVIEW.md). Only SourceModel constructor/fresh/shared-interval path changes; new world and native-oracle wrapper are added. Math/clock/weather/reference/admission and renderer/shaders retain17f bytes. Baseline-only source handoff/portable receipts reside in tests/source/baseline-17f; no new portable.py run is claimed.

## Producer and consumer API

```js
const world = new TwoCellWorld(configuration, initialControls, {
  cells: [
    { cellID: 'A', rootXZ: [0, 0] },
    { cellID: 'B', rootXZ: [16, 0] }
  ]
});
const clock = new SourceClock(world); // unchanged quarter-second SourceClock
world.enqueueBatch([
  { patch: windTurn, requestedTime: 150 },
  { patch: spatialFront, requestedTime: 500 }
]);
const tuple = clock.tuple();
const optical = evaluateWorld(tuple, point, sharedNativeAssets, sharedNoise);
const owned = snapshotWorldForProbe(tuple); // before await or another commit
```

`configuration` is the existing SourceModel `{templates,admissionMetadata,admissionPolicy?}` contract; this code names no native payload filename. The liquid Cu role IDs remain body/crown-b; this is not a generic family/plugin ABI. SourceModel also accepts `{cellID,rootXZ}` alongside dt; old defaults and public single-cell tuples remain exactly equivalent. Fresh/reset/replay-seek retain original absolute roots/IDs. Absolute worldX drives front exposure; this is not a render offset.

One world queue validates a whole batch before either producer advances. Both evolve exactly once using one frozen old interval, then receive prevalidated end-barrier controls before monitor/birth/recovery. No future input leaks into the interval. There is no per-reader stepping. Unexpected failure after A advances/B does not quarantines the world: getters/publication/cached-clock reads reject, older borrowed leases reject, and fault metadata only exposes labelled unsafe clocks. Full fresh/reset/replay-seek reconstructs both. No rollback or partial repair is claimed; owned old observer snapshots remain valid historical facts.

A ready tuple exposes shared epoch/tick/time/alpha/controls plus two `groups`, separate support boxes, formationRanges and borrowed per-cell F32 exposure views. No concatenated control banks or sixteen-part CPU pose copy is introduced. Each part has qualified `ID=JSON.stringify([epoch,cellID,localID])`, qualified parentID, localID/localParentID and **local** slot; globalSlot is groupIndex*8+slot. Event local IDs remain explicitly scoped by group cellID/epoch. Formation ranges distinguish dense partStart/count from fixed slotStart/count and controlElementOffset. GPU uploads later must use the fixed control offsets, not dense active-part order.

Borrowed publications expire at the next world commit or fault; `assertWorldPublication` rejects them. Array views remain read-only by consumer contract. Asynchronous CPU probes use `snapshotWorldForProbe`, which owns628,864 exposure bytes and cloned canonical pose arrays. Serialized metadata is not executable optical state. Original SourceClock still owns seek epochs; old/new cohort IDs cannot collide across reset. One ready clear world returns0 with valid inputs; missing inputs/publications and faults throw, never fabricated clear.

## Actual tests and numerical receipts

- 12 focused contract checks pass: exact17f default single-cell state/pose/buffer equivalence through550s; persistent absolute origins; qualified identity/slot mapping; rejected atomic batch; shared half-open controls/barrier; reset/seek;1x/16x equivalence; borrowed/owned lifetime; slot reuse; injected half-step failure and cached-clock rejection; shared-interval physics exactly matches independently commanded producers at150/500 boundaries.
- 6 actual native-oracle checks pass.558direct-versus-bound-rejected points include75positive points; queries do not advance source. Native inputs are loaded once/shared between groups.
- At120s, overlapping BODY roots X417.408/433.408 produce midpoint qA=.132259675, qB=.105008632; correct sigma=.004508097823. Deliberately wrong globalMAX gives.002512933821; proxySUM gives.007141703780.
- Remote initialB[11992.715801343124,6779.681531943434] puts its actual120s BODY root on Sun5°/.5azimuth ray from[0,2,0], root/ray discrepancy3.64e−12m.65actualR16 samples over±32m all have Bq>0 (minimum.07196045); omittedB/A-only gives0. B is outside A's16km fixture.64m trapezoid tau=.11868756 is a finite CPU diagnostic, not a rendered/full-ray shadow reference.
- Shared150wind/500front programme yields A maxE50.25 and B0 at committed550.25s while presentation is550s. Receipt timestamps distinguish these facts. This tests absolute world coordinates and atomic forcing, not two-cell appearance.
- Copied affected single-source suite8/8 and original render tests8/8 pass. Render tests validate compatibility with the old single-cell consumer; they do not implement16-slot/multi-group GPU queries.

See tests/world/contracts-results.json, native-results.json, tests/source/suite-results.json, and guarded-contracts/native/render-results.json. `historical-runs/guarded-all-concurrent-stopped.json` retains the earlier overall attempt including the stopped concurrent renderer scheduler; the top-level all-run receipt can be overwritten by a new sequential run in a disposable restored copy. Its earlier positive phase log paths were subsequently reused by the final focused/native phases; current phase receipts/logs are authoritative. The failure log run-logs/render.log is unchanged; a separate copy survives in historical-runs.

## Resource account and adverse scheduler

Pair controls allocate exactly1,886,592CPU B; native inputs shared once16,187,392B. Planned GPU control/pose table bytes628,864/1,536 are **not allocated here**. All other native fields and GPU resources remain unchanged copies/references; no512-cell case or compressed/lazy exposure scheme is introduced.

Sampled process-tree peaks, including Python monitor/ps and functional test children: final focused138.734MiB; native130.078MiB; source suite184.938MiB; serial renderer131.750MiB. These are small Node validation processes, not browser residency or runtime memory admission. The first renderer run used Node's default concurrent test workers and overshot the sampled guard to300.5MiB before termination. Both early224 and hard256 were exceeded in that scheduler attempt; sampled guards are not allocation barriers. The receipt/failure log is retained. Identical tests rerun with --test-concurrency=1 passed within the unchanged limits. No budget or test threshold was raised. No claim says every attempted process stayed below256MiB.

Run only sequentially, outside another owner's timing window:

```sh
python3 run-guarded.py --phase all
```

This is functional verification, never a Node benchmark. Current macOS ps guard is not portable process-residency instrumentation. Code/test SHA pins are immutable; receipts can be overwritten in disposable restored copies. No more heavy jobs are pending from this authoring slice.

## Remaining integration

The original GPU/query paths still have8global slots/globalMAX. A renderer owner must pack16slots/control offsets, MAX inside each group and ADD liquid coefficients between groups for **every** optical reader, retain both supports/occupied interval union, and avoid offscreen/cache omission. One union bound is a diagnostic/conservative enclosure, not a fixed-step traversal plan across14km. Integrate shared air/fog, receiver/mirror/environment, current complete light fallbacks, histories/disabled cost and immutable async submission facts separately. No new renderer/app/GPU code is part of this slice. Native source anatomy/distance/certification/lifecycle admission and complete scene/device cost remain open.
