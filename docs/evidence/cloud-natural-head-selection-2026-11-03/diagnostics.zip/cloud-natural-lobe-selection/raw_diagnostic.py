#!/usr/bin/env python3
"""Read-only, slabbed diagnostics for the frozen cloud-03-256 scalar."""
from pathlib import Path
import hashlib, json, resource, time
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'cloud-authored-master'
META = json.loads((SOURCE / 'cloud-03-256.json').read_text())
RAW = SOURCE / 'cloud-03-256.density.r16f'
EXPECTED = '42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9'
assert META['output']['sha256'] == EXPECTED and RAW.stat().st_size == 256**3*2
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1<<20), b''): h.update(b)
    return h.hexdigest()
assert sha(RAW) == EXPECTED
t0=time.perf_counter()
a=np.memmap(RAW,dtype='<f2',mode='r',shape=(256,256,256)) # Z,Y,X
front=np.zeros((256,256),np.float64);side=np.zeros((256,256),np.float64);top=np.zeros((256,256),np.float64)
front_max=np.zeros((256,256),np.float32);side_max=np.zeros((256,256),np.float32);top_max=np.zeros((256,256),np.float32)
height_mass=np.zeros(256,np.float64);height_cells=np.zeros(256,np.int64)
height_area=np.zeros(256,np.int64);height_xlo=np.full(256,256,np.int32);height_xhi=np.full(256,-1,np.int32)
height_zlo=np.full(256,256,np.int32);height_zhi=np.full(256,-1,np.int32)
sl_y=[220,240,260,280,300,320,336]
slices={y:np.zeros((256,256),np.float32) for y in sl_y}
for z0 in range(0,256,4):
    v=np.asarray(a[z0:z0+4],dtype=np.float32)
    front+=v.sum(axis=0,dtype=np.float64)*2
    front_max=np.maximum(front_max,v.max(axis=0))
    side[z0:z0+4]=v.sum(axis=2,dtype=np.float64)*2
    side_max[z0:z0+4]=v.max(axis=2)
    top[z0:z0+4]=v.sum(axis=1,dtype=np.float64)*2
    top_max[z0:z0+4]=v.max(axis=1)
    height_mass+=v.sum(axis=(0,2),dtype=np.float64)
    q=v>.041
    height_cells+=q.sum(axis=(0,2))
    for j in range(256):
        if not q[:,j,:].any(): continue
        zz,xx=np.nonzero(q[:,j,:]);height_xlo[j]=min(height_xlo[j],int(xx.min()+0));height_xhi[j]=max(height_xhi[j],int(xx.max()+0));height_zlo[j]=min(height_zlo[j],int(zz.min()+z0));height_zhi[j]=max(height_zhi[j],int(zz.max()+z0))
    for y in sl_y:slices[y][z0:z0+4]=v[:,(y-1)//2,:]
    del v,q

def panel(data, label, ax1, ax2, old_box=None, point=None, cutoff=None):
    # Domain x horizontal, vertical up. Any orientation follows the named axes.
    if cutoff is None:
        lum=1-np.exp(-.019*np.maximum(data,0))
        lum=np.clip(np.sqrt(lum),0,1)
    else:lum=(data>cutoff).astype(np.float32)
    im=Image.fromarray(np.uint8(np.rint(lum*245)),mode='L').convert('RGB').transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    im=im.resize((512,512),Image.Resampling.NEAREST)
    canvas=Image.new('RGB',(580,570),(15,20,28));canvas.paste(im,(45,24));d=ImageDraw.Draw(canvas)
    for coord in range(0,513,64):
        px=45+coord;py=24+(512-coord)
        d.line((px,24,px,536),fill=(48,66,82),width=1);d.line((45,py,557,py),fill=(48,66,82),width=1)
        if coord<512:d.text((px+2,536),str(coord),fill=(190,215,230))
        if 0<coord<=512:d.text((2,py-5),str(coord),fill=(190,215,230))
    if old_box:
        (lo1,hi1),(lo2,hi2)=old_box
        d.rectangle((45+lo1,24+512-hi2,45+hi1,24+512-lo2),outline=(255,183,0),width=2)
    if point:
        x,y=point;px=45+x;py=24+512-y;d.ellipse((px-4,py-4,px+4,py+4),outline=(30,235,235),width=2)
    d.text((45,3),label,fill=(230,239,247));d.text((230,540),f'{ax1} (m), {ax2} (m) up',fill=(190,215,230))
    return canvas

panels=[
 ('front-opacity.png',panel(front,'Raw front / integral along Z, Beer kappa .019','X','Y',((104,296),(160,352)),(221,295))),
 ('side-opacity.png',panel(side,'Raw side / integral along X, Beer kappa .019','Z','Y',((128,320),(160,352)),(207,295))),
 ('top-opacity.png',panel(top,'Raw top / integral along Y, Beer kappa .019','X','Z',((104,296),(128,320)),(221,207))),
 ('front-peak041.png',panel(front_max,'Raw peak q > .041, Z projection','X','Y',((104,296),(160,352)),(221,295),.041)),
 ('side-peak041.png',panel(side_max,'Raw peak q > .041, X projection','Z','Y',((128,320),(160,352)),(207,295),.041)),
]
for y,s in slices.items():panels.append((f'slice-y{y}.png',panel(s,f'Raw XZ slice Y={y} m, q > .041','X','Z',((104,296),(128,320)),(221,207),.041)))
for y in [260,280,300,320]:
    im=panel(slices[y],f'Raw XZ Y={y} m; candidate diagonal seam only','X','Z',((96,304),(96,304)),(225,197),.041)
    d=ImageDraw.Draw(im)
    for u,col in [(80,(255,70,70)),(120,(255,220,70))]:
        pts=[]
        for z in range(0,513,2):
            x=z+u
            if 0<=x<=512:pts.append((45+x,24+512-z))
        d.line(pts,fill=col,width=2)
    d.text((46,542),'red: X-Z=80; yellow: X-Z=120 (diagnostic, no mask)',fill=(245,210,190))
    panels.append((f'slice-y{y}-seam.png',im))
for name,im in panels:im.save(ROOT/name,optimize=True)
profiles=[]
for j in range(256):
    if height_cells[j]==0:continue
    profiles.append({'y_m':2*j+1,'mass_native_sum':float(height_mass[j]),'cells_q_gt041':int(height_cells[j]),'x_range_m':[int(2*height_xlo[j]+1),int(2*height_xhi[j]+1)],'z_range_m':[int(2*height_zlo[j]+1),int(2*height_zhi[j]+1)]})
out={'source_sha256':EXPECTED,'source_meta_sha256':sha(SOURCE/'cloud-03-256.json'),'projection_axes':'front XY along Z, side ZY along X, top XZ along Y; 2m native sample centres; axes annotated in metres','attenuation':'one native axis sum q*2m then 1-exp(-.019*tau); image luminance sqrt only for display','threshold':.041,'old_B_box_xyz_m':[[104,296],[160,352],[128,320]],'old_B_root':[225,265,197],'old_B_head':[221,295,207],'height_profile':profiles,'wall_s':time.perf_counter()-t0,'process_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'outputs':[x for x,_ in panels]}
(ROOT/'diagnostic.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'wall_s':out['wall_s'],'peak_MiB':out['process_highwater_bytes']/2**20,'outputs':len(panels)}))
