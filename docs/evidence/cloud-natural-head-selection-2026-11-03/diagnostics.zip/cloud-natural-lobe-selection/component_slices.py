#!/usr/bin/env python3
"""Measure the q>.041 4-connected native slice component around the proven B head."""
from pathlib import Path
from collections import deque
import hashlib, json, resource, time
import numpy as np
R=Path(__file__).resolve().parent; src=R.parent/'cloud-authored-master/cloud-03-256.density.r16f'
assert src.stat().st_size==256**3*2
hasher=hashlib.sha256()
with src.open('rb') as f:
    for block in iter(lambda:f.read(1<<20),b''):hasher.update(block)
h=hasher.hexdigest()
assert h=='42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9'
a=np.memmap(src,dtype='<f2',mode='r',shape=(256,256,256));out=[];t=time.perf_counter()
for y in [265,281,295,301,311,321,331]:
    v=np.asarray(a[:,(y-1)//2,:],dtype=np.float32)>.041
    sz,sx=(207-1)//2,(221-1)//2
    if not v[sz,sx]:
        near=[(abs(z-sz)+abs(x-sx),z,x) for z in range(max(0,sz-12),min(256,sz+13)) for x in range(max(0,sx-12),min(256,sx+13)) if v[z,x]]
        assert near;_,sz,sx=min(near)
    seen=np.zeros((256,256),bool);seen[sz,sx]=True;q=deque([(sz,sx)])
    mnx=mxx=sx;mnz=mxz=sz;n=0
    while q:
        z,x=q.popleft();n+=1;mnx=min(mnx,x);mxx=max(mxx,x);mnz=min(mnz,z);mxz=max(mxz,z)
        for zz,xx in ((z-1,x),(z+1,x),(z,x-1),(z,x+1)):
            if 0<=zz<256 and 0<=xx<256 and v[zz,xx] and not seen[zz,xx]:seen[zz,xx]=True;q.append((zz,xx))
    out.append({'y_m':y,'seed_xz_m':[2*sx+1,2*sz+1],'cells_4_connected_q_gt041':n,'bbox_x_m':[2*mnx+1,2*mxx+1],'bbox_z_m':[2*mnz+1,2*mxz+1]})
seams=[]
for y in [260,280,300,310,320,330]:
    v=np.asarray(a[:,(y-1)//2,:],dtype=np.float32)
    for u in [60,70,80,90,100]:
        x=2*np.arange(256)+1;z=x-u;valid=(z>=1)&(z<=511)&((z-1)%2==0);ix=np.flatnonzero(valid);iz=((z[valid]-1)//2).astype(int);vals=v[iz,ix];hits=vals>.041
        seams.append({'y_m':y,'plane_x_minus_z_m':u,'samples_q_gt041':int(hits.sum()),'peak_q':float(vals.max())})
o={'source_sha256':h,'scope':'2D native threshold components and diagnostic diagonal-plane samples; no selected field or mask','threshold':.041,'component_2d_connectivity':4,'seed_policy':'(221,207) XZ or closest q>.041 within 12 cells','components':out,'seams':seams,'wall_s':time.perf_counter()-t,'process_highwater_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(R/'component-slices.json').write_text(json.dumps(o,indent=2)+'\n')
