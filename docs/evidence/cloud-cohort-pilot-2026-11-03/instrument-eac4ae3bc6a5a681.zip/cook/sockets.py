from pathlib import Path
import numpy as np,json,hashlib,platform,resource
from scipy import ndimage
R=Path(__file__).resolve().parents[1];A=R/'assets';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rho=np.memmap(A/'cloud-03-256.density.r16f',dtype='<f2',mode='r',shape=(256,256,256));distance=np.memmap(A/'cloud-03-256-iso0p001.distance.r16f',dtype='<f2',mode='r',shape=(256,256,256));meta=json.loads((A/'cloud-03-256.json').read_text());quality=next(v for v in meta.values() if isinstance(v,dict) and 'support_bbox_min_zyx' in v);lo=np.maximum(0,np.array(quality['support_bbox_min_zyx'])-2);hi=np.minimum(255,np.array(quality['support_bbox_max_zyx'])+2);shape=tuple(hi-lo+1);threshold=.041;maxd=float(distance.max());endpoint=(maxd+8+2)/.3
smooth=lambda x:np.clip(x,0,1)**2*(3-2*np.clip(x,0,1));age210=endpoint*smooth((210-200)/160)
def mask_and_radius(exposure):
 mask=np.zeros(shape,bool)
 for z in range(shape[0]):
  rr=rho[z+lo[0],lo[1]:hi[1]+1,lo[2]:hi[2]+1].astype(np.float32);dd=distance[z+lo[0],lo[1]:hi[1]+1,lo[2]:hi[2]+1].astype(np.float32);mask[z]=rr*smooth((dd-exposure+8)/16)>=threshold
 edt=ndimage.distance_transform_edt(mask,sampling=2).astype(np.float32);return mask,edt
seedmask,seedr=mask_and_radius(0);parentmask,parentr=mask_and_radius(age210);desired=np.array([149,116,83]);zyx=desired[::-1]-lo
if np.any(zyx<0) or np.any(zyx>=shape) or parentr[tuple(zyx)]<18:
 zyx=np.array(np.unravel_index(np.argmax(parentr),shape));desired=(zyx+lo)[::-1]
anchor=(desired+.5)*2
# Candidate sites are actual nearby native density intersections with a sufficiently deep worst-age ball.
sites=[];used=set()
for j,(dx,dz,dy) in enumerate([(0,0,0),(-4,2,0),(4,-3,-1),(2,4,1),(-3,-4,-1),(5,1,1),(-5,-1,1),(0,5,-1)]):
 target=desired+np.array([dx,dy,dz]);best=None
 for z in range(max(0,int(target[2]-lo[0]-3)),min(shape[0],int(target[2]-lo[0]+4))):
  for y in range(max(0,int(target[1]-lo[1]-3)),min(shape[1],int(target[1]-lo[1]+4))):
   for x in range(max(0,int(target[0]-lo[2]-3)),min(shape[2],int(target[0]-lo[2]+4))):
    xyz=np.array([x+lo[2],y+lo[1],z+lo[0]]);key=tuple(xyz);r=float(parentr[z,y,x])-np.sqrt(3)*2-.002
    if r<17 or key in used:continue
    score=float(np.sum((xyz-target)**2))-.01*r
    if best is None or score<best[0]:best=(score,xyz,r,float(seedr[z,y,x])-np.sqrt(3)*2-.002)
 if best:
  _,xyz,r,r0=best;used.add(tuple(xyz));rr=float(rho[tuple(xyz[::-1])]);dd=float(distance[tuple(xyz[::-1])]);sites.append({'id':'socket-'+str(j),'index_xyz':xyz.tolist(),'local_xyz':((xyz+.5)*2).tolist(),'parent_radius_local_m':r,'seed_radius_local_m':r0,'raw_rho':rr,'d_local_m':dd,'q_ref':rr*float(smooth((dd+8)/16)),'q_worst_parent_210':rr*float(smooth((dd-age210+8)/16))})
# Conservative support radius: every positive trilinear footprint lies within one fullcell diagonal of some positive native centre.
support_radius=0.
for z in range(256):
 yy,xx=np.nonzero(rho[z]>0)
 if len(xx):support_radius=max(support_radius,float(np.sqrt(((xx+.5)*2-anchor[0])**2+((yy+.5)*2-anchor[1])**2+((z+.5)*2-anchor[2])**2).max()))
support_radius+=np.sqrt(3)*2
anchor_i=tuple((desired[::-1]-lo));anchor_r=float(seedr[anchor_i])-np.sqrt(3)*2-.002
# Independent native vertex witness for each certified parent ball, not an assumed raw-mask radius.
for site in sites:
 center=np.array(site['local_xyz']);rad=site['parent_radius_local_m'];index=np.array(site['index_xyz']);extent=int(np.ceil((rad+np.sqrt(3)*2)/2));minimum=1.
 for z in range(max(0,index[2]-extent),min(256,index[2]+extent+1)):
  for y in range(max(0,index[1]-extent),min(256,index[1]+extent+1)):
   xx=np.arange(max(0,index[0]-extent),min(256,index[0]+extent+1));within=((xx+.5)*2-center[0])**2+((y+.5)*2-center[1])**2+((z+.5)*2-center[2])**2<=(rad+np.sqrt(3)*2)**2
   if np.any(within):rr=rho[z,y,xx[within]].astype(np.float32);dd=distance[z,y,xx[within]].astype(np.float32);minimum=min(minimum,float((rr*smooth((dd-age210+8)/16)).min()))
 site['independent_vertex_min_q_parent_ball_plus_guard']=minimum;site['native_witness_pass']=minimum>=threshold-1e-7
assert sites and all(s['native_witness_pass'] for s in sites)
record={'schema':1,'rho_sha256':sha(A/'cloud-03-256.density.r16f'),'distance_sha256':sha(A/'cloud-03-256-iso0p001.distance.r16f'),'noise_sha256':sha(A/'channels-32.r16f'),'anchor_index_xyz':desired.tolist(),'anchor_local_xyz':anchor.tolist(),'anchor_radius_local_m':anchor_r,'support_radius_local_m':support_radius,'support_radius_unitworld_m':support_radius*4,'threshold_q_attach':.04,'native_threshold_with_numerical_margin':threshold,'parent_future_age_s':210,'parent_age_exposure_local_m':float(age210),'max_decoded_d_local_m':maxd,'zero_endpoint_local_m':endpoint,'native_pitch_local_m':2,'guard_subtraction_local_m':float(np.sqrt(3)*2+.002),'sites':sites,'proof':'EDT of actual rho*smoothstep(-8,8,d-Eage210)>=.041 mask minus one full native-cell diagonal plus.002localm strict/rounding margin; independent guard-vertex checks. For constant exposure,1/smoothstep is convex on positive support, so multilinear rho and distance preserve the vertex product lower bound. Weather-free healthy interval only; drying cancels certificate. GPU numerical precision separately observed.','tool':{'python':platform.python_version(),'numpy':np.__version__,'recipe_sha256':sha(Path(__file__)),'peak_process_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
(A/'sockets.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
