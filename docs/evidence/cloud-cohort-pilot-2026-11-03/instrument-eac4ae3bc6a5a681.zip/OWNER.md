Owner: cloud_lifecycle_diagnosis, bounded C1 pilot commission.
Purpose: one liquidCu cell with at most8finite fresh-rest cohorts, attached growth, renewal and spatial/age loss through shared optics. NoCb/ice/fullsky/defaultsource claim.
Storage: new owned disk≤512MiB; shared03density+distance64MiB and32³noise via immutable hardlinks. No negativeCbcopy or movie/sourcePDEcache. Retain exact recipe/state/certificate and chosen receipts until parent review/retention.
