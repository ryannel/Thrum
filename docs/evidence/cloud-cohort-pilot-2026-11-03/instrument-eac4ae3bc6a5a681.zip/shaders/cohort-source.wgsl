// One immutable presentation tuple. All optical consumers evaluate this same finite field.
struct CohortSource {centerB:vec4f,rotationK:vec4f,anchorA:vec4f,lossSlot:vec4f}
@group(0) @binding(18) var cohortDistance:texture_3d<f32>;
@group(0) @binding(19) var cohortNoise:texture_3d<f32>;
@group(0) @binding(20) var<storage,read> cohortStates:array<CohortSource>;
@group(0) @binding(21) var<storage,read> cohortExposure:array<f32>;
fn exposureValue(slot:u32,i:vec3u)->f32{let index=slot*4913u+(i.z*17u+i.y)*17u+i.x;return mix(cohortExposure[index],cohortExposure[39304u+index],p.lifecycle.y);}
fn materialExposure(slot:u32,a:vec3f)->f32{
 let p=clamp(a/32.,vec3f(0),vec3f(16));let lo=min(vec3u(floor(p)),vec3u(15));let f=p-vec3f(lo);
 let z0=mix(mix(exposureValue(slot,lo),exposureValue(slot,lo+vec3u(1,0,0)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,0)),exposureValue(slot,lo+vec3u(1,1,0)),f.x),f.y);
 let z1=mix(mix(exposureValue(slot,lo+vec3u(0,0,1)),exposureValue(slot,lo+vec3u(1,0,1)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,1)),exposureValue(slot,lo+vec3u(1,1,1)),f.x),f.y);return mix(z0,z1,f.z);
}
fn cohortQuery(x:vec3f,raw:bool)->f32{
 if(p.domain.w>.5){return 0.;}var amount=0.;
 for(var j=0u;j<8u;j++){
  let c=cohortStates[j];if(c.lossSlot.z<.5||c.anchorA.w<=0.){continue;}
  let b=c.centerB.w;let dy=(x.y-c.centerB.y)/b;let u=x.xz-c.centerB.xz-c.rotationK.zw*dy;let co=c.rotationK.x;let si=c.rotationK.y;
  let a=c.anchorA.xyz+vec3f((co*u.x+si*u.y)/b,dy,(-si*u.x+co*u.y)/b);
  if(any(a<vec3f(0))||any(a>vec3f(512))){continue;}
  let uv=a/512.;let rho=textureSampleLevel(densityTex,linearClamp,uv,0.).x;if(rho<=0.){continue;}
  var q=c.anchorA.w*rho;
  if(!raw){let d=textureSampleLevel(cohortDistance,linearClamp,uv,0.).x;let M=.3+.7*clamp(textureSampleLevel(cohortNoise,linearClamp,uv,0.).x,0.,1.);let e=materialExposure(u32(c.lossSlot.y),a);q*=smoothstep(-8.,8.,d-M*(c.lossSlot.x+e));}
  amount=max(amount,q);
 }
 return amount;
}
