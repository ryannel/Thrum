from pathlib import Path
import subprocess,re,json
R=Path(__file__).resolve().parents[1];out=R/'cook/assembled';out.mkdir(exist_ok=True);naga=Path.home()/'.cargo/bin/naga';optics=(R/'shaders/optics.wgsl').read_text().replace('// COHORT_SOURCE_INCLUDE',(R/'shaders/cohort-source.wgsl').read_text());paths=[]
for name in ['light','shadow','view','air']:
 p=out/(name+'.wgsl');p.write_text(optics+(R/'shaders'/f'{name}.wgsl').read_text());paths.append(str(p))
text=(R/'src/cohort-adapter.js').read_text();shader=re.search(r's\.codes\.optics\+`(.*?)`\);s\.write',text,re.S).group(1).replace('\\n','\n');p=out/'probe.wgsl';p.write_text(optics+shader);paths.append(str(p));result=subprocess.run([str(naga),'--bulk-validate',*paths],text=True,capture_output=True);print(result.stdout);print(result.stderr);(R/'cook/shader-validation.json').write_text(json.dumps({'naga':subprocess.check_output([str(naga),'--version'],text=True).strip(),'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'scope':'Offline WGSL/Naga parsing+validation for actual assembled5consumer modules; no browser pipeline/device admission'},indent=2)+'\n');raise SystemExit(result.returncode)
