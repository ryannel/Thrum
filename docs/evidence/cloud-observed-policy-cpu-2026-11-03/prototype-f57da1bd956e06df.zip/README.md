# Isolated observed-establishment CPU prototype

Owner: cloud_lifecycle_diagnosis. Opt-in `cu-held-predict-observe-v1` on copied reviewed1a CPU source/world and unchanged natural inputs. No renderer/GPU/browser/server/live-proof changes. **Unadopted: healthy wet replay still declines420/820; runtime cost gate and actual optical proof are unrun.** Original370s legacy rejection remains preserved beside the new result.

Configuration: construct SourceModel/TwoCellWorld with the existing `{templates,admissionMetadata}` and an additional `observedGrowth:{policyID:'cu-held-predict-observe-v1', nativeAssets, pins}`. `nativeAssets[body/crown-b]` is one verified immutable shared `{origin,span,dims,pitch,density:Uint16Array,distance:Uint16Array}` corpus,14,352,384B total. Do not clone or decode per model/cell. `pins` records input/admission/policy specification identity. No observedGrowth means exact legacy outputs. fresh() retains configuration but creates a new observer owner; no mode setter exists. Math/weather/clock/admission/reference numerical functions are unchanged.

New source helpers are pure CPU: `observed-policy.js` and `native-potential.js`. Selection simulates180 exact held-cause quarter steps, preserving conservative attachment, then calls the existing endpoint spatial helper at known transforms. A fixed qualified-coordinate numerical guard adds conservative padding; it is not a universal trajectory solver. Native occupied witnesses use a conservative native-cell-corner lower bound over the inverse-coordinate error box; sampled zeros cannot prove emptiness. Source at45s advances references with actual completed-interval controls before monitor/observation/cleanup. Cancellation keeps the reference to45; observation failure never deletes/moves/fades material.

Raw IDs belong to the model instance/cell/localID/birthTick. Metadata is raw. Explicit validated presentation epoch qualifies summary IDs; omitted epoch remains raw even through TwoCellWorld, explicit undefined is rejected. Clock supplies its own epoch unchanged. For full on-demand raw receipt use `model.observed.receipt()`; external captures bind the publication epoch, and direct tests supply a namespace. `interruption(reason,namespace)` emits an external journal record before reset/seek discards the old instance. The observer has no wall clock or second epoch.

Functional commands from this directory (serial224MiB early/256MiB hard process-tree guard):

```
python3 run-guard.py legacy-source8 node tests/source/run.mjs
python3 run-guard.py legacy-world12 node tests/world/contracts.mjs
python3 run-guard.py legacy-world-native node tests/world/native.mjs
python3 run-guard.py legacy-diff node tests/observed/legacy-diff.mjs
python3 run-guard.py observed-contracts node tests/observed/contracts.mjs
python3 run-guard.py observed-replays node --expose-gc tests/observed/replays.mjs
python3 run-guard.py observed-native node tests/observed/native.mjs
```

Copied source/world suites use legacy asset fixtures to preserve their original assertions. The4800-step/301-checkpoint default differential uses the new natural corpus in both frozen1a and candidate and compares metadata/events/decisions/published F32 arrays exactly. The six new-vs-legacy replays also use natural inputs; detailed per-site declines, birth root q/velocity/fresh K, terminal retirement and observations are in results. They are functional runs, not cost measurements. Two harness-only development failures (missing copied test oracle; shadowed parent variable) are retained under attempts and corrected without changing source physics.

Current result: wet1200 has13BODY+21B births,20exposed+1pending,2held-endpoint declines at420/820 (all8sites fail spatial certification). Legacy has13BODY+19B and4failures. The new370 birth is actually exposed at415 with the exact current-t0370 ID7 retained. This improves that instance, not continuous renewal/art acceptance. Off150/on200 has no failed births and explicit weather-cancelled observations; clear/initial-off recovery works. Default dry reaches actual zero; weather/parent failures remain separate. Full six-case outcomes are in results/replays.json. Native source/independent query checks cover1248points/493positive, maxdifference6.25e-17;384lower-witness comparisons pass. Finite CPU checks do not qualify GPU interpolation or appearance.

Bounded work follows the design: <=3060 forecast pose steps/opportunity,65,280 forecast BVH nodes; actual observation<=8160nodes/864native queries; <=8CPU-only old references, no E arrays or render contributors. Geometry copies omit prior certificates to avoid recursive history. Decline details and latest receipt are bounded rather than embedded in every event. Existing controls943,296B/cell and shared native buffer are charged. Runtime/preparation GC/transient objects are not yet cost-qualified. No async source transaction is implemented. The <=4ms maximum whole synchronous step gate must be measured under root's quiet grant; failing it blocks runtime enablement, without wall-time-dependent births or a hidden policy fallback.
