# First cost gate — FAIL

Quiet grant from root; command `python3 tmp/cloud-observed-policy-proof/run-guard.py observed-cost node --expose-gc tests/observed/cost.mjs`. Exact evaluator SHA b4d2c2b54f523c2451714c2293190d70e644efacfac86bb5371e799d8e9895fe, frozen source pins f57da1bd956e06df5e936b67e05b6358d20b0477a8d8d6d7a86eda8adbd3098f. Cost receipt/arrays pinned in COST-HANDOFF.json. Functional README described this gate before execution; this is its later result.

| Workload | Legacy max ms | Observed max ms | Observed p99 ms | New4ms gate |
|---|---:|---:|---:|---|
| Single wet1200 |3.220709|4.766750|.224875|FAIL |
| Single dry900 |1.577000|5.234000|.306584|FAIL |
| Two wet1200 |2.746750|8.634250|.386375|FAIL |

All new maxima occur at source420s; the two-cell820s step also takes7.443750ms. These coincide with all-eight-site forecast declines. This alignment motivates profiling/reuse; it does not independently attribute every microsecond or remove GC. First/cold and later/warm source durations are retained.648 GC entries, maximum2.059166ms, are retained but cannot be assigned exactly to a step because the unchanged evaluator does not retain each step's wall-start stamp. Typical times do not override maxima. Process-tree sampled peak177,045,504B passes224MiB early/256MiB hard; this is not an allocation barrier or GPU accounting.

Evaluator/threshold/source were not changed; no repeats or outlier deletion. Legacy/new cases use the same natural inputs. The result blocks interactive adoption of this exact candidate. Any future exact work reduction is a separate candidate and must preserve all semantics/counters/reasons and use this retained evaluator/gate; no deferred births/clock or async transaction is authorized by this failure.
