from pathlib import Path
import subprocess,json,sys,resource,math,time,hashlib
R=Path(__file__).resolve().parent
names=[]
def launch(n,workload,mode,profile=None):
 parent=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin'else 1024);reserve=math.ceil(parent/1024**2+4)*1024**2;name=f'{n}-{workload}-{mode}'+('-'+profile if profile else'');args={'copies':n,'workload':workload,'mode':mode,'profile':profile,'name':name,'parentReserveBytes':reserve};start=time.perf_counter()
 with (R/'results'/f'{name}.log').open('w')as out:p=subprocess.run(['node','--expose-gc',str(R/'worker.mjs'),json.dumps(args)],stdout=out,stderr=subprocess.STDOUT,timeout=90)
 names.append({'name':name,'exitCode':p.returncode,'orchestratorWallSeconds':time.perf_counter()-start});print(name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError((R/'results'/f'{name}.log').read_text())
for n in[1,2,16,64]:
 for workload in['steady','birth','dry']:
  for mode in['ticks','present']:launch(n,workload,mode)
for profile in['pattern','cpu','allocation']:launch(16,'steady','present',profile)
(R/'run-index.json').write_text(json.dumps({'scope':'sequentialisolatedCPUbenchmarks,noGPU/browser','runs':names},indent=2)+'\n')
