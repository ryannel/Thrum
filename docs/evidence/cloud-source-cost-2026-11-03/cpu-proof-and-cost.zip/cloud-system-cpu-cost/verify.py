"""Validate retained evidence and dependency pins; never executes source ticks."""
from pathlib import Path
import hashlib,json,math
R=Path(__file__).resolve().parent;P=R.parent/'cloud-system-proof'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
h=json.loads((R/'HANDOFF.json').read_text());a=json.loads((R/'analysis.json').read_text())
for p,v in h['files'].items():assert sha(R/p)==v['sha256'],p
for p,v in h['inputs'].items():assert sha(P/p)==v,p
for p,v in h['sourceHashes'].items():assert sha(P/'src/source'/p)==v,p
assert len(a['runs'])==27
primary=[r for r in a['runs']if not r['diagnostic']];assert len(primary)==24
assert len([r for r in primary if r['status']=='complete'])==18
for r in a['runs']:
 raw=json.loads((R/'results'/(r['name']+'.json')).read_text());assert raw['sourceHashes']==h['sourceHashes']
 assert raw['inputIndexSHA256']==h['inputs']['assets/input-index.json']
 assert r['reservedPairPeakBytes']<h['hardCombinedMemoryBytes']
 assert r['memory']['persistentLogicalCPUControlsBytes']==r['constructedCopies']*943296
 if r['status']=='stopped':assert r['copies']==64 and r['arithmeticMultipliers'] is None and r['failure']['message']=='EARLY_MEMORY_LIMIT';continue
 n=r['copies'];ticks={'steady':40,'birth':120,'dry':161}[r['workload']];assert r['tick']['count']==n*ticks
 assert r['counterDelta']['sourceSteps']==n*ticks
 assert r['counterDelta']['controlPointUpdates']==(3404709*n if r['workload']=='dry'else 0)
 if r['mode']=='present':
  assert r['changedTickPublication']['count']==n*ticks and r['sameTickPublication']['count']==14*n*ticks
  m=r['arithmeticMultipliers'];t=r['tick']['meanMs'];f=r['changedTickPublication']['meanMs'];s=r['sameTickPublication']['meanMs']
  assert math.isclose(m['oneXCPUmsPerWallSecond'],n*(4*t+4*f+56*s),rel_tol=1e-12)
  assert math.isclose(m['sixteenXCPUmsPerWallSecond'],n*(64*t+60*f),rel_tol=1e-12)
assert a['pattern']['movingSameTickTupleIsNew'] and a['pattern']['identicalRequestTupleReused'] and a['pattern']['controlArrayBuffersReused']
assert a['pattern']['probeAdditionalControlBytes']==314432
assert max(r['reservedPairPeakBytes']for r in a['runs'])==h['maxRecordedCombinedBytes']
print(json.dumps({'pass':True,'runs':27,'primaryComplete':18,'memoryStopped':6,'diagnostics':3,'sourceAndMetadataPinsUnchanged':True,'payloadPinsChecked':len(h['files']),'maxRecordedPairMiB':h['maxRecordedCombinedBytes']/2**20}))
