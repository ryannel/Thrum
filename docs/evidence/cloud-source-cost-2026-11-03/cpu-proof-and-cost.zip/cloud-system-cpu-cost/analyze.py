"""Summarize retained runs; no source execution or asset volume reads."""
from pathlib import Path
from collections import defaultdict
import json,hashlib
R=Path(__file__).resolve().parent
runs=[]
for p in sorted((R/'results').glob('*.json')):
 if p.name.endswith(('.cpu.json','.allocation.json')):continue
 r=json.loads(p.read_text());m=r['measurement'];mem=r['memory'];rmax=max(mem['maxSampledWorkerRSSBytes'],mem['maxReportedWorkerRSSBytes'])
 runs.append({'name':p.stem,'status':r['status'],'diagnostic':r['args']['profile'],'copies':r['args']['copies'],'workload':r['args']['workload'],'mode':r['args']['mode'],'constructedCopies':r['constructedCopies'],'failure':r['failure'],'sourceWindow':[m['sourceStart'],m['sourceEnd']],'completedGroupTicks':m['completedGroupTicks'],'tick':m['tick'],'changedTickPublication':m['changedTickPresentation'],'sameTickPublication':m['sameTickMovingAlphaPresentation'],'wallMs':m['wallMs'],'processCpuMicroseconds':m.get('cpu'),'counterDelta':m['counterDelta'],'gcCount':r['gc']['measuredEventCount'],'gcDurationMs':r['gc']['measuredDurationMs'],'maxWorkerRSSBytes':rmax,'reservedPairPeakBytes':rmax+mem['parentReserveBytes'],'memory':mem,'arithmeticMultipliers':r['multipliers'] if r['validForExtrapolation'] else None})
def key(f):return (f.get('url',''),f.get('functionName',''),f.get('lineNumber',-1)+1)
a=json.loads((R/'results/16-steady-present-cpu.cpu.json').read_text());nodes={n['id']:n for n in a['nodes']};cpu=defaultdict(lambda:[0,0])
for i,nid in enumerate(a['samples']):
 k=key(nodes[nid]['callFrame']);cpu[k][0]+=1;cpu[k][1]+=a.get('timeDeltas',[0]*len(a['samples']))[i]
a=json.loads((R/'results/16-steady-present-allocation.allocation.json').read_text());alloc=defaultdict(int)
def walk(n):
 alloc[key(n['callFrame'])]+=n['selfSize']
 for c in n.get('children',[]):walk(c)
walk(a['head'])
def rows(d):return [{'url':k[0],'function':k[1],'line':k[2],'value':v}for k,v in sorted(d.items(),key=lambda x:x[1][0]if isinstance(x[1],list)else x[1],reverse=True)]
result={'scope':'CPU kernel costs; stopped runs excluded from multipliers. No GPU/fullsky/M2 admission. Raw profiles diagnostic only.','host':json.loads((R/'results/16-steady-present.json').read_text())['host'],'runs':runs,'cpuProfile':{'samples':sum(v[0]for v in cpu.values()),'rows':rows(cpu)},'allocationProfile':{'sampledEstimatedBytesBySelfSize':sum(alloc.values()),'sampleSizesSum':sum(s['size']for s in a['samples']),'rows':rows(alloc)},'pattern':json.loads((R/'results/16-steady-present-pattern.json').read_text())['pattern']}
(R/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runs':len(runs),'primaryComplete':sum(r['status']=='complete'and not r['diagnostic']for r in runs),'primaryStopped':sum(r['status']=='stopped'and not r['diagnostic']for r in runs),'maxReservedPairMiB':max(r['reservedPairPeakBytes']for r in runs)/2**20,'cpuTop':result['cpuProfile']['rows'][:7],'allocationTop':result['allocationProfile']['rows'][:7]},indent=2))
