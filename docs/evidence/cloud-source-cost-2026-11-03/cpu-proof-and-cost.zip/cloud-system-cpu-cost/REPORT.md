# Frozen Cu source CPU kernel cost

Owner: cloud_lifecycle_diagnosis. This is a bounded CPU study of the current quarter-second source kernel, not a combined sky, GPU benchmark, frame-budget pass, or M2 admission. Source and input hashes are in `HANDOFF.json`; raw outcomes, profiles and `analysis.json` are retained. No source implementation changed.

Node v24.16.0, darwin arm64, reported Apple M3 Max / 14 logical CPUs. Root acknowledged browser startup complete and paused before timing; held GPU observer checks could contend. The later browser-recording announcement arrived after these runs finished. Wall and process CPU are separate. There is one fresh process per case, one run per configuration, no confidence interval or cross-device claim. Short wet windows and timer/JIT/GC effects explain why per-copy means do not scale monotonically.

## Method and complete outcomes

Shared frozen JSON metadata only; no native density/distance volume reads. Isolated copies deliberately repeat IDs and weather cells. Tick-only calls `model.step()` without publication. Normal mode adds 15 changing-alpha `clock.tuple()` calls per source tick, split into first changed-tick publication and 14 same-tick presentations. Source ticks are 4 Hz; window/setup/warmup are pinned in `PREFLIGHT.md`. Explicit GC occurs before, never within, measured phases. Timers are unadjusted; RSS guards/yields and result bookkeeping occur outside timed calls. Process CPU and wall include that harness work and V8 background work. GC observations are runtime instrumentation, not a complete allocation ledger.

Mean milliseconds per copy/call:

| Copies | Window | Tick only | Tick with publication | First publication | Same-tick publication |
|---:|---|---:|---:|---:|---:|
| 1 | wet steady | .05369 | .06561 | .04179 | .04068 |
| 2 | wet steady | .05632 | .04909 | .04061 | .03611 |
| 16 | wet steady | .03659 | .04587 | .03468 | .03473 |
| 1 | wet birth | .06877 | .07073 | .05458 | .03413 |
| 2 | wet birth | .06160 | .06506 | .05248 | .03395 |
| 16 | wet birth | .05030 | .05815 | .04375 | .03199 |
| 1 | drying/birth | .46611 | .45337 | .61516 | .03291 |
| 2 | drying/birth | .41500 | .49865 | .67480 | .03767 |
| 16 | drying/birth | .40730 | .40686 | .59393 | .02859 |

For 16 copies, normal drying tick p50/p95/p99/max = .4335/.4972/.6871/1.8995 ms; first publication = .5647/.7078/.7624/1.4233 ms; same-tick publication = .02579/.03704/.05092/.90417 ms. Complete distributions and worst-call source times remain in each JSON. Counts are producer counters, not independently counted machine instructions:

| 16-copy normal window | Steps | Admission-node tests | Updated E nodes | Births / failed | E publications |
|---|---:|---:|---:|---:|---:|
| steady 230–240 s | 640 | 0 | 0 | 0 / 0 | 0 |
| birth 195–225 s | 1,920 | 3,152 | 0 | 32 / 0 | 32 |
| dry 469.75–510 s | 2,576 | 1,296 | 54,475,344 | 16 / 16 | 2,576 |

The drying window includes B births at 470 s and BODY rejection at 500 s under the existing weather/lease policy. Those source failures are workload events, not harness errors.

## Memory and stopped 64-copy runs

Each copy owns exactly 943,296 logical control bytes: two Float64 state banks (628,864 B) and two Float32 publication banks (314,432 B), four distinct buffers. This is .900 / 1.799 / 14.394 / 57.574 MiB at 1/2/16/64 copies. State objects, bounded events/reference descriptors, shared metadata, transient arrays and runtime overhead are additional. Every tick also copies the eight Float64 slot grids (314,432 B/copy) even in clear weather; `controlPointUpdates` counts weather integration, not these copies.

Hypothetical GPU accounting is separate: 314,432 control B + 768 pose B per copy, plus one shared 64 B domain table. No GPU allocation/upload/driver cost was measured. At 16 copies that estimate is 4.810 MiB plus the shared table. A control revision could require 314,432 upload B/copy; whether a consumer skips zeros/unchanged revisions is outside this kernel study.

The Python-parent reserve was 25 MiB. All six 64-copy cases stopped at the early 224 MiB combined guard; none completed. Tick-birth reached a partial measured phase, and all other 64 outcomes stopped during setup/warmup. Exclude every 64 result from scaling estimates. Process exit 0 means the adverse JSON was saved, not that the case passed. Partial `multipliers` in raw stopped files are invalid; `analysis.json` sets them null.

| 64-copy case | Last observed stage | Peak worker + reserve, MiB |
|---|---|---:|
| steady ticks | setup, 60 constructed | 225.00 |
| steady normal | warmup, all 64 constructed | 241.28 |
| birth ticks | partial measured ticks | 224.09 |
| birth normal | setup, 64th incomplete | 225.61 |
| dry ticks | setup, 50th incomplete | 230.67 |
| dry normal | setup, 49th incomplete | 224.12 |

Early limits are sampled, not allocation barriers. The 300-call presentation warmup has no inner guard, so steady-normal overshot early224 before the next check. Some runtime high-water marks also exceeded sampled RSS. Maximum recorded pair high-water was 241.28125 MiB, below hard256. Allocation profiling separately recorded 224.31 MiB combined after profiler shutdown despite a lower sampled peak. These are guard limitations, retained rather than hidden; do not reuse this harness as a hard allocator quota.

16-copy normal measured phase:

| Window | Wall ms | User+system CPU ms | GC events / observed ms | Worker peak MiB |
|---|---:|---:|---:|---:|
| steady | 377.98 | 434.15 | 87 / 13.35 | 125.16 |
| birth | 1,101.17 | 1,222.34 | 195 / 35.44 | 182.50 |
| dry | 3,678.26 | 3,855.76 | 224 / 35.93 | 163.42 |

RSS, heap, external and ArrayBuffer counts overlap and must not be summed as unique bytes. Peaks include setup as well as measurement. No forced GC was used to keep a case under the limit.

## Arithmetic cadence estimates

For N copies, 1× estimate is N(4 tick + 4 first publication + 56 same-tick publication) ms/wall-second. At 16× assume 64 ticks and 60 changed-source publications/s: N(64 tick + 60 first publication). These are sums of isolated API-call means, not measured playback or 60 Hz scheduling guarantees.

| Copies | Window | 1× CPU ms/s | 16× CPU ms/s |
|---:|---|---:|---:|
| 1 | steady / birth / dry | 2.71 / 2.41 / 6.12 | 6.71 / 7.80 / 65.93 |
| 2 | steady / birth / dry | 4.76 / 4.74 / 13.61 | 11.16 / 14.62 / 144.80 |
| 16 | steady / birth / dry | 36.28 / 35.18 / 89.67 | 80.26 / 101.54 / 986.80 |

The 16-copy accelerated drying estimate approaches one CPU-second per wall-second before any renderer/driver/UI work. It is not evidence that such a sky is valid or schedulable. The stopped 64-copy cases give no supported 64-copy cadence estimate.

## Allocation findings and next change

An exact sampled identity check at six active parts found 75 reachable plain objects in each tuple and 57 new reachable objects for a changed-alpha tuple. An identical request returns its cached tuple. The two publication buffers are reused across same-tick tuples. `snapshotForProbe` adds two distinct control buffers (314,432 B); that observer is absent from ordinary frame work. Reachable counts do not include temporary math allocations.

A separate 100 µs CPU profile (2,352 samples) identifies `freeze`, `fieldColumns`/its matrix-building callbacks, `bounds`, and `rotated` as major wet publication work. A separate 32 KiB statistical allocation profile estimates 1.521 GB allocated over the diagnostic window (640 ticks / 9,600 publications), not retained memory or exact bytes. Aggregated self estimates attribute 428.9 MB to `fieldColumns`, 385.7 MB to `bounds`, and substantial further native map/iterator allocation. Raw samples and aggregation are retained; profiler overhead is excluded from primary timing. A full dry CPU profile was not run, so dry attribution below combines the first/same contrast with source inspection, not a sampled proof of percentage.

First priority is a small exact publication change: in `model.js:73`, hoist per-slot active/ID/terminal-zero selection outside the 4,913-element conversion loop, then bulk-convert/copy or fill each selected range. It currently repeats `terminalZero`/`ageE` inside the inner loop although they are slot constants. Dry first publication costs .565 ms/copy more than another tuple in the same tick; publication exceeds source integration at 16×. Preserve both retained snapshots, same-ID selection, zero flags, revision semantics and exact F32 bytes. Compare old/new publication buffers bitwise on retirement, birth, reused slot and dry-front cases before performance measurement. Do not change dt, E-grid pitch or weather semantics to achieve this saving.

Next, remove redundant wet bounds work: compute the exact numerical dual of fixed stored Q once at admission and derive an affine AABB from row extrema rather than forwarding eight corners through repeated `fieldColumns`. For A = b Qdual + K (rowY Qdual), bounds are C_i + sum_j min/max(A_ij(lo_j-root_j), A_ij(hi_j-root_j)). Use the actual stored Q transpose contract, not assumed perfect orthogonality; retain full positive-tail bounds and padding. This preserves the published descriptor API and requires no GPU change. Packed prior/current pose banks are a later option, since they change asynchronous ownership/capture lifetime and should not replace frozen descriptor objects with silently reused mutable views.

After these local changes, remeasure the same cases, including the adverse 64-copy outcomes. A later source-integration profile may justify optimizing the active 17³ weather loop; its .407 ms/copy/tick drying cost remains. No optimization was implemented here.

## Reproduction and retention

`python3 analyze.py` regenerates the aggregate without executing the source. `python3 run.py` runs the bounded 27-process matrix using `node --expose-gc`; it overwrites this folder's results. Preserve these outcomes first, or duplicate this small folder to a sibling of `cloud-system-proof` and run there. Only the proof source and pinned metadata JSON are required; no master volumes, browser or GPU. `PREFLIGHT.md` predates the runs. `HANDOFF.json` pins source, metadata and every retained file. The 2.8 MiB raw package was within the planned 8 MiB disk bound; final size is recorded in handoff. Scratch retention: keep until parent adopts this CPU evidence or explicitly replaces it, then remove disposable profiler detail under parent direction; do not touch other labs.
