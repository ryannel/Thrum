from pathlib import Path
import subprocess,json,sys,resource,math,time,datetime
R=Path(__file__).resolve().parent
runs=[]
def launch(n,workload,mode,variant,rep):
 parent=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin'else 1024)
 reserve=math.ceil(parent/1024**2+4)*1024**2
 name=f'{variant}-{n}-{workload}-{mode}-r{rep}'
 args={'copies':n,'workload':workload,'mode':mode,'profile':None,'variant':variant,'name':name,'parentReserveBytes':reserve}
 start=time.perf_counter();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(R/'results'/f'{name}.log').open('w')as out:
  p=subprocess.run(['node','--expose-gc',str(R/'worker.mjs'),json.dumps(args)],stdout=out,stderr=subprocess.STDOUT,timeout=90)
 result=json.loads((R/'results'/f'{name}.json').read_text())if p.returncode==0 else None
 runs.append({'name':name,'exitCode':p.returncode,'status':result['status']if result else'error','startedUTC':utc,'orchestratorWallSeconds':time.perf_counter()-start})
 (R/'run-index.json').write_text(json.dumps({'scope':'Matched isolated CPU kernels only; noGPU/browser/fullsky','runs':runs},indent=2)+'\n')
 print(name,p.returncode,runs[-1]['status'],flush=True)
 if p.returncode:raise RuntimeError((R/'results'/f'{name}.log').read_text())
case=0
for n in[1,2,16,64]:
 for workload in['steady','birth','dry']:
  for mode in['ticks','present']:
   for rep in range(1,(2 if mode=='present'and n!=64 else 1)+1):
    order=['baseline','publication']if(case+rep)%2 else['publication','baseline']
    for variant in order:launch(n,workload,mode,variant,rep)
   case+=1
