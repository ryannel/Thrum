import assert from 'node:assert/strict';import {writeFile} from 'node:fs/promises';
import {SourceModel as A}from '../src/source/model.js';import {SourceModel as B}from '../frame/src/source/model.js';
import {configuration,nativeAssets}from '../tests/source/fixtures.mjs';
import {evaluatePoint}from '../src/source/reference.js';import {packParts}from '../src/render/held-oracle.js';import {forward}from '../src/source/math.js';
const config=await configuration(),{assets,noise}=await nativeAssets(),bytes=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength);let points=0,positive=0;
for(const t of[94.13,210.13,480.13,590.13]){
 const a=new A(config),b=new B(config),end=Math.ceil(t/.25)*.25;while(a.time<end){a.step();b.step();}const x=a.presentation(t+.25),y=b.presentation(t+.25);assert.deepEqual(x.bounds,y.bounds);assert.ok(bytes(packParts(x.parts)).equals(bytes(packParts(y.parts))));
 for(const p of x.parts)for(let i=0;i<100;i++){
  const asset=assets[p.templateID],local=i<20?p.root.map((v,k)=>v+10*Math.sin(i*11+k*7)):asset.origin.map((v,k)=>v+asset.span[k]*((i*31+k*17)%101)/101),world=forward(p,local),u=evaluatePoint(x,world,assets,noise),v=evaluatePoint(y,world,assets,noise);assert.ok(Object.is(u,v));if(u>0)positive++;assert.equal(evaluatePoint(x,world,assets,noise,{zero:true}),evaluatePoint(y,world,assets,noise,{zero:true}));assert.equal(evaluatePoint(x,world,assets,noise,{raw:true}),evaluatePoint(y,world,assets,noise,{raw:true}));points++;
 }
}
assert.ok(positive>50);const result={pass:true,points,positive,nativeCoefficientQExact:true,rawAndZeroExact:true,packedPoseF32BytesExact:true,worldBoundsExact:true,scope:'Finite CPU native point/operator and pose-buffer differential, no actual GPU or continuous-domain certificate'};await writeFile(new URL('frame-field-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
