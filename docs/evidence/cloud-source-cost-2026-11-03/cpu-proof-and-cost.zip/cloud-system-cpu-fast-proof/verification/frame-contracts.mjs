import assert from 'node:assert/strict';import {writeFile} from 'node:fs/promises';
import * as old from '../src/source/math.js';import * as fast from '../frame/src/source/math.js';
import {SourceModel,DEFAULT_CONTROLS} from '../frame/src/source/model.js';
import {configuration} from '../tests/source/fixtures.mjs';
const config=await configuration(),I=()=>[[1,0,0],[0,1,0],[0,0,1]],pose=Q=>({ID:1,Qcolumns:Q,C:[5,1239.2,-13],root:[299,233,167],K:[.39,0,-.27],u:[0,0,0],b:4}),template=config.admissionMetadata.templates.body;
let points=0,boxes=0;
function probe(p){for(let i=0;i<20;i++){const a=p.root.map((v,k)=>v+37*Math.sin(i*11+k*7));assert.deepEqual(fast.forward(p,a),old.forward(p,a));assert.deepEqual(fast.matrix(p),old.matrix(p));points++;}assert.deepEqual(fast.bounds(p,template),old.bounds(p,template));boxes++;}
for(let i=0;i<25;i++){
 const theta=i*.19,c=Math.cos(theta),s=Math.sin(theta),Q=[[c+1e-7,s,0],[-s,c,0],[0,0,1]],p=pose(Q);probe(p);
 // Arbitrary mutable Q is never registered; in-place mutations must remain visible.
 p.Qcolumns[0][0]+=1e-6;probe(p);const arbitrary=fast.cloneGeometry(p);assert.notEqual(arbitrary.Qcolumns,p.Qcolumns);probe(arbitrary);
 fast.registerBirthFrame(p);assert.ok(Object.isFrozen(p.Qcolumns)&&p.Qcolumns.every(Object.isFrozen));assert.throws(()=>p.Qcolumns[0].splice(0,1,123),TypeError);probe(p);
 const copied=fast.cloneGeometry(p);assert.equal(copied.Qcolumns,p.Qcolumns);probe(copied);
 const target=pose(I());assert.ok(fast.copyBirthFrame(p,target));assert.equal(target.Qcolumns,p.Qcolumns);probe(target);
 const frozenQ=Object.freeze(p.Qcolumns.map(v=>Object.freeze([...v]))),descriptor=Object.freeze({...p,Qcolumns:frozenQ});assert.notEqual(descriptor.Qcolumns,p.Qcolumns);assert.deepEqual(fast.boundsForFrozenDescriptor(descriptor,template,p),old.bounds(descriptor,template));boxes++;
 const wrong=Object.freeze({...descriptor,Qcolumns:Object.freeze(frozenQ.map((v,j)=>Object.freeze(v.map((n,k)=>j===0&&k===0?n+1e-8:n))))});assert.throws(()=>fast.boundsForFrozenDescriptor(wrong,template,p),/changed Qcolumns/);
 p.Qcolumns=I();p.Qcolumns[0][0]+=2e-6;probe(p);const noFrame=pose(I());assert.equal(fast.copyBirthFrame(p,noFrame),false);assert.deepEqual(fast.boundsForFrozenDescriptor(descriptor,template,p),old.bounds(descriptor,template));boxes++;
}
const model=new SourceModel(config,{...DEFAULT_CONTROLS,dryGain:0});while(model.time<220)model.step();for(const p of model.current.filter(p=>p.active)){assert.ok(Object.isFrozen(p.Qcolumns)&&p.Qcolumns.every(Object.isFrozen));const prev=model.previous[p.slot];if(prev.ID===p.ID)assert.equal(prev.Qcolumns,p.Qcolumns);probe(p);}
if(model.referenceLease)for(const p of model.referenceLease.parts){assert.ok(Object.isFrozen(p.Qcolumns));probe(p);const endpoint=model.endpoint(p,45);assert.equal(endpoint.Qcolumns,p.Qcolumns);probe(endpoint);}
const fresh=model.fresh(),first=fresh.current.find(p=>p.active);assert.equal(first.ID,1);assert.notEqual(first.Qcolumns,model.current.find(p=>p.active).Qcolumns);probe(first);
const result={pass:true,points,boxes,arbitraryMutableFallback:true,registeredQDeeplyFrozen:true,wholeQReplacementFallback:true,clonesShareOnlyImmutableBirthQ:true,newModelIDRestartDoesNotReuseFrame:true,separatelyClonedFrozenPublicQ:true,mismatchedDescriptorRejected:true,referenceAndEndpointFrames:true,sameEightCornerArithmetic:true,scope:'CPU exact numeric/lifetime checks; no GPU/art/frame admission'};await writeFile(new URL('frame-contracts-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
