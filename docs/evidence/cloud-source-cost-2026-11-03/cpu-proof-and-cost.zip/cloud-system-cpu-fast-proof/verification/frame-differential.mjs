import {writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {SourceModel as Baseline,DEFAULT_CONTROLS} from '../src/source/model.js';
import {SourceModel as Candidate} from '../frame/src/source/model.js';
import {SourceClock} from '../src/source/clock.js';
import {snapshotForProbe} from '../src/source/reference.js';
import {configuration} from '../tests/source/fixtures.mjs';
const config=await configuration(),bytes=a=>Buffer.from(a.buffer,a.byteOffset,a.byteLength),sameArray=(a,b)=>assert.ok(bytes(a).equals(bytes(b)),'Array bytes differ');
let tuples=0,steps=0,births=0,retires=0,reuses=0,maxRSS=0;
const limit=224*1024**2;function guard(){const rss=process.memoryUsage.rss();maxRSS=Math.max(maxRSS,rss);if(rss>=limit)writeFileSync(new URL('frame-attempt2-failure.json',import.meta.url),JSON.stringify({rss,maxRSS,steps,tuples,hard256MiBBreached:rss>=256*1024**2}));assert.ok(rss<limit,'Differential early224MiB guard');}
function compareTuple(a,b){const {exposurePrevious:ap,exposureCurrent:ac,...aa}=a,{exposurePrevious:bp,exposureCurrent:bc,...bb}=b;assert.deepEqual(aa,bb);sameArray(ap,bp);sameArray(ac,bc);tuples++;}
// Exhaustive selector truth table with actual terminal test and F64→F32 edge values.
const a=new Baseline(config),b=new Candidate(config);let selectors=0;
for(const activeA of[false,true])for(const activeB of[false,true])for(const same of[false,true])for(const terminal of[false,true])for(const values of['zero','sparse','underflow']){
 for(const s of[a,b]){for(let slot=0;slot<8;slot++){const p=s.previous[slot],c=s.current[slot];p.active=activeA;c.active=activeB;p.ID=100+slot;c.ID=same?p.ID:200+slot;p.Aseed=c.Aseed=1;p.minE=terminal?1e6:0;p.maxE=0;c.minE=c.maxE=0;p.E.fill(0);c.E.fill(0);if(values!=='zero'){const v=values==='underflow'?[Number.MIN_VALUE,1e-50,2**-150]:[.1,1/3,2**-149,16777217,1e6];for(let i=0;i<v.length;i++){p.E[(slot*157+i*991)%4913]=v[i];c.E[(slot*397+i*811)%4913]=v[v.length-i-1];}}}s.exposureRevision++;s.prepareExposure();}
 sameArray(a.exposurePrevious,b.exposurePrevious);sameArray(a.exposureCurrent,b.exposureCurrent);assert.equal(a.exposureAllZero,b.exposureAllZero);assert.equal(a.stats.exposurePublications,b.stats.exposurePublications);selectors++;
}
const prior=b.exposurePrevious,current=b.exposureCurrent,rev=b.exposureRevision,count=b.stats.exposurePublications;b.prepareExposure();assert.equal(prior,b.exposurePrevious);assert.equal(current,b.exposureCurrent);assert.equal(rev,b.exposureRevision);assert.equal(count,b.stats.exposurePublications);
const fixtures=[
 {name:'wet1200',end:1200,initial:{dryGain:0},commands:[]},
 {name:'defaultDry900',end:900,initial:{},commands:[]},
 {name:'off150on200',end:600,initial:{dryGain:0},commands:[[150,{moist:false}],[200,{moist:true}]]},
 {name:'clearRecovery750',end:750,initial:{dryGain:0},commands:[[80,{moist:false}],[500,{moist:true}]]},
 {name:'initialOff400',end:400,initial:{dryGain:0,moist:false},commands:[[200,{moist:true}]]},
 {name:'windFront900',end:900,initial:{},commands:[[150,{meanX:0,meanZ:5,shearX:0,shearZ:.0015,uplift:.2}],[500,{frontX:-4000,frontSpeed:12}],[650,{dryGain:0}]]},
];
const outcomes=[];
for(const f of fixtures){let x=new Baseline(config,{...DEFAULT_CONTROLS,...f.initial}),y=new Candidate(config,{...DEFAULT_CONTROLS,...f.initial});for(const[t,p]of f.commands){x.enqueue(p,t);y.enqueue(p,t);}const used=new Map();let lastEvents=0,localReuses=0,lastYield=performance.now();
 while(x.time<f.end){x.step();y.step();steps++;for(let k=0;k<2;k++)sameArray(x.stateGrids[k],y.stateGrids[k]);
  for(const dt of[0,.125,.25])compareTuple(x.presentation(x.time+dt,7),y.presentation(y.time+dt,7));
  if(x.eventCount!==lastEvents){const ev=x.events.slice(-(x.eventCount-lastEvents));births+=ev.filter(e=>['birth','clear-recondensation'].includes(e.type)).length;retires+=ev.filter(e=>e.type==='retired').length;lastEvents=x.eventCount;}
  for(const p of x.current)if(p.active){const old=used.get(p.slot);if(old&&old!==p.ID){reuses++;localReuses++;}used.set(p.slot,p.ID);}
  if(x.tick%32===0){guard();if(performance.now()-lastYield>20){await new Promise(r=>setImmediate(r));lastYield=performance.now();}}
 }
 assert.deepEqual(x.metadata(),y.metadata());outcomes.push({name:f.name,end:f.end,stats:y.stats,eventCount:y.eventCount,slotReuses:localReuses});if(global.gc)global.gc();
}
// Revision-keyed buffers and copied asynchronous observer state across commits/reset.
const ca=new SourceClock(new Baseline(config)),cb=new SourceClock(new Candidate(config));
for(const t of[0,94.13,480.13,510,100]){if(t===0){ca.reset();cb.reset();}else{await ca.seek(t);await cb.seek(t);}compareTuple(ca.tuple(),cb.tuple());assert.equal(cb.tuple(),cb.tuple());const snap=snapshotForProbe(cb.tuple()),owned=Buffer.from(bytes(snap.exposureCurrent));cb.model.step();cb.model.presentation(cb.model.time+.25);assert.ok(owned.equals(bytes(snap.exposureCurrent)));assert.notEqual(snap.exposureCurrent.buffer,cb.model.exposureCurrent.buffer);guard();}
const sourceHash=async p=>createHash('sha256').update(await readFile(new URL(p,import.meta.url))).digest('hex');
const result={pass:true,stage:'frame-cache',selectors,steps,tuples,births,retires,slotReuses:reuses,outcomes,maxObservedRSSBytes:maxRSS,sourceHashes:{baseline:await sourceHash('../src/source/model.js'),candidate:await sourceHash('../frame/src/source/model.js')},scope:'Exact CPU state/F32 bytes/descriptors and snapshot ownership; no browser/GPU or whole-sky claim'};assert.ok(births>40&&retires>20&&reuses>20);await writeFile(new URL('frame-differential-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
