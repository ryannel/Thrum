# Publication-only result

The candidate preserves CPU source outputs and reduces changed-tick drying publication cost. It is not a GPU/render/full-sky qualification. Current live proof, prior evaluator and its results are unchanged. Candidate model SHA `087c84f8aca679c75b7551bf2d8561b8b81142d000ee3e0fbef783283f2e8da2`; baseline `675edc8de1d0ad197434be3ae1b04ea4f842362fa1ec8d227e1ae878a0a7133b`.

`STAGE1.md` records the operation and correctness scope. Exact differential passed 48 selector cases, 19,000 steps / 57,005 tuples, 102 births, 72 retirements and 66 slot reuses; all six complete forcing trajectories and snapshot/reset/seek behavior. Copied source suite8 and renderer suite8 pass. Main code change is only per-slot source selection plus bulk F64→F32 set/fill; raw allZero semantics remain exact.

Parent explicitly held browser recording/decode/zip/new shader loads and other CPU-heavy authors for this timed window. Sixty-six fresh Node processes were run sequentially on reported Apple M3 Max, Node24.16.0 arm64. One tick-only pair and two normal pairs per1/2/16 workload; one pair per64 workload. Pair order alternates. Results include every repetition, not best-of. Windows/quality/source semantics are identical to the retained cpu-cost plan. New evaluator differs only by target selection, UTC recording and outside-call warmup RSS guards. No profiler runs were mixed into timings. Results are unadjusted single-call performance.now timings; host/runtime/GC noise remains. Process CPU, measured wall, percentiles, work counts and RSS are retained independently in `cost/analysis.json` and raw JSONs.

Mean changed-tick publication ms per copy (both normal repetitions):

| Copies | Workload | Baseline | Candidate |
|---:|---|---|---|
| 1 | wet steady | .04240 / .03808 | .03969 / .03938 |
| 2 | wet steady | .03319 / .03445 | .03388 / .03614 |
| 16 | wet steady | .03492 / .03311 | .03283 / .03240 |
| 1 | wet birth | .05317 / .05287 | .03916 / .04069 |
| 2 | wet birth | .05066 / .05069 | .04022 / .03810 |
| 16 | wet birth | .04167 / .03991 | .03214 / .03216 |
| 1 | drying | .59581 / .59326 | .06095 / .06452 |
| 2 | drying | .58716 / .58757 | .05868 / .05961 |
| 16 | drying | .60253 / .59731 | .06053 / .07137 |

Wet steady has no consistent material win across counts. Wet birth first-publication improves; ordinary repeated-alpha work is mostly unchanged. Source ticks were not intentionally optimized. At16 copies drying first-publication p95 drops .6960/.6818→.0853/.1017ms. The slower candidate repetition is retained: tick mean .47499 vs baseline .40580ms, same-tick mean .04001 vs .02849ms, observed GC154.07 vs37.77ms. This is not evidence that unrelated tick logic sped up.

At16 copies, the cadence arithmetic `N*(64*tick+60*firstPublication)` for16× goes989.96/988.97→456.72/554.90CPUms per wall-second, a43.9–53.9% reduction. The1× arithmetic `N*(4*tick+4*first+56*same)` drops21.1–40.5%. These are estimates from API means, not actual playback, display or multi-cell scheduling. Actual measured drying process CPU user+system drops3866.1/3860.1→2396.5/2690.4ms for the fixed window; measured wall3712.0/3687.4→2215.1/3004.9ms includes harness/yield/GC. Persistent CPU control bytes943,296/model and hypothetical GPU control/pose bytes314,432+768/model are unchanged. Node observers do not measure driver/GPU costs.

55 outcomes complete,11 memory-stop outcomes retained. Baseline64steady tick-only alone completed near222.92MiB reserved pair RSS; its candidate stopped224.25MiB during setup. Every64 normal/birth/dry outcome stopped. No matched64 capacity/cadence conclusion follows. All stopped cases excluded from paired extrapolation, even if raw partial multiplier fields exist. Maximum recorded reserved pair RSS225.234375MiB; early224 is sampled, hard256 was not crossed. The new warmup guards prevent the old unguarded300-call overshoot, but remain samples, not allocator barriers. GC/heap/RSS measures overlap; no sum as unique memory.

Run `node --expose-gc verification/differential.mjs`, `node tests/source/run.mjs`, and `node --test --test-concurrency=1 tests/render/*.test.mjs` from this lab or absolute paths. `python3 cost/analyze.py` only aggregates saved outcomes. `python3 cost/run.py` reruns/overwrites this matched matrix; preserve existing results first. No further timing repeat was selected after seeing adverse data. Frozen publication source and evaluator remain separate from any later frame-cache stage.
