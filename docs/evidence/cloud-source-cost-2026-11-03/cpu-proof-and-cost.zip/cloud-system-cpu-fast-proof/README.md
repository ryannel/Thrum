# Isolated Cu CPU optimization proof

Owner cloud_lifecycle_diagnosis. No live proof/canonical/evidence/browser/commit edits. `src/source` is the frozen publication-only candidate; `baseline/src/source` the original; `frame/src/source` the final combined candidate. `frame-attempt1` is rejected and documented. `combined-source.patch` reconstructs the two final changed files exactly. Main copied viewer is not a claim that the final frame candidate ran in a browser.

Read `PUBLICATION-RESULT.md` and `FRAME-RESULT.md` for separate matched measurements and limitations. `PUBLICATION-HANDOFF.json` freezes the first stage; `FINAL-HANDOFF.json` pins this complete delivery. New non-R16 code/results stay below8MiB. R16 payloads are immutable hardlinks to existing inputs; their repeated logical paths are not extra physical payload copies. Do not edit them through these links.

Reproduce correctness:

```
node --expose-gc verification/differential.mjs
node --expose-gc verification/frame-differential.mjs
node verification/frame-contracts.mjs
node verification/frame-field.mjs
node tests/source/run.mjs
node frame/tests/source/run.mjs
node --test --test-concurrency=1 tests/render/*.test.mjs
node --test --test-concurrency=1 frame/tests/render/*.test.mjs
python3 verify.py
```

These test commands overwrite their result files: preserve frozen receipts first. Run suites sequentially. For saved data only, `python3 cost/analyze.py` / `python3 frame-cost/analyze.py`. For new measurements, coordinate exclusive host CPU time first, preserve old outcomes, then run respective `run.py`; it uses fresh Node workers, bounded memory/phase duration and alternating matched pairs. The actual executed evaluators/results remain distinct from the original frozen cpu-cost study. No profiler or broad repeat after seeing results.

Finite CPU equivalence/performance does not establish actual loaded WebGPU, shader/source-consumer latency, normal/16× visual continuity, fullsky capacity, M2 or production acceptance. Root owns those integration checks. Retain this proof through parent selection/review; remove disposable bulk only after adoption/replacement is recorded. No software installs or new density masters were used.
