# Exact frame-cache result

The revised frame candidate preserves tested source/field/bounds values and reduces ordinary wet presentation work. Main `src/source` remains the frozen publication-only stage; final combined candidate is `frame/src/source/{model,math}.js`. Model SHA `e21f9f5163f0a183136ce02a2d2cc9d6d5f6459943acfc5fa3254ba8ec8ae70e`; math SHA `7f85fe25b759b7e1d37770b3e4bcea13199ef49dbb66362b0d79c621556bd862`. Other source files are unchanged. No live proof, shader, lighting, source physics/dt/control-grid pitch/admission, or previous evaluator changed.

`FRAME-STAGE.md` records the independently challenged representation and failed first attempt. It caches the existing exact numerical dual once per owned immutable birthQ; same-ID state/reference/endpoint copies share it, while fresh births/reset install new Q identities. Only those immutable Q keys are registered. Arbitrary mutable Q, whole-Q replacement and public Q clones retain uncached fallback. Public descriptor fields/independently cloned frozen Q arrays remain as before. Internal frozen-descriptor bounds verify all nine Q values and evaluate the same eight corners in the same operand/order sequence. No row-extrema/reassociated bound or optical-support substitution for weather-domain bounds.

The discarded pose-keyed attempt stopped at the early224MiB guard. Source/log/recipe are retained; exact triggering RSS and source time were not logged and the hard-limit outcome is unknown. Additional transient WeakMap entries were a plausible, not profiled, GC cause. Revised design removes those entries; it was independently challenged before the retry, with no budget increase. Revised exact differential observed164.95MiB.

Correctness:48selector cases;19000source steps/57005tuples;102births,72retirements,66slotreuses across six full fixtures; exact state grids, F32publication bytes, descriptors, bounds, alpha/reset/seek and snapshot ownership. Frame contracts3840points/242boxes exercise mutable fallback, deep freeze, Q replacement, new-model repeated IDs, old references/endpoints and wrong-frame rejection. Native differential1600points/466positive verifies q/raw/zero and packed poseF32 bytes exactly. Copied source suite8/render suite8 pass. These are finite CPU proofs, not actual GPU/continuous-domain/art qualification.

## Matched CPU comparison

Root explicitly held browser recordings/loads, ffmpeg/zip and other heavy authors. Same host Node24.16.0/darwin arm64/reported AppleM3Max. A separate66worker matrix compares publication-only vs frame: one tick-only pair and two alternating-order normal pairs per1/2/16workload, adverse64 pairs once. Same source windows and evaluator except explicit variant paths/names. No extra profiling or result-selected repeat. Full distributions, source hashes, work counts, wall/processCPU, GC and memory outcomes are in `frame-cost/analysis.json`/raw JSONs. These timings compare only this matched matrix; do not multiply stage gains from different timing windows into an alleged end-to-end result.

Mean same-tick presentation ms/copy, repetition1/repetition2:

| Copies | Window | Publication-only | Frame |
|---:|---|---|---|
| 1 | wet steady | .04240 / .04115 | .02899 / .03041 |
| 2 | wet steady | .03814 / .04161 | .02743 / .02668 |
| 16 | wet steady | .03085 / .03176 | .02377 / .02219 |
| 1 | wet birth | .03814 / .03757 | .02614 / .02601 |
| 2 | wet birth | .03855 / .03992 | .02493 / .02572 |
| 16 | wet birth | .03091 / .03151 | .02194 / .02127 |
| 1 | drying | .03406 / .03414 | .02560 / .02622 |
| 2 | drying | .04497 / .03124 | .02469 / .02319 |
| 16 | drying | .02798 / .02765 | .01992 / .01991 |

At16copies wet steady changed-tick publication .03161/.03196→.02413/.02267ms, and source ticks .03808/.03937→.03499/.03392ms. Wet1× cadence arithmetic saves21.9–28.8%; wetbirth26.5–30.8%. Dry1× saves12.8–15.4%. The16× arithmetic savings are14.9–20.4% wetsteady and14.1–22.2% wetbirth; dry ranges3.7% improvement to0.7% regression, because the unchanged17³weather loop dominates. Retain that adverse result; no universal accelerated gain claim.

At16copies, measured wetsteady phase wall332.8/343.0→262.7/246.1ms; processCPU user+system391.7/404.5→332.8/300.3ms. Dry wall2226.6/2186.5→1887.2/1909.9ms; CPU2399.6/2360.7→2055.9/2081.3ms. Observed dry GC223/221events,31.12/30.87ms→142/141events,20.24/19.56ms; this is a runtime observation, not an exact allocation total. Source counters and updated control-node counts match per completed workload. Control storage remains943296CPU bytes/model; hypothetical GPU control/pose314432+768B/model plus shared64B domain, with no GPU allocation measured. Private frames have bounded state/previous/reference membership, not an ID-history map; object/WeakMap resident overhead is not exactly measured. RSS/heap/external overlap.

56outcomes complete/10memory-stopped. Both64birth tick-only workloads completed (publication220.20MiB/frame210.75MiB reserved pair peaks); all64normal cases and other64tick cases stopped. No supported64source+presentation capacity claim;64 excluded from cadence extrapolation as predeclared. Maximum recorded reserved pair RSS226.984375MiB, under hard256; early224 remains a sampled guard, not an allocation barrier. Unmatched earlier64success/failure differences are retained as runtime variability, not optimized sky capacity.

The1× arithmetic is N(4tick+4first+56same)ms/wallsecond;16× is N(64tick+60first). It is not measured playback, GPU, driver, display, full-sky or M2 admission. All results/repetitions and the rejected attempt remain. No further optimization or benchmark search was commissioned/run after these comparisons. Next integration belongs to root: independently review the two-file patch, preserve these identities, run the actual renderer/query/visual and cadence checks before any integrated claim.
