from pathlib import Path
import json,hashlib,statistics
R=Path(__file__).resolve().parent
runs=[]
for f in sorted((R/'results').glob('*.json')):
 r=json.loads(f.read_text());m=r['measurement'];mem=r['memory'];x={'name':f.stem,'variant':r['args']['variant'],'copies':r['args']['copies'],'workload':r['args']['workload'],'mode':r['args']['mode'],'rep':int(f.stem.rsplit('r',1)[1]),'status':r['status'],'failure':r['failure'],'sourceHashes':r['sourceHashes'],'startedUTC':r['startedUTC'],'finishedUTC':r['finishedUTC'],'tick':m['tick'],'changedTickPublication':m['changedTickPresentation'],'sameTickPublication':m['sameTickMovingAlphaPresentation'],'counters':m['counterDelta'],'wallMs':m['wallMs'],'cpuMicroseconds':m.get('cpu'),'gcCount':r['gc']['measuredEventCount'],'gcDurationMs':r['gc']['measuredDurationMs'],'maxWorkerRSSBytes':max(mem['maxSampledWorkerRSSBytes'],mem['maxReportedWorkerRSSBytes']),'parentReserveBytes':mem['parentReserveBytes'],'persistentCPUControlBytes':mem['persistentLogicalCPUControlsBytes'],'logicalGPUControlBytes':mem['logicalGPUControlsBytes'],'logicalGPUPoseBytes':mem['logicalGPUPoseBytes'],'multiplier':r['multipliers']if r['status']=='complete'and r['args']['copies']<64 else None};x['maxReservedPairRSSBytes']=x['maxWorkerRSSBytes']+x['parentReserveBytes'];runs.append(x)
pairs=[]
for n in[1,2,16,64]:
 for w in['steady','birth','dry']:
  for mode in['ticks','present']:
   for rep in[1,2]:
    rr={r['variant']:r for r in runs if(r['copies'],r['workload'],r['mode'],r['rep'])==(n,w,mode,rep)}
    if not rr:continue
    assert set(rr)=={'publication','frame'}
    a,b=rr['publication'],rr['frame'];eligible=n<64 and all(r['status']=='complete'for r in rr.values());x={'copies':n,'workload':w,'mode':mode,'rep':rep,'eligibleMatchedCost':eligible,'publication':a['name'],'frame':b['name']}
    if eligible:
     for name in['tick','changedTickPublication','sameTickPublication']:
      if a[name]['count']:x[name+'Speedup']=a[name]['meanMs']/b[name]['meanMs']
     if mode=='present':
      for name in['oneXCPUmsPerWallSecond','sixteenXCPUmsPerWallSecond']:x[name+'ReductionFraction']=1-b['multiplier'][name]/a['multiplier'][name]
    pairs.append(x)
result={'scope':'Frame-cache vs publication-only isolatedCPU kernels;64excludedfrompaired extrapolation;two normal repetitions kept individually;noGPU/browser/fullsky/M2 admission','runCount':len(runs),'complete':sum(r['status']=='complete'for r in runs),'stopped':sum(r['status']=='stopped'for r in runs),'maxReservedPairRSSBytes':max(r['maxReservedPairRSSBytes']for r in runs),'runs':runs,'pairs':pairs}
(R/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in['runs','pairs']},indent=2))
for x in pairs:
 if x['copies']==16 and x['mode']=='present':print(x)
