struct Params  {
  camera:vec4f, focus:vec4f, sun:vec4f, bmin:vec4f, bmax:vec4f, weather:vec4f, control:vec4f, front:vec4f, image:vec4f, domain:vec4f, lifecycle:vec4f
}
;
@group(0) @binding(0) var<uniform> p:Params;
@group(0) @binding(1) var densityTex:texture_3d<f32>;
@group(0) @binding(2) var basis:texture_3d<f32>;
@group(0) @binding(3) var linearClamp:sampler;
@group(0) @binding(4) var restTex:texture_3d<f32>;
@group(0) @binding(5) var voxelLight:texture_3d<f32>;
@group(0) @binding(7) var airTrans:texture_2d<f32>;
@group(0) @binding(10) var previousQ:texture_3d<f32>;
@group(0) @binding(11) var previousRest:texture_3d<f32>;
@group(0) @binding(13) var receiverMap:texture_2d<f32>;
@group(0) @binding(14) var linearRepeat:sampler;
@group(0) @binding(16) var restB:texture_3d<f32>;
@group(0) @binding(17) var previousRestB:texture_3d<f32>;
const PI:f32=3.141592653589793;
fn rayBox(o:vec3f,d:vec3f,lo:vec3f,hi:vec3f)->vec2f {
  let safe=select(vec3f(1e-7),d,abs(d)>vec3f(1e-7));
  let a=(lo-o)/safe;
  let b=(hi-o)/safe;
  return vec2f(max(max(min(a.x,b.x),min(a.y,b.y)),min(a.z,b.z)),min(min(max(a.x,b.x),max(a.y,b.y)),max(a.z,b.z)));
}
fn uvw(x:vec3f)->vec3f {
  return(x-p.bmin.xyz)/(p.bmax.xyz-p.bmin.xyz);
}
// Held static component query. Two local R16F template pairs serve eight poses.
@group(0) @binding(18) var bodyDistance:texture_3d<f32>;
@group(0) @binding(19) var crownBDensity:texture_3d<f32>;
@group(0) @binding(20) var crownBDistance:texture_3d<f32>;
struct HeldPart {
  C_b:vec4f, Q0_A:vec4f, Q1_asset:vec4f, Q2_active:vec4f,
  K_rootX:vec4f, rootYZ:vec4f
};
struct AssetDomain { origin_pitch:vec4f, span:vec4f };
@group(0) @binding(21) var<storage,read> heldParts:array<HeldPart,8>;
@group(0) @binding(22) var<storage,read> assetDomains:array<AssetDomain,2>;
@group(0) @binding(23) var<storage,read> cohortExposure:array<f32>;
fn exposureValue(slot:u32,i:vec3u)->f32 {
  let index=slot*4913u+(i.z*17u+i.y)*17u+i.x;
  return mix(cohortExposure[index],cohortExposure[39304u+index],p.lifecycle.y);
}
fn materialExposure(slot:u32,a:vec3f,domain:AssetDomain)->f32 {
  let grid=clamp((a-domain.origin_pitch.xyz)/domain.span.xyz*16.,vec3f(0),vec3f(16));
  let lo=min(vec3u(floor(grid)),vec3u(15));let f=grid-vec3f(lo);
  let z0=mix(mix(exposureValue(slot,lo),exposureValue(slot,lo+vec3u(1,0,0)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,0)),exposureValue(slot,lo+vec3u(1,1,0)),f.x),f.y);
  let z1=mix(mix(exposureValue(slot,lo+vec3u(0,0,1)),exposureValue(slot,lo+vec3u(1,0,1)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,1)),exposureValue(slot,lo+vec3u(1,1,1)),f.x),f.y);
  return mix(z0,z1,f.z);
}
fn partDensity(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(densityTex,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDensity,linearClamp,uv,0.).x;
}
fn partDistance(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(bodyDistance,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDistance,linearClamp,uv,0.).x;
}
fn componentQuery(x:vec3f,raw:bool)->f32 {
  var q=0.;
  for(var i=0u;i<8u;i++) {
    let s=heldParts[i];
    if(s.Q2_active.w<.5||s.Q0_A.w<=0.||s.C_b.w<=0.){continue;}
    let h=(x.y-s.C_b.y)/s.C_b.w;
    let v=(x-s.C_b.xyz-s.K_rootX.xyz*h)/s.C_b.w;
    let a=vec3f(dot(s.Q0_A.xyz,v),dot(s.Q1_asset.xyz,v),dot(s.Q2_active.xyz,v))
      +vec3f(s.K_rootX.w,s.rootYZ.x,s.rootYZ.y);
    let index=u32(s.Q1_asset.w);
    if(index>=2u){continue;}
    let domain=assetDomains[index];
    let uv=(a-domain.origin_pitch.xyz)/domain.span.xyz;
    if(any(uv<vec3f(0.))||any(uv>vec3f(1.))){continue;}
    let rho=partDensity(index,uv);
    var mask=1.;
    if(!raw){
      let material=.3+.7*clamp(textureSampleLevel(basis,linearClamp,clamp(a/512.,vec3f(0),vec3f(1)),0.).x,0.,1.);
      let loss=s.rootYZ.z+materialExposure(u32(s.rootYZ.w),a,domain);
      mask=smoothstep(-8.,8.,partDistance(index,uv)-material*loss);
    }
    q=max(q,s.Q0_A.w*rho*mask);
  }
  return q;
}
fn rawQ(x:vec3f)->vec4f {return vec4f(componentQuery(x,true),0.,0.,0.);}
fn coefficients(x:vec3f,detail:f32)->vec2f {
  if(p.domain.w>.5){return vec2f(0.);}
  return vec2f(componentQuery(x,false)*p.bmin.w,0.);
}

fn tauRay(x:vec3f,d:vec3f,count:u32,detail:f32)->f32 {
  let interval=rayBox(x,d,p.bmin.xyz,p.bmax.xyz);
  let start=max(0.,interval.x);
  let end=interval.y;
  if(end<=start) {
    return 0.;
  }
  let ds=(end-start)/f32(count);
  var tau=0.;
  for(var j=0u;j<count;j++) {
    let c=coefficients(x+d*(start+(f32(j)+.5)*ds),detail);
    tau+=(c.x+c.y)*ds;
  }
  return tau;
}
// Independent thin-plane attenuation provider. There is no density field in this profile.
fn analyticShadowT(x:vec3f)->f32 {
  if(x.y>=2200.){return 1.;}
  let caster=x+p.sun.xyz*((2200.-x.y)/max(p.sun.y,.03));
  let wave=.55+.35*sin((caster.x-p.weather.w)*.0012)*cos(caster.z*.001);
  let front=1.-.85*smoothstep(p.front.x-400.,p.front.x+400.,caster.x);
  let amount=max(0.,wave)*p.control.x*(1.-p.control.y)*front;
  return exp(-amount*1.8);
}
fn directT(x:vec3f)->vec2f {
  if(p.domain.w>1.5){return vec2f(1);}
  if(p.domain.w>.5){let t=analyticShadowT(x);return vec2f(t,pow(t,p.domain.y));}
  let tau=tauRay(x,p.sun.xyz,32u,1.);
  return exp(-vec2f(tau,tau*p.domain.y));
}
fn cacheT(x:vec3f)->vec2f {
  if(p.domain.w>.5){return directT(x);}
  let uv=uvw(x);
  if(any(uv<vec3f(0))||any(uv>vec3f(1))) {
    return directT(x);
  }
  return textureSampleLevel(voxelLight,linearClamp,uv,0.).xy;
}
fn cloudSun(x:vec3f)->vec2f {
  var tau=0.;
  let ds=100.;
  for(var i=0u;i<2u;i++) {
    let c=coefficients(x+p.sun.xyz*((f32(i)+.5)*ds),1.);
    tau+=(c.x+c.y)*ds;
  }
  return exp(-vec2f(tau,p.domain.y*tau))*cacheT(x+p.sun.xyz*200.);
}
fn ambientA(x:vec3f)->f32 {
  let uv=uvw(x);
  if(any(uv<vec3f(0))||any(uv>vec3f(1))) {
    return 1.;
  }
  return textureSampleLevel(voxelLight,linearClamp,uv,0.).z;
}
fn hg(g:f32,mu:f32)->f32 {
  return(1.-g*g)/(4.*PI*pow(max(1.+g*g-2.*g*mu,.001),1.5));
}
fn phase(mu:f32,ice:f32,factor:f32)->f32 {
  let a=mix(.8,.85,ice)*factor;
  let b=mix(-.2,-.15,ice)*factor;
  let w=mix(.8,.85,ice);
  return w*hg(a,mu)+(1.-w)*hg(b,mu);
}
fn airAt(x:vec3f)->mat3x3f {
  let h=max(x.y,0.);
  let ray=exp(-h/8000.)*vec3f(5.802e-6,13.558e-6,33.1e-6);
  let mie=vec3f(4e-6*exp(-h/1200.));
  let ozone=vec3f(.65e-6,1.881e-6,.085e-6)*max(0.,1.-abs(h-25000.)/15000.);
  return mat3x3f(ray+mie+ozone,ray,mie*.9);
}
fn atmosphereExit(x:vec3f,d:vec3f)->f32 {
  let o=x+vec3f(0,6371000.,0);
  let b=dot(o,d);
  let c=dot(o,o)-6471000.*6471000.;
  return max(0.,-b+sqrt(max(b*b-c,0.)));
}
fn airRayT(x:vec3f,dir:vec3f)->vec3f {
  let o=x+vec3f(0,6371000.,0);
  let dotSun=dot(o,dir);
  if(dotSun<0.) {
    if(dotSun*dotSun-dot(o,o)+6371000.*6371000.>0.) {
      return vec3f(0);
    }
  }
  let total=atmosphereExit(x,dir);
  var tau=vec3f(0);
  for(var i=0u;i<48u;i++) {
    let t0=pow(f32(i)/48.,2.)*total;
    let t1=pow(f32(i+1u)/48.,2.)*total;
    let point=x+dir*((t0+t1)*.5);
    let h=length(point+vec3f(0,6371000.,0))-6371000.;
    tau+=airAt(vec3f(0,h,0))[0]*(t1-t0);
  }
  return exp(-tau);
}
fn airSun(x:vec3f)->vec3f {
  let o=x+vec3f(0,6371000.,0);
  let h=max(length(o)-6371000.,0.);
  let mu=dot(normalize(o),p.sun.xyz);
  if(mu<0.) {
    let b=dot(o,p.sun.xyz);
    if(b*b-dot(o,o)+6371000.*6371000.>0.) {
      return vec3f(0);
    }
  }
  let uv=vec2f(mu*.5+.5,sqrt(clamp(h/100000.,0.,1.)));
  return textureSampleLevel(airTrans,linearClamp,uv,0.).rgb;
}
fn solar()->vec3f {
  return vec3f(6.8,6.55,6.3);
}
fn skyMean()->vec3f {
  return vec3f(.42,.49,.58)*(.2+.8*smoothstep(-.08,.4,p.sun.y));
}

struct Transport  {
  s:vec3f,t:vec3f
}
;
fn beer(source:vec3f,sigma:vec3f,ds:f32)->Transport {
  let t=exp(-sigma*ds);
  let x=sigma*ds;
  let integral=select((1.-t)/max(sigma,vec3f(1e-20)),vec3f(ds)*(1.-x*.5+x*x/6.),x<vec3f(.001));
  return Transport(source*integral,t);
}
fn join(a:Transport,b:Transport)->Transport {
  return Transport(a.s+a.t*b.s,a.t*b.t);
}
fn fogSigma(x:vec3f)->f32 {
  if(p.image.w<.5) {
    return 0.;
  }
  let ell=(x-vec3f(-1400.,120.,900.))/vec3f(1900.,500.,1800.);
  return .0007*max(0.,1.-dot(ell,ell));
}
fn fogSun(x:vec3f)->f32 {
  if(p.image.w<.5) {
    return 1.;
  }
  let iv=rayBox(x,p.sun.xyz,vec3f(-3300.,0.,-900.),vec3f(500.,620.,2700.));
  let a=max(iv.x,0.);
  let b=iv.y;
  if(b<=a) {
    return 1.;
  }
  let ds=(b-a)/8.;
  var tau=0.;
  for(var i=0u;i<8u;i++) {
    tau+=fogSigma(x+p.sun.xyz*(a+(f32(i)+.5)*ds))*ds;
  }
  return exp(-tau);
}
fn rayAir(o:vec3f,d:vec3f,a:f32,b:f32,count:u32)->Transport {
  var r=Transport(vec3f(0),vec3f(1));
  let mu=dot(d,p.sun.xyz);
  for(var i=0u;i<count;i++) {
    let f0=f32(i)/f32(count);
    let f1=f32(i+1u)/f32(count);
    let t0=a+(b-a)*f0*f0;
    let t1=a+(b-a)*f1*f1;
    let point=o+d*((t0+t1)*.5);
    let h=length(point+vec3f(0,6371000.,0))-6371000.;
    let air=airAt(vec3f(0,h,0));
    let jr=3.*(1.+mu*mu)/(16.*PI);
    let fog=fogSigma(point);
    var visibility=1.;
    if(fog>0.) {
      visibility=cacheT(point).x;
    }
    let sunT=fogSun(point);
    let j=(air[1]*jr+air[2]*hg(.8,mu))*solar()*airSun(point)*sunT;
    let jf=fog*.9*(solar()*airSun(point)*visibility*sunT*hg(.3,mu)+skyMean()*.4);
    r=join(r,beer(j+jf,air[0]+vec3f(fog),t1-t0));
  }
  return r;
}
fn receiverT(x:vec3f)->f32 {
  if(p.domain.w>1.5) {
    return 1.;
  }
  if(p.domain.w>.5){return analyticShadowT(x);}
  let center=(p.bmin.xyz+p.bmax.xyz)*.5;
  let extent=(p.bmax.xyz-p.bmin.xyz)*2.;
  let uv=(x.xz-center.xz)/extent.xz+.5;
  if(any(uv<vec2f(0))||any(uv>vec2f(1))) {
    return directT(x).x;
  }
  return textureSampleLevel(receiverMap,linearClamp,uv,0.).x;
}
fn ground(x:vec3f,d:vec3f)->vec3f {
  let sunT=receiverT(x)*fogSun(x);
  let checker=select(.12,.16,((i32(floor(x.x/1200.))+i32(floor(x.z/1200.)))&1)==0);
  let base=vec3f(checker*.65,checker*.9,checker);
  return base*(solar()*airSun(x)*max(p.sun.y,0.)*sunT/PI+skyMean()*.45);
}
fn integrate(o:vec3f,d:vec3f,terminal:f32,cloudEnabled:bool)->Transport {
  let box=rayBox(o,d,p.bmin.xyz,p.bmax.xyz);
  let start=max(0.,box.x);
  let end=min(box.y,terminal);
  var transport=Transport(vec3f(0),vec3f(1));
  let mode=u32(p.focus.w);
  if(end>start&&p.domain.w<.5&&cloudEnabled) {
    transport=rayAir(o,d,0.,start,8u);
    let count=u32(clamp(p.front.z,96.,384.));
    let ds=(end-start)/f32(count);
    let mu=dot(d,p.sun.xyz);
    for(var i=0u;i<count;i++) {
      let x=o+d*(start+(f32(i)+.5)*ds);
      let coeff=coefficients(x,1.);
      let sigma=coeff.x+coeff.y;
      let air=airAt(x);
      let fog=fogSigma(x);
      var source=vec3f(0);
      if(sigma>.000005) {
        let ice=coeff.y/max(sigma,.000001);
        let vis=cloudSun(x);
        let sunlight=solar()*airSun(x)*fogSun(x);
        let direct=sunlight*(phase(mu,ice,1.)*vis.x+p.sun.w*phase(mu,ice,p.domain.z)*vis.y);
        let ambient=skyMean()*.5*(.2+.8*ambientA(x));
        source=sigma*.995*(direct+ambient);
        if(mode==2u) {
          source=sigma*.995*direct;
        }
        if(mode==3u) {
          source=vec3f(sigma*ambientA(x));
        }
        if(mode==4u) {
          let age=rawQ(x).z/160.;
          source=sigma*mix(vec3f(.2,.8,.95),vec3f(1.,.4,.15),clamp(age,0.,1.));
        }
      }
      let cloudVis=cacheT(x).x;
      let jAir=(air[1]*(3.*(1.+mu*mu)/(16.*PI))+air[2]*hg(.8,mu))*solar()*airSun(x)*cloudVis*fogSun(x);
      let jFog=fog*.9*(solar()*airSun(x)*cloudVis*hg(.3,mu)+skyMean()*.4);
      transport=join(transport,beer(source+jAir+jFog,vec3f(sigma+fog)+air[0],ds));
      if(max(max(transport.t.x,transport.t.y),transport.t.z)<.004) {
        break;
      }
    }
    if(max(max(transport.t.x,transport.t.y),transport.t.z)>.004) {
      transport=join(transport,rayAir(o,d,max(end,0.),terminal,24u));
    }
  }
  else {
    transport=rayAir(o,d,0.,terminal,36u);
  }
  return transport;
}
fn skyBoundary(d:vec3f)->vec3f {
  let disk=smoothstep(cos(.0048),cos(.0042),dot(d,p.sun.xyz));
  return solar()*(disk/.0000685);
}
fn skyRay(o:vec3f,d:vec3f)->vec3f {
  let ray=integrate(o,d,atmosphereExit(o,d),true);
  return ray.s+ray.t*skyBoundary(d);
}
// Geometry diagnostic: the same coefficient field and96 steps, with no lighting/cache/air/fog.
fn opacityRay(o:vec3f,d:vec3f,terminal:f32)->vec3f {
  let iv=rayBox(o,d,p.bmin.xyz,p.bmax.xyz);let a=max(0.,iv.x);let b=min(iv.y,terminal);
  let count=u32(clamp(p.front.z,96.,384.));var tau=0.;if(b>a){let ds=(b-a)/f32(count);for(var i=0u;i<count;i++){let x=o+d*(a+(f32(i)+.5)*ds);let c=select(coefficients(x,1.),rawQ(x).xy*vec2f(p.bmin.w,p.bmax.w),u32(p.focus.w)==6u);tau+=(c.x+c.y)*ds;}}
  return mix(vec3f(.02,.04,.08),vec3f(.95),1.-exp(-tau));
}
@vertex fn vs(@builtin(vertex_index) i:u32)->@builtin(position) vec4f {
  let a=array<vec2f,3>(vec2f(-1,-1),vec2f(3,-1),vec2f(-1,3));
  return vec4f(a[i],0,1);
}
@fragment fn fs(@builtin(position) frag:vec4f)->@location(0) vec4f {
  let uv=frag.xy/p.image.xy;
  let aspect=p.image.x/p.image.y;
  let f=normalize(p.focus.xyz-p.camera.xyz);
  let r=normalize(cross(f,vec3f(0,1,0)));
  let u=cross(r,f);
  let xy=(uv*2.-1.)*vec2f(aspect,-1.)*p.image.z;
  let d=normalize(f+r*xy.x+u*xy.y);
  let mode=u32(p.focus.w);
  var color=vec3f(0);
  if(mode==1u) {
    let x=mix(p.bmin.x,p.bmax.x,uv.x);
    let y=mix(p.bmax.y,p.bmin.y,uv.y);
    let q=rawQ(vec3f(x,y,0));
    color=vec3f(q.x,q.y,q.w*25.);
    return vec4f(color,1);
  }
  let top=atmosphereExit(p.camera.xyz,d);
  var terminal=top;
  var hit=false;
  if(d.y<-.0001) {
    let tg=-p.camera.y/d.y;
    if(tg>0.&&tg<terminal) {
      terminal=tg;
      hit=true;
    }
  }
  if(mode==5u||mode==6u){return vec4f(opacityRay(p.camera.xyz,d,terminal),1);}
  let near=integrate(p.camera.xyz,d,terminal,p.front.w>.5);
  var background=skyBoundary(d);
  if(hit) {
    let pt=p.camera.xyz+d*terminal;
    background=ground(pt,d);
    if(p.camera.w>.5) {
      let reflected=reflect(d,vec3f(0,1,0));
      let mirror=skyRay(pt+vec3f(0,.05,0),reflected);
      let fresnel=.045+.955*pow(1.-max(dot(-d,vec3f(0,1,0)),0.),5.);
      background=mix(background,mirror,fresnel*.92);
    }
  }
  color=near.s+near.t*background;
  return vec4f(min(color*.5,vec3f(60000.)),1);
}
