"""Evidence/dependency verification only: no source steps, volume scans or timing."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((R/'BASELINE.json').read_text())['sourceHashes']
for n,v in base.items():assert sha(R/'baseline/src/source'/n)==v and sha(R.parent/'cloud-system-proof/src/source'/n)==v,n
assert sha(R.parent/'cloud-system-cpu-cost/worker.mjs')=='2f5427a825c1cd7cb2f3a59c51cf880e06088c234dbc22744ee5cfd49f65d43d'
h=json.loads((R/'PUBLICATION-HANDOFF.json').read_text())
for n,v in h['files'].items():assert sha(R/n)==v['sha256'],n
for folder in['src/source','frame/src/source']:
 for n,v in base.items():
  if n not in['model.js','math.js']:assert sha(R/folder/n)==v
for n in['model.js','math.js']:assert sha(R/'verification/patch-restore/src/source'/n)==sha(R/'frame/src/source'/n)
for n in['differential-results','frame-differential-results','frame-contracts-results','frame-field-results']:
 assert json.loads((R/'verification'/(n+'.json')).read_text())['pass']
for d in['tests/source','frame/tests/source']:
 s=json.loads((R/d/'suite-results.json').read_text());assert s['pass']and s['sourceUnchangedDuringRun']and len(s['runs'])==8
 assert s['sourceHashes']['model.js']==sha(R/('frame/src/source/model.js'if d.startswith('frame/')else'src/source/model.js'))
for n in['render-suite.log','frame-render-suite.log']:assert 'ℹ pass 8'in(R/'verification'/n).read_text()and'ℹ fail 0'in(R/'verification'/n).read_text()
variants={'baseline':'baseline/src/source','publication':'src/source','frame':'frame/src/source'}
matrices=[]
for directory,counts,labels in[('cost',(55,11),('baseline','publication')),('frame-cost',(56,10),('publication','frame'))]:
 a=json.loads((R/directory/'analysis.json').read_text());assert(a['complete'],a['stopped'])==counts and a['runCount']==66
 assert a['maxReservedPairRSSBytes']<256*2**20
 byname={r['name']:r for r in a['runs']}
 for f in(R/directory/'results').glob('*.json'):
  r=json.loads(f.read_text());variant=r['args']['variant'];assert r['sourceHashes']=={n:sha(R/variants[variant]/n)for n in base}
  assert r['inputIndexSHA256']==sha(R/'assets/input-index.json')
  assert r['memory']['persistentLogicalCPUControlsBytes']==r['constructedCopies']*943296
 for p in a['pairs']:
  if p['copies']==64:assert not p['eligibleMatchedCost'];continue
  assert p['eligibleMatchedCost'];x,y=[byname[p[label]]for label in labels];assert x['counters']==y['counters']
 matrices.append({'matrix':directory,'complete':a['complete'],'stopped':a['stopped'],'maxReservedPairMiB':a['maxReservedPairRSSBytes']/2**20})
for p in R.rglob('*.r16f'):
 q=R/'assets'/p.relative_to(R).as_posix().split('assets/',1)[1];assert p.stat().st_ino==q.stat().st_ino and p.stat().st_dev==q.stat().st_dev
newbytes=sum(p.stat().st_size for p in R.rglob('*')if p.is_file()and p.suffix!='.r16f');assert newbytes<8*2**20
final=R/'FINAL-HANDOFF.json'
if final.exists():
 for n,v in json.loads(final.read_text())['files'].items():assert sha(R/n)==v['sha256'],n
print(json.dumps({'pass':True,'publicationFreezeFiles':len(h['files']),'sourceAndOldEvaluatorUnchanged':True,'sourceOnlyFinalPatchReconstructsExactly':True,'matrices':matrices,'newNonR16Bytes':newbytes,'budgetBytes':8*2**20}))
