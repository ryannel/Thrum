Owner: /root/t2_account_oracle, commissioned by /root on 2026-11-03.
Purpose: scratch-only independent deterministic model of the provisional first-host T2 account.
Expected peak disk: <1 MiB; no compiler output or copied project trees.
Inputs: C05/C10/C12, T2-SAME-VOLUME-JOB-ACCOUNT-2026-11-03.md,
T2-EXTERNAL-INPUT-ROOT-2026-11-03.md, T2-EXTERNAL-COMPILER-OUTPUT-2026-11-03.md.
Retained output: model source, compact deterministic JSON result, report and input hashes.
Closeout: parent may select compact evidence; this agent makes no tracked edits or production claim.
