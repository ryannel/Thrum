#!/usr/bin/env python3
"""Scratch reference oracle; not T2 production implementation or physical quota.

Python 3.11+, stdlib only. Run from the repository root. Bytes are tiny integer
units. All arithmetic is bounded by MAX_U64 where the proposed API would use u64.
The model reads no engine code and does not call F3/F4 APIs. It derives admission
and lifecycle rules from the contract/design inputs recorded in results.json.
"""
from collections import Counter, deque
from dataclasses import dataclass, replace
from hashlib import sha256
from itertools import product, permutations
import json
from pathlib import Path


MAX_U64 = 2**64 - 1
CLASSES = ("managed_temporary", "main_wal", "compiler_output", "other")
ACTIVE = ("active", "cancelling", "stopped", "quarantine")


def checked_sum(values):
    total = 0
    for value in values:
        if value < 0 or value > MAX_U64 - total:
            return None
        total += value
    return total


def report_identity_guard(current, event):
    if event[0] != current[0]:
        return "wrong_job_incarnation"
    if event[1] != current[1]:
        return "stale_phase_generation"
    if event[2] != current[2]:
        return "stale_report_version"
    return "accepted"


@dataclass(frozen=True)
class Job:
    token: str
    resource: str
    initial: int
    allocated: int = 0
    reported_current: int = 0
    reported_remaining: int = 0
    future: int = 0
    status: str = "active"
    reader: bool = False
    retained_reason: bool = False

    def charge(self):
        if self.status == "released":
            return 0
        if self.status == "retained":
            return self.allocated
        if self.resource == "compiler_output":
            return max(self.initial, self.allocated)
        return self.reported_current + self.reported_remaining

    def growth(self):
        if self.status in ("released", "retained"):
            return 0
        if self.resource == "compiler_output":
            return max(self.initial, self.allocated)
        return self.reported_remaining


@dataclass(frozen=True)
class State:
    jobs: tuple = ()

    def mutate(self, job):
        return State(tuple(job if old.token == job.token else old for old in self.jobs))


def true_temporary_total(state):
    """Independent oracle: physical current plus exact authorized future demand.

    Deliberately never calls Job.charge()/growth() or reads reported estimates.
    Those are the accounting mechanism being challenged, not the oracle.
    """
    total = 0
    for job in state.jobs:
        if job.resource != "managed_temporary" or job.status == "released":
            continue
        if job.status == "retained":
            total += job.allocated
        else:
            total += job.allocated + job.future
    return total


def exact_plan_feasible(state, proposal, target, available, headroom=0):
    temporary = true_temporary_total(state)
    if proposal.resource == "managed_temporary":
        temporary += proposal.initial
    future = sum(job.future for job in state.jobs) + proposal.initial + headroom
    return temporary <= target and future <= available


def assert_true_temporary_safe(state, target):
    assert true_temporary_total(state) <= target, (state, target, true_temporary_total(state))


def admission(state, proposal, temp_target, fresh_available, headroom=0,
              snapshot_epoch=0, current_epoch=0, root_valid=True,
              inventory_complete=True, unresolved=False):
    """One serialized compare+insert's predicate. No filesystem callbacks here."""
    if not inventory_complete or unresolved:
        return "recovery_unresolved"
    if snapshot_epoch != current_epoch:
        return "stale_epoch"
    if not root_valid:
        return "invalid_root_domain_or_scope"
    if proposal.token in {j.token for j in state.jobs}:
        return "duplicate_job_token"
    if proposal.resource not in CLASSES or proposal.initial < 0:
        return "unknown_or_invalid_demand"
    temp = checked_sum([j.charge() for j in state.jobs
                        if j.resource == "managed_temporary"] +
                       ([proposal.initial] if proposal.resource == "managed_temporary" else []))
    growth = checked_sum([j.growth() for j in state.jobs] + [proposal.initial, headroom])
    if temp is None or growth is None:
        return "overflow"
    if temp > temp_target:
        return "managed_temporary_policy"
    if growth > fresh_available:
        return "observed_available_policy"
    return "admitted"


def add(state, token, resource, amount, temp_target, available):
    proposal = Job(token, resource, amount, reported_remaining=amount, future=amount)
    reason = admission(state, proposal, temp_target, available)
    return (State(state.jobs + (proposal,)), reason) if reason == "admitted" else (state, reason)


def vector_admission(active, retained, proposed, target, available):
    """Atomic four-class complete plan; vectors are disjoint owner charges.

    Active values here mean remaining growth for zero-current instrumented
    owners; retained values are inventoried current bytes with no future writes.
    The lifecycle/arithmetic tests above cover nonzero/lagging current use.
    """
    temporary = checked_sum((active[0], retained[0], proposed[0]))
    growth = checked_sum(active + proposed)
    if temporary is None or growth is None:
        return "overflow"
    if temporary > target:
        return "managed_temporary_policy"
    if growth > available:
        return "observed_available_policy"
    return "admitted"


def vector_exhaustion():
    vectors = tuple(product(range(2), repeat=len(CLASSES)))
    checked = 0
    for active, retained, proposed in product(vectors, repeat=3):
        for target, available in product(range(4), range(9)):
            result = vector_admission(active, retained, proposed, target, available)
            # Enumerate each class as distinct normalized owned roots, using the
            # scalar coordinator only as a separate two-phase reference: trial
            # insert all components privately, commit only if all succeed.
            old_jobs = tuple(Job(f"active:{i}", resource, active[i],
                                 reported_remaining=active[i], future=active[i])
                             for i, resource in enumerate(CLASSES))
            old_jobs += tuple(Job(f"retained:{i}", resource, retained[i], retained[i],
                                  retained[i], 0, 0, "retained")
                              for i, resource in enumerate(CLASSES))
            trial, failed = State(old_jobs), False
            for i, resource in enumerate(CLASSES):
                trial, reason = add(trial, f"proposed:{i}", resource, proposed[i], target, available)
                if reason != "admitted":
                    failed = True
                    break
            assert (result == "admitted") == (not failed)
            checked += 1
    # A complete mixed-class job must either own both subclaims or neither.
    assert vector_admission((0, 0, 0, 0), (0, 0, 0, 0), (2, 0, 0, 2), 3, 3) != "admitted"
    return {"four_class_vectors": len(vectors), "complete_plan_comparisons": checked,
            "partial_reservation_without_commit": "rejected"}


def lifecycle(state, token, operation, owner_token=None):
    """No refunds on cancel/exit. Verified inventory transfers; cleanup removes."""
    if owner_token is None:
        owner_token = token
    matches = [j for j in state.jobs if j.token == token]
    if len(matches) != 1 or owner_token != token:
        return state, "wrong_or_stale_owner"
    job = matches[0]
    if job.status == "released":
        return state, "already_released"
    if operation == "acquire_reader":
        if job.status not in ("active", "stopped", "retained") or job.reader:
            return state, "reader_not_acquirable"
        return state.mutate(replace(job, reader=True)), "reader_acquired"
    if operation == "release_reader":
        if not job.reader:
            return state, "reader_already_released"
        return state.mutate(replace(job, reader=False)), "reader_released"
    if operation == "drop_retained_reason":
        if not job.retained_reason:
            return state, "no_retained_reason"
        return state.mutate(replace(job, retained_reason=False)), "retained_reason_dropped"
    if operation == "write":
        if job.status != "active" or not job.future:
            return state, "write_not_authorized"
        return state.mutate(replace(job, allocated=job.allocated + 1,
                                   future=job.future - 1)), "written"
    if operation == "stable_handoff":
        if job.status != "active" or job.resource == "compiler_output":
            return state, "handoff_not_instrumented"
        return state.mutate(replace(job, reported_current=job.allocated,
                                   reported_remaining=job.future)), "reconciled"
    if operation == "cancel":
        if job.status != "active":
            return state, "cancel_not_active"
        return state.mutate(replace(job, status="cancelling")), "cancel_requested"
    if operation == "family_stopped":
        if job.status not in ("active", "cancelling"):
            return state, "stop_not_active"
        return state.mutate(replace(job, status="stopped", future=0)), "stopped_unreleased"
    if operation == "cleanup_fail":
        if job.status not in ("stopped", "quarantine"):
            return state, "cleanup_requires_stopped_family"
        return state.mutate(replace(job, status="quarantine")), "quarantined"
    if operation == "cleanup_verified":
        if job.status not in ("stopped", "quarantine", "retained"):
            return state, "cleanup_requires_stopped_family"
        if job.reader or job.retained_reason:
            return state, "cleanup_blocked_by_required_root_or_reader"
        return state.mutate(replace(job, status="released", allocated=0,
                                   reported_current=0, reported_remaining=0, future=0)), "released"
    if operation == "inventory_transfer_retained":
        if job.status != "stopped":
            return state, "transfer_requires_stopped_inventory"
        return state.mutate(replace(job, status="retained", retained_reason=True,
                                   reported_current=job.allocated,
                                   reported_remaining=0, future=0)), "transferred_once"
    return state, "unknown_operation"


def invariants(state):
    assert len({j.token for j in state.jobs}) == len(state.jobs)
    for job in state.jobs:
        assert min(job.allocated, job.future, job.charge(), job.growth()) >= 0
        assert job.charge() >= job.allocated
        assert job.growth() >= job.future
        assert job.allocated + job.future <= job.initial
        if job.status == "released":
            assert job.charge() == job.growth() == job.allocated == 0
            assert not job.reader and not job.retained_reason
        if job.status == "retained":
            assert job.charge() == job.allocated and job.growth() == 0


def arithmetic_exhaustion():
    """All two-job states in this envelope; independently compute exact future need.

    Each active owner has initial charge 0..2; allocation 0..initial; last stable
    report can lag allocation. Jobs may instead have transferred to retained.
    For compiler jobs the full initial charge is always kept until transfer.
    """
    variants = []
    for resource in CLASSES:
        for initial in range(3):
            for allocated in range(initial + 1):
                for reported in range(allocated + 1):
                    variants.append(Job("A", resource, initial, allocated, reported,
                                        initial - reported, initial - allocated))
                variants.append(Job("A", resource, initial, allocated, allocated, 0, 0, "retained"))
    checked = admitted = conservative_deferrals = 0
    for left, right in product(variants, repeat=2):
        state = State((left, replace(right, token="B")))
        invariants(state)
        for resource, amount, target, headroom in product(CLASSES, range(3), range(5), range(2)):
            proposal = Job("C", resource, amount)
            # Test all physical availability 0..6, independently of toy capacity.
            # Availability already subtracts all current allocations.
            for available in range(7):
                reason = admission(state, proposal, target, available, headroom)
                exact_feasible = exact_plan_feasible(state, proposal, target, available, headroom)
                if reason == "admitted":
                    admitted += 1
                    assert exact_feasible, (state, proposal, target, available)
                elif exact_feasible:
                    conservative_deferrals += 1
                    # Lagging reports and the full compiler claim explain all such cases.
                    assert sum(j.growth() for j in state.jobs) > left.future + right.future
                checked += 1
    return {"owner_variants": len(variants), "admission_comparisons": checked,
            "admitted": admitted, "conservative_deferrals": conservative_deferrals,
            "false_admissions_within_declared_estimate_envelope": 0}


def reachable_lifecycle_exhaustion():
    operations = ("write", "stable_handoff", "cancel", "family_stopped", "cleanup_fail",
                  "cleanup_verified", "inventory_transfer_retained", "acquire_reader",
                  "release_reader", "drop_retained_reason")
    profiles = ((3, 8, "managed_temporary", "managed_temporary"),
                (8, 3, "managed_temporary", "managed_temporary"),
                (2, 8, "managed_temporary", "compiler_output"),
                (0, 8, "main_wal", "other"))
    output = []
    for target, capacity, left_resource, right_resource in profiles:
        initial = State()
        queue, seen = deque([initial]), {initial}
        attempts = changed = true_temporary_successor_checks = 0
        reasons = Counter()
        while queue:
            state = queue.popleft()
            invariants(state)
            assert_true_temporary_safe(state, target)
            available = capacity - sum(j.allocated for j in state.jobs)
            assert available >= 0
            for token, resource in (("A", left_resource), ("B", right_resource)):
                successor, reason = add(state, token, resource, 2, target, available)
                attempts += 1
                reasons[reason] += 1
                assert_true_temporary_safe(successor, target)
                true_temporary_successor_checks += 1
                if successor != state:
                    changed += 1
                    assert sum(j.charge() for j in successor.jobs
                               if j.resource == "managed_temporary") <= target
                if successor not in seen:
                    seen.add(successor)
                    queue.append(successor)
                for operation in operations:
                    successor, reason = lifecycle(state, token, operation)
                    attempts += 1
                    reasons[reason] += 1
                    assert_true_temporary_safe(successor, target)
                    true_temporary_successor_checks += 1
                    # Every other job must be byte-for-byte unchanged.
                    assert [j for j in state.jobs if j.token != token] == [
                        j for j in successor.jobs if j.token != token]
                    before = [j for j in state.jobs if j.token == token]
                    after = [j for j in successor.jobs if j.token == token]
                    if successor != state:
                        changed += 1
                        if operation in ("cancel", "family_stopped", "cleanup_fail"):
                            assert before[0].charge() == after[0].charge()
                            assert before[0].growth() == after[0].growth()
                        if operation == "write":
                            assert before[0].charge() == after[0].charge()
                            assert before[0].growth() == after[0].growth()
                        if operation in ("acquire_reader", "release_reader", "drop_retained_reason"):
                            assert before[0].charge() == after[0].charge()
                            assert before[0].growth() == after[0].growth()
                    invariants(successor)
                    if successor not in seen:
                        seen.add(successor)
                        queue.append(successor)
        output.append({"temporary_target": target, "capacity": capacity,
                       "resources": [left_resource, right_resource],
                       "reachable_states": len(seen), "operation_attempts": attempts,
                       "true_temporary_successor_checks": true_temporary_successor_checks,
                       "state_changing_edges": changed, "result_counts": dict(sorted(reasons.items()))})
    return output


def registration_recovery_exhaustion():
    """Abstract crash cuts, not a filesystem durability simulator.

    Registration ordering: root -> synced record -> work -> known-stopped ->
    delete root -> sync parent -> remove record. A replay replaces this token's
    claim. Root without record or unresolved family blocks admissions globally.
    """
    results = []
    for root_present, record_present, stopped, inventory in product((False, True), repeat=4):
        if not inventory:
            disposition = "block_inventory_incomplete"
        elif root_present and not record_present:
            disposition = "block_unpaired_root"
        elif record_present and not stopped:
            disposition = "block_unresolved_family"
        elif record_present and root_present:
            disposition = "inventory_then_cleanup_or_transfer"
        elif record_present:
            disposition = "verify_parent_and_close_record"
        else:
            disposition = "clear"
        results.append({"root": root_present, "record": record_present, "stopped": stopped,
                        "inventory": inventory, "disposition": disposition})
    # Repeated startup reconciliation is idempotent for every small observed size,
    # including observed growth over initial estimate. No repeated += inventory.
    replay_cases = 0
    for initial, observed, restarts in product(range(4), range(5), range(1, 9)):
        registry = {}
        for _ in range(restarts):
            registry["immutable-job-token"] = max(initial, observed)
        assert sum(registry.values()) == max(initial, observed)
        replay_cases += 1
    return {"crash_inventory_cases": results, "idempotent_replay_cases": replay_cases}


def targeted_cases():
    cases = {}
    empty = State()
    # Two individually affordable jobs; second must not create output.
    for target, available, label in ((3, 100, "temporary"), (100, 3, "available")):
        first, reason = add(empty, "A", "managed_temporary", 2, target, available)
        assert reason == "admitted"
        assert add(empty, "B", "managed_temporary", 2, target, available)[1] == "admitted"
        second, reason = add(first, "B", "managed_temporary", 2, target, available)
        assert reason.endswith("policy") and second == first
        cases[f"joint_{label}_deferral"] = reason
    # One owner, exact one release, duplicate event and stale unique token rejected.
    state, _ = add(empty, "A:g1", "managed_temporary", 2, 8, 8)
    state, _ = add(state, "B:g1", "managed_temporary", 2, 8, 8)
    assert lifecycle(state, "B:g1", "cleanup_verified", owner_token="A:g1")[0] == state
    cancelled, _ = lifecycle(state, "A:g1", "cancel")
    assert sum(j.charge() for j in cancelled.jobs) == 4
    stopped, _ = lifecycle(cancelled, "A:g1", "family_stopped")
    failed, reason = lifecycle(stopped, "A:g1", "cleanup_fail")
    assert failed.jobs[0].status == "quarantine" and failed.jobs[0].charge() == 2
    released, _ = lifecycle(failed, "A:g1", "cleanup_verified")
    assert sum(j.charge() for j in released.jobs) == 2
    assert lifecycle(released, "A:g1", "cleanup_verified")[0] == released
    assert lifecycle(released, "A:g2", "cleanup_verified")[0] == released
    cases["owned_idempotent_release_and_failed_cleanup"] = "passed"
    # A cancellation cannot drop the F4 reader or retained-ready-root reason.
    pinned, _ = lifecycle(state, "A:g1", "acquire_reader")
    pinned, _ = lifecycle(pinned, "A:g1", "cancel")
    pinned, _ = lifecycle(pinned, "A:g1", "family_stopped")
    assert lifecycle(pinned, "A:g1", "cleanup_verified")[1] == "cleanup_blocked_by_required_root_or_reader"
    pinned, _ = lifecycle(pinned, "A:g1", "release_reader")
    retained, _ = lifecycle(pinned, "A:g1", "inventory_transfer_retained")
    assert lifecycle(retained, "A:g1", "cancel")[0] == retained
    assert lifecycle(retained, "A:g1", "cleanup_verified")[1] == "cleanup_blocked_by_required_root_or_reader"
    retained, _ = lifecycle(retained, "A:g1", "drop_retained_reason")
    assert lifecycle(retained, "A:g1", "cleanup_verified")[1] == "released"
    cases["reader_and_ready_retention_survive_cancellation"] = "passed"
    # Versioned snapshot invalidated by every cooperating admission/handoff/release.
    proposal = Job("C", "managed_temporary", 1)
    for snapshot, current in product(range(3), repeat=2):
        expected = "admitted" if snapshot == current else "stale_epoch"
        assert admission(empty, proposal, 8, 8, snapshot_epoch=snapshot,
                         current_epoch=current) == expected
    for root_valid, inventory_complete, unresolved in product((False, True), repeat=3):
        result = admission(empty, proposal, 8, 8, root_valid=root_valid,
                           inventory_complete=inventory_complete, unresolved=unresolved)
        assert (result == "admitted") == (root_valid and inventory_complete and not unresolved)
    cases["stale_epoch_root_inventory_guards"] = "17 combinations passed"
    # An owner report has independent job incarnation, phase generation and report
    # version, rather than using only the admitted source/build generation.
    # This pure tuple gate is deliberately separate from the charge arithmetic.
    current_identity = ("job-incarnation-1", 2, 3)
    report_cases = 0
    for token, phase, version in product(("job-incarnation-1", "job-incarnation-2"),
                                       range(1, 4), range(2, 5)):
        result = report_identity_guard(current_identity, (token, phase, version))
        assert (result == "accepted") == ((token, phase, version) == current_identity)
        report_cases += 1
    cases["stale_owner_phase_report_guard"] = {"tuple_combinations": report_cases,
                                                "accepted_exact_snapshot": 1}
    # Near u64 boundary: equality accepted, aggregate overflow refused.
    huge = Job("huge", "main_wal", MAX_U64, reported_remaining=MAX_U64, future=MAX_U64)
    assert admission(empty, huge, MAX_U64, MAX_U64) == "admitted"
    assert admission(State((huge,)), proposal, MAX_U64, MAX_U64) == "overflow"
    assert admission(empty, proposal, 1, 1, headroom=MAX_U64) == "overflow"
    cases["checked_equality_and_overflow"] = "passed"
    # A fresh sample must be taken within serialized compare+insert, not reused.
    before = admission(empty, proposal, 8, 2)
    after = admission(empty, proposal, 8, 0)
    assert before == "admitted" and after == "observed_available_policy"
    cases["fresh_available_sample"] = {"old_sample": before, "fresh_sample": after}
    # Compiler full claim is kept through writes, cancel, exit and failed cleanup.
    compiler, _ = add(empty, "compiler", "compiler_output", 2, 0, 8)
    compiler, _ = lifecycle(compiler, "compiler", "write")
    compiler, _ = lifecycle(compiler, "compiler", "write")
    assert compiler.jobs[0].growth() == 2 and compiler.jobs[0].allocated == 2
    compiler, _ = lifecycle(compiler, "compiler", "family_stopped")
    compiler, _ = lifecycle(compiler, "compiler", "cleanup_fail")
    assert compiler.jobs[0].growth() == 2
    # Zero future growth in reality, but full uncertain claim defers one byte.
    assert admission(compiler, Job("next", "other", 1), 0, 2) == "observed_available_policy"
    compiler = replace(compiler, jobs=(replace(compiler.jobs[0], status="stopped"),))
    compiler, _ = lifecycle(compiler, "compiler", "inventory_transfer_retained")
    assert compiler.jobs[0].charge() == 2 and compiler.jobs[0].growth() == 0
    assert admission(compiler, Job("next", "other", 1), 0, 2) == "admitted"
    cases["compiler_full_claim_and_once_only_transfer"] = "passed; conservative deferral is explicit"
    # Exhaust all interleavings of two atomic claim transactions and two cancels.
    # No physical blocking/time claim; this only models short serialized operations.
    schedules = 0
    for schedule in permutations(("admit_A", "admit_B", "cancel_A", "cancel_B")):
        state = State()
        for operation in schedule:
            prefix, token = operation.split("_")
            if prefix == "admit":
                state, _ = add(state, token, "managed_temporary", 2, 3, 8)
            else:
                state, _ = lifecycle(state, token, "cancel")
            assert sum(j.charge() for j in state.jobs) <= 3
            assert_true_temporary_safe(state, 3)
        schedules += 1
    cases["atomic_transaction_schedules"] = schedules
    return cases


def mutant_counterexamples():
    """Minimal adversarial witnesses; these are intentionally wrong algorithms."""
    witnesses = []
    def witness(name, correct, mutant, consequence, trace):
        assert correct != mutant
        witnesses.append({"mutation": name, "correct": correct, "mutant": mutant,
                          "consequence": consequence, "trace": trace})
    # Execute the dangerous charge mutation against the actual admission code.
    # A has allocated 0 but still owns 2 future bytes; B also needs 2 at target3.
    # The exact-plan oracle and successor invariant must both reject its result.
    undercharged = State((Job("A", "managed_temporary", 2,
                              reported_remaining=2, future=2),))
    proposed = Job("B", "managed_temporary", 2, reported_remaining=2, future=2)
    correct_reason = admission(undercharged, proposed, 3, 8)
    charge_implementation = Job.charge
    try:
        Job.charge = lambda self: self.allocated
        mutant_reason = admission(undercharged, proposed, 3, 8)
        assert mutant_reason == "admitted"
        assert not exact_plan_feasible(undercharged, proposed, 3, 8)
        try:
            arithmetic_exhaustion()
        except AssertionError:
            scalar_exhaustion_rejected = True
        else:
            scalar_exhaustion_rejected = False
        assert scalar_exhaustion_rejected
        unsafe_successor = State(undercharged.jobs + (proposed,))
        try:
            assert_true_temporary_safe(unsafe_successor, 3)
        except AssertionError:
            successor_rejected = True
        else:
            successor_rejected = False
        assert successor_rejected
    finally:
        Job.charge = charge_implementation
    witness("charge_only_allocated_bytes", correct_reason, mutant_reason,
            "false admission rejected independently by exact plan and every-successor invariant",
            "target=3; A allocated=0/future=2; B proposed=2; mutated existing charge0 admits B; true temporary=4>3")
    witnesses[-1].update({"scalar_exhaustion_rejected": scalar_exhaustion_rejected,
                          "successor_invariant_rejected": successor_rejected})
    state, _ = add(State(), "A", "managed_temporary", 2, 3, 8)
    correct, _ = add(state, "B", "managed_temporary", 2, 3, 8)
    isolated_b, _ = add(State(), "B", "managed_temporary", 2, 3, 8)
    witness("independent_local_admission", sum(j.charge() for j in correct.jobs),
            sum(j.charge() for j in state.jobs + isolated_b.jobs), "false aggregate admission",
            "target=3; A=2 and B=2 both read empty total; both locally accept; serialized second defers")
    cancelled, _ = lifecycle(state, "A", "cancel")
    witness("refund_on_cancel_or_exit", cancelled.jobs[0].charge(),
            cancelled.jobs[0].charge() - cancelled.jobs[0].initial,
            "premature refund while owned roots/reader may remain",
            "A claim=2; cancel request or process exit; no checked cleanup/inventory")
    state, _ = add(State(), "A", "managed_temporary", 2, 8, 8)
    state, _ = add(state, "B", "managed_temporary", 2, 8, 8)
    stopped, _ = lifecycle(state, "A", "family_stopped")
    released, _ = lifecycle(stopped, "A", "cleanup_verified")
    duplicate, _ = lifecycle(released, "A", "cleanup_verified")
    witness("subtract_release_event_twice", sum(j.charge() for j in duplicate.jobs),
            sum(j.charge() for j in state.jobs) - 2 * state.jobs[0].initial,
            "double refund spends B's claim",
            "A=2,B=2; process A release twice using aggregate -=2; actual B remains=2")
    written, _ = lifecycle(state, "A", "write")
    witness("scan_active_root_plus_full_claim", written.jobs[0].charge(),
            written.jobs[0].charge() + written.jobs[0].allocated,
            "false managed-temporary deferral",
            "A active phase=2, allocated=1; scanning 1 then adding full 2 charges 3")
    retained = Job("retained", "managed_temporary", 2, 2, 2, 0, 0, "retained")
    witness("scan_retained_bytes_as_remaining_growth", retained.growth() + 1,
            retained.allocated + 1, "false available-space deferral",
            "retained root allocated=2 already reflected in available=2; next needs=1; wrongly require 2+1")
    compiler = Job("compiler", "compiler_output", 2, 2, 0, 2, 0)
    witness("refund_compiler_bytes_as_written", compiler.growth(),
            max(0, compiler.initial - compiler.allocated),
            "uncertain claim silently reclassified as exact",
            "compiler admitted full=2; racing scan sees=2; subtracts 2; compiler may still write an unestimated suffix")
    registry, accumulator = {}, 2
    for _ in range(4):
        registry["A"] = 2
        accumulator += 2
    witness("recover_by_adding_inventory_each_time", sum(registry.values()), accumulator,
            "unbounded overcount as restart count grows",
            "same token full claim=2 and observed=2; four replay passes +=2 yield 10; replace remains2")
    safe, _ = lifecycle(state, "B", "cleanup_verified", owner_token="A")
    witness("release_by_source_generation_only", safe.jobs[1].charge(),
            safe.jobs[1].charge() - state.jobs[0].initial,
            "one job releases another job in same generation",
            "A and B share source/build generation7; A's delayed release matches B after ID reuse")
    proposal = Job("next", "other", 1)
    witness("reuse_available_sample", admission(State(), proposal, 0, 0),
            admission(State(), proposal, 0, 2), "false decision against fresh observation",
            "old available=2; external writer consumes2 before compare; fresh=0; proposed=1")
    witness("allow_new_work_before_startup_inventory",
            admission(State(), proposal, 0, 2, inventory_complete=False),
            admission(State(), proposal, 0, 2), "forgotten live root/claim",
            "record registered or unpaired root exists after crash; in-memory active total starts0")
    current, delayed = ("A", 2, 2), ("A", 1, 1)
    stale_proposal = 1
    kept = 2 if report_identity_guard(current, delayed) != "accepted" else stale_proposal
    witness("accept_stale_owner_handoff", kept, stale_proposal,
            "stale estimate overwrites replacement phase claim",
            "phase epoch2 owns charge2; phase epoch1 delayed current0/remaining1 replaces current claim")
    witness("wrap_u64_sum", checked_sum((MAX_U64, 1)),
            (MAX_U64 + 1) & MAX_U64, "false admission after checked-domain overflow",
            "MAX_U64 +1 becomes0 under wrapping arithmetic; must refuse before work")
    return witnesses


def physical_limit_counterexamples():
    # Passing admission cannot establish any of these physical guarantees.
    return [
        {"case": "external_writer_after_fresh_sample", "sample": 2, "proposed_growth": 2,
         "external_after_sample": 1, "result": "admission passes; later native write can hit ENOSPC"},
        {"case": "compiler_uninterposed_overrun", "full_phase_claim": 2,
         "bytes_before_next_sample": 3,
         "result": "estimate exceeded before supervisor can observe/cancel; no physical hard cap"},
        {"case": "unknown_descendant", "supervisor_exited": True,
         "family_resolved": False,
         "result": "quarantine and block overlapping work; process exit is not release proof"},
        {"case": "unknown_orphan_size_or_family", "root_without_registration": True,
         "result": "retain known conservative information and block; inventing a finite zero/default claim is unsafe"},
    ]


def main():
    inputs = ["AGENTS.md", "docs/design/CONTRACTS.md",
              "docs/design/research/T2-SAME-VOLUME-JOB-ACCOUNT-2026-11-03.md",
              "docs/evidence/integration/T2-EXTERNAL-INPUT-ROOT-2026-11-03.md",
              "docs/evidence/integration/T2-EXTERNAL-COMPILER-OUTPUT-2026-11-03.md"]
    results = {
        "scope": "scratch independent arithmetic/lifecycle oracle; no production implementation claim",
        "inputs_sha256": {name: sha256(Path(name).read_bytes()).hexdigest() for name in inputs},
        "source_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "arithmetic": arithmetic_exhaustion(),
        "multi_class_plans": vector_exhaustion(),
        "reachable_lifecycle": reachable_lifecycle_exhaustion(),
        "startup_reconciliation": registration_recovery_exhaustion(),
        "targeted": targeted_cases(),
        "intentionally_wrong_mutants_rejected": mutant_counterexamples(),
        "physical_guarantees_rejected": physical_limit_counterexamples(),
    }
    output = Path(__file__).with_name("results.json")
    output.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"result": "PASS", "arithmetic": results["arithmetic"],
                      "reachable_states": sum(x["reachable_states"] for x in results["reachable_lifecycle"]),
                      "lifecycle_operation_attempts": sum(x["operation_attempts"] for x in results["reachable_lifecycle"]),
                      "mutants_rejected": len(results["intentionally_wrong_mutants_rejected"]),
                      "results_path": str(output)}, sort_keys=True))


if __name__ == "__main__":
    main()
