# T2 first-host account oracle — 3 November 2026

Scratch-only design proof commissioned by `/root`; no tracked files, engine APIs,
main branch, Broadsides, compiler outputs or external services were changed.
The code baseline was `50024fa8bbe57fa9d22c651a359f73cb4dccd4e3`;
the parent then clarified the provisional T2 design and C05 during review.
`results.json` records the exact final input-document hashes.
The author read C05/C10/C12, the provisional same-volume account and both
external-input/compiler evidence records before writing the model. This is an
independent reference model relative to production code, not a blind design
review. No production T2 account implementation is claimed.

## Reproduce and identities

From the repository root:

```sh
python3.11 tmp/t2-account-oracle/model.py
shasum -a 256 tmp/t2-account-oracle/model.py tmp/t2-account-oracle/results.json
```

- Model SHA-256: `0eb12f4a448f9661317d59ec210d7b61b398aaedc080e8a2118ef0e4413bd514`
- Result SHA-256: `1c7b0b4923978b36ace1d1b387a32fb5b38bc1e533e4f8e6d3ad626be59c8834`
- Exact input hashes, per-profile event counts, counterexample traces and
  recovery tables are in `results.json`.
- Python 3.11 stdlib only; no generated cache or third-party dependency.

## Proof-oracle correction after adversarial review

The first version reused `Job.charge()` when deciding exact temporary
feasibility and checked the aggregate target only immediately after admission.
That made the temporary-safety proof insufficiently independent: an
allocated-only charge mutation could evade the intended check. This version
replaces that oracle with true allocated-plus-exact-future demand for active
roots, allocated bytes for retained roots, and proposed temporary growth. It
never calls the charge/growth mechanism or reads its reported estimates.
Every admission and lifecycle successor, including rejected/idempotent
operations, now checks that independent aggregate against the target.

The executed `charge_only_allocated_bytes` mutant admits B=2 alongside A with
allocated=0/future=2 at target3. The corrected scalar exhaustion rejects that
mutation, and the successor assertion independently rejects true use4>3.
Both rejection outcomes are recorded in `results.json`.

## Model and rejection conditions

Each owned root/claim has an immutable token, resource class, phase-full estimate,
actual allocated bytes, last owner-reported current/remaining quantities, exact
future demand used only by the oracle, status, reader flag and retained-root
reason. The four classes are managed temporary, main/WAL, compiler/output and
other. Active and retained roots occupy one representation each.

At an instrumented stable handoff the charge is current plus revised remaining
work. During an unreported write the old charge and old remaining-growth claim
remain. A compiler keeps its full uncertain phase claim until the family has
stopped and inventory has resolved its output. Cancellation, family exit and
failed cleanup never refund a claim. Cleanup requires a stopped family, no
reader and no required retained-root reason. An inventoried transfer replaces
active ownership with retained ownership; the existing allocation is not added
again. Duplicate release is idempotent; another token cannot release the claim.

A new complete plan is refused/deferred for unresolved startup inventory or
family, stale cooperating epoch, invalid root/domain/scope, duplicate job token,
unknown/invalid demand, checked overflow, managed-temporary target excess, or
insufficient freshly observed availability. A four-class plan is committed
atomically; component reservations remain private until the entire plan fits.
A separate owner-report gate rejects stale job incarnation, phase generation
and report version. Root validation and durability evidence are abstract inputs,
not implemented operating-system checks.

The managed-temporary test includes all retained managed-temporary roots and
one charge per active managed-temporary root. The independent exact oracle
uses active allocated-plus-future demand and retained allocated bytes, never
`Job.charge()`. Main/WAL, compiler and other
classes do not enter that bucket. The available-space test excludes retained
allocated bytes (already reflected in the sample), then includes active
remaining-growth claims, proposed incremental growth and headroom. Full
compiler claims and lagging instrumented reports can count already-written
bytes conservatively. They are not physical reservations.

## Exhaustive bounded results

| Check | Envelope / result |
| --- | --- |
| Scalar admission | 64 per-owner variants; all two-owner pairs; 4 proposal classes; proposed bytes 0–2; target 0–4; headroom 0–1; available 0–6 |
| Scalar comparisons | 3,440,640; 1,703,465 admissions; **zero false admissions within the declared future-growth envelope** |
| Explicit conservative deferrals | 314,464; every case is explained by lagging owner reports or retained full compiler claims |
| Atomic four-class plans | 16 vectors per active/retained/proposed owner; 147,456 complete-plan comparisons; all match an independent private trial/commit reference |
| Reachable lifecycle | 14,620 unique states across four profiles; 321,640 attempted operations; every reachable state checked; 321,640 independent aggregate temporary-safety successor checks |
| Lifecycle profiles | Two 2-byte temporary jobs at target 3; two 2-byte jobs at available 3; temporary plus compiler; main/WAL plus other with temporary target 0 |
| Startup | All 16 root/record/stopped/inventory combinations; 160 keyed-replay cases including inventory above original estimate |
| Snapshot and report guards | 9 epoch pairs, 8 root/recovery combinations, 18 owner/phase/report tuples; only the exact current owner report is accepted |
| Atomic interleavings | All 24 orders of A/B admission and A/B cancellation preserve the target |
| Arithmetic | Equality admitted; sum/headroom overflow refused before work |
| Wrong algorithms rejected | 13 concrete computed witnesses, including an executed allocated-only charge mutation in the result file |

Every lifecycle operation verifies other owners are byte-for-byte unchanged.
Every successor checks true aggregate temporary demand independently of the
accounting formula, rather than checking only after admission.
Reader acquisition/release and retained-root reasons cannot change charge.
A and B each fit alone in both the temporary-target and availability fixtures;
the second concurrent plan defers without creating its job state. Releasing A
once refunds only A; duplicate release, release by B's token and stale token
release do not refund again. Failed cleanup quarantines the original charge.

The intentionally wrong algorithms demonstrate false admission from independent
local checks, stale free-space samples, missing startup inventory, stale owner
reports and wrapping arithmetic; premature/double refund from cancel/exit or
aggregate subtraction; conservative double-counting from active-root scans or
retained bytes treated as remaining growth; wrong-owner release using source
generation; and restart overcount from repeatedly adding inventory. The latter
has recurrence `charge(n) = initial + n * observed`; keyed replacement is
idempotent and does not acquire another charge on replay.

## Recommended contract/API clarifications

These are implementation obligations or underspecified details in the
provisional design, not findings in an existing production coordinator.

1. Use an immutable registration/job-incarnation token independent of source or
   build generation. Key each class/root/phase claim beneath that token. A and B
   may legitimately share a source generation. A delayed A release must not match
   B or an ID reused after restart. An event/release receipt should name the exact
   token and return already-released for duplicates.
2. Make a complete per-class plan one atomic compare-and-register operation.
   Include root/allocation identity and exclusive owner so aliases/shared roots
   normalize to one charge. Do not reserve one class publicly and leak it when a
   later class fails. The oracle's vector trial state never becomes visible on
   refusal. A job-wide close must remove/transfer exactly its own subclaims.
3. Carry `(job incarnation, phase generation, owner report version)` plus the
   cooperating domain epoch through handoffs and claim attempts. A late report
   from the old phase cannot replace the newer phase's charge. Epoch validation
   does not make an unreported write visible; holding the full previous charge
   is still necessary. Capture the fresh availability sample during the short
   serialized comparison, after validating the paired snapshot.
4. Define recovery as keyed reconstruction/replacement from durable phase
   records and a complete inventory, never `existing claim += root scan`.
   For a known unresolved root use at least the durable full phase claim and
   inventoried overrun, with uncertainty recorded. An orphan with no trustworthy
   phase bound cannot be assigned a justified finite conservative upper bound:
   mark its amount unknown and block the domain/overlapping work until recovery.
   Repeated inventories must not amplify its charge. An observed overrun or
   unresolved descendant remains quarantined.
5. Separate `CancelRequested`, `FamilyStopped`, `OutputInventoried`,
   `CleanupVerified` and `TransferredToRetained`. Require owner-local reader and
   retained-root checks as well as the documented sync barriers. Cancellation
   cannot drop source pins or a ready build, and process exit alone cannot
   release a compiler claim. Failed cleanup needs a durable unresolved state.
6. Type receipt fields so class charge, retained allocation, incremental-growth
   estimate, full uncertain compiler claim, available-space observation,
   observation time/age, domain and overcount reason cannot be confused.
   Unknown quantities must remain unknown. Configurable policy deferral must
   remain distinct from native I/O failure and from a physical-space guarantee.

## Cost account and limits

The reference comparisons visit a finite set of jobs and four classes; they
perform no payload copy, hash or filesystem walk per mutation. General account
cost is O(J*C) for J active/retained records and fixed C=4; startup root inventory
is deliberately separate. The exhaustive runner's operation counts above are
model work, not coordinator or compiler performance measurements. Production
can keep aggregate class totals and owner-reported deltas, provided an invariant
checker can reconstruct the same totals. No timing benefit is claimed.

This is bounded deterministic exploration, not a theorem over all byte values
or schedules. The lifecycle uses at most two live job tokens, each a single
class/root with a 2-byte phase; the vector check adds complete multi-class
admission but does not model concurrent job-wide multi-root close. A reader
flag represents zero/one-or-more readers. Shared allocations are assumed
normalized/disjoint before entering the model. It does not implement F3/F4/T2,
SQLite/WAL, allocation accounting, filesystem root/alias validation, sync,
crash persistence, process groups, locks or real cleanup. Registration recovery
checks a table of abstract crash cuts, not native filesystem power-loss
semantics. No required repository gate follows from scratch-only model files;
only the reproducible model command was run for this commission.

Zero false admission assumes actual future demand stays within the declared
estimate and no unrelated writer changes availability after observation.
Neither assumption holds as an OS guarantee for an un-interposed compiler.
The result file preserves explicit counterexamples: an external writer can
consume space after a fresh sample, and compiler output can exceed its estimate
before the next sample/cancellation. Those require native failure handling and
owner-local completeness/recovery, not stronger wording about reservations.
An unresolved family/orphan may defer indefinitely; that is a deliberate safe
policy outcome, not proof of bounded liveness or transitive containment.
