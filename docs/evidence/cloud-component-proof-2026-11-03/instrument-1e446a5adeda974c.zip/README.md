# Held component v2 optical comparison

This static proof uses the archived 7c renderer (`docs/evidence/cloud-cohort-pilot-2026-11-03/instrument-7c719e6a164480db.zip`). The `light`, `shadow`, `air`, `view`, and `display` WGSL files are byte-identical. `optics.wgsl` preserves the 7c transport suffix from `fn tauRay` onward byte-identically and replaces only the source header. The Scene held path allocates the source textures, light, receiver, air, view, uniforms, eight pose slots and two domains. It allocates no PDE, rest, velocity, noise, curl, support, q cache, or old 64 MiB master pair.

The v2 input set has compressed BODY and one rounded B basis, with two B instances pointing at the same R16F rho/d pair. The field is `max_j Aseed_j*rho_j(a_j)*smoothstep(-8,8,d_j(a_j))`, liquid only. Each part explicitly carries `s_i`, `g`, `b=s_i*g`, `Q` columns, `C`, `K`, and its local root. The BODY η=.6 is baked in rho and fresh distance. The viewer applies no second compression or opacity compensation. Individual placed source integrals are `Aseed*b³*localIntegral`; max ownership makes the whole-field integral smaller than their sum.

All optical readers call the same `coefficients` helper. The inverse map solves world Y first, then multiplies by `Qᵀ`. Raw rho is a separate opacity diagnostic. Outside the finite asset domains the query is zero. The fixed camera focus and renderer bounds are shared across all held fixtures. Fixture changes advance no clock.

The candidate anatomy, attachment and growth cues are **UNQUALIFIED** until actual images and independent gates pass. The writer's frozen input manifest pins the fixture, two metadata JSONs and four R16F payloads. The small JSONs are copied into this proof; the payloads are symlinked without duplication, and every SHA and byte length is verified before load. The server's build URL is content hashed and stale paths are rejected.

After the input snapshot is frozen, run `python3 serve.py --port 8154`; only the root operator uses the browser. The Probe button compares the actual assembled GPU query against an independent CPU trilinear oracle. Receipts record input hashes, poses, profile, rays, device, resource ledger, submission and queue completion. This is no lifecycle, weather, full-sky, budget or art acceptance claim.

Offline checks: `node --test tests/held-oracle.test.mjs`, JavaScript syntax, all assembled WGSL modules and GPU probe via Naga, 7c byte comparison, and served dependency identity. No GPU workload is started by these checks.
