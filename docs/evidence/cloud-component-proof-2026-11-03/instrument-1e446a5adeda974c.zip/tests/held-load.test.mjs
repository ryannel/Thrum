import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {loadHeldAssets} from '../src/held-adapter.js';
const assetDir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../assets');
const originalFetch=globalThis.fetch;
const fileFetch=async (url,fixtureOverride)=>{
  const name=String(url).replace(/^assets\//,'');
  if(name.includes('/')||name.includes('..'))return new Response('Not found',{status:404});
  try{return new Response(name==='held-fixture.json'&&fixtureOverride?JSON.stringify(fixtureOverride):await fs.readFile(path.join(assetDir,name)),{status:200});}
  catch{return new Response('Not found',{status:404});}
};
const hash=b=>createHash('sha256').update(b).digest('hex');
test('frozen v2 fixture, all metadata, and four actual R16 payloads load through the browser fetch path',async()=>{
  const pins=JSON.parse(await fs.readFile(path.join(assetDir,'FROZEN-INPUTS.json')));
  for(const [name,pin] of Object.entries(pins.files)){
    const b=await fs.readFile(path.join(assetDir,name));assert.equal(b.byteLength,pin.bytes,name);assert.equal(hash(b),pin.sha256,name);
  }
  globalThis.fetch=url=>fileFetch(url);
  try{
    const loaded=await loadHeldAssets(()=>{});
    assert.equal(loaded.fixture.version,2);assert.equal(loaded.fixture.fixtures.length,11);
    assert.equal(loaded.fixtureSha256,'ad2bfe222215b069422e717bcb6f7645960ae4bc4e4fd2229a00e5a464ff06c7');
    assert.deepEqual(Object.keys(loaded.assets),['body','crown-b']);
    assert.equal(loaded.assets.body.density.length,192*64*256);
    assert.equal(loaded.assets['crown-b'].density.length,96**3);
    assert.ok(loaded.fixture.fixtures.some(f=>f.id==='b1-alone'));
    assert.ok(loaded.fixture.fixtures.some(f=>f.id==='b2-alone'));
  }finally{globalThis.fetch=originalFetch;}
});
test('invalid fixture versions 0, 1, and 3 fail before asset uploads',async()=>{
  const actual=JSON.parse(await fs.readFile(path.join(assetDir,'held-fixture.json')));
  for(const version of[0,1,3]){
    const wrong={...actual,version};globalThis.fetch=url=>fileFetch(url,wrong);
    await assert.rejects(loadHeldAssets(()=>{}),/Invalid held v2 fixture contract/);
  }
  globalThis.fetch=originalFetch;
});
test('two-basis contract rejects an invented independent A template',async()=>{
  const actual=JSON.parse(await fs.readFile(path.join(assetDir,'held-fixture.json')));
  globalThis.fetch=url=>fileFetch(url,{...actual,assets:{...actual.assets,'crown-a':'crown-a.json'}});
  try{await assert.rejects(loadHeldAssets(()=>{}),/Invalid held v2 fixture contract/);}
  finally{globalThis.fetch=originalFetch;}
});
