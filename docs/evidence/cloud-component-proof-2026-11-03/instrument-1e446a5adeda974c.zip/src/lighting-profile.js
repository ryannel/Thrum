// Existing optical model; only its three declared additional-scattering uniforms vary.
const uniformMap=Object.freeze({a:'p.sun.w',b:'p.domain.y',c:'p.domain.z'});
const make=(id,name,a,b,c,reference)=>Object.freeze({id,name,a,b,c,abc:Object.freeze([a,b,c]),uniformMap,reference,scope:'Additional scattering approximation look parameters; source/extinction/phase function unchanged'});
export const LIGHTING_PROFILES=Object.freeze({
 'legacy':make('legacy','Legacy',1,.25,0,'Historical eac4ae3bc6a5a681 Scene.write uniforms'),
 'selected-production':make('selected-production','SelectedProduction',.5,.5,.5,'docs/design/modules/CLOUD-PRODUCTION-BASELINE.md:441 — Cloud source additional octave a=b=c=.5'),
});
export function lightingProfile(id='selected-production'){const p=LIGHTING_PROFILES[id];if(!p)throw Error('Unknown optical lighting profile:'+id);return p;}
