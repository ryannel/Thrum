import {Gpu} from './gpu.js';
import {Scene} from './scene.js';
import {frameFence,assertGpuHealthy} from './frame-lifecycle.js';
import {assetIds,packParts,packDomains,heldPoint,forwardPoint} from './held-oracle.js';

export const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
const shaderNames=['optics','light','shadow','air','view','display'];
async function verifiedFile(file,hash,bytes){
  if(!hash||!Number.isInteger(bytes))throw Error('Asset has no SHA/byte pin: '+file);
  const r=await fetch('assets/'+file);if(!r.ok)throw Error('Asset unavailable '+file+' '+r.status);
  const data=await r.arrayBuffer();if(data.byteLength!==bytes||await sha(data)!==hash)throw Error('Asset hash/byte mismatch '+file);
  return data;
}
function uploadHalf3d(gpu,label,asset,data){
  const dims=asset.dims,src=new Uint8Array(data.buffer),row=dims[0]*2,stride=Math.ceil(row/256)*256;
  const padded=new Uint8Array(stride*dims[1]*dims[2]);
  for(let z=0;z<dims[2];z++)for(let y=0;y<dims[1];y++){
    const offset=(z*dims[1]+y)*row;
    padded.set(src.subarray(offset,offset+row),(z*dims[1]+y)*stride);
  }
  const tex=gpu.device.createTexture({label,size:dims,dimension:'3d',format:'r16float',usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST});
  gpu.device.queue.writeTexture({texture:tex},padded,{bytesPerRow:stride,rowsPerImage:dims[1]},dims);
  gpu.allocations.push({label,bytes:data.byteLength,format:'r16float',size:dims,role:'Shared immutable held component'});
  return tex;
}
function normalizeManifest(id,m){
  const dims=m.dimensions_xyz,origin=m.domain_origin_global_xyz_local_m;
  const span=m.domain_span_local_m;
  const pitch=m.pitch_local_m;
  if(!Array.isArray(dims)||!Array.isArray(origin)||!Array.isArray(span)||!Number.isFinite(pitch)||!Array.isArray(m.root_global_xyz_local_m)||!Number.isFinite(m.reference?.reference_integral_local_m3))throw Error('Asset manifest local domain/integral missing '+id);
  for(let i=0;i<3;i++)if(Math.abs(span[i]-dims[i]*pitch)>1e-5)throw Error('Asset span/pitch inconsistency '+id);
  if(!String(m.distance?.definition).startsWith('EDT(rho>='))throw Error('Distance sign unqualified '+id);
  return {id,dims,origin,span,pitch,manifest:m};
}
function allBounds(fixture){
  const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
  for(const f of fixture.fixtures){if(!f.bounds_world_xyz||f.bounds_world_xyz.length!==2)throw Error('Missing fixture bounds '+f.id);for(let i=0;i<3;i++){
    if(!Number.isFinite(f.bounds_world_xyz[0][i])||!Number.isFinite(f.bounds_world_xyz[1][i])||f.bounds_world_xyz[1][i]<=f.bounds_world_xyz[0][i])throw Error('Invalid fixture bounds '+f.id);
    lo[i]=Math.min(lo[i],f.bounds_world_xyz[0][i]);hi[i]=Math.max(hi[i],f.bounds_world_xyz[1][i]);
  }}return [lo,hi];
}
export async function loadHeldAssets(progress){
  progress('Reading qualified held fixture and asset manifests…');
  const response=await fetch('assets/held-fixture.json');if(!response.ok)throw Error('Qualified held fixture unavailable');
  const fixtureBytes=await response.arrayBuffer(),fixtureSha256=await sha(fixtureBytes),fixture=JSON.parse(new TextDecoder().decode(fixtureBytes));
  if(fixture.version!==2||!Array.isArray(fixture.fixtures)||fixture.fixtures.length===0||fixture.basis_count!==2||fixture.distinct_crown_basis_count!==1||fixture.same_B_basis_shared_by_two_instances!==true||fixture.body_eta_already_baked_no_second_compression!==true||fixture.kappa!==.019||Object.keys(fixture.assets??{}).sort().join(',')!=='body,crown-b')throw Error('Invalid held v2 fixture contract');
  const assets={};
  for(const id of assetIds){
    const filename=fixture.assets[id],r=await fetch('assets/'+filename);if(!r.ok)throw Error('Asset manifest unavailable '+id);
    const raw=await r.arrayBuffer(),manifest=JSON.parse(new TextDecoder().decode(raw));
    const manifestSha256=await sha(raw);
    if(!fixture.asset_manifest_sha256?.[id]||fixture.asset_manifest_sha256[id]!==manifestSha256)throw Error('Manifest pin mismatch '+id);
    const a=normalizeManifest(id,manifest);a.manifestSha256=manifestSha256;
    for(const kind of ['density','distance']){
      const info=manifest[kind],data=await verifiedFile(info.file,info.sha256,info.bytes);
      if(data.byteLength!==a.dims.reduce((x,y)=>x*y,1)*2)throw Error('R16 size/domain mismatch '+id+'/'+kind);
      a[kind]=new Uint16Array(data);
    }
    assets[id]=a;
  }
  const ids=new Set();for(const f of fixture.fixtures){if(ids.has(f.id))throw Error('Duplicate held fixture '+f.id);ids.add(f.id);packParts(f.parts);for(const p of f.parts){const r=assets[p.asset_id].manifest.root_global_xyz_local_m;if(r.some((v,i)=>Math.abs(v-p.root_global_xyz_local_m[i])>1e-6))throw Error('Fixture root differs from asset manifest '+f.id+'/'+p.asset_id);}}
  return {fixture,fixtureSha256,assets,bounds:allBounds(fixture)};
}
export class HeldAdapter{
  static async create(canvas,progress){
    const data=await loadHeldAssets(progress),gpu=await Gpu.open(canvas);
    if(gpu.device.limits.maxSampledTexturesPerShaderStage<16)throw Error('Device sampled texture stage limit below held 16-slot contract');
    const codes=Object.fromEntries(await Promise.all(shaderNames.map(async n=>{
      const r=await fetch('shaders/'+n+'.wgsl');if(!r.ok)throw Error('Missing shader '+n);return[n,await r.text()];
    })));
    const a=new HeldAdapter();Object.assign(a,{...data,gpu,codes});
    const s=new Scene(gpu,codes,0,0);a.scene=s;s.heldMode=true;s.bounds=()=>a.bounds;s.fixedFocus=a.bounds[0].map((x,i)=>(x+a.bounds[1][i])/2);s.target=()=>[s.fixedFocus[0]+s.camera.panX,s.fixedFocus[1]+s.camera.panY,s.fixedFocus[2]];
    const maxExtent=Math.max(...a.bounds[0].map((x,i)=>a.bounds[1][i]-x));
    s.camera={yaw:.3,pitch:-.05,distance:Math.max(3000,maxExtent*1.5),panX:0,panY:0};
    try{
      await s.init(progress);
      a.textures={};for(const id of assetIds){const x=a.assets[id];a.textures[id]={density:uploadHalf3d(gpu,id+' density',x,x.density),distance:uploadHalf3d(gpu,id+' distance',x,x.distance)};}
      s.heldDensity=a.textures.body.density;
      a.partBuffer=gpu.buffer('eight held poses',8*24*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.domainBuffer=gpu.buffer('two held domains',2*8*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      gpu.device.queue.writeBuffer(a.domainBuffer,0,packDomains(a.assets));
      s.heldInputs=()=>[[18,a.textures.body.distance.createView()],[19,a.textures['crown-b'].density.createView()],[20,a.textures['crown-b'].distance.createView()],[21,a.partBuffer],[22,a.domainBuffer]];
      a.select(a.fixture.fixtures[0].id);await frameFence(gpu);return a;
    }catch(error){await s.dispose();throw error;}
  }
  select(id){
    const f=this.fixture.fixtures.find(v=>v.id===id);if(!f)throw Error('Unknown fixture '+id);
    this.packed=packParts(f.parts);this.gpu.device.queue.writeBuffer(this.partBuffer,0,this.packed);
    this.current=f;this.scene.epoch++;return f;
  }
  metadata(){return {fixtureId:this.current.id,description:this.current.description,parts:this.current.parts,fixtureSha256:this.fixtureSha256,fixtureBounds:this.current.bounds_world_xyz,commonBounds:this.bounds,sourceHashes:Object.fromEntries(assetIds.map(id=>[id,{manifest:this.assets[id].manifestSha256,density:this.assets[id].manifest.density.sha256,distance:this.assets[id].manifest.distance.sha256}])),componentIntegrals:this.current.parts.map(p=>{const a=this.assets[p.asset_id],local=a.manifest.reference.reference_integral_local_m3,b=p.b_world_per_local_m;return{id:p.id,assetId:p.asset_id,sWorldPerLocalM:p.s_world_per_local_m,g:p.g,bWorldPerLocalM:b,worldNativePitchM:b*a.pitch,localReferenceQuadratureM3:local,worldReferenceQuadratureM3BeforeMax:p.Aseed*b**3*local,worldJacobian:b**3,scope:'Per-part texel-centre native rho/d quadrature transformed by b³; nonlinear filtered continuous integral and joint max ownership not claimed'};}),sourceMode:'held static native R16 component max field',poseSourceTimeForAuthoringSeconds:this.current.source_time_for_pose_s,rendererTimeSeconds:0,legacyPdeSteps:0,logicalGpuBytes:this.gpu.bytes,allocations:this.gpu.allocations,qualification:'UNQUALIFIED candidate assets and growth/attachment cues; only frozen field hashes and offline math checks passed',limitations:'Static authoring and common consumer query only; no lifecycle, weather, full sky or budget acceptance'};}
  async probe(ui){
    const s=this.scene,g=this.gpu,d=g.device,parts=this.current.parts,points=[];
    for(const p of parts)for(const delta of[[0,0,0],[4,0,0],[-4,0,0],[0,4,0],[0,-4,0],[0,0,4],[0,0,-4],[20,10,10]])points.push(forwardPoint(p,p.root_global_xyz_local_m.map((v,i)=>v+delta[i])));
    const [lo,hi]=this.bounds;for(let z=0;z<12;z++)for(let y=0;y<12;y++)for(let x=0;x<12;x++)points.push(lo.map((v,i)=>v+(hi[i]-v)*([x,y,z][i]+.5)/12));
    const input=new Float32Array(points.length*4);for(let i=0;i<points.length;i++)input.set(points[i],i*4);
    const bytes=input.byteLength,uniform=d.createBuffer({size:176,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),positions=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),output=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),read=d.createBuffer({size:bytes,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
    try{
      this.probePipeline??=await g.compute('held shared coefficient oracle',s.codes.optics+`\n@group(0) @binding(25) var<storage,read> queryPoints:array<vec4f>;@group(0) @binding(26) var<storage,read_write> queryOut:array<vec4f>;@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id:vec3u){if(id.x>=arrayLength(&queryPoints)){return;}let x=queryPoints[id.x].xyz;let c=coefficients(x,1.);queryOut[id.x]=vec4f(componentQuery(x,false),componentQuery(x,true),c);}`);
      s.write(uniform,{wind:0,windIntegral:0,moist:0,dry:0,lift:0,frontX:0,storm:0},ui,null,0);
      d.queue.writeBuffer(positions,0,input);
      const bg=g.group(this.probePipeline,[[0,uniform],[1,s.heldDensity.createView()],[3,s.clamp],...s.heldInputs(),[25,positions],[26,output]]);
      const e=d.createCommandEncoder(),pass=e.beginComputePass();pass.setPipeline(this.probePipeline);pass.setBindGroup(0,bg);pass.dispatchWorkgroups(Math.ceil(points.length/64));pass.end();e.copyBufferToBuffer(output,0,read,0,bytes);g.submit(e);
      await read.mapAsync(GPUMapMode.READ);const data=new Float32Array(read.getMappedRange());let maxQ=0,maxRaw=0,maxSigma=0,invalid=0,positive=0;const examples=[];
      const kappa=.0045*ui.extinctionScale;
      for(let i=0;i<points.length;i++){
        const x=Array.from(input.subarray(i*4,i*4+3)),a=data.subarray(i*4,i*4+4),q=heldPoint(parts,this.assets,x),raw=heldPoint(parts,this.assets,x,true);
        maxQ=Math.max(maxQ,Math.abs(a[0]-q));maxRaw=Math.max(maxRaw,Math.abs(a[1]-raw));maxSigma=Math.max(maxSigma,Math.abs(a[2]-q*kappa));
        if(!Array.from(a).every(Number.isFinite)||a[3]!==0||a[0]<0||a[1]<0||a[2]<0)invalid++;if(a[0]>0)positive++;
        if(examples.length<12&&q>0)examples.push({x,gpu:a[0],cpu:q,rawGpu:a[1],rawCpu:raw});
      }
      read.unmap();assertGpuHealthy(g);
      return {pass:invalid===0&&maxQ<=.002&&maxRaw<=.002&&maxSigma<=.002*kappa,points:points.length,positive,invalid,maxAbsQ:maxQ,maxAbsRaw:maxRaw,maxAbsSigma:maxSigma,declaredToleranceQ:.002,declaredToleranceSigma:.002*kappa,examples,scope:'Actual shared componentQuery and coefficients at root neighborhoods plus common bound grid; f32 inverse and hardware R16 filtering compared with independent JS trilinear. No beauty or performance acceptance.'};
    }finally{for(const x of[uniform,positions,output,read])x.destroy();}
  }
}
