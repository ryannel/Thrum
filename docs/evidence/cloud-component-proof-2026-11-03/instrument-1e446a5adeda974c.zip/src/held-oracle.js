import {halfToFloat} from './reference.js';
export const MAX_PARTS=8, PART_FLOATS=24, DOMAIN_FLOATS=8;
export const assetIds=['body','crown-b'];
const f32=Math.fround;
export function packParts(parts){
  if(parts.length>MAX_PARTS)throw Error('More than eight held parts');
  const a=new Float32Array(MAX_PARTS*PART_FLOATS);
  for(let j=0;j<parts.length;j++){
    const p=parts[j],i=j*PART_FLOATS,index=assetIds.indexOf(p.asset_id);
    if(index<0||!Number.isInteger(index))throw Error('Unknown asset '+p.asset_id);
    if(!Array.isArray(p.Q_columns)||p.Q_columns.length!==3||p.Q_columns.some(v=>v.length!==3))throw Error('Q_columns must be three column vectors');
    if(!(p.b_world_per_local_m>0)||!(p.Aseed>=0))throw Error('Invalid held gain');
    if(!(p.s_world_per_local_m>0)||!Number.isFinite(p.g)||Math.abs(p.b_world_per_local_m-p.s_world_per_local_m*p.g)>2e-5)throw Error('Held b must be s_i*g');
    const q=p.Q_columns.map(v=>v.map(f32));
    for(let k=0;k<3;k++)for(let n=0;n<3;n++){
      const dot=q[k].reduce((s,v,t)=>s+v*q[n][t],0);
      if(Math.abs(dot-(k===n?1:0))>2e-4)throw Error('Q is not orthogonal');
    }
    if(Math.abs(p.K_world_per_rotated_local_y[1])>1e-7)throw Error('K_y must be zero');
    a.set([...p.C_world_m,p.b_world_per_local_m],i);
    a.set([...q[0],p.Aseed],i+4);
    a.set([...q[1],index],i+8);
    a.set([...q[2],1],i+12);
    a.set([...p.K_world_per_rotated_local_y,p.root_global_xyz_local_m[0]],i+16);
    a.set([p.root_global_xyz_local_m[1],p.root_global_xyz_local_m[2],0,0],i+20);
  }
  return a;
}
export function packDomains(assets){
  const a=new Float32Array(assetIds.length*DOMAIN_FLOATS);
  for(let j=0;j<assetIds.length;j++){
    const x=assets[assetIds[j]],i=j*DOMAIN_FLOATS;
    if(!x||x.origin.length!==3||x.span.length!==3||x.dims.length!==3)throw Error('Missing domain '+assetIds[j]);
    if(x.span.some(v=>v<=0)||x.dims.some(v=>!Number.isInteger(v)||v<=0))throw Error('Invalid domain '+assetIds[j]);
    a.set([...x.origin,x.pitch],i);a.set([...x.span,0],i+4);
  }
  return a;
}
export function inversePoint(p,x){
  const b=p.b_world_per_local_m,C=p.C_world_m,K=p.K_world_per_rotated_local_y,Q=p.Q_columns,r=p.root_global_xyz_local_m;
  const h=(x[1]-C[1])/b,v=x.map((z,i)=>(z-C[i]-K[i]*h)/b);
  return r.map((z,i)=>z+Q[i].reduce((s,t,j)=>s+t*v[j],0));
}
export function forwardPoint(p,a){
  const Q=p.Q_columns,r=p.root_global_xyz_local_m,v=[0,1,2].map(i=>Q.reduce((s,col,j)=>s+col[i]*(a[j]-r[j]),0));
  return p.C_world_m.map((z,i)=>z+p.b_world_per_local_m*v[i]+p.K_world_per_rotated_local_y[i]*v[1]);
}
export function sampleHalf(data,dims,uv){
  const coord=uv.map((v,i)=>v*dims[i]-.5),base=coord.map(Math.floor),f=coord.map((v,i)=>v-base[i]);
  let sum=0;for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){
    const ij=[x,y,z].map((v,i)=>Math.max(0,Math.min(dims[i]-1,base[i]+v)));
    const weight=[x,y,z].reduce((v,t,i)=>v*(t?f[i]:1-f[i]),1);
    sum+=halfToFloat(data[(ij[2]*dims[1]+ij[1])*dims[0]+ij[0]])*weight;
  }return sum;
}
export function heldPoint(parts,assets,x,raw=false){
  let q=0;for(const p of parts){if(p.Aseed<=0)continue;
    const asset=assets[p.asset_id],a=inversePoint(p,x),uv=a.map((v,i)=>(v-asset.origin[i])/asset.span[i]);
    if(uv.some(v=>v<0||v>1))continue;
    const rho=sampleHalf(asset.density,asset.dims,uv);
    if(rho<=0)continue;
    const d=raw?0:sampleHalf(asset.distance,asset.dims,uv);
    const t=raw?1:(()=>{let u=Math.max(0,Math.min(1,(d+8)/16));return u*u*(3-2*u);})();
    q=Math.max(q,p.Aseed*rho*t);
  }return q;
}
