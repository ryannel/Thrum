from pathlib import Path
import os,sys,json,hashlib,platform,resource,time,threading,subprocess,gc
import numpy as np, scipy
from scipy import ndimage as ndi
ROOT=Path(__file__).resolve().parent;INPUT=ROOT.parent/'cloud-authored-master/cloud-03-256.density.r16f';LIMIT=512*1024**2
PEAK=0;DONE=False

def watch():
 global PEAK
 while not DONE:
  try:
   rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(os.getpid())]).strip())*1024;PEAK=max(PEAK,rss)
   if rss>448*1024**2:
    (ROOT/('MEMORY-FAILURE-'+str(os.getpid())+'.json')).write_text(json.dumps({'rss_bytes':rss,'early_stop_bytes':448*1024**2,'absolute_limit_bytes':LIMIT,'scope':'early process RSS stop'},indent=2));os._exit(72)
  except Exception:pass
  time.sleep(.1)
threading.Thread(target=watch,daemon=True).start()
def check(stage):
 peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
 if peak>LIMIT:raise MemoryError(stage+' exceeded512MiB')
 print(stage,'rss_peak_MiB',round(peak/1024**2,2),flush=True)
def sha(p):
 h=hashlib.sha256()
 with open(p,'rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def smooth(x):
 v=np.clip(x,0,1);return v*v*(3-2*v)
def reduce_cell(a,which):
 out=a[:-1,:-1,:-1].copy()
 op=np.minimum if which=='min'else np.maximum
 for z in[0,1]:
  for y in[0,1]:
   for x in[0,1]:
    if z or y or x:op(out,a[z:z+out.shape[0],y:y+out.shape[1],x:x+out.shape[2]],out=out)
 return out

def cell_lower(rho,d):
 a=reduce_cell(rho,'min');b=reduce_cell(d,'min');a*=smooth((b+8)/16);return a

def ball_radius(good,root,origin):
 # Bad cell boxes cover every uncertified interpolation location. Exact box-distance minimum.
 shape=good.shape;cx=origin[0]+2*(np.arange(shape[2])+1);cy=origin[1]+2*(np.arange(shape[1])+1)
 dx=np.maximum(np.abs(cx-root[0])-1,0)**2;dy=np.maximum(np.abs(cy-root[1])-1,0)**2;best=np.inf
 for iz in range(shape[0]):
  bad=~good[iz]
  if not bad.any():continue
  dz=max(abs(origin[2]+2*(iz+1)-root[2])-1,0)**2;dd=dx[None,:]+dy[:,None]+dz;best=min(best,float(dd[bad].min()))
 domain=np.array(good.shape[::-1])*2
 edge=float(np.min(np.r_[np.array(root)-(np.array(origin)+1),(np.array(origin)+domain+1)-root]))
 return max(0,min(np.sqrt(best),edge)-.001)

def potential_support(rho,d,root,origin):
 r=reduce_cell(rho,'max');dd=reduce_cell(d,'max');possible=(r>0)&(dd>-8);del r,dd
 lo=np.array([np.inf]*3);hi=-lo;radius=0
 for iz in range(possible.shape[0]):
  yy,xx=np.nonzero(possible[iz]);
  if not len(xx):continue
  centres=np.stack([origin[0]+2*(xx+1),origin[1]+2*(yy+1),np.full(len(xx),origin[2]+2*(iz+1))],1);lo=np.minimum(lo,centres.min(0)-1);hi=np.maximum(hi,centres.max(0)+1);radius=max(radius,float(np.sqrt(np.sum((np.abs(centres-root)+1)**2,1)).max()))
 return {'local_support_bbox_min_xyz_m':lo.tolist(),'local_support_bbox_max_xyz_m':hi.tolist(),'conservative_radius_about_root_local_m':radius,'bound':'every potentially nonzero trilinear cell corner; separate maxrho>0,maxd>−8; may overestimate actual support'}

def bounds(a,t,origin):
 mask=a>t;count=int(np.count_nonzero(mask))
 if not count:return None
 starts=[];ends=[]
 for axis in[2,1,0]:
  line=np.any(mask,axis=tuple(k for k in range(3)if k!=axis));ids=np.flatnonzero(line);starts.append(int(ids[0]));ends.append(int(ids[-1]))
 return {'sample_min_xyz_m':(np.array(origin)+(np.array(starts)+.5)*2).tolist(),'sample_max_xyz_m':(np.array(origin)+(np.array(ends)+.5)*2).tolist(),'sample_count':count,'filled_volume_local_m3':count*8}

def frame(q,root,origin):
 # Density-weighted upper crown centre, selected deterministically before previews.
 yy=origin[1]+2*np.arange(q.shape[1])+1;w=q*(yy[None,:,None]>=root[1]+20);mass=float(w.sum(dtype=np.float64));coords=[]
 for axis,dim in [(2,0),(1,1),(0,2)]:
  ww=w.sum(tuple(a for a in range(3)if a!=axis),dtype=np.float64);coords.append(float(ww@(origin[dim]+2*np.arange(q.shape[axis])+1)/mass))
 u=np.array(coords)-root;u/=np.linalg.norm(u);right=np.cross(u,[0,0,1.]);right/=np.linalg.norm(right);forward=np.cross(right,u);return {'upper_density_centroid_global_xyz_m':coords,'root_to_crown_orthoframe_columns':np.stack([right,u,forward],axis=0).tolist(),'definition':'outer list contains right/up/forward COLUMN VECTORS; matrix=np.array(columns).T; up=normalized upper density centroid−root; right=cross(up,+Z)'}

def largest_connected_mask(mask):
 labels,n=ndi.label(mask,structure=ndi.generate_binary_structure(3,1))
 if n==0:return np.zeros_like(mask,dtype=bool),0
 counts=np.bincount(labels.ravel());counts[0]=0;return labels==int(counts.argmax()),int(n)

def coverage(q,lb,origin):
 core=np.zeros(lb.shape,bool);Y=origin[1]+2*(np.arange(lb.shape[1])+1)
 for iy,y in enumerate(Y):
  inside=lb[:,iy,:]>=.01;d=ndi.distance_transform_edt(np.pad(inside,1),sampling=2)[1:-1,1:-1];radius=.32*max(abs(y-1-233),abs(y+1-233));core[:,iy,:]=d>radius+2*np.sqrt(2)+.001
 core,n=largest_connected_mask(core)
 denominator=int(np.count_nonzero(q>=.01));area=int(np.count_nonzero(np.any(q>=.01,axis=1)));cells=int(core.sum());fp=int(np.count_nonzero(np.any(core,axis=1)));starts=[];ends=[]
 for axis in[2,1,0]:
  ids=np.flatnonzero(np.any(core,axis=tuple(k for k in range(3)if k!=axis)));starts.append(int(ids[0])if len(ids)else 0);ends.append(int(ids[-1])if len(ids)else 0)
 dst=ROOT/'body.wet-core.cells.u8';core.astype('u1').tofile(dst)
 result={'threshold':.01,'cell_lower_threshold':.01,'youngest_mature_age_range_s':[60,160],'inverse_shear_norm_bound':.32,'continuous_guard_local_m':'horizontal disk .32*maxabsYcelloffset +2sqrt(2)m +.001m; per-cell separate-minrho/mind product>=.01','connectivity':'largest6-connected face-sharing certified cell region','component_count_before_selection':int(n),'core_cells':cells,'volume_local_m3':cells*8,'body_native_filled_voxels':denominator,'volume_fraction':cells/max(denominator,1),'projected_footprint_fraction':fp/max(area,1),'footprint_local_m2':fp*4,'body_native_footprint_local_m2':area*4,'bounds_cell_centres_global_xyz_m':[(np.array(origin)+2*(np.array(starts)+1)).tolist(),(np.array(origin)+2*(np.array(ends)+1)).tolist()]if cells else None,'required_volume_fraction':.25,'required_footprint_fraction':.25,'pass':cells/max(denominator,1)>=.25 and fp/max(area,1)>=.25,'mask':{'file':dst.name,'sha256':sha(dst),'dims_xyz':list(core.shape[::-1]),'storage':'U8 cell flags, Xfastest; centres origin+2*(index+1)'}}
 return result

def catalogue(lb,origin):
 fullgood=lb>=.041;iy0=max(0,int((232-origin[1])/2)-1);iy1=min(lb.shape[1],int((278-origin[1])/2));band=lb[:,iy0:iy1,:];bandorigin=np.array(origin)+np.array([0,2*iy0,0]);good=band>=.041;dd=ndi.distance_transform_edt(np.pad(good,1),sampling=2)[1:-1,1:-1,1:-1].astype(np.float32);r=dd-np.sqrt(3)-.001;Y=bandorigin[1]+2*(np.arange(band.shape[1])+1);eligible=good&(r>=10)&(Y[None,:,None]>=244)&(Y[None,:,None]<=260);blur=ndi.gaussian_filter(dd,3);sites=[]
 for j in range(8):
  best=None
  for z in range(eligible.shape[0]):
   yy,xx=np.nonzero(eligible[z])
   if not len(xx):continue
   px=bandorigin[0]+2*(xx+1);py=bandorigin[1]+2*(yy+1);pz=bandorigin[2]+2*(z+1);score=py+.02*np.hypot(px-299,pz-167)
   for prior in sites:
    v=prior['root_global_xyz_m'];score[(px-v[0])**2+(py-v[1])**2+(pz-v[2])**2<40**2]=-np.inf
   k=int(np.argmax(score))
   if np.isfinite(score[k])and(best is None or score[k]>best[0]):best=(float(score[k]),z,int(yy[k]),int(xx[k]),np.array([px[k],py[k],pz]))
  if best is None:break
  _,z,y,x,p=best;gradient=np.array([(blur[z,y,x+1]-blur[z,y,x-1])/4,(blur[z,y+1,x]-blur[z,y-1,x])/4,(blur[z+1,y,x]-blur[z-1,y,x])/4]);normal=-gradient;normal/=max(np.linalg.norm(normal),1e-30);up=np.array([normal[0],max(normal[1],.75),normal[2]]);up/=np.linalg.norm(up)
  if up[1]<np.sqrt(.5):up=np.r_[up[0],1.,up[2]];up/=np.linalg.norm(up)
  right=np.cross(up,[0,0,1.]);right/=max(np.linalg.norm(right),1e-30);fwd=np.cross(right,up);rp=ball_radius(fullgood,p,np.array(origin));sites.append({'id':f'body-shoulder-{j}','root_global_xyz_m':p.tolist(),'actual_q041_ball_radius_local_m':rp,'parent_age165_world_radius_lower_m':rp*4*(np.sqrt(4+.33**2)-.33)/2,'outward_normal_from_smoothed_attach_distance':normal.tolist(),'desired_crown_world_frame_columns':np.stack([right,up,fwd],axis=0).tolist(),'scope':'finite content catalogue; actual interpolationcell-ball certificate, not runtime/admission/exposure result'})
 return sites

RECIPES=[{'id':'body','origin':[64,176,0],'span':[384,128,512],'root':[299,233,167],'eta':.6},{'id':'crown-b','origin':[104,160,128],'span':[192,192,192],'root':[225,265,197],'rounded_controls':[[225,265,197,33],[221,295,207,40]],'w_half':8}]

# Support-only module. Use stage.py in fresh processes; no monolithic cooking entry point.
