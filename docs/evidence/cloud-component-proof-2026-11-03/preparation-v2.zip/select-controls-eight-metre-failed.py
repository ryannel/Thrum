from pathlib import Path
import struct,mmap,json,math,heapq,functools,resource,hashlib
R=Path(__file__).resolve().parent;P=R.parent/'cloud-component-assets';SRC=R.parent/'cloud-authored-master/cloud-03-256.density.r16f';F=SRC.open('rb');MM=mmap.mmap(F.fileno(),0,access=mmap.ACCESS_READ)
def check():
 if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>128*1024**2:raise MemoryError('scalarcontrolselection128MiBstop')
@functools.lru_cache(maxsize=50000)
def rho(i):
 if any(v<0 or v>=256 for v in i):return 0.
 return struct.unpack_from('<e',MM,2*((i[2]*256+i[1])*256+i[0]))[0]
def xyz(i):return tuple(2*v+1 for v in i)
def idx(p):return tuple(int((v-1)//2)for v in p)
def norm(v):return math.sqrt(sum(q*q for q in v))
def dist(a,b):return norm([x-y for x,y in zip(a,b)])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def positive_radius(p):
 i=idx(p);best=24.;v0=rho(i)
 if v0<.041:return 0.,v0
 for shell in range(1,13):
  for dz in range(-shell,shell+1):
   for dy in range(-shell,shell+1):
    for dx in range(-shell,shell+1):
     if max(abs(dx),abs(dy),abs(dz))!=shell:continue
     dd=2*math.sqrt(dx*dx+dy*dy+dz*dz)
     if dd<best and rho((i[0]+dx,i[1]+dy,i[2]+dz))<.041:best=dd
  if best<=2*shell:break
 return max(0,best-2*math.sqrt(3)),v0

def pathfind(start,goal):
 si,gi=idx(start),idx(goal);low=tuple(min(a,b)-6 for a,b in zip(si,gi));high=tuple(max(a,b)+6 for a,b in zip(si,gi));cost={si:0.};parent={};heap=[(2*dist(si,gi),si)];pops=0
 while heap:
  if len(cost)>32000 or len(heap)>192000:raise RuntimeError('boundedrawpathcapacityfailure')
  _,u=heapq.heappop(heap);pops+=1
  if pops%1024==0:check()
  if u==gi:
   path=[u]
   while u!=si:u=parent[u];path.append(u)
   return list(reversed([xyz(i)for i in path])),len(cost)
  for ax in range(3):
   for sign in[-1,1]:
    v=list(u);v[ax]+=sign;v=tuple(v)
    if any(v[i]<low[i]or v[i]>high[i]for i in range(3))or rho(v)<.041:continue
    alt=cost[u]+2*(1+.1/((rho(u)+rho(v))*.5+.01))
    if alt<cost.get(v,math.inf):cost[v]=alt;parent[v]=u;heapq.heappush(heap,(alt+2*dist(v,gi),v))
 raise RuntimeError('noq041rawpathinboundedcorridor')
def segdist(p,a,b):
 ab=[y-x for x,y in zip(a,b)];v=[x-y for x,y in zip(p,a)];t=max(0,min(1,dot(v,ab)/dot(ab,ab)));return dist(p,[a[i]+t*ab[i]for i in range(3)])
def simplify(path):
 chosen=[0,len(path)-1]
 while len(chosen)<4:
  worst=(0,None)
  for lo,hi in zip(chosen,chosen[1:]):
   for k in range(lo+1,hi):
    d=segdist(path[k],path[lo],path[hi])
    if d>worst[0]:worst=(d,k)
  if worst[0]<=8:break
  chosen.append(worst[1]);chosen.sort()
 deviation=max(min(segdist(p,path[a],path[b])for a,b in zip(chosen,chosen[1:]))for p in path)
 if deviation>8:raise RuntimeError('rawpathcannotfit4control8mdeviation')
 return chosen,deviation
out=[]
for name in['crown-a','crown-b']:
 m=json.loads((P/(name+'.json')).read_text());root=tuple(m['root_global_xyz_local_m']);guide=m['root_to_crown_frame']['upper_density_centroid_global_xyz_m'];origin=m['domain_origin_global_xyz_local_m'];span=m['domain_span_local_m'];candidates=[]
 ranges=[]
 for k in range(3):
  vals=[2*i+1 for i in range(256)if abs(2*i+1-guide[k])<=20 and ((k==1 and 2*i+1>=295)or(k!=1 and origin[k]+52<=2*i+1<=origin[k]+span[k]-52))];ranges.append(vals)
 for x in ranges[0]:
  for y in ranges[1]:
   for z in ranges[2]:
    p=(x,y,z);r,q=positive_radius(p)
    if r>0:candidates.append((r,-dist(p,guide),p,q))
 check()
 if not candidates:raise RuntimeError(name+' nooccupiedheadwithdomainmargin')
 best=max(candidates);head=best[2];path,visited=pathfind(root,head);chosen,deviation=simplify(path);length=[0.]
 for a,b in zip(path,path[1:]):length.append(length[-1]+dist(a,b))
 nodes=[{'center_global_xyz_local_m':list(path[i]),'radius_local_m':33+7*length[i]/length[-1]}for i in chosen];margins=[min(min(n['center_global_xyz_local_m'][k]-n['radius_local_m']-8-origin[k],origin[k]+span[k]-n['center_global_xyz_local_m'][k]-n['radius_local_m']-8)for k in[0,2])for n in nodes]
 if min(margins)<4-1e-9:raise RuntimeError(name+' simplifiedroundsupportdomainmarginfailure')
 out.append({'id':name,'domain_origin_global_xyz_local_m':origin,'domain_span_local_m':span,'root':list(root),'guide_existing_upper_centroid':guide,'chosen_head_native_xyz_local_m':list(head),'head_rawrho':best[3],'head_conservative_raw_q041_positive_ball_radius_local_m':best[0],'head_candidates_count':len(candidates),'path_rawq_min':min(rho(idx(p))for p in path),'path_vertex_count':len(path),'path_visited_nodes':visited,'path_global_xyz_local_m':[list(p)for p in path],'roundmask_controls':nodes,'maximum_geodesic_path_deviation_to_control_segments_local_m':deviation,'minimum_control_support_box_margin_to_existing_domain_XZ_local_m':min(margins),'Y_zero_collar_basis':'originalrawsampleY175..337 (cell174..338) inside160..352; no Yface density for anymask','root_head_distance_local_m':dist(root,head),'unknowns':'newroundmask/root/headpost-distancecertificates andgeometry/appearance notcooked/notqualified'})
record={'scope':'designcontrolsfromexistingrawscalarreads,noV2volumeallocation/cook','source_sha256':'42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9','threshold_rawq':.041,'w_half_local_m':8,'selection_preflight_sha256':hashlib.sha256((R/'CONTROL-PREFLIGHT.md').read_bytes()).hexdigest(),'components':out,'peak_process_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()};(R/'controls.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'controls':[{'id':v['id'],'nodes':v['roundmask_controls'],'headq':v['head_rawrho'],'headball':v['head_conservative_raw_q041_positive_ball_radius_local_m'],'deviation':v['maximum_geodesic_path_deviation_to_control_segments_local_m'],'margin':v['minimum_control_support_box_margin_to_existing_domain_XZ_local_m']}for v in out],'peakMiB':record['peak_process_rss_bytes']/2**20},indent=2))
