from pathlib import Path
import json,hashlib,numpy as np
from geometry import bodypart,crownpart,matrix
R=Path(__file__).resolve().parent;metas={n:json.loads((R/(n+'.json')).read_text())for n in['body','crown-b']};inst=json.loads((R/'instances.json').read_text())['instances'];fixtures=[]
def add(id,t,parts,description):
 lo=np.array([np.inf]*3);hi=-lo
 for p in parts:
  assert abs(p['b_world_per_local_m']-p['s_world_per_local_m']*p['g'])<1e-9;m=metas[p['asset_id']]['potential_support'];corners=np.array([[x,y,z]for x in[m['local_support_bbox_min_xyz_m'][0],m['local_support_bbox_max_xyz_m'][0]]for y in[m['local_support_bbox_min_xyz_m'][1],m['local_support_bbox_max_xyz_m'][1]]for z in[m['local_support_bbox_min_xyz_m'][2],m['local_support_bbox_max_xyz_m'][2]]]);v=(corners-p['root_global_xyz_local_m'])@matrix(p).T+p['C_world_m'];lo=np.minimum(lo,v.min(0));hi=np.maximum(hi,v.max(0))
 fixtures.append({'id':id,'description':description,'source_time_for_pose_s':t,'parts':parts,'bounds_world_xyz':[lo.tolist(),hi.tolist()]})
for id,t in[('body-mature',70),('b1-seed',70),('b1-ramp',72),('b1-half',94.5),('b1-full',115),('b2-seed',120),('b2-ramp',122),('b2-half',144.5),('b2-full',165)]:
 parts=[bodypart(t,metas['body'])]
 if t>=100:parts.append(bodypart(t-100,metas['body'],birth=100))
 if id!='body-mature':parts.append(crownpart(inst[0],t-70,70,metas['crown-b'],metas['body']))
 if t>=120:parts.append(crownpart(inst[1],t-120,120,metas['crown-b'],metas['body']))
 add(id,t,parts,'candidateheldgeometry; sameBbasisfirsts6seconds5, etaalreadybakedBODY; contentUNQUALIFIED')
for id,baseid,i in[('b1-alone','b1-full',0),('b2-alone','b2-full',1)]:
 base=next(f for f in fixtures if f['id']==baseid);p=next(p for p in base['parts']if p['id'].startswith(inst[i]['id']));add(id,base['source_time_for_pose_s'],[p],'exactisolatedfullpose, SAMEBbasis withdifferentfixedQ/scale')
out={'version':2,'kappa':.019,'scope':'validhashedstaticUNQUALIFIEDinput; notassetadoption/clock/lifecycle/artpass','world_frame':'weather-regionregisteredXZ,R=[0,1239.2,0], meanwindtranslationremovedonlyforheldgeometry','basis_count':2,'distinct_crown_basis_count':1,'same_B_basis_shared_by_two_instances':True,'frame_contract':'Q_columnsOUTERLISTcolumnvectors; v=Q(a-root),X=C+bv+Kv.y; b=s_world_per_local_m*g','asset_manifest_sha256':{n:hashlib.sha256((R/(n+'.json')).read_bytes()).hexdigest()for n in metas},'assets':{n:n+'.json'for n in metas},'body_eta_already_baked_no_second_compression':True,'fixtures':fixtures};(R/'held-fixture.json').write_text(json.dumps(out,indent=2)+'\n');print('fixtureSHA',hashlib.sha256((R/'held-fixture.json').read_bytes()).hexdigest())
