# Each invocation runs one bounded phase in a fresh process. See STAGED-COST-PLAN.md.
from pathlib import Path
import json,sys,platform,gc,resource
import numpy as np,scipy
from scipy import ndimage as ndi
import cook_support as C
from checks import validate_dependency_chain
R=C.ROOT;name,stage=sys.argv[1:3];rec=next(v for v in C.RECIPES if v['id']==name);origin=np.array(rec['origin']);dims=np.array(rec['span'])//2

def rss():return int(C.subprocess.check_output(['ps','-o','rss=','-p',str(C.os.getpid())]).strip())*1024

def reserve(label,mb):
 now=rss()
 if now+mb*1024**2>384*1024**2:raise MemoryError(f'Preallocation stop {label}: RSS{now} + allowance{mb}MiB >384MiB planned')
 print('reserve',label,'RSSMiB',round(now/1024**2,2),'additionalMiB',mb,flush=True)

def save(record,filename):
 record['stage_tool']={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'stage_recipe_sha256':C.sha(Path(__file__)),'helper_recipe_sha256':C.sha(Path(C.__file__))};record['process_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;print('stage_peak_rss_bytes',record['process_peak_rss_bytes'],flush=True);(R/filename).write_text(json.dumps(record,indent=2,default=lambda v:v.item()if isinstance(v,np.generic)else str(v))+'\n');return record

def loadfields():
 rm=json.loads((R/(name+'.rho-stage.json')).read_text());dm=json.loads((R/(name+'.distance-stage.json')).read_text());validate_dependency_chain(rm,dm,dims);assert rm['recipe']==rec and rm['source_sha256']=='42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9'
 for kind in['density','distance']:
  manifest=json.loads((R/(name+'.'+('rho'if kind=='density'else'distance')+'-stage.json')).read_text());p=R/(name+'.'+kind+'.r16f');assert p.stat().st_size==int(np.prod(dims))*2 and C.sha(p)==manifest['output_sha256']
 return tuple(np.fromfile(R/(name+'.'+kind+'.r16f'),dtype='<f2').reshape(tuple(dims[::-1])).astype(np.float32)for kind in['density','distance'])

if stage=='rho':
 assert C.sha(C.INPUT)=='42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9';reserve('native source and streamed crop',96);source=np.memmap(C.INPUT,mode='r',dtype='<f2',shape=(256,256,256));whole=float(source.sum(dtype=np.float64));start=origin//2;extra={}
 if name=='body':
  eta=.6;dstlo=origin[1]+2*np.arange(dims[1]);srclo=2*np.arange(256);mappedlo=233+eta*(srclo-233);mappedhi=mappedlo+2*eta;W=np.maximum(0,np.minimum(dstlo[:,None]+2,mappedhi[None,:])-np.maximum(dstlo[:,None],mappedlo[None,:]))/2;half=np.empty(tuple(dims[::-1]),dtype='<f2');ideal=0.;error=0.;before=0.
  assert np.max(np.abs(W.sum(1)-1))<1e-12
  for iz in range(0,dims[2],16):
   n=min(16,dims[2]-iz);src=source[start[2]+iz:start[2]+iz+n,:,start[0]:start[0]+dims[0]].astype(np.float32);before+=float(src.sum(dtype=np.float64));dst=np.zeros((n,dims[1],dims[0]),np.float64)
   for j in range(dims[1]):
    for i in np.flatnonzero(W[j]):dst[:,j,:]+=W[j,i]*src[:,i,:]
   raw=dst.astype('<f2');ideal+=float(dst.sum(dtype=np.float64));error=max(error,float(np.max(np.abs(dst-raw))));half[iz:iz+n]=raw
  assert abs(ideal-.6*whole)/whole<5e-13;extra={'vertical_compression_eta':.6,'anchor_y_local_m':233,'operation':'exact1Doverlap ofpiecewiseconstant sourcecells under ydst=233+.6(ysrc−233); Float64accumulation→R16','ideal_prehalf_integral_native_sum':ideal,'eta_times_whole_native_sum':.6*whole,'prehalf_relative_mass_error':abs(ideal-.6*whole)/whole,'source_equivalent_vertical_pitch_local_m':2/.6,'eta_already_baked_no_second_compression':True}
 else:
  rho=source[start[2]:start[2]+dims[2],start[1]:start[1]+dims[1],start[0]:start[0]+dims[0]].astype(np.float32);before=float(rho.sum(dtype=np.float64));zz,yy,xx=np.ogrid[:dims[2],:dims[1],:dims[0]];a=[origin[0]+2*xx+1,origin[1]+2*yy+1,origin[2]+2*zz+1];c0=np.array([225,265,197]);c1=np.array([221,295,207]);L=np.linalg.norm(c1-c0);e=(c1-c0)/L;k=7/L;v=[a[i]-c0[i]for i in range(3)];along=sum(v[i]*e[i]for i in range(3));h=np.sqrt(sum((v[i]-along*e[i])**2 for i in range(3)));ss=np.clip(along+k*h/np.sqrt(1-k*k),0,L);D=33+k*ss-np.sqrt((along-ss)**2+h*h);rho*=C.smooth((D+8)/16);half=rho.astype('<f2');error=float(np.max(np.abs(rho-half)));extra={'roundmask_controls':rec['rounded_controls'],'mask_halfwidth_local_m':8,'field':'exactmaxlinearlyvaryingballs33→40,smoothstep(−8,8,D); notassumedSDF','root_head_length_local_m':float(L),'radius_gradient':float(k),'additional_spatial_resampling':'none'}
 assert all(np.count_nonzero(v)==0 for v in[half[0],half[-1],half[:,0],half[:,-1],half[:,:,0],half[:,:,-1]]);p=R/(name+'.density.r16f');half.tofile(p);save({'source_sha256':C.sha(C.INPUT),'preflight_sha256':C.sha(R/'COOK-PREFLIGHT.md'),'recipe':rec,'dimensions_xyz':dims.tolist(),'source_whole_integral_native_sum':whole,'source_crop_integral_native_sum':before,'masked_raw_integral_native_sum':float(half.sum(dtype=np.float64)),'half_rounding_max_abs':error,'all_six_border_faces_zero':True,'conversion':extra,'output_sha256':C.sha(p),'output_bytes':p.stat().st_size},name+'.rho-stage.json')
elif stage in['distance-inside','distance-outside']:
 m=json.loads((R/(name+'.rho-stage.json')).read_text());p=R/(name+'.density.r16f');assert C.sha(p)==m['output_sha256'];reserve('read cropped classification',24);rho=np.fromfile(p,dtype='<f2').reshape(tuple(dims[::-1]));inside=rho.astype(np.float32)>=.001;del rho
 if stage=='distance-outside':np.logical_not(inside,out=inside)
 reserve('one fresh signed EDT',216);d=ndi.distance_transform_edt(inside,sampling=2).astype(np.float32);half=d.astype('<f2');error=float(np.max(np.abs(d-half)));p=R/(name+'.'+stage+'.r16f');half.tofile(p);save({'density_sha256':m['output_sha256'],'sign':stage,'dimensions_xyz':dims.tolist(),'half_rounding_max_abs_local_m':error,'output_sha256':C.sha(p),'output_bytes':p.stat().st_size},name+'.'+stage+'-stage.json')
elif stage=='distance':
 reserve('disjoint sign merge',48);records=[json.loads((R/(name+'.'+v+'-stage.json')).read_text())for v in['distance-inside','distance-outside']];arrays=[];rm=json.loads((R/(name+'.rho-stage.json')).read_text());validate_dependency_chain(rm,{'dimensions_xyz':dims.tolist(),'density_sha256':records[0]['density_sha256']},dims,records)
 for v,m in zip(['distance-inside','distance-outside'],records):
  p=R/(name+'.'+v+'.r16f');assert C.sha(p)==m['output_sha256'];arrays.append(np.fromfile(p,dtype='<f2').reshape(tuple(dims[::-1])))
 assert not np.any((arrays[0]>0)&(arrays[1]>0));d=arrays[0].astype(np.float32);d-=arrays[1];half=d.astype('<f2');p=R/(name+'.distance.r16f');half.tofile(p);save({'density_sha256':records[0]['density_sha256'],'definition':'EDT(rho>=.001)−EDT(rho<.001), opposite-class sample centres,2m; separatefreshprocess signs float32→half then disjointmerge; exactly same signedfloat32→half','dimensions_xyz':dims.tolist(),'min_decoded_local_m':float(half.min()),'max_decoded_local_m':float(half.max()),'half_rounding_max_abs_local_m':max(m['half_rounding_max_abs_local_m']for m in records),'output_sha256':C.sha(p),'output_bytes':p.stat().st_size,'sign_scratch_deleted_after_verified_merge':True},name+'.distance-stage.json')
 for v in['distance-inside','distance-outside']:(R/(name+'.'+v+'.r16f')).unlink()
elif stage=='root':
 reserve('decoded cropped fields and cell bounds',112);rho,d=loadfields();q=rho*C.smooth((d+8)/16);lb=C.cell_lower(rho,d);lb.tofile(R/(name+'.lower-proof.f32'));root=np.array(rec['root']);good=lb>=.041;radius=C.ball_radius(good,root,origin);potential=C.potential_support(rho,d,root,origin);end=(float(d.max())+10)/.3;assert np.count_nonzero(rho*C.smooth((d-.3*end+8)/16))==0;rm=json.loads((R/(name+'.rho-stage.json')).read_text());dm=json.loads((R/(name+'.distance-stage.json')).read_text());total=rm['masked_raw_integral_native_sum'];ref=float(q.sum(dtype=np.float64));out={'id':name,'source_sha256':rm['source_sha256'],'source_file_reference':'../cloud-authored-master/cloud-03-256.density.r16f','source_license':'CC0; see masterprovenance','domain_origin_global_xyz_local_m':origin.tolist(),'domain_span_local_m':rec['span'],'dimensions_xyz':dims.tolist(),'pitch_local_m':2,'basis_units':'LOCALmetres/density, no bakedworldscale; perinstanceb=s*g; worldintegral=b³localintegral','array_storage':'little-endian Float16, Xfastest, numpy[Z,Y,X]','texture_coordinate_contract':'uv=(global material xyz−origin)/span; texelcentres origin+(i+.5)*2; return0 outside domain','root_global_xyz_local_m':rec['root'],'recipe':rec,'zero_all_six_border_faces':rm['all_six_border_faces_zero'],'density':{'file':name+'.density.r16f','bytes':rm['output_bytes'],'sha256':rm['output_sha256'],'max_abs_half_rounding':rm['half_rounding_max_abs']},'distance':{'file':name+'.distance.r16f','bytes':dm['output_bytes'],'sha256':dm['output_sha256'],'definition':dm['definition'],'iso':.001,'min_decoded_local_m':dm['min_decoded_local_m'],'max_decoded_local_m':dm['max_decoded_local_m'],'max_abs_half_rounding_local_m':dm['half_rounding_max_abs_local_m']},'reference':{'definition':'separate decoded rho/d samples then rho*smoothstep(−8,8,d), localw8/worldw32','kappa_per_world_m':.019,'source_whole_integral_native_sum':rm['source_whole_integral_native_sum'],'source_crop_integral_native_sum':rm['source_crop_integral_native_sum'],'masked_raw_integral_native_sum':total,'tapered_integral_native_sum':ref,'mask_loss_of_source_crop':1-total/rm['source_crop_integral_native_sum'],'reference_loss_of_masked_raw':1-ref/total,'reference_loss_of_whole_master':1-ref/rm['source_whole_integral_native_sum'],'raw_integral_local_m3':total*8,'reference_integral_local_m3':ref*8},'actual_reference_bounds':{str(t):C.bounds(q,t,origin)for t in[0,.001,.005,.01,.04]},'root_certificate':{'q_attach':.04,'guard_threshold':.041,'ball_radius_local_m':radius,'method':'separate minrho,mind in interpolationcell, productlower>=.041; nearest uncertifiedcellbox−.001m','pass_positive':radius>0},'potential_support':potential,'seed_support_formula':'Rlocal*s*G0*sigmaMax(.008) for first4healthywall=growthseconds withgG0/mu1; off/drycancelsclaim','finite_extinction':{'min_channel_multiplier':.3,'endpoint_local_m':end,'formula':'(maxdecodedD+8localtaper+2localguard)/.3','native_nonzero_endpoint':0,'continuous_bound':'trilineard<=maxdecodedD,M>=.3 implies smooth0 everywhere'},'qualification':'staticproduceronly; noGPU/runtime/art/lifecycleadmission'}
 if name!='body':
  inst=json.loads((R/'instances.json').read_text());out['root_to_crown_frame']={'head_global_xyz_local_m':[221,295,207],'root_to_crown_orthoframe_columns':inst['instances'][0]['Fasset_columns'],'definition':'outerlistCOLUMNvectors; actualroot→selecteddensehead, NOTcentroid'}
 out['conversion']=rm['conversion']
 save(out,name+'.json')
elif stage=='core':
 assert name=='body';reserve('reference q preparation',72);rho,d=loadfields();q=rho*C.smooth((d+8)/16);del rho,d;gc.collect();lb=np.fromfile(R/'body.lower-proof.f32',dtype='<f4').reshape(tuple(dims[::-1]-1));reserve('slice core labels',64);result=C.coverage(q,lb,origin);m=json.loads((R/'body.json').read_text());m['wet_core']=result;save(m,'body.json')
elif stage=='catalogue':
 assert name=='body';reserve('fixed shoulder cell bounds',24);lb=np.fromfile(R/'body.lower-proof.f32',dtype='<f4').reshape(tuple(dims[::-1]-1));good=lb>=.041;inst=json.loads((R/'instances.json').read_text());sites=[]
 for p in inst['instances']:
  point=p['compressed_parent_global_xyz_local_m'];radius=C.ball_radius(good,point,origin);sites.append({'id':p['original_parent_site_id'],'root_global_xyz_m':point,'actual_q041_ball_radius_local_m':float(radius),'parent_age165_world_radius_lower_m':float(radius)*4*(np.sqrt(4+.33**2)-.33)/2,'desired_crown_world_frame_columns':p['Fworld_columns'],'source':'fixedv1sitecompressedabout233; notnewplacementsearch','instance_id':p['id']})
 m=json.loads((R/'body.json').read_text());m['shoulder_catalogue']=sites;save(m,'body.json')
elif stage=='path':
 assert name=='crown-b';reserve('post taper path cells',16);lb=np.fromfile(R/'crown-b.lower-proof.f32',dtype='<f4').reshape(tuple(dims[::-1]-1));good=lb>=.041;controls=json.loads((R/'controls.json').read_text());path=next(p for p in controls['components']if p['id']=='crown-b')['path_global_xyz_local_m'];witness=[{'point_global_xyz_local_m':p,'actual_q041_ball_radius_local_m':float(C.ball_radius(good,p,origin))}for p in path];m=json.loads((R/'crown-b.json').read_text());head=[221,295,207];m['head_certificate']={'root_global_xyz_local_m':head,'actual_q041_ball_radius_local_m':float(C.ball_radius(good,head,origin))};m['path_certificate']={'threshold':.041,'vertices':witness,'maximum_axis_step_local_m':2,'minimum_vertex_radius_local_m':min(p['actual_q041_ball_radius_local_m']for p in witness),'continuous_polyline_tube_radius_local_lower_m':max(0,min(p['actual_q041_ball_radius_local_m']for p in witness)-1),'scope':'actualposttaperpercelllowerbound sphereunion; includesrawmaskandfreshEDT'};save(m,'crown-b.json')
else:raise ValueError(stage)
C.DONE=True;print('COMPLETE',name,stage,'peak',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,flush=True)
