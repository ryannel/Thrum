def validate_dependency_chain(rho,distance,dims,signs=None):
 assert rho['dimensions_xyz']==list(dims),'rho dimensions differ from recipe'
 assert distance['dimensions_xyz']==list(dims),'distance dimensions differ from recipe'
 assert distance['density_sha256']==rho['output_sha256'],'distance was derived from another density'
 if signs is not None:
  for sign in signs:
   assert sign['dimensions_xyz']==list(dims),'sign dimensions differ from recipe'
   assert sign['density_sha256']==rho['output_sha256'],'sign was derived from another density'
