# Offline direct native component evaluator; never a runtime density cache.
from pathlib import Path
import json,numpy as np
from scipy import ndimage as ndi
R=Path(__file__).resolve().parent
G0=1/64

def smooth(t):
 t=np.clip(t,0,1);return t*t*(3-2*t)
def growth(t,T):return G0+(1-G0)*smooth((t-4)/(T-4))
def integral_g(t,T):
 u=np.clip((t-4)/(T-4),0,1);return G0*t+(1-G0)*((T-4)*(u**3-.5*u**4)+max(t-T,0))
def readassets():
 out={}
 for n in['body','crown-b']:
  m=json.loads((R/(n+'.json')).read_text());shape=tuple(m['dimensions_xyz'][::-1]);out[n]={'meta':m,**{k:np.fromfile(R/m[k]['file'],dtype='<f2').reshape(shape).astype(np.float32)for k in['density','distance']}}
 return out

def matrix(p):
 Q=np.array(p['Q_columns']).T;K=np.array(p['K_world_per_rotated_local_y']);return(p['b_world_per_local_m']*np.eye(3)+np.outer(K,[0,1,0]))@Q

def forward(p,a):
 root=np.array(p['root_global_xyz_local_m']);A=matrix(p);return[p['C_world_m'][i]+sum(A[i,j]*(a[j]-root[j])for j in range(3))for i in range(3)]

def query(p,w,assets,potential=False,noise=None):
 if p['Aseed']<=0:return np.zeros(np.broadcast_shapes(*[np.shape(v)for v in w]),np.float32)
 meta=assets[p['asset_id']]['meta'];Q=np.array(p['Q_columns']).T;b=p['b_world_per_local_m'];K=p['K_world_per_rotated_local_y'];vy=(w[1]-p['C_world_m'][1])/b;v=[(w[0]-p['C_world_m'][0]-K[0]*vy)/b,vy,(w[2]-p['C_world_m'][2]-K[2]*vy)/b];shape=np.broadcast_shapes(*[np.shape(vv)for vv in v]);coords=np.empty((3,)+shape,np.float32);valid=np.ones(shape,bool)
 for j in range(3):
  a=p['root_global_xyz_local_m'][j]+sum(Q[i,j]*v[i]for i in range(3));valid&=(a>=meta['domain_origin_global_xyz_local_m'][j])&(a<=meta['domain_origin_global_xyz_local_m'][j]+meta['domain_span_local_m'][j]);coords[2-j]=(a-meta['domain_origin_global_xyz_local_m'][j])/2-.5
 rho=ndi.map_coordinates(assets[p['asset_id']]['density'],coords,order=1,mode='nearest',prefilter=False);d=ndi.map_coordinates(assets[p['asset_id']]['distance'],coords,order=1,mode='nearest',prefilter=False);E=0 if potential else p.get('age_exposure_local_m',0)
 if E and noise is not None:
  ndims=np.array(meta['dimensions_xyz'][::-1]);nc=np.empty_like(coords)
  for j in range(3):nc[j]=(coords[j]+.5)/ndims[j]*32-.5
  E=E*(.3+.7*ndi.map_coordinates(noise,nc,order=1,mode='nearest',prefilter=False))
 elif E:E=E*.3
 rho*=p['Aseed']*smooth((d-E+8)/16);rho[~valid]=0;return rho

def bounds(parts,assets):
 low=np.array([np.inf]*3);hi=-low
 for p in parts:
  m=assets[p['asset_id']]['meta']['potential_support'];lo=m['local_support_bbox_min_xyz_m'];up=m['local_support_bbox_max_xyz_m'];corners=np.array([[x,y,z]for x in[lo[0],up[0]]for y in[lo[1],up[1]]for z in[lo[2],up[2]]]);v=(corners-np.array(p['root_global_xyz_local_m']))@matrix(p).T+np.array(p['C_world_m']);low=np.minimum(low,v.min(0));hi=np.maximum(hi,v.max(0))
 return[low.tolist(),hi.tolist()]

def bodypart(age,meta,shear=(.002,0),birth=0):
 return{'id':f'body-{birth}','asset_id':'body','role':'BODY','age_s':age,'born_s':birth,'C_world_m':[0,1239.2,0],'Q_columns':np.eye(3).tolist(),'s_world_per_local_m':4,'b_world_per_local_m':4*growth(age,60),'K_world_per_rotated_local_y':[4*shear[0]*integral_g(age,60),0,4*shear[1]*integral_g(age,60)],'root_global_xyz_local_m':meta['root_global_xyz_local_m'],'g':float(growth(age,60)),'Aseed':float(smooth(age/4)),'age_exposure_local_m':meta['finite_extinction']['endpoint_local_m']*float(smooth((age-180)/120))}

def crownpart(instance,age,birth,meta,bodymeta,shear=(.002,0)):
 s=instance['mature_world_metres_per_local_metre'];parent=bodypart(birth+age,bodymeta,shear);point=instance['compressed_parent_global_xyz_local_m'];base=np.array(forward(parent,point));dy=.15*(age-10*(1-np.exp(-age/10)));I=.15*(.5*age**2-10*age+100*(1-np.exp(-age/10)));C=base+np.array([shear[0]*I,dy,shear[1]*I]);return{'id':instance['id']+'-'+str(birth),'asset_id':'crown-b','role':'BILLOW','age_s':age,'born_s':birth,'parent_id':'body-0','parent_site_id':instance['original_parent_site_id'],'C_world_m':C.tolist(),'Q_columns':instance['Q_columns'],'s_world_per_local_m':s,'b_world_per_local_m':s*growth(age,45),'K_world_per_rotated_local_y':[s*shear[0]*integral_g(age,45),0,s*shear[1]*integral_g(age,45)],'root_global_xyz_local_m':meta['root_global_xyz_local_m'],'g':float(growth(age,45)),'Aseed':float(smooth(age/4)),'age_exposure_local_m':meta['finite_extinction']['endpoint_local_m']*float(smooth((age-100)/50))}
