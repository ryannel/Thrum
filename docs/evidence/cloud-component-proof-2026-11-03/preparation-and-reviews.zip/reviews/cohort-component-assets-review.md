# Component cook review and bounded admission mechanism

3 November 2026. `cloud_core_review`, read-only review of `tmp/cloud-component-assets/{cook.py,stage.py,STAGED-COST-PLAN.md,PREFLIGHT.md,body.json,crown-a.json,crown-b.json}` and the relevant held geometry helper. Only this owned scratch note was written. No GPU/browser, canonical change, full-field recook, runtime implementation or source/art acceptance.

## Defects found and closure

1. **[P2] Preserve an empty robust core as empty.** Original `cook.py:81` zeroed background count and chose label0 when `ndi.label` returned n=0. `labels==0` then made the whole domain true and could pass an empty candidate. Actual retained BODY has74 components, so its reported result was not produced by this branch. Writer factored `largest_connected_mask`; n=0 now returns an all-false mask and0. Small empty/positive-component regression passes. No heavy recook was needed to prove this correction.
2. **[P2] Bind staged distances to the density they were derived from.** Original `stage.py:35–38` checked each sign against its own file hash but not that both signs used the current density; original `loadfields` checked density/distance individually without their dependency link. Resuming a rho recook could qualify stale distances. Writer added `checks.validate_dependency_chain`, called during merge and loading, checking dimensions and every sign/distance `density_sha256` against current rho `output_sha256`. Root loading also checks recipe/source identity. Synthetic stale-density and wrong-dimension rejection passes; all three actual retained chains pass.

**No remaining confirmed root/cell-guard/core/frame/calibration findings after these corrections.** Seed-support scope should remain explicit in metadata: growth is G0=1/64 during the first4 healthy growth seconds; with healthy mu=1 these are4 calendar seconds, so |K|/b<=.008. Thus `R_local*4/64*sigmaMax(.008)` is a valid first-ramp upper radius. It is not a bound over arbitrary wall time with stalled growth. Off/drying cancels the healthy establishment contract rather than extending that guarantee indefinitely.

The held helper correctly composes `Q_final=F_world * transpose(F_asset)` and stores its columns explicitly. CrownA/B's natural root-to-crown axes are not globalY. Applying the desired-world frame directly as Q would rotate the wrong anatomical direction; that error is not present in the reviewed helper. Both retained asset frames are orthonormal with determinant+1 to double precision.

## Actual data validation and mathematical scope

Independent bounded checks streamed rho/d and interpolation-cell bounds two planes at a time. Peak process RSS was57,425,920B; a separate 2D-slice-only robust-core check peaked70,975,488B. These are validation costs, not runtime costs. No full3D EDT, labels, point cloud or mesh was allocated by this review.

- All three rho/d hashes agree with asset and stage metadata. Inside/outside/distance density dependencies all match current rho.
- Every recomputed cell lower bound exactly matches retained `*.lower-proof.f32` (maximum discrepancy0). The bound is `min(decodedrho corners)*smoothstep(-8,8,min(decodedd corners))`, not interpolation of pre-multiplied native q. It is conservative for the actual separate-sample query.
- Recomputed nearest uncertified-cell-box distances, domain guards and .001m margin exactly reproduce local root radii: BODY24.73763375370596m, CrownA21.2592916254693m, CrownB23.15067380558045m. These certify the stated reference field, not arbitrary future erosion or visible neck quality.
- Potential-support cell bounds correctly include every cell with separate maxrho>0/maxd>-8, including its corners. They may overestimate support, which is appropriate for seed burial and conservative bounds. Zero outer rho faces make omitted beyond-domain clamp cells irrelevant.
- BODY wet-core mask hash matches. It contains124,194 certified cells and7,453 projected footprint cells. All selected cells pass the per-height continuous horizontal-disk guard; minimum retained margin is.0505728752538096 local metres. Reported fractions34.4130654% volume and46.3985557% footprint match the retained inputs. These compare certified cell measure with declared native reference counts; they are not exact continuous volume ratios or a beauty pass.
- The core guard is valid: for each Y-cell, shear displacement is bounded by .32*max|Ycell−233|; the2sqrt(2)m term covers the query-cell and opposite-cell half diagonals in the horizontal plane. Selecting one6-connected certified-cell region maintains face-sharing positive coverage. No sampled-angle theorem is substituted for this disk bound.
- Finite endpoint `(maxDecodedD+8+2)/.3` is conservative under trilinear decoded d<=maxDecodedD and channel M>=.3. R16 roundoff is already included in decoded maxima. Retiring actual/previous-reader state remains a later runtime obligation.
- Source calibration is consistently kappa=.019 per world metre with mature world/local scale4 and no rho normalization. Crop/mask/taper losses and physical integral scaling are reported separately. EDT is honestly labelled signed opposite-class sample-centre distance, not an exact continuous isosurface SDF.

The maximum retained successful stage receipt is BODY outside EDT320,012,288B=305.1875MiB, below the revised384MiB planned process ceiling. Earlier612.8MiB and451.56MiB failed/stopped attempts remain adverse evidence; they are not cost passes. This review checked the receipts and algorithm staging, not a repeated full cook. The lower-bound/certificate tests do not qualify visible billow content, exposed-growth cues, body turnover variation, all consumers or runtime performance.

## Bounded geometry admission proposal to retain before runtime

This is a proposed complete cheap admission/reference mechanism, not code already present in the cook and not an acceptance claim for its assets. It replaces any interpretation of U_old as a per-birth full3D grid, CPU mesh or full-resolution runtime search.

### Prepared finite metadata

For each adopted component, cook at most16 overlapping guarded positive q>=.04 balls forming a root-to-one-primary-head chain. The chain proves the exposed head belongs to the rooted component, rather than an isolated fragment. Its radii/density/thickness are pinned by actual qualified content and interpolation witnesses. A transformed ball contains a world ball of radius sigmaMin(A)*r_local; seed A and actual loss still apply to the runtime neck contract.

Cook a conservative loss-free q>.005 support BVH capped at128 leaves/255 nodes per template. Mark interpolation cells using the conservative upper bound `maxrho*smoothstep(-8,8,maxd)`; coarse merged leaf boxes cover all marked cells. Merging may fill holes and reject a usable placement but must never omit support or create a false admission. Border/collar and trilinear guards are explicit. Three such trees plus ball chains/catalogs are roughly under32KiB CPU metadata; exact serialization must account for it. No new density volume is implied.

Pin at most8 world/weather-owned shoulder/type/frame candidate poses in deterministic order, using `F_world*F_asset^T`. A candidate passes if its primary mature head ball is provably outside every frozen older support at the45s endpoint, and its existing phased root attachment passes. Inverse-map the proposed head centre into each older chart, conservatively inflate its test radius using inverse sigmaMin and prospective motion bounds, then query its support BVH. Worst case is8poses*8olderIDs*255nodes=16,320 small node tests per scheduled birth for one primary head, outside the frame path. This is a work bound, not a measured millisecond win. If these conservative bounds reject every catalog pose, report content/recipe infeasibility; do not loosen thresholds silently or fall back to a full scan.

Exposure is required by the deadline, not throughout the initially buried interval. Offline root-to-head connectivity and the actual neck/burial programme remain separate from the old-support exclusion test.

### Prospective forcing and live edits

Use relative motion under common affine W. Shared mean wind cancels, so do not independently inflate every object by12m/s*45s. Bound differential horizontal motion with |shear|<=.002 times relative height, root uplift with the11m guarded 3D separation, and differential K with `.002*integral(b dt)`.

Each old leaf must be swept over its actual possible growth interval `[b_now,b_max45]` and K interval. Mature/max-scale support need not contain the smaller-scale shape, and local dry forcing may slow an old member's growth; therefore a frozen/mature-only old box is invalid. Conservative leaf displacements include `Delta_b*max|Q(a-r)|` and `Delta_K*max|[Q(a-r)]y|`. Child healthy mu=1/on/D=0 uses its pinned growth programme; deliberate off/dry cancels that healthy certificate. Within-range wind edits remain inside the prospective guard; out-of-bound edits are rejected before activation. Observe actual state at source ticks and fail/revoke a violated certificate, never count it retrospectively as completed renewal. These bounds need explicit serialization/tests before implementation.

### Reference versus optical capacity

Freeze U_old membership at billow birth from older actual source-active or publication-retained IDs. Exclude certification-only leases and already-expired history. Continue each member's same-forcing C/u/K/g/A/mu if it retires during the lease; set only opacity losses0, preserve reference taper, and discard at the45s deadline/cancellation. Reference members cannot contribute optically, parent, or seed another reference chain.

Keep those descriptors in a separate bounded CPU reference table (at most8 frozen IDs for the pinned programme, with that bound independently proved/enforced). No Eweather control volume or GPU texture is needed for loss-free references.50s billow cadence with45s deadlines permits at most one billow exposure certificate at a time. The8 optical slots cover actual current/prior reader publication, not an interchangeable pool of optical and reference states. Count active, previous-reader and reference capacities separately; no silent list drop.

### BODY coverage and cue scope

The youngest healthy mature BODY has age60..<160, b=4 and zero age erosion, so |K|/b<=.32. Its robust local core can be cooked by horizontal erosion of qref>=.01 with disk radius `.32*|aY-233|` plus the verified interpolation guards. The actual retained core fractions above support this bounded coverage ingredient. Turnover envelope/opacity variation and native body geometry remain separate qualification gates.

Retain the >=5% novel projected crown area in two fixed canonical offline views as a content/recipe/art screen before old loss. Runtime admission is the camera-independent3D exposed-head test. Requiring every birth to change both global2D silhouettes would incorrectly reject legitimate backside or foreground-occluded growth in a steady cloud. This offline-versus-runtime distinction must be an explicit reviewed contract change, not silent weakening. Actual1x/16x observations must still demonstrate convincing local billowing; neither positive balls nor 3D new volume alone establish it.

## Disposition

Two cook-validation defects were found, corrected by the owning writer and passed their small regressions. No remaining confirmed defect was found in the actual retained root/cell-guard/core/frame/calibration data. The next permission remains **asset qualification only**: held BODY/crown geometry, exact witness/catalog adoption, exposed-cue and turnover screens. Full runtime remains uncommissioned until those actual cues pass. The bounded admission metadata and reference mechanism above must be pinned and reviewed before dependent runtime code; it is not a reason to assume the assets pass.
