# Prepared only; run after root's early optical look. All screens pinned in PREFLIGHT.md.
from pathlib import Path
import json,sys,resource,numpy as np
import cook as C
from geometry import bodypart,query
R=Path(__file__).resolve().parent;m=json.loads((R/'body.json').read_text());shape=tuple(m['dimensions_xyz'][::-1]);assets={'body':{'meta':m,**{k:np.fromfile(R/m[k]['file'],dtype='<f2').reshape(shape).astype(np.float32)for k in['density','distance']}}};npth=R.parent/'cloud-distance-proof/channels-32.r16f';noise=np.fromfile(npth,dtype='<f2').reshape((32,32,32)).astype(np.float32);H=float(sys.argv[1])if len(sys.argv)>1 else 8.;cases=[]
# Common finite support envelope for all admitted angles/times, with no whole3D field.
bb=m['potential_support'];lc=np.array(bb['local_support_bbox_min_xyz_m']);hc=np.array(bb['local_support_bbox_max_xyz_m']);root=np.array(m['root_global_xyz_local_m']);maxy=max(abs(lc[1]-root[1]),abs(hc[1]-root[1]));lo=4*(lc-root)+[0,1332,0];hi=4*(hc-root)+[0,1332,0];lo[[0,2]]-=2.4*maxy;hi[[0,2]]+=2.4*maxy;lo=np.floor(lo/H)*H-H;hi=np.ceil(hi/H)*H+H;ns=np.ceil((hi-lo)/H).astype(int);axes=[lo[i]+(np.arange(ns[i])+.5)*H for i in range(3)]
for angle in range(0,360,45):
 shear=(.002*np.cos(np.deg2rad(angle)),.002*np.sin(np.deg2rad(angle)))
 for t in range(100,301,10):
  parts=[bodypart(t-b,m,shear,birth=b)for b in range(max(0,(t//100-2)*100),t+1,100)];pf=np.zeros((ns[1],ns[0]),np.float64);ps=np.zeros((ns[2],ns[1]),np.float64);mf=np.zeros_like(pf,np.float32);ms=np.zeros_like(ps,np.float32);top=np.zeros((ns[2],ns[0]),bool);volume=mass=0.
  # Y-plane traversal means early domain culling skips provably zero young-body planes.
  for iy,y in enumerate(axes[1]):
   w=[axes[0][None,:],np.array([[y]]),axes[2][:,None]];q=np.zeros((ns[2],ns[0]),np.float32)
   for p in parts:
    if p['Aseed']<=0:continue
    ay=p['root_global_xyz_local_m'][1]+(y-p['C_world_m'][1])/p['b_world_per_local_m'];dlo=m['domain_origin_global_xyz_local_m'][1];dhi=dlo+m['domain_span_local_m'][1]
    if ay<dlo or ay>dhi:continue
    np.maximum(q,query(p,w,assets,False,noise),out=q)
   volume+=np.count_nonzero(q>=.01)*H**3;mass+=float(q.sum(dtype=np.float64))*H**3;pf[iy]=q.sum(0,dtype=np.float64)*H;ps[:,iy]=q.sum(1,dtype=np.float64)*H;mf[iy]=q.max(0);ms[:,iy]=q.max(1);top|=q>=.01
  record={'time_s':t,'shear_angle_deg':angle,'filled_volume_q001_world_m3':volume,'density_integral_world_m3':mass,'top_footprint_q001_world_m2':int(top.sum())*H**2,'front_footprint_q001_world_m2':int(np.count_nonzero(mf>=.01))*H**2,'side_footprint_q001_world_m2':int(np.count_nonzero(ms>=.01))*H**2,'front_optical_opacity_area_world_m2':float((1-np.exp(-.019*pf)).sum())*H**2,'side_optical_opacity_area_world_m2':float((1-np.exp(-.019*ps)).sum())*H**2};cases.append(record)
 print('angle',angle,'done',flush=True)
metrics=[k for k in cases[0]if k not in['time_s','shear_angle_deg']];summaries={}
for a in range(0,360,45):
 vals=[c for c in cases if c['shear_angle_deg']==a];summaries[str(a)]={}
 for k in metrics:
  v=np.array([c[k]for c in vals]);variation=float((v.max()-v.min())/v.mean());summaries[str(a)][k]={'minimum':float(v.min()),'maximum':float(v.max()),'mean':float(v.mean()),'minimum_time_s':vals[int(v.argmin())]['time_s'],'maximum_time_s':vals[int(v.argmax())]['time_s'],'variation_range_over_mean':variation,'threshold':.10,'pass':variation<=.10}
out={'scope':'BODYonlynative8mworldquadrature, twowetturnovers; noart/GPU/runtime/allpossiblewindsclaim','pitch_world_m':H,'times_s':list(range(100,301,10)),'angles_degrees':list(range(0,360,45)),'world_bounds_xyz':[lo.tolist(),hi.tolist()],'dimensions_xyz':ns.tolist(),'body_manifest_sha256':C.sha(R/'body.json'),'noise_sha256':C.sha(npth),'growth':'G0through4τ, smoothstep4..60 to1; ageE180..300; rootR/QI/s4/u0 exactly','required_screen_metrics':[k for k in metrics if k!='density_integral_world_m3'],'density_integral_is_additional_report_not_predeclared_gate':True,'summary':summaries,'cases':cases,'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'recipe_sha256':C.sha(Path(__file__))};out['sampled_screen_pass']=all(summaries[str(a)][k]['pass']for a in range(0,360,45)for k in out['required_screen_metrics']);(R/'body-turnover-screens.json').write_text(json.dumps(out,indent=2)+'\n');C.DONE=True;print('DONE',out['sampled_screen_pass'],out['process_peak_rss_bytes']/2**20,flush=True)
