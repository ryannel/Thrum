from pathlib import Path
import json,numpy as np,resource
from PIL import Image,ImageDraw
import cook as C
from geometry import readassets,query
R=Path(__file__).resolve().parent;assets=readassets();data=json.loads((R/'held-fixture.json').read_text());fixtures={f['id']:f for f in data['fixtures']};records=[]

def render(parts,bb,view):
 direction={'front':np.array([0.,0.,1.]),'side':np.array([1.,0.,0.]),'oblique':np.array([1.,0.,1.])/np.sqrt(2)}[view];right=np.cross([0.,1.,0.],direction);up=np.array([0.,1.,0.]);lo,hi=np.array(bb);corners=np.array([[x,y,z]for x in[lo[0],hi[0]]for y in[lo[1],hi[1]]for z in[lo[2],hi[2]]]);x=corners@right;y=corners@up;z=corners@direction;xlo,xhi=x.min()-32,x.max()+32;ylo,yhi=y.min()-32,y.max()+32;zlo,zhi=z.min()-8,z.max()+8;nx=min(320,max(32,int(np.ceil((xhi-xlo)/8))));ny=min(200,max(32,int(np.ceil((yhi-ylo)/8))));xx=xlo+(np.arange(nx)+.5)*(xhi-xlo)/nx;yy=ylo+(np.arange(ny)+.5)*(yhi-ylo)/ny;H=8.;n=int(np.ceil((zhi-zlo)/H));ds=(zhi-zlo)/n;amount=np.zeros((ny,nx),np.float32);mx=amount.copy()
 for i in range(n):
  t=zlo+(i+.5)*ds;w=[right[k]*xx[None,:]+up[k]*yy[:,None]+direction[k]*t for k in range(3)];q=np.maximum.reduce([query(p,w,assets)for p in parts if p['Aseed']>0]);amount+=q*ds;np.maximum(mx,q,out=mx)
 return[1-np.exp(-.019*amount),np.clip(mx/.71533203125,0,1)],{'view':view,'pixel_world_m_xy':[(xhi-xlo)/nx,(yhi-ylo)/ny],'pixels_xy':[nx,ny],'ray_step_world_m':ds,'kappa':.019,'projection_basis_right':right.tolist(),'projection_basis_up':up.tolist(),'direction':direction.tolist()}

def panel(canvas,a,col,row,W,H,title):
 rgb=np.repeat(np.round(np.clip(a,0,1)*255).astype('uint8')[:,:,None],3,axis=2);pic=Image.fromarray(np.flipud(rgb));scale=min((W-12)/pic.width,(H-27)/pic.height);pic=pic.resize((round(pic.width*scale),round(pic.height*scale)),Image.Resampling.NEAREST);canvas.paste(pic,(col*W+(W-pic.width)//2,row*H+26));ImageDraw.Draw(canvas).text((col*W+6,row*H+6),title,fill='white')
W=350;H=190;canvas=Image.new('RGB',(3*W,6*H),(14,18,24))
for j,fid in enumerate(['body-mature','crown-a-alone','crown-b-alone']):
 f=fixtures[fid]
 for k,view in enumerate(['front','side','oblique']):
  fields,meta=render(f['parts'],f['bounds_world_xyz'],view);records.append({'fixture':fid,**meta});panel(canvas,fields[1],j,2*k,W,H,f'{fid} {view} maxq/.7153');panel(canvas,fields[0],j,2*k+1,W,H,f'{fid} {view} opacity k=.019')
 print('individual',fid,flush=True)
canvas.save(R/'components-native.png')
ids=['body-mature','a-half','a-full','b-half','b-full'];lo=np.min([fixtures[f]['bounds_world_xyz'][0]for f in ids],axis=0);hi=np.max([fixtures[f]['bounds_world_xyz'][1]for f in ids],axis=0);canvas=Image.new('RGB',(len(ids)*W,3*H),(14,18,24))
for j,fid in enumerate(ids):
 f=fixtures[fid]
 for k,view in enumerate(['front','side','oblique']):
  fields,meta=render(f['parts'],[lo,hi],view);records.append({'fixture':fid,'fixed_comparison_bounds_world_xyz':[lo.tolist(),hi.tolist()],**meta});panel(canvas,fields[0],j,k,W,H,f'{fid} {view} opacity k=.019')
 print('held',fid,flush=True)
canvas.save(R/'held-native-opacity.png');out={'scope':'nativeρ/d directquery, opticalscientificprojection, no light/scattering/art/GPU/runtimepass; displaynearestresize labelled','input_manifest_sha256':C.sha(R/'FROZEN-INPUTS.json'),'records':records,'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(R/'preview.json').write_text(json.dumps(out,indent=2)+'\n');C.DONE=True;print('COMPLETE',out['process_peak_rss_bytes']/2**20,flush=True)
