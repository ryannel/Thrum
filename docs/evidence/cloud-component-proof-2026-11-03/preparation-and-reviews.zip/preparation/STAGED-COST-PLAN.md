# Revised staged plan — awaiting root review before allocation

The first run peaked612.8MiB and failed. A second run with early448MiB stop exited before512MiB (watchdog sample473,497,600B=451.56MiB), still before final metadata publication. Both logs/failure JSON remain. No successful cost qualification is claimed. No further cook/array process launches until root reviews this plan.

Every stage is a **fresh short-lived Python process**. Memmap only raw03 half input; no64MiB whole decoded source and no old distance. Output fields remain the exact pinned recipes. Never combine EDT field cooking with root/coverage/catalogue metadata in one process.

| Stage | Intentionally resident inputs | Largest work/scratch | Conservative process plan |
|---|---|---|---:|
| 1 masked rho | half memmap<=32MiB pages +BODYfloatcrop12MiB +half6MiB | rounding/mask/reduction<=24MiB; interpreter allowance100MiB |<192MiB |
| 2 distance only | decoded rho12MiB +bool3MiB +decoded signed accumulator12MiB | SciPy rank3 feature indices36MiB, index/double transform72MiB, Float64 output24MiB, per-sign temporaries/reduction<=72MiB; signs sequential. half output6MiB. interpreter100MiB |<=384MiB; prior observed343.2MiB |
| 3 root/bounds/integrals only | rho/d24MiB; q12MiB; cell-lower12MiB; bool3MiB | cellmin pair24MiB, support maxima24MiB, per-plane box-distance<1MiB, axis reductions<=4MiB; NO3D EDT/labels/argwhere |<=256MiB |
| 4 BODY wetcore only | conservative cell lower12MiB; q12MiB | slice EDT<=3MiB, core3MiB, labels12MiB/counts12MiB, axis reductions<=4MiB; rho/d not concurrently retained after lower-bound generation |<=256MiB |
| 5 BODY shoulders only | cell lower12MiB +good3MiB | fixed upper band255×24×191<=1,168,920cells; EDT feature14MiB/double27MiB/output9MiB/additional<=27MiB; lower-bound root checks per plane; selected catalogue<=8; no whole3D argwhere list |<=256MiB |
| 6 previews/turnover, separately | exact component rho/d pair(s)<=37.5MiB float32total for3assets | streamed ray/slab arrays<=32MiB; images/projection arrays<=24MiB |<=256MiB |

Stage checkpoints include currentRSS before large calls plus conservative next-call allowance, not only historicalmaxRSS after completion. Guard process at448MiB;512MiB is failure. Expected plannedmax384MiB. Memmap page residency and interpreter/SciPy are charged above. Per-asset process restart avoids freed SciPy/NumPy arenas overlapping later metadata allocation highwater.

Partial BODYrho/d files can be reused only after a stage manifest validates sourceSHA, exact dimensions/bytecount, recipe/preflight identity, deterministic masked-R16rho hash and signed-distance algorithm contract. Stage2 will compute fresh distance from verified rho if recipe provenance cannot fully establish old partiald. No existingfile implies qualification. Numerical screens are unchanged and remain unrun until stage completion.

## Root-reviewed launch closure

Root inspected the installed SciPy implementation and requires each EDT sign in a separate fresh process. Adopted: `distance-inside` and `distance-outside` each convert EDTdouble→Float32→half, then a separate merge process selects their disjoint nonzero signs. EDT(inside)>0 only inside; EDT(outside)>0 only outside, so sign symmetry and disjointness make this exactly the old signedFloat32→half result. Small half-space/irregular analytic bit comparisons run before BODY.

Correct SciPy phase-max accounting: distance-conversion phase has int32feature36MiB +oldint32diff36MiB +newFloat64diff72MiB +inputint8/bool~6MiB=150MiB at BODY shape, with feature-transform/index generation a separate~108MiB phase. These are maxima of different phases, not an extra72MiB arbitrarily concurrent with all arrays. Charge<=216MiB additional allowance plus fresh interpreter/input/allocator headroom; planned fresh-process peak<=384MiB, early448MiB stop and absolute512MiB failure. Merge has at most2×6MiBhalf signs +12MiBfloat merge +6MiBhalf final and small reductions. Sign scratch files are verified by SHA/bytes then deleted after merge; manifests/hashes remain. No later metadata runs in either EDT-sign process.
