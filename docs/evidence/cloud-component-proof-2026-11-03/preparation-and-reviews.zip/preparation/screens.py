from pathlib import Path
import json,sys,resource,gc,numpy as np
from scipy import ndimage as ndi
import cook as C
from geometry import readassets,query,forward,matrix
R=Path(__file__).resolve().parent;mode=sys.argv[1];assets=readassets();data=json.loads((R/'held-fixture.json').read_text());fixtures={f['id']:f for f in data['fixtures']}
def save(name,value):
 value['process_peak_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;value['held_fixture_sha256']=C.sha(R/'held-fixture.json');value['recipe_sha256']=C.sha(Path(__file__));(R/name).write_text(json.dumps(value,indent=2,default=lambda x:x.item()if isinstance(x,np.generic)else str(x))+'\n');C.DONE=True;print(name,value['process_peak_rss_bytes']/2**20,flush=True)
if mode=='roots':
 results=[]
 for name in assets:
  m=assets[name]['meta'];r=m['root_certificate']['ball_radius_local_m'];p={'asset_id':name,'C_world_m':[0,1332,0],'Q_columns':np.eye(3).tolist(),'K_world_per_rotated_local_y':[0,0,0],'b_world_per_local_m':4,'root_global_xyz_local_m':m['root_global_xyz_local_m'],'Aseed':1};i=np.arange(4096);z=1-2*(i+.5)/len(i);a=i*np.pi*(3-np.sqrt(5));v=np.stack([np.sqrt(1-z*z)*np.cos(a),z,np.sqrt(1-z*z)*np.sin(a)],axis=1);world=[4*r*(1-1e-6)*v[:,k]+p['C_world_m'][k]for k in range(3)];values=query(p,world,assets);results.append({'asset':name,'root_ball_local_m':r,'sphere_samples':len(i),'actual_direct_query_min_q':float(values.min()),'required_guard_q':.041,'tolerance':2e-6,'pass':float(values.min())>=.041-2e-6})
 phases=[]
 for f in[fixtures['a-full'],fixtures['b-full']]:
  child=f['parts'][-1];m=assets[child['asset_id']]['meta'];site=next(v for v in assets['body']['meta']['shoulder_catalogue']if v['id']==child['parent_site_id']);rp=site['parent_age165_world_radius_lower_m'];rc=m['root_certificate']['ball_radius_local_m']*4*(np.sqrt(4+.09**2)-.09)/2;neck=min(rp,rc,(rp+rc-11)/2);seed=m['seed_support_world_upper_first4growths_m'];phases.append({'component':child['asset_id'],'parent_site':site['id'],'parent_actual_ball_world_lower_to_age165_m':rp,'first4_support_world_upper_m':seed,'conservative_seed_burial_margin_using_full11m_lease_guard':rp-seed-11,'g_through_first4':1/64,'child_actual_positive_ball_only_after_Aseed1':True,'actual_child_ball_world_lower_mature_m':rc,'mature_neck_world_radius_lower_using11m_separation_m':neck,'required_mature_neck_m':16,'pass':rp-seed-11>0 and neck>=16})
 save('root-neck-screens.json',{'scope':'actualstaticdecodedrho/d spherechecks+conservativeconditionalhealthyphasedcertificate; notruntime/GPU/art','roots':results,'phased_necks':phases,'all_pass':all(v['pass']for v in results+phases)})
elif mode=='exposure':
 results=[]
 for fid in['a-full','b-full']:
  fixture=fixtures[fid];child=fixture['parts'][-1];old=[p for p in fixture['parts']if p['born_s']<child['born_s']];meta=assets[child['asset_id']]['meta'];dims=np.array(meta['dimensions_xyz']);origin=np.array(meta['domain_origin_global_xyz_local_m']);novel=np.zeros(tuple(dims[::-1]),bool);stats={str(t):[0,0]for t in[.005,.04]}
  for iz in range(0,dims[2],4):
   xx=origin[0]+(np.arange(dims[0])+.5)*2;yy=origin[1]+(np.arange(dims[1])+.5)*2;zz=origin[2]+(np.arange(iz,min(iz+4,dims[2]))+.5)*2;w=forward(child,[xx[None,None,:],yy[None,:,None],zz[:,None,None]]);q=query(child,w,assets);qo=np.maximum.reduce([query(p,w,assets,True)for p in old])
   for t in[.005,.04]:stats[str(t)][0]+=int(np.count_nonzero(q>t));stats[str(t)][1]+=int(np.count_nonzero((q>t)&(qo<=t)))
   novel[iz:iz+q.shape[0]]=(q>.04)&(qo<=.04)
  largest,n=C.largest_connected_mask(novel);dd=ndi.distance_transform_edt(largest,sampling=2);radius=max(0,float(dd.max())-2*np.sqrt(3));sigmamin=float(np.linalg.svd(matrix(child),compute_uv=False).min());max_nativeedge=max(2*np.linalg.norm(matrix(child),axis=0));diameter=2*radius*sigmamin;thickness_required=4*max_nativeedge;del dd,largest,novel;gc.collect()
  H=8.;lo=np.floor(np.array(fixture['bounds_world_xyz'][0])/H)*H-H;hi=np.ceil(np.array(fixture['bounds_world_xyz'][1])/H)*H+H;ns=np.ceil((hi-lo)/H).astype(int);axes=[lo[i]+(np.arange(ns[i])+.5)*H for i in range(3)];cp=[np.zeros((ns[1],ns[0]),np.float32),np.zeros((ns[2],ns[1]),np.float32)];op=[a.copy()for a in cp]
  for iz in range(0,ns[2],4):
   end=min(iz+4,ns[2]);w=[axes[0][None,None,:],axes[1][None,:,None],axes[2][iz:end,None,None]];q=query(child,w,assets);qo=np.maximum.reduce([query(p,w,assets,True)for p in old]);np.maximum(cp[0],q.max(0),out=cp[0]);np.maximum(op[0],qo.max(0),out=op[0]);cp[1][iz:end]=q.max(2);op[1][iz:end]=qo.max(2)
  projection={};reach_required=meta['potential_support']['conservative_radius_about_root_local_m']*4/4
  for i,name in enumerate(['front_Z','side_X']):
   cm=cp[i]>.005;nov=cm&(op[i]<=.005);distance=ndi.distance_transform_edt(op[i]<=.005)*H;fraction=np.count_nonzero(nov)/max(np.count_nonzero(cm),1);reach=float(distance[nov].max(initial=0));projection[name]={'threshold':.005,'new_area_fraction_child_projection':fraction,'required_fraction':.05,'max_outward_reach_m':reach,'required_reach_quarter_conservative_component_radius_m':reach_required,'pass':fraction>=.05 and reach>=reach_required}
  result={'fixture':fid,'child':child['id'],'frozen_old_members_at_birth':[p['id']for p in old],'native_quadrature':{t:{'child_voxels':v[0],'novel_voxels':v[1],'novel_fraction':v[1]/max(v[0],1),'voxel_world_m3':float(np.linalg.det(matrix(child)))*8}for t,v in stats.items()},'dense_novel_component_count':n,'sampled_dense_interior_diameter_world_lower_heuristic_m':diameter,'four_actual_transformed_native_edges_m':thickness_required,'sampled_thickness_screen_pass':diameter>=thickness_required,'projections':projection,'geometry_screen_pass':all(v['pass']for v in projection.values())and diameter>=thickness_required,'limits':'nativepointclassification EDT plus whole8mworldprojections; thickness is numericalscreen with2sqrt3localguard, not a continuousoldqueryintervalproof; art/GPU/runtimeunqualified'};results.append(result);print(fid,'screen',result['geometry_screen_pass'],projection,flush=True)
 save('exposure-screens.json',{'scope':'staticcandidateconditionalhealthyexposureonly; screens pinned beforedata, noartpass','results':results})
else:raise ValueError(mode)
