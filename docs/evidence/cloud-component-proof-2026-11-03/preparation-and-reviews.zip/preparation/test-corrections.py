import numpy as np,json
from pathlib import Path
import cook as C
from checks import validate_dependency_chain
m,n=C.largest_connected_mask(np.zeros((4,4,4),bool));assert n==0 and not m.any()
a=np.zeros((4,4,4),bool);a[1:3,1:3,1:3]=True;m,n=C.largest_connected_mask(a);assert n==1 and m.sum()==8
rho={'dimensions_xyz':[2,3,4],'output_sha256':'a'};d={'dimensions_xyz':[2,3,4],'density_sha256':'a'};validate_dependency_chain(rho,d,[2,3,4],[d,d])
for wrong in[{'dimensions_xyz':[2,3,4],'density_sha256':'b'},{'dimensions_xyz':[4,3,2],'density_sha256':'a'}]:
 try:validate_dependency_chain(rho,wrong,[2,3,4],[d,wrong])
 except AssertionError:pass
 else:raise AssertionError('stale or wrong-dimension dependency was accepted')
r=Path(__file__).resolve().parent
for name in['body','crown-a','crown-b']:
 rm=json.loads((r/(name+'.rho-stage.json')).read_text());dm=json.loads((r/(name+'.distance-stage.json')).read_text());ss=[json.loads((r/(name+'.'+v+'-stage.json')).read_text())for v in['distance-inside','distance-outside']];validate_dependency_chain(rm,dm,rm['dimensions_xyz'],ss)
C.DONE=True;print('empty core false; positive component preserved; stale density/dimension rejected; actual three dependency chains match')
