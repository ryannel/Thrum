from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(r/'test-disjoint-signs.py')],check=True)
for name in['body','crown-a','crown-b']:
 for stage in(['root','core','catalogue']if name=='body'else['rho','distance-inside','distance-outside','distance','root']):
  p=r/(name+'.'+stage+'.log')
  with p.open('w')as out:result=subprocess.run([sys.executable,str(r/'stage.py'),name,stage],stdout=out,stderr=subprocess.STDOUT)
  print(name,stage,'exit',result.returncode,flush=True)
  if result.returncode:print(p.read_text(),flush=True);raise SystemExit(result.returncode)
