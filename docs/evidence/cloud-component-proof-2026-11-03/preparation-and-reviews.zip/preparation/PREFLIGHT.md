# Frozen component qualification plan — before cooking

Owner cloud_lifecycle_diagnosis, commissioned by root2026-11-03. Own only this directory plus reviewed edits to ../cloud-cohort-diagnosis/TWO-ROLE-CARD.md. No browser/runtime/8150/canonical changes. Source input is exact CC0 cloud03/256 R16 raw density SHA42431f9da2d76e253d649cc35802fd1be7b23ddb698e73c6c4247ac3c90a97c9, referenced read-only from ../cloud-authored-master. κ=.019, world/local mature scale4. No density renormalization. Native pitch2m local. Do not load the old whole-master distance. Need only BODY/CrownA/CrownB; no component search/threshold relaxation after results.

Peak new disk<=64MiB; available80GiB at admission. Intended retained rho/d pairs18.75MiB, recipes/metadata/images small; input is referenced, not duplicated. Preserve exact negatives and report failures; ignored output is not durable backup. Retain until root selects/rejects and retains required sources/results.

## Pinned arrays and memory policy

Python NumPy/SciPy/PIL existing tools only. Native half input is memmapped read-only; convert only one crop toFloat32 at a time. Hard process stop512MiB via sampling RSS watchdog plus checkpoints at every large allocation; stop with failure metadata, never rerun a larger allocation. Before allocate, known shapes bound working arrays:

| Array | Largest shape | dtype | bytes |
|---|---|---|---:|
| Input memmap (file resident pages charged honestly) |256³ |Float16 |33,554,432 |
| BODY rho |256×64×192 |Float32 |12,582,912 |
| BODY class or cell bool |<=same |Bool |3,145,728 |
| One EDT output |<=same |Float64 |25,165,824 |
| Decoded/working distance |<=same |Float32 |12,582,912 |
| R16 output copy |<=same |Float16 |6,291,456 |
| Reference q |<=same |Float32 |12,582,912 |
| Label/component array |<=same |Int32 |12,582,912 |
| Cell min rho/d |<=same, sequential reduction |Float32 each |12,582,912 each |
| Root-bound scratch |one192×64 plane |Float64 |98,304 |
| Preview ray/slab |<=256×256 points |Float32×12 |3,145,728 |
| BODY turnover sampled slabs |<=4×80×300 |Float32×12 |4,608,000 |

Maximum intentional simultaneously live array payload<=192MiB including memmapped source pages. Allow up to256MiB for interpreter/SciPy/allocator; absolute process512MiB. Cook and qualification/preview run separately, loading only needed component fields. No full256³ float64 masks/EDTs beyond the smaller listed BODY dimensions. Rejected old diagnosis peaks605.81MiB/1953.67MiB remain recorded in ../cloud-cohort-diagnosis, not relabelled as within this plan.

## Pinned recipes and gates

BODY domain origin[64,160,0], span[384,128,512], dimsXYZ[192,64,256], mask1−smoothstep(250,278,a_y). Root[299,233,167], QI, s4. CrownA domain[192,160,40] span192³/dims96³, ROI[208,232,52]..[368,344,220]; CrownB domain[104,160,128] span192³/dims96³, ROI[116,232,156]..[284,344,292]. Crown mask is product of six12m smooth collars. Pinned crown root candidates A[237,261,181],B[225,265,197]; no silent root relocation. Store rho Float16 after masking, new signed centre EDT of rho>=.001 Float16. Reference q samples rho and d independently then multiplies smoothstep(-8,8,d). All array boundaries must rho=0. No resampling: density ingredient is exact native voxel subset times mask, R16 roundoff reported. Recomputed d is centre EDT, not an exact continuous isosurface SDF.

Actual q>=.04 root certificates use per-cell separate rho/d minimum product>=.041 and geometric bad-cell guards, not interpolation of native q products. Potential seed support uses per-cell maximum rho>0 and maximum d>−8, with a conservative cell-corner radius. Max decoded d sets finite E endpoint with M_min=.3 and8m local taper. Native/scientific previews do not qualify GPU or art.

BODY robust wet-core K: youngest mature BODY age60..160, |K|/b<=.32. For every height use continuous horizontal shift disk radius.32*|a_y−233|; erode conservative q>=.01 cells by that disk plus cell/interpolation guard. Keep largest6-connected3D region. **Pinned screens:** K footprint>=25% of mature BODY q>=.01 projected footprint AND K filled volume>=25% of mature BODY q>=.01 filled volume. Report full3D volume/height/connectedness; a root ball is insufficient. No sampled-angle claim of global proof.

BODY-only turnover: times100..300s every10s (two complete100s turnovers); constant admitted max shear .002/s at angles0,45,90,135,180,225,270,315degrees, common exact anchor and fixed world registration, age erosion180..300. Native8m world lattice,4m selected-extremum refinement if screen near limit; all bounds derived actual finite fields. Measure projected q>=.01 footprint, q>=.01 filled volume and integrated optical opacity area (front andside, κ=.019). Pinned variation screen(max−min)/mean<=10% for each scalar; report sampled scope, do not call eight angles an all-wind theorem. BODY coverage proof uses analytic disk, independent of angle sampling. If any body gate fails, report infeasible; no threshold or content changes.

Crown ramp: entire potential seed support buried within actualparentq>=.04ball for first4growthseconds; no actualchildq-neckclaim atA0. AfterA1 require positive actual neck and mature resolved radius>=16m, with11m guarded3D separation. Prospective parentage<=165 beforeerosion180. Mature world/local s=4, b=s*g. Four-native-voxel thickness uses transformed metric (worst native edges BODY10.7523m/BILLOW9.2895m), not automatic32m. Exposed crown gate by45s: support beyond all OLD uneroded potential, novel projected area>=5% of own projection in two fixed orthogonal horizontal views, reach>=¼ of crown radius, positive novel volume and a connected dense interior four transformed native voxels thick. Prepare one parent+two unequal crown held comparison; finite shoulder catalogue/frames/witnesses, no claim dynamic lease/controller exists. If no certified shoulder/crown placement passes, report the missing qualification without fabricating it.

## Cost correction before retry (same fields/thresholds)

First BODY q/d preparation peaked344MiB, but later metadata/catalogue work crossed512MiB: watchdog sample642,564,096B. Stop was real; no final metadata/index was published. `MEMORY-FAILURE.json` and `cook-v1-memory-failure.*` retain this failed cost gate. Cause: SciPy EDT's rank3 feature-transform/index/double scratch was missing from the original table, plus whole-volume `argwhere` coordinate lists and retained allocator pages.

Retry keeps all masks/roots/thresholds fixed. Metadata bounds use per-axis Boolean reductions, no N×3 coordinate list. Shoulder EDT input is the predeclared globalY232..278 cell band (at most255×23×191=1,120,215 cells), with its cut borders false: extra conservatism, no new sites outside the pinned244..260 band. EDT internal upper workspace accounted as<=64bytes/cell (~68.4MiB), plus<16MiB derived fields; no fullBODY catalogue EDT. Whole-body EDT cooking remains at most3,145,728 cells with<=192MiB internal-work allowance and observed344MiB process. Each asset runs in a fresh process. Watchdog proactively stops at448MiB;512MiB remains absolute failure. No cost pass is attributed to the old run. Root was informed before retry.
