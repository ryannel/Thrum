from pathlib import Path
import json,numpy as np,resource
import cook as C
from geometry import readassets,forward
R=Path(__file__).resolve().parent;assets=readassets();fixtures={f['id']:f for f in json.loads((R/'held-fixture.json').read_text())['fixtures']};out=[]
for fid in['body-mature','crown-a-alone','crown-b-alone']:
 p=fixtures[fid]['parts'][0];m=assets[p['asset_id']]['meta'];rho=assets[p['asset_id']]['density'];d=assets[p['asset_id']]['distance'];origin=np.array(m['domain_origin_global_xyz_local_m']);dims=np.array(m['dimensions_xyz']);stats={str(t):{'lo':np.array([np.inf]*3),'hi':np.array([-np.inf]*3),'count':0}for t in[0,.005,.01,.04]}
 for iz in range(dims[2]):
  q=rho[iz]*C.smooth((d[iz]+8)/16);xx=origin[0]+2*np.arange(dims[0])+1;yy=origin[1]+2*np.arange(dims[1])+1;zz=origin[2]+2*iz+1;w=forward(p,[xx[None,:],yy[:,None],np.array([[zz]])]);w=np.broadcast_arrays(*w)
  for t,s in stats.items():
   mask=q>float(t)
   if not mask.any():continue
   s['lo']=np.minimum(s['lo'],[float(v[mask].min())for v in w]);s['hi']=np.maximum(s['hi'],[float(v[mask].max())for v in w]);s['count']+=int(mask.sum())
 out.append({'fixture':fid,'thresholds':{t:{'sample_min_world_xyz_m':s['lo'].tolist(),'sample_max_world_xyz_m':s['hi'].tolist(),'sample_count':s['count']}for t,s in stats.items()},'scope':'tight bounds over actual native post-taper voxel-centre samples in exact held affinepose; continuous support conservatively bounded separately in assetmanifest'})
record={'scope':'nativeactualbounds not domaincube dimensions','input_manifest_sha256':C.sha(R/'FROZEN-INPUTS.json'),'records':out,'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(R/'native-bounds.json').write_text(json.dumps(record,indent=2)+'\n');C.DONE=True;print('DONE',record['process_peak_rss_bytes']/2**20)
