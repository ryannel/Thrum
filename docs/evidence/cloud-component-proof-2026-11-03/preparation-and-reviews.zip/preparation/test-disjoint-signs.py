import numpy as np
from scipy import ndimage as ndi
for kind in['halfspace','irregular']:
 b=np.zeros((13,15,17),bool)
 if kind=='halfspace':b[:,:,:8]=True
 else:b[3:10,4:12,2:14]=True;b[4:7,2:8,10:15]=True;b[6,7,8]=False
 a=ndi.distance_transform_edt(b,sampling=2);z=ndi.distance_transform_edt(~b,sampling=2)
 old=a.astype(np.float32);old-=z;old=old.astype('<f2');ap=a.astype(np.float32).astype('<f2');zp=z.astype(np.float32).astype('<f2');assert not np.any((ap>0)&(zp>0));new=ap.astype(np.float32);new-=zp;new=new.astype('<f2');assert np.array_equal(old.view('u2'),new.view('u2'))
 print(kind,'disjoint signedR16exact',old.size)
