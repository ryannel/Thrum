// Held static component query. Local R16F textures are shared by up to eight poses.
@group(0) @binding(18) var bodyDistance:texture_3d<f32>;
@group(0) @binding(19) var crownADensity:texture_3d<f32>;
@group(0) @binding(20) var crownADistance:texture_3d<f32>;
@group(0) @binding(21) var crownBDensity:texture_3d<f32>;
@group(0) @binding(22) var crownBDistance:texture_3d<f32>;
struct HeldPart {
  C_b:vec4f, Q0_A:vec4f, Q1_asset:vec4f, Q2_active:vec4f,
  K_rootX:vec4f, rootYZ:vec4f
};
struct AssetDomain { origin_pitch:vec4f, span:vec4f };
@group(0) @binding(23) var<storage,read> heldParts:array<HeldPart,8>;
@group(0) @binding(24) var<storage,read> assetDomains:array<AssetDomain,3>;
fn partDensity(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(densityTex,linearClamp,uv,0.).x;}
  if(index==1u){return textureSampleLevel(crownADensity,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDensity,linearClamp,uv,0.).x;
}
fn partDistance(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(bodyDistance,linearClamp,uv,0.).x;}
  if(index==1u){return textureSampleLevel(crownADistance,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDistance,linearClamp,uv,0.).x;
}
fn componentQuery(x:vec3f,raw:bool)->f32 {
  var q=0.;
  for(var i=0u;i<8u;i++) {
    let s=heldParts[i];
    if(s.Q2_active.w<.5||s.Q0_A.w<=0.||s.C_b.w<=0.){continue;}
    let h=(x.y-s.C_b.y)/s.C_b.w;
    let v=(x-s.C_b.xyz-s.K_rootX.xyz*h)/s.C_b.w;
    let a=vec3f(dot(s.Q0_A.xyz,v),dot(s.Q1_asset.xyz,v),dot(s.Q2_active.xyz,v))
      +vec3f(s.K_rootX.w,s.rootYZ.x,s.rootYZ.y);
    let index=u32(s.Q1_asset.w);
    if(index>=3u){continue;}
    let domain=assetDomains[index];
    let uv=(a-domain.origin_pitch.xyz)/domain.span.xyz;
    if(any(uv<vec3f(0.))||any(uv>vec3f(1.))){continue;}
    let rho=partDensity(index,uv);
    let mask=select(smoothstep(-8.,8.,partDistance(index,uv)),1.,raw);
    q=max(q,s.Q0_A.w*rho*mask);
  }
  return q;
}
fn rawQ(x:vec3f)->vec4f {return vec4f(componentQuery(x,true),0.,0.,0.);}
fn coefficients(x:vec3f,detail:f32)->vec2f {
  if(p.domain.w>.5){return vec2f(0.);}
  return vec2f(componentQuery(x,false)*p.bmin.w,0.);
}
