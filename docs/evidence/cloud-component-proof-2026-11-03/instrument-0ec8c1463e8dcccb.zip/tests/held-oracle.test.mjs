import test from 'node:test';
import assert from 'node:assert/strict';
import {packParts,packDomains,inversePoint,forwardPoint,heldPoint,assetIds} from '../src/held-oracle.js';
const part={asset_id:'body',C_world_m:[311,1332,-82],Q_columns:[[.8,0,.6],[0,1,0],[-.6,0,.8]],b_world_per_local_m:3.2,K_world_per_rotated_local_y:[.25,0,-.11],root_global_xyz_local_m:[299,233,167],Aseed:.7};
const asset={origin:[64,160,0],span:[384,128,512],pitch:2,dims:[2,2,2],density:new Uint16Array(8).fill(0x3c00),distance:new Uint16Array(8).fill(0x3c00)};
test('column packing and inverse agree on tilted held pose',()=>{
 const p=packParts([part]);assert.deepEqual(Array.from(p.slice(4,7)),[Math.fround(.8),0,Math.fround(.6)]);
 assert.deepEqual(Array.from(p.slice(8,11)),[0,1,0]);assert.deepEqual(Array.from(p.slice(12,15)),[Math.fround(-.6),0,Math.fround(.8)]);
 const a=[317,214,289],x=forwardPoint(part,a),recovered=inversePoint(part,x);
 recovered.forEach((v,i)=>assert.ok(Math.abs(v-a[i])<1e-10));
 const domains=Object.fromEntries(assetIds.map(id=>[id,asset]));assert.equal(packDomains(domains).length,24);
});
test('positive inside SDF, exterior guard, and max ownership',()=>{
 const assets={body:asset},x=forwardPoint(part,[256,224,256]);
 assert.ok(Math.abs(heldPoint([part],assets,x)-.7*(9/16)**2*(3-2*(9/16)))<1e-12);
 assert.equal(heldPoint([part],assets,forwardPoint(part,[63,224,256])),0);
 const twin={...part,Aseed:.4};assert.equal(heldPoint([part,twin],assets,x),heldPoint([part],assets,x));
 assert.equal(heldPoint([part],assets,x,true),.7);
});
