# CPU-only integrated source17f

Current source pins and executed checks are in HANDOFF.json and suite-results.json. Model e21f9f5 and math7f85fe2 replace baseline675edc8/1eca92. Original GPU/recipes/clock remain unchanged. Baseline-only handoff/portable results are retained byte-for-byte in historical-c3e0/; do not treat their old source/file hashes as current integration results. The outer evidence README owns browser/GPU/motion and root fresh-archive checks. No new portable.py run or performance admission is claimed.
