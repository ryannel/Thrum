from pathlib import Path
import tempfile,shutil,subprocess,json,hashlib,time
HERE=Path(__file__).resolve().parent;VIEWER=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
with tempfile.TemporaryDirectory(prefix='source-restored-',dir=HERE)as location:
 dest=Path(location)
 for name in['src','shaders','assets']:
  if(VIEWER/name).exists():shutil.copytree(VIEWER/name,dest/name)
 for name in['index.html','style.css','serve.py']:
  if(VIEWER/name).exists():shutil.copy2(VIEWER/name,dest/name)
 tests=dest/'tests/source';tests.mkdir(parents=True)
 for p in HERE.iterdir():
  if p.is_file()and(p.suffix=='.mjs' or p.name in['control-domain-before-fix.json','control-domain-before-fix.log']):shutil.copy2(p,tests/p.name)
 start=time.perf_counter();result=subprocess.run(['node',str(tests/'run.mjs')],cwd=dest,capture_output=True,text=True);(HERE/'portable.log').write_text(result.stdout+result.stderr)
 if result.returncode:raise RuntimeError('Fresh restored source suite failed: '+str(result.returncode))
 receipt=json.loads((tests/'suite-results.json').read_text());current=json.loads((HERE/'suite-results.json').read_text());assert receipt['pass']and receipt['modelSHA256']==current['modelSHA256']and receipt['inputIndexSHA256']==current['inputIndexSHA256'];out={'pass':True,'scope':'Fresh copied viewer served payload+source tests, no siblingworktree/masterdata/code paths used; Node source suite only, no browser/GPU restoration claim','modelSHA256':receipt['modelSHA256'],'inputIndexSHA256':receipt['inputIndexSHA256'],'admissionSHA256':receipt['admissionSHA256'],'tests':[{'test':r['test'],'exitCode':r['exitCode']}for r in receipt['runs']],'filesCopied':sum(1 for p in dest.rglob('*')if p.is_file()),'bytesCopied':sum(p.stat().st_size for p in dest.rglob('*')if p.is_file()),'nodeSuiteWallSeconds':time.perf_counter()-start,'temporaryCopiedViewerRemovedAfterValidation':True,'clockProfile':receipt['clockProfile']};(HERE/'portable-results.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
