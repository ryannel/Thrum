import {Gpu} from './gpu.js';import {Scene} from './scene.js';
import {frameFence,assertGpuHealthy} from './frame-lifecycle.js';
import {loadRenderAssets,uploadHalf3d} from './assets.js';
import {assetIds,packParts,packDomains,forwardPoint,MAX_PARTS,GRID_COUNT,EXPOSURE_FLOATS} from './held-oracle.js';
import {evaluatePoint,snapshotForProbe} from '../source/reference.js';
const shaderNames=['optics','light','shadow','air','view','display'];
const staticWeather={wind:0,windIntegral:0,moist:0,dry:0,lift:0,frontX:0,storm:0};
function frameWeather(tuple){
  const c=tuple.controls??{},region=tuple.weatherRegion??tuple.region??[0,0,0];
  return {time:tuple.time,wind:c.meanX??0,windIntegral:Array.isArray(region)?region[0]:0,moist:Number(Boolean(c.moist)),dry:c.dry??0,lift:Number(Boolean(c.lift)),frontX:c.frontX??0,storm:c.storm??0};
}
function validateTuple(tuple){
  if(!tuple||!Array.isArray(tuple.parts)||tuple.parts.length>MAX_PARTS||!Array.isArray(tuple.bounds)||tuple.bounds.length!==2)throw Error('Invalid common source presentation');
  if(!Number.isFinite(tuple.time)||!Number.isFinite(tuple.alpha)||tuple.alpha<0||tuple.alpha>1||!Number.isInteger(tuple.sourceTick)||!Number.isInteger(tuple.epoch))throw Error('Invalid common source clock');
  if(tuple.exposurePrevious?.length!==MAX_PARTS*GRID_COUNT||tuple.exposureCurrent?.length!==MAX_PARTS*GRID_COUNT||!Number.isInteger(tuple.exposureRevision))throw Error('Invalid common source control grids');
  for(let i=0;i<3;i++)if(!Number.isFinite(tuple.bounds[0][i])||!Number.isFinite(tuple.bounds[1][i])||tuple.bounds[1][i]<=tuple.bounds[0][i])throw Error('Invalid common source bounds');
  const slots=new Set(),ids=new Set();for(const p of tuple.parts){if(slots.has(p.slot)||ids.has(p.ID))throw Error('Duplicate presented source slot or ID');slots.add(p.slot);ids.add(p.ID);}
}
export class RenderAdapter{
  static async create(canvas,progress=()=>{}){
    const input=await loadRenderAssets(progress),gpu=await Gpu.open(canvas);
    if(gpu.device.limits.maxSampledTexturesPerShaderStage<8)throw Error('Device lacks eight sampled textures per stage for the common view');
    const codes=Object.fromEntries(await Promise.all(shaderNames.map(async n=>{const r=await fetch('shaders/'+n+'.wgsl');if(!r.ok)throw Error('Missing shader '+n);return[n,await r.text()];})));
    const a=new RenderAdapter();Object.assign(a,{input,gpu,codes,published:null,poseUploadCount:0,poseUploadBytes:0,controlUploadCount:0,controlUploadBytes:0,controlWasZero:true});
    const s=new Scene(gpu,codes,0,0);a.scene=s;s.heldMode=true;s.bounds=()=>a.published?.bounds??[[-2000,0,-2000],[2000,4000,2000]];s.fixedFocus=[0,1300,0];s.target=()=>[s.fixedFocus[0]+s.camera.panX,s.fixedFocus[1]+s.camera.panY,s.fixedFocus[2]];s.camera={yaw:.3,pitch:-.05,distance:3000,panX:0,panY:0};
    try{
      await s.init(progress);
      a.textures={};for(const id of assetIds){const v=input.assets[id];a.textures[id]={density:uploadHalf3d(gpu,id+' rho',v.dims,v.density),distance:uploadHalf3d(gpu,id+' d',v.dims,v.distance)};}
      a.noise=uploadHalf3d(gpu,'fixed material M noise',[32,32,32],input.noise);
      s.heldDensity=a.textures.body.density;
      a.poseBuffer=gpu.buffer('8 common presented part maps',MAX_PARTS*24*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.domainBuffer=gpu.buffer('2 local asset domains',2*8*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.exposureBuffer=gpu.buffer('prior/current local weather loss',EXPOSURE_FLOATS*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.zeroExposure=new Float32Array(EXPOSURE_FLOATS);
      gpu.device.queue.writeBuffer(a.domainBuffer,0,packDomains(input.assets));
      s.heldInputs=()=>[[2,a.noise.createView()],[18,a.textures.body.distance.createView()],[19,a.textures['crown-b'].density.createView()],[20,a.textures['crown-b'].distance.createView()],[21,a.poseBuffer],[22,a.domainBuffer],[23,a.exposureBuffer]];
      await frameFence(gpu);return a;
    }catch(error){await s.dispose();throw error;}
  }
  publish(tuple){
    validateTuple(tuple);
    const g=this.gpu,sourceKey=tuple.epoch+'/'+tuple.sourceTick+'/'+tuple.exposureRevision;
    if(this.controlKey!==sourceKey){
      if(tuple.exposureAllZero){
        if(!this.controlWasZero){g.device.queue.writeBuffer(this.exposureBuffer,0,this.zeroExposure);this.controlUploadCount++;this.controlUploadBytes+=this.zeroExposure.byteLength;}
        this.controlWasZero=true;
      }else{
        g.device.queue.writeBuffer(this.exposureBuffer,0,tuple.exposurePrevious);
        g.device.queue.writeBuffer(this.exposureBuffer,MAX_PARTS*GRID_COUNT*4,tuple.exposureCurrent);
        this.controlUploadCount+=2;this.controlUploadBytes+=2*MAX_PARTS*GRID_COUNT*4;this.controlWasZero=false;
      }
      this.controlKey=sourceKey;
    }
    const poseKey=[tuple.epoch,tuple.sourceTick,tuple.time,tuple.alpha,tuple.forcingRevision].join('/');
    if(this.poseKey!==poseKey){
      this.packed=packParts(tuple.parts);g.device.queue.writeBuffer(this.poseBuffer,0,this.packed);this.poseUploadCount++;this.poseUploadBytes+=this.packed.byteLength;this.poseKey=poseKey;
    }
    this.published=tuple;this.scene.time=tuple.time;this.scene.steps=0;this.scene.epoch=tuple.epoch;
    return tuple;
  }
  render(ui){
    if(!this.published)throw Error('No common presentation published');
    const tuple=this.published,options={...ui,cohorts:true,sourceAlpha:tuple.alpha,provider:0,family:0,alpha:1,extinctionScale:.019/.0045};
    const snapshot=frameWeather(tuple);return this.scene.render({sample:()=>snapshot},options,0,tuple.time);
  }
  metadata(){
    const t=this.published;if(!t)throw Error('No common presentation');
    return {sourceTime:t.time,sourceTick:t.sourceTick,previousTime:t.previousTime,committedTime:t.committedTime,requestedTime:t.requestedTime,alpha:t.alpha,epoch:t.epoch,cellId:t.cellId,forcingRevision:t.forcingRevision,parts:t.parts.map(p=>({...p})),bounds:t.bounds,controls:t.controls,events:t.events,stats:t.stats,inputIndexSha256:this.input.indexSha256,sourceFrozenSha256:this.input.frozenSha256,assetHashes:Object.fromEntries(assetIds.map(id=>[id,{rho:this.input.assets[id].manifest.density.sha256,distance:this.input.assets[id].manifest.distance.sha256,correctedMetadata:this.input.assets[id].metadataSha256}])),noiseSha256:this.input.index.noise.sha256,poseUploadCount:this.poseUploadCount,poseUploadBytes:this.poseUploadBytes,controlUploadCount:this.controlUploadCount,controlUploadBytes:this.controlUploadBytes,logicalGpuBytes:this.gpu.bytes,logicalGpuAllocations:this.gpu.allocations,scope:'One common immutable liquid source query; source/art/performance/full sky not qualified'};
  }
  async probe(ui){
    const t=this.published&&snapshotForProbe(this.published);if(!t)throw Error('No common presentation');
    const s=this.scene,g=this.gpu,d=g.device,points=[];
    for(const p of t.parts)for(const delta of[[0,0,0],[4,0,0],[-4,0,0],[0,4,0],[0,-4,0],[0,0,4],[0,0,-4],[20,10,10]])points.push(forwardPoint(p,p.root.map((v,i)=>v+delta[i])));
    const [lo,hi]=t.bounds;for(let z=0;z<12;z++)for(let y=0;y<12;y++)for(let x=0;x<12;x++)points.push(lo.map((v,i)=>v+(hi[i]-v)*([x,y,z][i]+.5)/12));
    const input=new Float32Array(points.length*4);for(let i=0;i<points.length;i++)input.set(points[i],i*4);
    const bytes=input.byteLength,uniform=d.createBuffer({size:176,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),positions=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),output=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),read=d.createBuffer({size:bytes,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
    try{
      this.probePipeline??=await g.compute('integrated common coefficient oracle',s.codes.optics+`\n@group(0) @binding(25) var<storage,read> queryPoints:array<vec4f>;@group(0) @binding(26) var<storage,read_write> queryOut:array<vec4f>;@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id:vec3u){if(id.x>=arrayLength(&queryPoints)){return;}let x=queryPoints[id.x].xyz;let c=coefficients(x,1.);queryOut[id.x]=vec4f(componentQuery(x,false),componentQuery(x,true),c);}`);
      const options={...ui,cohorts:true,sourceAlpha:t.alpha,provider:0,family:0,extinctionScale:.019/.0045};s.write(uniform,frameWeather(t),options,null,t.time);
      d.queue.writeBuffer(positions,0,input);
      const bg=g.group(this.probePipeline,[[0,uniform],[1,s.heldDensity.createView()],[3,s.clamp],...s.heldInputs(),[25,positions],[26,output]]);
      const e=d.createCommandEncoder(),pass=e.beginComputePass();pass.setPipeline(this.probePipeline);pass.setBindGroup(0,bg);pass.dispatchWorkgroups(Math.ceil(points.length/64));pass.end();e.copyBufferToBuffer(output,0,read,0,bytes);g.submit(e);
      await read.mapAsync(GPUMapMode.READ);const data=new Float32Array(read.getMappedRange());let maxQ=0,maxRaw=0,maxSigma=0,invalid=0,positive=0;const examples=[];
      for(let i=0;i<points.length;i++){
        const x=Array.from(input.subarray(i*4,i*4+3)),v=data.subarray(i*4,i*4+4),q=evaluatePoint(t,x,this.input.assets,this.input.noise),raw=evaluatePoint(t,x,this.input.assets,this.input.noise,{raw:true});
        maxQ=Math.max(maxQ,Math.abs(v[0]-q));maxRaw=Math.max(maxRaw,Math.abs(v[1]-raw));maxSigma=Math.max(maxSigma,Math.abs(v[2]-q*.019));
        if(!Array.from(v).every(Number.isFinite)||v[3]!==0||v[0]<0||v[1]<0||v[2]<0)invalid++;if(v[0]>0)positive++;
        if(examples.length<12&&q>0)examples.push({x,gpu:v[0],cpu:q,rawGpu:v[1],rawCpu:raw});
      }read.unmap();assertGpuHealthy(g);
      return {pass:invalid===0&&maxQ<=.002&&maxRaw<=.002&&maxSigma<=.002*.019,points:points.length,positive,invalid,maxAbsQ:maxQ,maxAbsRaw:maxRaw,maxAbsSigma:maxSigma,toleranceQ:.002,toleranceSigma:.002*.019,examples,scope:'Actual shared source/coefficients GPU against independent CPU rho/d/M/domain-grid interpolation, including raw source; no art or performance pass'};
    }finally{for(const x of[uniform,positions,output,read])x.destroy();}
  }
}
