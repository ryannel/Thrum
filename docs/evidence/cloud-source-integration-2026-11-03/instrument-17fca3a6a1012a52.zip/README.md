# Integrated CPU source candidate

This isolated proof copies frozen integrated viewer `c3e0ebee9680337c`
and replaces exactly two source files with the independently reviewed final
CPU candidate: `src/source/model.js` SHA-256
`e21f9f5163f0a183136ce02a2d2cc9d6d5f6459943acfc5fa3254ba8ec8ae70e`
and `src/source/math.js` SHA-256
`7f85fe25b759b7e1d37770b3e4bcea13199ef49dbb66362b0d79c621556bd862`.
All shaders, renderer, bench, source clock/weather/reference/admission and
native metadata are byte-identical to c3e0. The five native R16 inputs are
hardlinks to the frozen originals. The failed query-fast shaders are absent.

The new served build identity and all pins are in `FREEZE.json`. Run
`python3 serve.py --port 8158` only when root schedules the browser/GPU slot.
This author did not start that server or run browser/GPU checks.

Fresh copies of all eight source tests passed; the source receipt is
`tests/source/suite-results.json`. All eight renderer tests passed. These
checks establish CPU contracts and local import closure, not native image,
GPU query, playback cadence, resource peak or device admission. Root's
remaining gate compares native source 100 and 550.125 against c3e0 and
records the 40 s 16× motion window. The baseline c3e0 tree and its evidence
are untouched. Retain this proof and exact test receipts until root selects
or rejects the integration; no new unique native payload bytes were created.
