"""One fixed cheap pre-distance scalar screen. No EDT/native field/output asset/GPU."""
from pathlib import Path
import hashlib,json,math,resource
import numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import maximum_filter
from scipy.signal import find_peaks,peak_widths
P=Path(__file__).resolve().parent;B=P.parent/'cloud-natural-coupled-proof';O=P/'preflight-v3';O.mkdir(exist_ok=True)
S=lambda x:np.clip(x,0,1)**2*(3-2*np.clip(x,0,1))
def sha(f):
 h=hashlib.sha256()
 with Path(f).open('rb') as s:
  while b:=s.read(1048576):h.update(b)
 return h.hexdigest()
def hash32(i,j,k,seed):
 with np.errstate(over='ignore'):
  x=np.uint32(seed)^np.asarray(i,dtype=np.int64).astype('u4')*np.uint32(0x9e3779b1)^np.asarray(j,dtype=np.int64).astype('u4')*np.uint32(0x85ebca77)^np.asarray(k,dtype=np.int64).astype('u4')*np.uint32(0xc2b2ae3d)
  x=x^(x>>16);x=x*np.uint32(0x7feb352d);x=x^(x>>15);x=x*np.uint32(0x846ca68b);return x^(x>>16)
def noise(x,y,z,pitch,seed):
 x,y,z=np.broadcast_arrays(x/pitch,y/pitch,z/pitch);ix=np.floor(x).astype(np.int64);iy=np.floor(y).astype(np.int64);iz=np.floor(z).astype(np.int64);fx,fy,fz=S(x-ix),S(y-iy),S(z-iz)
 v=[]
 for dz in [0,1]:
  rows=[]
  for dy in [0,1]:
   a=(hash32(ix,iy+dy,iz+dz,seed).astype(np.float64)+.5)/2**32;c=(hash32(ix+1,iy+dy,iz+dz,seed).astype(np.float64)+.5)/2**32;rows.append(a+(c-a)*fx)
  v.append(rows[0]+(rows[1]-rows[0])*fy)
 return v[0]+(v[1]-v[0])*fz
def author(r,d,x,y,z,role):
 E=noise(x,y,z,8,731^0x243f6a88)+2*noise(x,y,z,16,731^0x85a308d3);H=d>E
 # Independent exhaustive native check: removedWnever changed this selected candidate.
 oldH=d>((1-S((d-8)/8))*E)
 assert np.array_equal(H,oldH)
 a=.30*S((r-.01)/.11);a*=S((y-218.2)/6) if role=='body' else 1;a*=H
 return a.astype(np.float32).astype('<f2').astype(np.float32)
idx=json.loads((B/'assets/input-index.json').read_text());poses=json.loads((P/'POSES-v2.json').read_text())['parts'];assert len(poses)==3
for f in ['RECIPE-v2.md','SCREEN.md','POSES-v2.json','preflight.py','PREFLIGHT-v3.md']:
 assert sha(P/f)==json.loads((P/'PRE-RUN-v3.json').read_text())['files'][f]
assets={}
for role in ['body','crown-b']:
 m=json.loads((B/'assets/templates'/f'{role}.json').read_text());dims=m['dimensions_xyz'];origin=m['domain_origin_global_xyz_local_m'];span=m['domain_span_local_m'];arr={}
 for k in ['density','distance']:
  f=B/'assets'/idx['templates'][role][k]['file'];assert sha(f)==idx['templates'][role][k]['sha256'];arr[k]=np.memmap(f,dtype='<f2',mode='r',shape=tuple(dims[::-1]))
 assets[role]={'meta':m,'dims':dims,'origin':np.array(origin),'span':np.array(span),'rho':arr['density'],'d':arr['distance']}
def forward(p,a):
 # Exact field numerical dual algebra, Q is NOT assumed perfectly orthogonal.
 M=np.asarray(p['Qcolumns']).T;((a0,b,c),(d,e,f),(g,h,i))=M.tolist();det=a0*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
 D=np.array([[(e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],[(f*g-d*i)/det,(a0*i-c*g)/det,(c*d-a0*f)/det],[(d*h-e*g)/det,(b*g-a0*h)/det,(a0*e-b*d)/det]])
 delta=np.asarray(a)-p['root'];v=delta@D
 return np.asarray(p['C'])+p['b']*v+v[...,1,None]*np.asarray(p['K'])
views={'front':np.array([1.,0.,0.]),'side':np.array([0.,0.,-1.]),'oblique':np.array([1.,0.,-1.])/math.sqrt(2)}
boxes=[]
for pose in poses:
 a=assets[pose['templateID']];corners=np.array([[x,y,z] for x in [a['origin'][0],a['origin'][0]+a['span'][0]] for y in [a['origin'][1],a['origin'][1]+a['span'][1]] for z in [a['origin'][2],a['origin'][2]+a['span'][2]]]);boxes.append(forward(pose,corners))
allcorners=np.concatenate(boxes);pix=8.;ylo=math.floor(float(allcorners[:,1].min())/pix)*pix;yhi=math.ceil(float(allcorners[:,1].max())/pix)*pix;specs={}
for name,u in views.items():
 h=allcorners@u;lo=math.floor(float(h.min())/pix)*pix;hi=math.ceil(float(h.max())/pix)*pix;specs[name]={'u':u,'lo':lo,'hi':hi,'W':int(round((hi-lo)/pix))+1,'H':int(round((yhi-ylo)/pix))+1}
world={}
for pi in range(3):
 for mode in ['old','author']:
  for vn,v in specs.items():world[(pi,mode,vn)]={'max':np.zeros((v['H'],v['W']),np.float32),'height':np.full(v['W'],-np.inf),'point':np.full((v['W'],3),np.nan)}
metrics={};native={};slices={}
for role in ['body','crown-b']:
 a=assets[role];nx,ny,nz=a['dims'];ox,oy,oz=a['origin'];x=(ox+1+2*np.arange(nx))[None,:];y=(oy+1+2*np.arange(ny))[:,None];myposes=[i for i,p in enumerate(poses) if p['templateID']==role]
 sums={'old':0.,'author':0.};counts={'old':0,'author':0};n={}
 for mode in ['old','author']:
  n[mode]={'front':np.zeros((ny,nx),np.float32),'side':np.zeros((ny,nz),np.float32),'top':np.zeros((nz,nx),np.float32),'tauFront':np.zeros((ny,nx),np.float64),'tauSide':np.zeros((ny,nz),np.float64)}
 sliceYs={int(round((v-oy-1)/2)) for v in ([233,249] if role=='body' else [265,301,313])};sliceXs={int(round((v-ox-1)/2)) for v in ([299] if role=='body' else [225,199,239])}
 for z in range(nz):
  zz=oz+1+2*z;r=a['rho'][z].astype(np.float32).astype(np.float64);d=a['d'][z].astype(np.float32).astype(np.float64);old=(r*S((d+8)/16)).astype(np.float32);new=author(r,d,x,y,zz,role)
  for mode,v in [('old',old),('author',new)]:
   sums[mode]+=float(v.sum(dtype=np.float64));counts[mode]+=int(np.count_nonzero(v>=.041));np.maximum(n[mode]['front'],v,out=n[mode]['front']);n[mode]['side'][:,z]=v.max(axis=1);n[mode]['top'][z]=v.max(axis=0);n[mode]['tauFront']+=v;n[mode]['tauSide'][:,z]=v.sum(axis=1,dtype=np.float64)
   for sy in sliceYs:
    if 0<=sy<ny:
     key=(role,mode,'Y',oy+1+2*sy)
     if key not in slices:slices[key]=np.zeros((nz,nx),np.float32)
     slices[key][z]=v[sy]
   for sx in sliceXs:
    if 0<=sx<nx:
     key=(role,mode,'X',ox+1+2*sx)
     if key not in slices:slices[key]=np.zeros((ny,nz),np.float32)
     slices[key][:,z]=v[:,sx]
   iy,ix=np.nonzero(v>0)
   if not len(ix):continue
   coords=np.column_stack([ox+1+2*ix,oy+1+2*iy,np.full(len(ix),zz)]);value=v[iy,ix]
   for pi in myposes:
    wp=forward(poses[pi],coords);vi=np.clip(np.floor((wp[:,1]-ylo)/pix).astype(int),0,next(iter(specs.values()))['H']-1)
    for vn,sp in specs.items():
     ui=np.clip(np.floor((wp@sp['u']-sp['lo'])/pix).astype(int),0,sp['W']-1);out=world[(pi,mode,vn)];np.maximum.at(out['max'],(vi,ui),value)
     eligible=(value>=.041)&(wp[:,1]>=1280)
     if np.any(eligible):
      eui=ui[eligible];ey=wp[eligible,1];points=wp[eligible];order=np.lexsort((ey,eui));eui=eui[order];ey=ey[order];points=points[order];last=np.r_[eui[1:]!=eui[:-1],True];ids=eui[last];ys=ey[last];pts=points[last];hit=ys>out['height'][ids];out['height'][ids[hit]]=ys[hit];out['point'][ids[hit]]=pts[hit]
  del r,d,old,new
 native[role]=n;scale=4 if role=='body' else 6
 metrics[role]={'native_above_041':counts,'native_sum':sums,'amount_ratio_author_to_old':sums['author']/sums['old'],'unrotated_scale_for_tau':scale,'tau':{mode:{axis:{'max':float((n[mode][axis]*2*scale*.019).max()),'positive_median':float(np.median((n[mode][axis]*2*scale*.019)[n[mode][axis]>0]))}for axis in ['tauFront','tauSide']} for mode in ['old','author']},'dead_W_native_mask_differences':0}
 print(role,json.dumps(metrics[role]),flush=True)
# Exact predeclared old-input ROI, native-compiled author planes interpolated vertically.
a=assets['body'];ox,oy,oz=a['origin'];nx,ny,nz=a['dims'];iy=int((233-oy-1)/2);oldroot=a['rho'][:,iy,:].astype(np.float64)*S((a['d'][:,iy,:].astype(np.float64)+8)/16);iz,ix=np.nonzero(oldroot>=.041);xx=ox+1+2*ix;zz=oz+1+2*iz;cx=float(xx.mean());cz=float(zz.mean());rank=(xx-cx)**2/a['span'][0]**2+(zz-cz)**2/a['span'][2]**2;order=np.lexsort((zz,xx,rank));sel=order[:math.ceil(.8*len(order))];iz,ix,xx,zz=iz[sel],ix[sel],xx[sel],zz[sel];ys=218.2+np.arange(65)*.25;cache={}
for j in range(ny):
 yy=oy+1+2*j
 if 215<=yy<=237:
  r=a['rho'][:,j,:].astype(np.float64);d=a['d'][:,j,:].astype(np.float64);gx=(ox+1+2*np.arange(nx))[None,:];gz=(oz+1+2*np.arange(nz))[:,None];cache[j]=author(r,d,gx,yy,gz,'body')[iz,ix]
curves=[]
for yy in ys:
 t=(yy-oy)/2-.5;lo=int(math.floor(t));f=t-lo;curves.append(cache[lo]*(1-f)+cache[lo+1]*f)
c=np.stack(curves,axis=1);peaks=c.max(axis=1);valid=peaks>=.041
crosses=[]
for f in [.1,.5,.9]:
 target=peaks*f;cross=np.argmax(c>=target[:,None],axis=1);prev=np.maximum(cross-1,0);v0=c[np.arange(len(c)),prev];v1=c[np.arange(len(c)),cross];frac=np.divide(target-v0,v1-v0,out=np.zeros_like(peaks),where=v1!=v0);crosses.append(ys[prev]+frac*(ys[cross]-ys[prev]))
width=(crosses[2]-crosses[0])*4;height=1239.2+4*(crosses[1]-233);passpoint=valid&(width<=24);frac=float(passpoint.mean());hrange=float(np.ptp(height[valid])) if valid.any() else None;basepass=frac>=.8 and hrange is not None and hrange<=16
base={'old_roi_qualified_pixels':len(order),'fixed_central80_pixels':len(sel),'centroid_local_xz':[cx,cz],'author_peak_ge_041_fraction':float(valid.mean()),'width_le24_and_peak_valid_fraction':frac,'width_world_m_p0_10_50_90_100':[float(v)for v in np.percentile(width[valid],[0,10,50,90,100])]if valid.any() else [],'height50_world_m_minmax':[float(height[valid].min()),float(height[valid].max())]if valid.any()else [],'height50_range_world_m':hrange,'pass':basepass,'scope':'Native-author centres vertically trilinearly interpolated; pre-distance upper bound, final effectiveq must repeat'}
# Heights/prominences are diagnostic, not automatic art/3D topology acceptance.
lobes={};unionmaps={}
for mode in ['old','author']:
 lobes[mode]={}
 for vn,sp in specs.items():
  arr=np.maximum.reduce([world[(pi,mode,vn)]['max']for pi in range(3)]);unionmaps[(mode,vn)]=arr
  hs=np.stack([world[(pi,mode,vn)]['height']for pi in range(3)]);who=np.argmax(hs,axis=0);h=hs[who,np.arange(sp['W'])];points=np.stack([world[(pi,mode,vn)]['point']for pi in range(3)])[who,np.arange(sp['W'])];h=np.where(np.isfinite(h),h,1280.)
  peaks,props=find_peaks(h,prominence=40,distance=math.ceil(100/pix));widths=peak_widths(h,peaks,rel_height=.5)[0]*pix if len(peaks)else []
  lobes[mode][vn]={'peak_diagnostic_count':len(peaks),'crests':[{'screen_u_world_m':float(sp['lo']+(j+.5)*pix),'height_world_m':float(h[j]),'prominence_world_m':float(props['prominences'][i]),'half_prominence_width_world_m':float(widths[i]),'native_3D_world_witness':points[j].tolist()}for i,j in enumerate(peaks)],'scope':'Unsmoothed native-centre .041 upper silhouette; width is projected prominence width, NOT3Dmass diameter/certificate'}
# Scientific figures. Native-centre splat display has a one-pixel footprint; raw numerical arrays are not dilated.
def color(v):
 t=np.clip(v/.30,0,1);return np.stack([30+210*np.sqrt(t),45+205*np.sqrt(t),65+180*np.sqrt(t)],-1).astype('u1')
def panel(v,title,foot=False):
 if foot:v=maximum_filter(v,size=3,mode='constant')
 im=Image.fromarray(color(np.flipud(v)));out=Image.new('RGB',(im.width,im.height+34),'#101820');out.paste(im,(0,34));ImageDraw.Draw(out).text((3,3),title,fill='white');return out
rows=[]
for role in ['body','crown-b']:
 for mode in ['old','author']:
  panels=[]
  for vn in ['front','side','top']:
   panels.append(panel(native[role][mode][vn],f'{role} {mode} {vn} qmax / .30'))
  row=Image.new('RGB',(sum(i.width for i in panels)+12*(len(panels)-1),max(i.height for i in panels)),'#101820');x=0
  for im in panels:row.paste(im,(x,0));x+=im.width+12
  rows.append(row)
contact=Image.new('RGB',(max(i.width for i in rows),sum(i.height for i in rows)+18*len(rows)),'#101820');y0=0
for im in rows:contact.paste(im,(0,y0));y0+=im.height+18
contact.save(O/'native-projections.png')
rows=[]
for mode in ['old','author']:
 for pi in [0,1,2,None]:
  panels=[]
  for vn,sp in specs.items():
   v=unionmaps[(mode,vn)] if pi is None else world[(pi,mode,vn)]['max'];title=f'{mode} '+('held3 MAX'if pi is None else f'part{poses[pi]["localID"]} b{poses[pi]["b"]}')+f' {vn} 8m/px';panels.append(panel(v,title,True))
  row=Image.new('RGB',(sum(i.width for i in panels)+24,max(i.height for i in panels)),'#101820');x=0
  for im in panels:row.paste(im,(x,0));x+=im.width+12
  rows.append(row)
contact=Image.new('RGB',(max(i.width for i in rows),sum(i.height for i in rows)+12*len(rows)),'#101820');y0=0
for im in rows:contact.paste(im,(0,y0));y0+=im.height+12
contact.save(O/'held-projections.png')
# Fixed material slices retained in a contact; no selected outcome-dependent cuts.
ims=[panel(v,f'{k[0]} {k[1]} {k[2]}={k[3]:g}') for k,v in slices.items()];W=max(i.width for i in ims);H=max(i.height for i in ims);sheet=Image.new('RGB',(4*(W+10),math.ceil(len(ims)/4)*(H+10)),'#101820')
for j,im in enumerate(ims):sheet.paste(im,((j%4)*(W+10),(j//4)*(H+10)))
sheet.save(O/'fixed-slices.png')
im=Image.new('RGB',(800,360),'#101820');draw=ImageDraw.Draw(im);draw.text((10,8),'BODY fixed old-input central80 ROI | new author pre-distance profiles',fill='white');draw.rectangle((55,40,775,310),outline='#667788')
for percentile,col in [(10,'#4598d0'),(50,'#ffffff'),(90,'#f29e49')]:
 v=np.percentile(c,percentile,axis=0);pts=[(55+(yy-218.2)/16*720,310-float(q)/.30*270)for yy,q in zip(ys,v)];draw.line(pts,fill=col,width=2)
draw.text((55,320),'local Y218.2 ->234.2 | peak scale .30 | p10 blue / medianwhite / p90orange',fill='white');im.save(O/'base-profiles.png')
report={'recipeSHA256':sha(P/'RECIPE-v2.md'),'scriptSHA256':sha(Path(__file__)),'scope':'ONE cheap pre-distance scalar upper-bound screen only; NOEDT/NOnewR16/NOcurrentruntimechange; no art admission','native_metrics':metrics,'base':base,'silhouette_diagnostics':lobes,'macro_cue_pass':'requiresROOTimagejudgment; no automatic3Dshape certificate','result':'REJECT_preflight_base_gate'if not basepass else 'PENDING_ROOT_macro_cue_review','r16_outputs_written':0,'edt_calls':0,'native_volume_outputs_written':0,'projection_scope':'Exact local-axis native-centre max/Beer sums; posed figures are max native-centre splats, onepixel display footprint ONLY. No beauty/lighting or additive optical proxy for MAXunion. Numerical silhouette diagnostic unsmoothed.','peak_process_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'inputs_indexSHA256':sha(B/'assets/input-index.json')}
(O/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'result':report['result'],'base':base,'peak_process_bytes':report['peak_process_bytes']}),flush=True)
