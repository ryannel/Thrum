"""Complete the predeclared root/all-four-head orthogonal diagnostics, same frozen recipe. No rerun/cook."""
from pathlib import Path
import ast,json,hashlib,resource
import numpy as np
from PIL import Image,ImageDraw
P=Path(__file__).resolve().parent;B=P.parent/'cloud-natural-coupled-proof';O=P/'preflight-v3'
# Reuse ONLY the exact frozen scalar functions; don't execute its full projection/run body.
tree=ast.parse((P/'preflight.py').read_text());selected=[]
for node in tree.body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='S' for t in node.targets):selected.append(node)
 if isinstance(node,ast.FunctionDef) and node.name in ['hash32','noise','author']:selected.append(node)
exec(compile(ast.Module(body=selected,type_ignores=[]),str(P/'preflight.py'),'exec'),globals())
rows=[];record=[]
for role in ['body','crown-b']:
 m=json.loads((B/'assets/templates'/f'{role}.json').read_text());nx,ny,nz=m['dimensions_xyz'];origin=np.array(m['domain_origin_global_xyz_local_m']);rho=np.memmap(B/'assets/templates'/f'{role}.density.r16f',dtype='<f2',mode='r',shape=(nz,ny,nx));d=np.memmap(B/'assets/templates'/f'{role}.distance.r16f',dtype='<f2',mode='r',shape=(nz,ny,nx));points=[('root',m['root_global_xyz_local_m'])]+[(h['id'],h['centerLocal'])for h in m.get('headWitnesses',[])];seen=set()
 for label,c in points:
  for axis in range(3):
   j=int(round((c[axis]-origin[axis]-1)/2));fixed=float(origin[axis]+1+2*j);key=(axis,j)
   if key in seen:continue
   seen.add(key)
   if axis==0:r=rho[:,:,j].astype(np.float64);v=d[:,:,j].astype(np.float64);x=fixed;y=(origin[1]+1+2*np.arange(ny))[None,:];z=(origin[2]+1+2*np.arange(nz))[:,None]
   elif axis==1:r=rho[:,j,:].astype(np.float64);v=d[:,j,:].astype(np.float64);x=(origin[0]+1+2*np.arange(nx))[None,:];y=fixed;z=(origin[2]+1+2*np.arange(nz))[:,None]
   else:r=rho[j].astype(np.float64);v=d[j].astype(np.float64);x=(origin[0]+1+2*np.arange(nx))[None,:];y=(origin[1]+1+2*np.arange(ny))[:,None];z=fixed
   vals=[('old',r*S((v+8)/16)),('author',author(r,v,x,y,z,role))];panels=[]
   for mode,a in vals:
    t=np.sqrt(np.clip(a/.30,0,1));rgb=np.stack([30+210*t,45+205*t,65+180*t],-1).astype('u1');im=Image.fromarray(np.flipud(rgb));pan=Image.new('RGB',(max(270,im.width),im.height+36),'#101820');pan.paste(im,(0,36));ImageDraw.Draw(pan).text((2,2),f'{role} {label} {"XYZ"[axis]}={fixed:g} {mode}',fill='white');panels.append(pan)
   row=Image.new('RGB',(sum(a.width for a in panels)+10,max(a.height for a in panels)),'#101820');row.paste(panels[0],(0,0));row.paste(panels[1],(panels[0].width+10,0));rows.append(row);record.append({'role':role,'pointLabel':label,'point':c,'axis':'XYZ'[axis],'actualNativePlaneLocalM':fixed})
W=max(i.width for i in rows);H=sum(i.height+8 for i in rows);im=Image.new('RGB',(W,H),'#101820');yy=0
for row in rows:im.paste(row,(0,yy));yy+=row.height+8
im.save(O/'fixed-slices-all.png');(O/'fixed-slices-all.json').write_text(json.dumps({'scope':'Completes originally omitted fixedroot/allhead slices. Same scalar recipe; no parameter/rho/d/EDT rerun, base result unchanged.','frozenScriptSHA256':hashlib.sha256((P/'preflight.py').read_bytes()).hexdigest(),'planes':record,'processPeakBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n');print('fixedplanes',len(record),'peak',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
