import json,pathlib,sys,hashlib,resource
import numpy as np
from scipy.ndimage import uniform_filter
root=pathlib.Path(__file__).resolve().parent
base=root.parent/'cloud-natural-coupled-proof/assets'
role=sys.argv[1];m=json.loads((base/'templates'/f'{role}.json').read_text())
dims=m.get('dimensions_xyz');dims=dims or m['domain']['dims'];shape=tuple(dims[::-1]);pitch=2
scales=[4] if role=='body' else [5,6]
idx=json.loads((base/'input-index.json').read_text());pins={}
for kind in ['density','distance']:
 f=base/idx['templates'][role][kind]['file'];b=f.read_bytes();h=hashlib.sha256(b).hexdigest();assert h==idx['templates'][role][kind]['sha256'];pins[kind]=h;del b
rho=np.memmap(base/'templates'/f'{role}.density.r16f',dtype='<f2',mode='r',shape=shape).astype(np.float32)
d=np.memmap(base/'templates'/f'{role}.distance.r16f',dtype='<f2',mode='r',shape=shape).astype(np.float32)
u=np.clip((d+8)/16,0,1);u*=u*(3-2*u);q=rho*u;del u
levels=[0,.001,.005,.01,.041,.1,.2]
def pct(a):return [float(x) for x in np.percentile(a,[1,10,25,50,75,90,99])] if a.size else []
def stat(a):return {'max':float(a.max()),'mean_domain':float(a.mean(dtype=np.float64)),'positive_quantiles_p1_10_25_50_75_90_99':pct(a[a>0]),'count_above':{str(t):int(np.count_nonzero(a>t)) for t in levels},'integral_local_m3':float(a.sum(dtype=np.float64)*8)}
r={'role':role,'pins':pins,'dimensions_xyz':dims,'pitch_local_m':2,'rho':stat(rho),'q':stat(q),'d_inside_rho_ge_001_quantiles':pct(d[rho>=.001]),'taper':{'mass_loss_fraction':float(1-q.sum(dtype=np.float64)/rho.sum(dtype=np.float64)),'mass_fraction_in_abs_d_le8':float(rho[np.abs(d)<=8].sum(dtype=np.float64)/rho.sum(dtype=np.float64)),'rho_ge_041_fraction_taper_affected':float(np.count_nonzero((rho>=.041)&(d<8))/max(1,np.count_nonzero(rho>=.041)))},'gradients':{},'scales':{}}
for name,a in [('rho',rho),('q',q)]:
 r['gradients'][name]={}
 for axis in range(3):
  v=np.abs(np.diff(a,axis=axis))/2
  r['gradients'][name][str(axis)]={'positive_gradient_quantiles_per_local_m':pct(v[v>0]),'L1total':float(v.sum(dtype=np.float64))};del v
# Fraction of scalar L2 energy removed by a box filter; not a perceptual spectral verdict.
energy=float(np.square(q,dtype=np.float64).sum())
for s in scales:
 sr={'native_pitch_world_m':2*s,'taper_10_90_world_m':float(9.7335966*s),'projection_tau':{},'detail_box_residual_energy_fraction':{}}
 for axis,name in [(0,'frontZ'),(2,'sideX'),(1,'topY')]:
  tau=q.sum(axis=axis,dtype=np.float64)*2*s*.019;rawtau=rho.sum(axis=axis,dtype=np.float64)*2*s*.019
  sr['projection_tau'][name]={'positive_tau_quantiles':pct(tau[tau>0]),'positive_opacity_quantiles':pct(-np.expm1(-tau[tau>0])),'area_tau_gt1_fraction_of_positive':float(np.count_nonzero(tau>1)/max(1,np.count_nonzero(tau>0))),'raw_tau_quantiles':pct(rawtau[rawtau>0])}
 for world in [32,64,128]:
  width=max(1,round(world/(2*s)));width+=1-width%2
  low=uniform_filter(q,size=width,mode='constant');low-=q
  sr['detail_box_residual_energy_fraction'][str(world)]={'actual_filter_world_m':width*2*s,'fraction':float(np.square(low,dtype=np.float64).sum()/energy)};del low
 r['scales'][str(s)]=sr
origin=m.get('domain_origin_global_xyz_local_m',m.get('domain',{}).get('origin'))
r['vertical_profiles']=[{'y_local':origin[1]+(y+.5)*2,'q_peak':float(q[:,y,:].max()),'q_sum':float(q[:,y,:].sum(dtype=np.float64)),'rho_peak':float(rho[:,y,:].max()),'footprint_q_gt_005':int(np.count_nonzero(q[:,y,:]>.005))} for y in range(shape[1])]
r['peak_process_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
(root/'results'/f'{role}.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'role':role,'rho':r['rho'],'q':r['q'],'taper':r['taper'],'peak_process_bytes':r['peak_process_bytes']}))
