import pathlib,json,numpy as np,resource
p=pathlib.Path(__file__).resolve().parent;b=p.parent/'cloud-natural-coupled-proof/assets';n=np.memmap(b/'noise/channels-32.r16f',dtype='<f2',mode='r',shape=(32,32,32)).astype(np.float32);o={}
for role in ['body','crown-b']:
 m=json.loads((b/'templates'/f'{role}.json').read_text());dims=m['dimensions_xyz'];origin=m['domain_origin_global_xyz_local_m'];nx,ny,nz=dims;r=np.memmap(b/'templates'/f'{role}.density.r16f',dtype='<f2',mode='r',shape=(nz,ny,nx));vals=[]
 x=(origin[0]+(np.arange(nx)+.5)*2)/16-.5;y=(origin[1]+(np.arange(ny)+.5)*2)/16-.5;ix=np.floor(x).astype(int);iy=np.floor(y).astype(int);fx=x-ix;fy=y-iy
 for z in range(nz):
  zz=(origin[2]+(z+.5)*2)/16-.5;iz=int(np.floor(zz));fz=zz-iz;plane=np.zeros((ny,nx),dtype=np.float64)
  for dz in [0,1]:
   for dy in [0,1]:
    for dx in [0,1]:plane+=n[np.clip(iz+dz,0,31),np.clip(iy+dy,0,31)[:,None],np.clip(ix+dx,0,31)[None,:]]*(fx if dx else 1-fx)[None,:]*(fy if dy else 1-fy)[:,None]*(fz if dz else 1-fz)
  vals.append((.3+.7*plane)[r[z]>=.001].astype(np.float32))
 v=np.concatenate(vals);o[role]={'M_on_rho_ge_001_percentiles_0_1_10_50_90_99_100':[float(a) for a in np.percentile(v,[0,1,10,50,90,99,100])],'native_noise_pitch_local_m':16,'gaussian_sigma_local_m':24,'kernel_FWHM_local_m':float(2*np.sqrt(2*np.log(2))*24),'gaussian_autocorrelation_FWHM_local_m':float(2*np.sqrt(2*np.log(2))*24*np.sqrt(2))}
o['peak_process_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss;(p/'results/noise.json').write_text(json.dumps(o,indent=2)+'\n');print(json.dumps(o))
