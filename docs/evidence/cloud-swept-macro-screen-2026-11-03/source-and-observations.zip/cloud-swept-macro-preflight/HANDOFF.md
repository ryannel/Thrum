# Macro-only prepared code — root review before first field

Inputs remain exact DECISION91fc4a5e, controls7914491d, commissiona62671e2 under inputs/. No recipe parameter changed. Original freeze0cb6f9a and its211-test receipt are preserved in history/code-review-first. review-first.md retains all six review findings: two actual macro fixes checked; three detailed-gate defects blocked, not passed; the RSS finding was withdrawn as a reviewer pre-freeze-read mismatch.

Current phase: four serial A/B BODY/crown **macro-only** grids, fixed scalar projections/slices/base/topology/major-owner/shoulder/chord gates, then unconditional hard stop. Detail is unavailable even if every macro gate passes. No detail grid entry or detailed support search remains in screen.py. Actual normalized oblique3D direction now changes h along the main chord. Root/worker/descendant sampled RSS already included the watchdog in original0cb; the new explicit PID assertion/mock adds verification only. Gate counts require distinct major owners, not shoulder/noise peaks.

211 scalar/structural checks PASS;25 small phase checks PASS (b4/b5/b6 3D chord mapping and finite domain, owner classification, mocked process tree, AST/CLI macro-only rejection). Five scripts pass py_compile. The tests allocate only scalar/1D/short mocked state, no full fields. Installed CPython3.14.10, NumPy2.4.6, SciPy1.17.1, Pillow12.2.0. scalar-results.json and phase-results.json retain exact results.

**No full field, candidate projection PNG, EDT or R16 output has executed.** Source91/current viewers/canonical/Git remain untouched. MEMORY.md keeps <=200MiB planned phase maximum with sampled224/256MiB policy; nothing claims an OS hard cap or measured field peak. FREEZE.json pins inputs, code, views and handoff before execution.

First-run command, ONLY after root explicit first-run authorization and narrow code-review closure:

    /opt/homebrew/bin/python3.14 /Users/ryannel/Workspace/thrum/tmp/worktrees/cloud-system-design/tmp/cloud-swept-macro-preflight/run_guard.py --authorize-field-run --macro-only

Flags do not supply authorization. The wrapper verifies current frozen bytes, refuses an existing run, executes screen.py --execute-field --macro-only once and retains sampled RSS/first failure. No retry, parameter search, detail, EDT or asset cook is authorized. Scalar projections and finite sampled contour/connectivity are neither beauty nor accepted anatomy. Final native2m/q/profile/root/neck/BVH/support/lifecycle/CPU/GPU/cost qualification remains unrun.
