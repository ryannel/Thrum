"""Pinned cu-swept-macro-v2 scalar author. No import-time field grids or I/O outputs.
D is an approximate positive-inside margin, never certified Euclidean distance.
"""
from pathlib import Path
import hashlib,json,math
import numpy as np
from scipy.interpolate import PchipInterpolator
ROOT=Path(__file__).resolve().parent
INPUT_HASHES={'DECISION-v2.md':'91fc4a5eac52ac4da17a85bd0679d003a4f040addf05bc2fae95a0a8daf8b357','controls-v2.json':'7914491d5f53c50b187bc9be9f9ea2b98196f9795a0af5b3085b1749fb695057','PREFLIGHT-COMMISSION-v2.md':'a62671e2ae8592f45cd59f0d784c657640116f0f8e9887dc71af7a581b248e91'}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def controls():
 for name,h in INPUT_HASHES.items():
  if sha(ROOT/'inputs'/name)!=h: raise ValueError('input hash mismatch: '+name)
 c=json.loads((ROOT/'inputs/controls-v2.json').read_text())
 if c['version']!='cu-swept-macro-v2': raise ValueError('version')
 return c
def smooth(t):
 t=np.clip(t,0.,1.); return t*t*(3.-2.*t)
def hash32(i,j,k,seed):
 with np.errstate(over='ignore'):
  x=np.uint32(seed)^np.asarray(i,dtype=np.int64).astype('u4')*np.uint32(0x9e3779b1)^np.asarray(j,dtype=np.int64).astype('u4')*np.uint32(0x85ebca77)^np.asarray(k,dtype=np.int64).astype('u4')*np.uint32(0xc2b2ae3d)
  x=x^(x>>16);x=x*np.uint32(0x7feb352d);x=x^(x>>15);x=x*np.uint32(0x846ca68b);return x^(x>>16)
def noise(x,y,z,pitch,seed):
 x,y,z=np.broadcast_arrays(np.asarray(x)/pitch,np.asarray(y)/pitch,np.asarray(z)/pitch)
 ix,iy,iz=[np.floor(v).astype(np.int64) for v in (x,y,z)];fx,fy,fz=[smooth(v-i) for v,i in zip((x,y,z),(ix,iy,iz))]
 v=[]
 for dz in (0,1):
  row=[]
  for dy in (0,1):
   a=(hash32(ix,iy+dy,iz+dz,seed).astype(np.float64)+.5)/2**32;b=(hash32(ix+1,iy+dy,iz+dz,seed).astype(np.float64)+.5)/2**32
   row.append(a+(b-a)*fx)
  v.append(row[0]+(row[1]-row[0])*fy)
 return v[0]+(v[1]-v[0])*fz
class Branch:
 def __init__(self,v,b,role):
  self.variant=v;self.spec=b;self.id=b['id'];self.role=role;k=np.asarray(b['knots'],dtype=np.float64)
  if len(k)<3 or k.shape[1]!=5 or not np.isfinite(k).all() or not np.all(np.diff(k[:,0])>0) or np.any(k[:,3:]<0) or np.any(k[-1,3:]!=0):raise ValueError('bad knots '+self.id)
  if np.any(k[1:-1,3:]<=0):raise ValueError('interior zero radius '+self.id)
  self.k=k;self.lo=float(k[0,0]);self.pen=float(k[-2,0]);self.H=float(k[-1,0]);self.delta=self.H-self.pen
  self.centres=[PchipInterpolator(k[:,0],k[:,j],extrapolate=False) for j in (1,2)]
  self.radii=[PchipInterpolator(k[:-1,0],k[:-1,j],extrapolate=False) for j in (3,4)]
  self.rpen=k[-2,3:].copy();self.slope=np.array([f.derivative()(self.pen) for f in self.radii])
  self.sectors=np.array([.86+.28*(int.from_bytes(hashlib.sha256(f'cu-swept-macro-v2|{v}|{self.id}|{j}'.encode()).digest()[:4],'little')/2**32) for j in range(8)])
 def section(self,h):
  h=np.asarray(h,dtype=np.float64);live=(h>=self.lo)&(h<self.H)
  hc=np.clip(h,self.lo,self.H);cx,cz=[f(hc) for f in self.centres];rr=[]
  for j,f in enumerate(self.radii):
   low=f(np.minimum(hc,self.pen));t=np.clip((hc-self.pen)/self.delta,0,1)
   cap=self.rpen[j]*np.sqrt(np.maximum(0.,1-t*t))+self.delta*self.slope[j]*t*(1-t)**2
   r=np.where(hc<=self.pen,low,cap)
   if np.any(r<0) or np.any((hc>self.pen)&(r>1.05*self.rpen[j])):raise ValueError('radius closure envelope '+self.id)
   rr.append(r)
  live=live&(rr[0]>0)&(rr[1]>0)
  return cx,cz,rr[0],rr[1],live
 def sector(self,theta):
  u=np.mod(theta,2*math.pi)*(8/(2*math.pi));i=np.floor(u).astype(np.int64);t=u-i
  p0,p1,p2,p3=[self.sectors[(i+j)%8] for j in (-1,0,1,2)]
  return np.clip(.5*(2*p1+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t),.80,1.20)
 def margin(self,x,h,z,a,detail=False,seed=0):
  x,h,z=np.broadcast_arrays(x,h,z);cx,cz,rx,rz,live=self.section(h)
  # Endpoint emptiness is decided before division; zero denominators are never evaluated.
  rr=np.zeros_like(x,dtype=np.float64);u=np.zeros_like(rr);v=np.zeros_like(rr)
  np.divide(x-cx,rx,out=u,where=live);np.divide(z-cz,rz,out=v,where=live)
  theta=np.arctan2(v,u)+self.spec['twistRadians']*(h-self.lo)/(self.H-self.lo)
  rr=np.minimum(rx,rz)*(self.sector(theta)-np.sqrt(u*u+v*v));rr=np.where(live,rr,-np.inf)
  if detail:
   d=rr.copy();cfg=(40,40,100,60,40,40,16,20,8) if self.role=='body' else (8,10,20,12,8,20,8,2.5,1)
   tip,start,rise,band,fall,l1,l2,amp1,amp2=cfg
   w=smooth((self.H-h)/tip)*smooth((h-start)/rise)*(1-smooth((np.abs(d)-band)/fall))
   n=amp1*(2*noise(*a,l1,seed^0x243f6a88)-1)+amp2*(2*noise(*a,l2,seed^0x85a308d3)-1)
   rr=np.where(live,rr+w*n,-np.inf)
  return rr
class Model:
 def __init__(self,c,variant,role):
  self.c=c;self.variant=variant;self.role=role;self.cfg=c[role];self.seed=c['variants'][variant]['detailSeed']
  self.branches=[Branch(variant,b,role) for b in c['variants'][variant][role+'Branches']]
  self.byid={b.id:b for b in self.branches};self.origin=np.array(self.cfg['materialOriginXYZ'],float);self.dims=np.array(self.cfg['dimensionsXYZ'],int);self.span=self.dims*2;self.root=np.array(self.cfg['rootLocalXYZ'],float)
 def coordinates(self,a):
  if self.role=='body':return (4*(a[0]-self.root[0]),4*(a[1]-self.root[1])+self.cfg['rootWorldY']-self.cfg['LCLWorldY'],4*(a[2]-self.root[2]))
  return (a[0]-self.root[0],a[1]-self.root[1],a[2]-self.root[2])
 def amount(self,D,h):
  dl=D/4 if self.role=='body' else D;G=smooth(h/20) if self.role=='body' else 1.
  rho=(.75*G*smooth(dl/4)*(.80+.20*smooth(dl/16))).astype(np.float32).astype('<f2').astype(np.float64)
  return rho,rho*smooth((dl+6)/12)
 def sample(self,a,detail=False,isolated=None):
  a=np.broadcast_arrays(*a);x,h,z=self.coordinates(a);D=np.full(x.shape,-np.inf);owner=np.full(x.shape,-1,np.int8)
  for i,b in enumerate(self.branches):
   if isolated is not None and b.id!=isolated:continue
   d=b.margin(x,h,z,a,detail,self.seed);hit=d>D;D=np.maximum(D,d);owner=np.where(hit,i,owner)
  rho,q=self.amount(D,h);return rho,q,owner,D
 def material(self,x,h,z):
  if self.role=='body':return (self.root[0]+np.asarray(x)/4,self.root[1]+(np.asarray(h)-59.2)/4,self.root[2]+np.asarray(z)/4)
  return (self.root[0]+np.asarray(x),self.root[1]+np.asarray(h),self.root[2]+np.asarray(z))
 def world(self,a,b):return tuple(b*(np.asarray(a[j])-self.root[j])+(self.cfg['rootWorldY'] if self.role=='body' and j==1 else 0) for j in range(3))
 def containment(self):
  result=[]
  for b in self.branches:
   if b.spec['kind']!='shoulder':continue
   h,cx,cz,rx,rz=b.k[0];p=self.byid[b.spec['parent']];px,pz,prx,prz,live=p.section(h)
   bound=.8*min(prx,prz)-math.hypot(cx-px,cz-pz)-1.2*max(rx,rz)
   th=np.arange(360)*math.pi/180;d=p.margin(cx+rx*np.cos(th),np.full(360,h),cz+rz*np.sin(th),self.material(cx+rx*np.cos(th),h,cz+rz*np.sin(th)))
   guard=28 if self.role=='body' else 3.5
   result.append({'id':b.id,'bound':float(bound),'perimeter_min':float(d.min()),'guard':guard,'pass':bool(live and bound>=guard and d.min()>=guard)})
  return result
 def cap_checks(self):
  rows=[]
  for b in self.branches:
   h=np.linspace(b.pen,b.H,4097);_,_,rx,rz,_=b.section(h)
   rows.append({'id':b.id,'maximum_radius_ratio':float(max(np.max(rx)/b.rpen[0],np.max(rz)/b.rpen[1])),'pass':bool(np.max(rx)<=1.05*b.rpen[0] and np.max(rz)<=1.05*b.rpen[1])})
  return rows

def tau_min(w):
 if not 100<=w<=400:return None
 return .75 if w<150 else 1.2 if w<200 else 1.8 if w<=250 else 1.8+.010*(w-250)
def ideal_tau(w,b,n=10000,legacy=False):
 x=-w/2+(np.arange(n)+.5)*w/n;d=(w/2-np.abs(x))/b
 q=(.30*smooth(d/12)*(.65+.35*smooth(d/40))*smooth((d+6)/12)) if legacy else .75*smooth(d/4)*(.80+.20*smooth(d/16))*smooth((d+6)/12)
 return .019*float(q.sum())*w/n

def world_chord_samples(model,centre_material,world_direction,b):
 """Complete domain chord, world-metre t and actual unit 3D direction.
 Identity static pose only: a(t)=centre_material+direction*t/b.
 BODY h is recomputed by Model.coordinates, so oblique dy changes h by dy*t.
 Crown h changes by dy*t/b. No horizontal projection of the camera direction.
 """
 c=np.asarray(centre_material,dtype=float);d=np.asarray(world_direction,dtype=float)
 if c.shape!=(3,) or d.shape!=(3,) or not np.isfinite(c).all() or not np.isfinite(d).all() or abs(float(d@d)-1)>1e-12 or b<=0:raise ValueError('chord input')
 lo=-math.inf;hi=math.inf
 for j in range(3):
  if d[j]==0:
   if not model.origin[j]<=c[j]<=model.origin[j]+model.span[j]:raise ValueError('chord outside parallel slab')
  else:
   a=(model.origin[j]-c[j])*b/d[j];z=(model.origin[j]+model.span[j]-c[j])*b/d[j];lo=max(lo,min(a,z));hi=min(hi,max(a,z))
 if not lo<hi or not math.isfinite(lo+hi):raise ValueError('empty chord')
 count=max(1,math.ceil((hi-lo)/(2*b)));ds=(hi-lo)/count;t=lo+(np.arange(count)+.5)*ds
 material=tuple(c[j]+d[j]*t/b for j in range(3))
 return material,t,ds,(lo,hi)

def classify_crests(witnesses,branches):
 """Count distinct major-head owners; shoulders/scallops cannot replace masses."""
 kinds={b.id:b.spec['kind'] for b in branches};major=[w for w in witnesses if kinds.get(w['owner'])=='major'];shoulder=[w for w in witnesses if kinds.get(w['owner'])=='shoulder']
 return {'major_crest_count':len({w['owner'] for w in major}),'major_peak_count':len(major),'major_owners':sorted({w['owner'] for w in major}),'shoulder_peak_count':len(shoulder),'major_witnesses':major,'shoulder_witnesses':shoulder}
