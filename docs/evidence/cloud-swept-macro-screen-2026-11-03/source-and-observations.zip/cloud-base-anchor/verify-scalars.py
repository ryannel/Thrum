#!/usr/bin/env python3
"""Bounded independent point algebra; no native fields, runtime import or grids."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
BASE = [256.0, 218.2, 192.0]
ROOT = [256.0, 233.0, 192.0]
CROWN_ROOT = [224.0, 264.0, 192.0]
S = [.0016, 0.0, -.0012]


def add(a, b):
    return [x+y for x, y in zip(a, b)]


def sub(a, b):
    return [x-y for x, y in zip(a, b)]


def mul(s, a):
    return [s*x for x in a]


def mv(A, x):
    return [sum(a*b for a, b in zip(row, x)) for row in A]


def transpose(A):
    return list(map(list, zip(*A)))


def yaw(t):
    c, s = math.cos(t), math.sin(t)
    return [[c, 0., s], [0., 1., 0.], [-s, 0., c]]


def wind(y):
    return [4+S[0]*(y-1500), 0., -1+S[2]*(y-1500)]


def body(a, C, b, Q, K):
    d = sub(a, BASE)
    return add(C, add(mul(b, mv(Q, d)), mul(d[1], K)))


def crown(a, C, b, Q, K):
    v = mv(Q, sub(a, CROWN_ROOT))
    return add(C, add(mul(b, v), mul(v[1], K)))


def inverse(x, C, b, Q, K, pivot):
    h = (x[1]-C[1])/b
    v = mul(1/b, sub(sub(x, C), mul(h, K)))
    return add(pivot, mv(transpose(Q), v))


def close(a, b, tolerance=1e-9):
    error = max(abs(x-y) for x, y in zip(a, b))
    assert error < tolerance, (a, b, error)
    return error


out = {"scope": "Independent scalar/point algebra only; no runtime/native/GPU/art/cost pass", "cases": {}}
Q = yaw(math.pi/2)
C = [100., 1180., -40.]
a = [270., 260., 210.]
for K, label in [([0., 0., 0.], "mature_zero_shear"), ([.2, 0., -.1], "mature_sheared")]:
    new = body(a, C, 4., Q, K)
    oldC = add(C, add(mul(4., mv(Q, sub(ROOT, BASE))), mul(14.8, K)))
    v = mv(Q, sub(a, ROOT))
    old = add(oldC, add(mul(4., v), mul(v[1], K)))
    out["cases"][label] = {"new": new, "old": old, "oldInteriorAnchor": oldC, "maxError": close(new, old)}

levels = []
for b in [.0625, 2.03125, 4.]:
    basePoint = body([300., 218.2, 190.], C, b, Q, [.2, 0., -.1])
    rootPoint = body(ROOT, C, b, Q, [.2, 0., -.1])
    close([basePoint[1]], [1180.])
    levels.append({"b": b, "baseY": basePoint[1], "positiveRootY": rootPoint[1]})
oldBaseY = [1239.2+b*(218.2-233.) for b in [.0625, 4.]]
close([oldBaseY[0]-oldBaseY[1]], [58.275])
out["cases"]["fixed_base_growth"] = {"states": levels, "oldBaseY": oldBaseY, "oldDescentM": oldBaseY[0]-oldBaseY[1]}

b0, bd = 2.03125, .06328125
K0 = [.2, 0., -.1]
site = [276., 258.2, 182.]
d = sub(site, BASE)
qd = mv(Q, d)
expected = add(wind(1180.), add(mul(bd, qd), mul(b0*d[1], S)))


def scale_at(t):
    # Actual retained response law: mu0=.6,target=1,time constant2s.
    tau = 32.+t-.8*(1-math.exp(-t/2.))
    u = max(0., min(1., (tau-4.)/56.))
    return 4.*(1/64.+(1.-1/64.)*u*u*(3.-2.*u))


def pose_at(t):
    # Simpson scalar integral; signed t supports central differences.
    integral = t/6.*(scale_at(0.)+4.*scale_at(t/2.)+scale_at(t))
    return body(site, add(C, mul(t, wind(1180.))), scale_at(t), Q, add(K0, mul(integral, S)))


finite = []
for epsilon in [1e-2, 1e-3]:
    observed = mul(.5/epsilon, sub(pose_at(epsilon), pose_at(-epsilon)))
    finite.append({"epsilonS": epsilon, "velocity": observed, "maxError": close(observed, expected, 1e-5)})
point = body(site, C, b0, Q, K0)
childU = sub(expected, wind(point[1]))
close(add(wind(point[1]), childU), expected)
out["cases"]["parent_point_velocity_and_crown_birth"] = {"tau": 32., "mu": .6, "b": b0, "bDot": bd, "parentSite": site, "worldPoint": point, "velocity": expected, "finiteDifferences": finite, "crownInitialWindRelativeU": childU, "reconstructedRootVelocity": add(wind(point[1]), childU)}

roundtrip = 0.
for theta in [0., .37, math.pi/2.]:
    frame = yaw(theta)
    for b in [.0625, 2.03125, 4.]:
        p = body(a, C, b, frame, K0)
        roundtrip = max(roundtrip, close(inverse(p, C, b, frame, K0, BASE), a))
# 8-corner versus independently expanded affine row min/max, not a field grid.
lo, hi = [64., 176., 0.], [448., 384., 384.]
frame = yaw(.37)
b = 2.03125
points = [body([x, y, z], C, b, frame, K0) for x in [lo[0], hi[0]] for y in [lo[1], hi[1]] for z in [lo[2], hi[2]]]
rowBounds = []
for i in range(3):
    row = [b*frame[i][j]+(K0[i] if j == 1 else 0.) for j in range(3)]
    low = C[i]+sum(min(row[j]*(lo[j]-BASE[j]), row[j]*(hi[j]-BASE[j])) for j in range(3))
    high = C[i]+sum(max(row[j]*(lo[j]-BASE[j]), row[j]*(hi[j]-BASE[j])) for j in range(3))
    close([low, high], [min(p[i] for p in points), max(p[i] for p in points)])
    rowBounds.append([low, high])
out["cases"]["yaw_roundtrip_and_affine_corner_bounds"] = {"maxRoundtripError": roundtrip, "worldBoundsByAxis": rowBounds}

# Crown retains full fixed birth tilt. Its shear depends on rotated height.
c, s = math.cos(.4), math.sin(.4)
F = [[1., 0., 0.], [0., c, -s], [0., s, c]]
ac = [236., 281., 187.]
cc = [100., 1330., -40.]
pc = crown(ac, cc, 3., F, K0)
err = close(inverse(pc, cc, 3., F, K0, CROWN_ROOT), ac)
v0 = mv(F, sub(ac, CROWN_ROOT))
u = [.2, .3, -.1]
v = add(add(wind(cc[1]), u), add(mul(.07, v0), mul(3.*v0[1], S)))
epsilon = .001

def fixed_crown_at(t):
    # Differential jet: Cdot=W(C.y)+u held at instant; bdot=.07,Kdot=S*b.
    return crown(ac, add(cc, mul(t, add(wind(cc[1]), u))), 3.+.07*t, F, add(K0, mul(3.*t+.035*t*t, S)))

observed = mul(.5/epsilon, sub(fixed_crown_at(epsilon), fixed_crown_at(-epsilon)))
out["cases"]["fixed_tilted_crown"] = {"roundtripError": err, "velocity": v, "finiteDifference": observed, "maxError": close(v, observed, 1e-6)}

# Hypothetical yaw rotation shows precisely the term omitted by frozen-Q law.
theta, omega = .3, .02
frame = yaw(theta)
cp, sp = math.cos(theta), math.sin(theta)
Qdot = [[-sp*omega, 0., cp*omega], [0., 0., 0.], [-cp*omega, 0., -sp*omega]]
extra = mul(b0, mv(Qdot, d))
eps = 1e-3
fd = mul(.5/eps, sub(body(site, C, b0, yaw(theta+omega*eps), K0), body(site, C, b0, yaw(theta-omega*eps), K0)))
close(extra, fd, 1e-7)
# Hypothetical pitch rotation has an additional K*(Qdot*d).y in crown form.
Qdot_pitch = [[0., 0., 0.], [0., 0., -omega], [0., omega, 0.]]
qd_pitch = mv(Qdot_pitch, [12., 17., -5.])
crown_extra = add(mul(3., qd_pitch), mul(qd_pitch[1], K0))
assert max(abs(x) for x in crown_extra) > 0
out["cases"]["rotating_Q_not_selected"] = {"bodyMissing_bQdot_d": extra, "centralYawDerivative": fd, "crownHypotheticalPitchMissing_bQdot_d_plus_Kheight": crown_extra, "selectedQdot": 0., "policy": "Fixed birth Q only; BODY yaw only; reject mutation/tilt"}
# A single analytic deep column quantifies centre interpolation, not a volume cook.
G219 = (.16**2)*(3.-2.*.16)
rho219 = .75*G219
rhoAtBase = .6*rho219
close([rho219, rhoAtBase], [.051456, .0308736])
out["cases"]["native_centre_straddle_not_runtime_bound"] = {"lowerCentreY": 217., "upperCentreY": 219., "authoringBaseY": 218.2, "analyticRho217": 0., "analyticRho219": rho219, "linearRhoAtBaseBeforeQuantization": rhoAtBase, "matureReferenceToLowerCentreM": 4.*(218.2-217.), "scope": "Deep-column illustration only; fresh final-q native onset/support recertification required"}
out["allPassed"] = True
out["proofScriptSHA256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(HERE/"scalar-results.json").write_text(json.dumps(out, indent=2)+"\n")
print(json.dumps({"allPassed": True, "caseCount": len(out["cases"]), "results": str(HERE/"scalar-results.json")}, indent=2))
