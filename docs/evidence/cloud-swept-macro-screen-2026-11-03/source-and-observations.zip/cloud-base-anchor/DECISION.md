# Cu BODY base anchor — operating-model addendum

3 November 2026. **Selected bounded target; design and scalar checks only.** This addendum completes the missing moving-frame contract before the new macro Cu source is integrated. It supersedes the interior-pivot BODY motion/renewal assumptions of the pinned comparators, without changing the v2 native authoring field, role timing, common weather, selected one-clock opportunity schedule or crown safety/observation thresholds. Input and output SHA-256 pins are in [pins.json](pins.json); the callsite handoff is [MIGRATION.md](MIGRATION.md). No canonical note, frozen viewer, asset or runtime code is changed here.

The representation fault is exact: with old interior pivot `a_root=[256,233,192]`, fixed `C.y=1239.2` and base material height218.2, the base moves from1238.275 to1180 m as BODY `b` grows from.0625 to4. Its58.275 m descent is caused by the pivot, even though the native authoring gate is level. Correct the moving material frame; do not add a world clip or redraw native content every tick.

## State and ownership

| Quantity | Selected meaning and authority |
| --- | --- |
| Native material `a` | Existing v2 local metres; no rebasing of arrays, noise, EDT, exposure lattice, sockets, BVH nodes or native sample centres. BODY `h_author=4*(a.y-218.2)` remains the mature authoring coordinate. |
| `transformPivotLocal` | BODY `a_base=[256,218.2,192]`; crown `[224,264,192]`. A transform origin, with no positivity or sampled-zero promise. Immutable F4 metadata, copied/pinned with each birth and snapshot. |
| `positiveRootLocal` | BODY `[256,233,192]`; crown `[224,264,192]`. Interior ball/chain certificate origin, separately recertified from final decoded q. BODY's base pivot is never the centre of a positive root ball. |
| `C` | BODY world base anchor `R_base`, with `C.y=1180`; crown world attachment-root position. Thus BODY's positive root is `forward(positiveRootLocal)`, **not** `C`. Explicit `frameKind=body-base-v1/crown-root-v1` discriminates these semantics. |
| `region` | One formation-owned base anchor; active BODY `C` agrees with it at each source barrier. Region Y is1180, its horizontal velocity is shared `W(1180)`. Inactive B retains its future birth XZ until activation; no preactivation advection. |
| `Q` / stored `Qcolumns` | `Q` below is the actual material→world linear frame. Existing `Qcolumns` stores vectors used by inverse dot-products, so the actual forward frame is `fieldColumns(Qcolumns)`, its numerical dual. Do not replace this dual by a transpose while preserving the old inverse. BODY is birth-fixed yaw only, with vertical row/column exactly `[0,1,0]`; crown keeps its admitted birth-fixed full frame. |
| `b`, `K`, `u` | `b=s*growth(role,tau)>0`; `K` is accumulated shear in world metres per local metre, `K.y=0`; crown `u` is root velocity relative to shared wind. BODY `u=0` identically. All are per-part histories; births reset only the new part. |

Use distinct metadata keys; do not overload the existing template `rootLocal` with the authoring-base pivot and then keep its positive-ball assertions. The current descriptor `root` can remain a versioned packing alias for `transformPivotLocal`, but every certificate reads `positiveRootLocal` explicitly. Emit frame/recipe revisions in checkpoint/publication and reject mixed old/new restores. The F4 domain and height/branch controls are unchanged. The fixed reference plane is distinct from reconstructed strict-positive support: pitch2/originY176 puts centre samples at217 and219 around218.2. Even a deep interior gated column with analytic rho217=0 and rho219=.051456 reconstructs rho218.2=.0308736 by linear interpolation before quantization, with positive support extending toward217. At b4 this is up to4.8 m below the1180 reference plane in that simple column; this scalar example is not a final-q bound. Keep finite native support/onset recertification in the forthcoming cook/profile, including the existing≤24 m10→90 rise and≤16 m onset-range screen plus fresh final-q tests. No new runtime gate or v2 field change is selected here. LCL1180 is fixed in this bounded profile. A future changing LCL requires a new motion/condensation contract, not assigning all old parts a new Y each tick.

## Map, inverse, bounds and velocity

Let `e_y=[0,1,0]`, `S=[shearX,0,shearZ]`, `W(y)=[meanX+shearX*(y-1500),0,meanZ+shearZ*(y-1500)]`. Shared weather is horizontal wind; crown uplift is its internal response, not a vertical component to add to BODY wind.

For BODY let `d=a-a_base` and select:

```
x(a,t) = R_base(t) + b(t)*Q*d + K(t)*d.y
R_base_dot = W(1180), R_base.y = 1180
K_dot = S*b
b_dot = s*growthDerivative(role,tau)*mu
v(a,t) = W(1180) + b_dot*Q*d + S*b*d.y
       = W(x.y) + b_dot*Q*d
```

The last identity uses fixed yaw, `Q`'s exact vertical axis and `K.y=0`. Every point on `a.y=218.2` remains on world Y1180; a positive interior root rises as `1180+14.8*b`. Horizontal material expands about the base point. Neither `W.y`, uplift, nor a spurious `b_dot*K` term appears. `K` stores the integral of `S*b`, not a dimensionless shear to multiply by `b` again. Existing quadrature for the growth integral remains its numerical approximation; command barriers use the same old half-open interval controls for region and K.

For crown let `d=a-positiveRootLocal`, `v0=Q*d`. Retain:

```
x = C + b*v0 + K*v0.y
C_dot = W(C.y) + u
u_dot = ([0,uplift,0]-u)/10
K_dot = S*b
v = W(C.y)+u + b_dot*v0 + S*b*v0.y
```

One affine form serves both roles under the BODY yaw restriction: `x=C+A*(a-transformPivotLocal)`, `A=(b*I+K*e_y^T)*Q`. Its exact inverse is `h=(x.y-C.y)/b`, `v0=(x-C-K*h)/b`, `a=transformPivotLocal+Q_inverse*v0`; `Q_inverse` is the stored dot-product matrix, not another reconstructed frame. This preserves the existing F64 CPU/F32 GPU numerical-dual convention. Eight transformed support/domain corners give exact affine AABBs. Jacobians, control-grid mapped edge pitch, inverse guards and singular-value bounds depend on A; pivot translation does not change those scales. Offset-dependent growth/shear sweep bounds **do** change because offsets now start at the base. If a consumer chooses explicit BODY `A=b*Q+K*e_y^T`, it is equal only while the yaw invariant is enforced.

Mature `b=4,K=0,R=[X,1180,Z]` is exactly v2's `C_old=[X,1239.2,Z]` and old pivot `[256,233,192]`, for any admitted yaw. With nonzero shear, exact instantaneous reparameterization is `C_old=R+4*Q*(a_root-a_base)+K*14.8 = R+[0,59.2,0]+14.8*K`. Keeping both horizontal C numbers unchanged shifts all points by14.8*K and is not equivalence. At arbitrary b, the corresponding old anchor is `C_old(t)=R+b*Q*(a_root-a_base)+K*14.8`; it is a derived moving interior point, never a second authority. New growth histories deliberately differ from the old fixed-interior-anchor histories; do not transplant the old region trajectory or inherit its acceptance evidence.

General differentiation, if an orientation were time varying, would add `b*Q_dot*d`. For crown's shear form it also adds `K*(Q_dot*d).y`; BODY's chosen local-height shear form does not. BODY pitch/roll would tilt the base and invalidate `d.y=v0.y`, the inverse and shear integration simplifications. **No time varying Q, pitch/roll BODY, finite-difference angular velocity, or frame interpolation is selected.** Store yaw at birth, keep exact vertical coefficients during F32 packing, cache its dual by that immutable birth frame, and reject unsupported frame changes. Crown may have a different fixed tilted birth frame; its inherited velocity includes its parent's actual point growth/shear, not an invented angular response.

## Real births, old material and one clock

Every initial, ordinary-renewal, recovery or rescue BODY birth is genuine new **parentless condensation** at current `region`, with `parentID=0`, `parentSite=null`, fresh exposure0, `K=0,u=0,tau=0,mu=1,b=.0625,Aseed=0`, its own monotonic ID and real source born tick. Positivity/collar/finite native/support/altitude checks and capacity/publication-union checks remain mandatory. There is no BODY neck lease, chooseBody parent attachment, zero-separation certificate or successful protected-establishment event. Weather or missing native qualification may decline a real opportunity; no part is pre-aged or made mature on recovery. Existing parts retain IDs, age, E, K and Q, even when a new BODY appears. They continue to contribute MAX within the formation under the selected common q; groups ADD once as before.

For an attached crown at selected native parent site `a_s`, compute `C_birth=forward(parent,a_s)` and `v_parent=fullVelocity(parent,a_s,committedControls)` from the **same actual barrier pose**. Then `u_child=v_parent-W(C_birth.y)`. Since its own root offset is0, crown root velocity at birth is exactly `W(C_birth.y)+u_child=v_parent`; shared wind is sampled once. Its later response decays toward `[0,uplift,0]`. Keep the existing parent maturity/loss-free lease, seed burial, separation≤11 m, resolved neck≥16 m, `.041/.005/6 m` exterior witness, held45 s prediction and actual all-old observation/cancellation gates. Recompute native certificates and swept bounds for the new fields/frames/profile; no previous acceptance transfers.

The [one-clock formation schedule](../cloud-formation-diversity-design/DECISION.md) still owns activation, all integer credit/delay/threshold draws, actual barrier attempts, pending seed retry/backoff, capacity, rescue timing and receipts. Only its call into BODY admission changes to parentless; its references to ordinary protected BODY admission are superseded. Its existing rescue guard/delay remains a scheduling rule for earlier new condensation, with no new attachment claim. The guard's60 s parent age horizon is retained literally for schedule compatibility; it must not be reused as an ordinary BODY admission requirement. The schedule’s off150/on200 worked example therefore changes mechanically: B’s ordinary211.75 BODY opportunity can succeed parentlessly if its native/weather/capacity gates pass; that actual birth cancels the already pending213.25 rescue under the schedule’s existing cancellation rule. Its former no-parent decline and later rescue birth cannot be carried over as expected outcomes. Do not add another schedule, epoch, clock or retroactive birth. All formation anchors/eligibility queries now mean the fixed-LCL base frame. Preserve the existing source response target sample at interval-start `C.x` and midpoint time for each part (BODY base, crown root), and region-midpoint eligibility for role credit; this correction does not silently alter time integration.

## Weather, health and publication consumers

Map every material exposure-lattice node through the corrected midpoint pose before `dryAt(worldX,intervalMidTime)`. Keep E irreversible and material-fixed. Source/held/reference forecasts, `health-x`'s midpoint minX and full-domain `weather-zero` bounds must all use the same base C, pivot, dual, b and K. For each A-row, `minX=C.x+sum_j min(A_xj*(domain.lo_j-pivot_j),A_xj*(domain.hi_j-pivot_j))`. `weather-zero` may retain its conservative `[0,s]` scale interval, bounded K interval, reserves and exact-input signature, but replace old BODY ROOT_Y with1180 and use the **transform** pivot in domain offsets. Its `rootCovered` shortcut becomes `driverCovered`: domain clear implies the C-position growth driver is clear only if the transform pivot lies in the domain; positivity is irrelevant. Include frame kind, both pivot/root metadata and profile/bundle hashes in reuse signatures. A stale proof returns unavailable/falls back, never clear.

Current/prior poses and observation all-old references keep the corrected per-part frame and advance exactly the same law, including BODYs that are only held references. A held BODY is not advanced at1239.2 merely because it has no live `region` argument. Interpolate same-ID C/b/K/Aseed with the declared quarter-second lag; BODY Y remains1180 at endpoints and between. Keep Q/pivots immutable, no future-born part before birth, previous-positive terminal parts/leases intact and staged checkpoints atomic.

The existing GPU affine inverse can represent the target **without increasing its24-float per-part stride**: C_b.xyz packs BODY base / crown root; K_rootX.w and rootYZ.xy pack the transform pivot; Q vectors retain inverse dot-product meaning. Positive roots/balls/sites are CPU/F4 metadata, not those packed fields. Bump/validate source-frame ABI/profile revision because the meaning changed. The diversity design's four-template bindings remain separate. CPU scalar/oracle, main, reflected/environment, light/ambient, receiver shadows, support intervals and diagnostics consume one immutable tuple and one q/profile. Replace diagnostics that assume `q(C)>0` with `q(forward(positiveRootLocal))`; the base pivot has no positive-root guarantee; no exact sampled `q(base)==0` theorem is claimed. Do not change κ, light, density or loss thresholds to compensate for the pivot.

## Bounded evidence and remaining work

[verify-scalars.py](verify-scalars.py) and [scalar-results.json](scalar-results.json) exercise only point/scalar algebra: mature zero/sheared equivalence, fixed level base while its interior root rises, yaw roundtrips/bounds, finite-difference actual parent-point velocity, crown birth inheritance, a fixed tilted crown frame and the missing terms under hypothetical rotating Q. They import no source runtime and allocate no field grid. This is an independent analytic comparator, not runtime correctness, native positivity, optical quality, GPU or cost proof. Before integration, complete the ordered checks in [MIGRATION.md](MIGRATION.md); keep all fresh native/profile/all-reader/admission and actual visual/cost gates open.
