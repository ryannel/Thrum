"""Small scalar/1D tests only. Never imports/exercises the coarse field screen."""
import json,math,platform,sys,hashlib
from pathlib import Path
import numpy as np,scipy,PIL
from macro import controls,Model,sha,noise,hash32,ideal_tau,tau_min,smooth
P=Path(__file__).resolve().parent
C=controls();tests=[]
def check(name,condition,detail=None):
 if not condition:raise AssertionError(name+': '+str(detail))
 tests.append({'name':name,'pass':True,'detail':detail})
check('known hash scalar',int(hash32(0,0,0,0))==0)
# Independent pure-Python unsigned32 hash oracle, including negative lattice coordinates.
def independent_hash(i,j,k,seed):
 x=(seed^((i*0x9e3779b1)&0xffffffff)^((j*0x85ebca77)&0xffffffff)^((k*0xc2b2ae3d)&0xffffffff))&0xffffffff
 x^=x>>16;x=x*0x7feb352d&0xffffffff;x^=x>>15;x=x*0x846ca68b&0xffffffff;return (x^(x>>16))&0xffffffff
vectors=[]
for v in [(0,0,0,1103),(-1,2,-3,1103^0x243f6a88),(1024,-99,71,2207^0x85a308d3)]:
 got=int(hash32(*v));expected=independent_hash(*v);check('hash vector '+str(v),got==expected);vectors.append({'input':v,'u32':got})
for seed in (1103^0x243f6a88,2207^0x85a308d3):
 got=float(noise(-40.,80.,120.,40,seed));expected=(independent_hash(-1,2,3,seed)+.5)/2**32;check('noise lattice exact '+str(seed),got==expected)
 got=float(noise(-20.,100.,140.,40,seed));corners=[(independent_hash(-1+i,2+j,3+k,seed)+.5)/2**32 for i in (0,1) for j in (0,1) for k in (0,1)];check('noise half-cell eight-corner mean '+str(seed),abs(got-sum(corners)/8)<2e-16)
 check('noise negative-coordinate continuity '+str(seed),abs(float(noise(-40-1e-7,80,120,40,seed))-float(noise(-40+1e-7,80,120,40,seed)))<1e-12)
check('smooth endpoints and midpoint',[float(smooth(v)) for v in (-1,0,.5,1,2)]==[0,0,.5,1,1])
records=[]
for variant in ('A','B'):
 for role in ('body','crown'):
  m=Model(C,variant,role)
  for b in m.branches:
   for row in b.k[:-1]:
    h,cx,cz,rx,rz=map(float,row);x,z,r1,r2,live=b.section(h);check('knot '+b.id+'/'+str(h),max(abs(x-cx),abs(z-cz),abs(r1-rx),abs(r2-rz))<2e-12)
   _,_,rx,rz,live=b.section(b.H);check('empty endpoint '+b.id,not bool(live) and rx==0 and rz==0)
   x,z,_,_,_=b.section(b.H);a=m.material(x,b.H,z)
   for detail in (False,True):check('endpoint field zero '+b.id+str(detail),float(m.sample(a,detail,b.id)[0])==0.)
   eps=1e-5;_,_,r1,r2,_=b.section(b.pen+eps);check('closure join slope '+b.id,max(abs((r1-b.rpen[0])/eps-b.slope[0]),abs((r2-b.rpen[1])/eps-b.slope[1]))<2e-4)
   sectors=[.86+.28*int.from_bytes(hashlib.sha256(f'cu-swept-macro-v2|{variant}|{b.id}|{j}'.encode()).digest()[:4],'little')/2**32 for j in range(8)]
   check('SHA sector knot '+b.id,np.array_equal(b.sector(np.arange(8)*math.pi/4),np.array(sectors)))
   check('cyclic sector seam '+b.id,abs(float(b.sector(-1e-9))-float(b.sector(2*math.pi-1e-9)))<1e-14)
  guards=m.containment();check('all start containment '+variant+'/'+role,all(x['pass'] for x in guards),guards)
  caps=m.cap_checks();check('all cap envelope '+variant+'/'+role,all(x['pass'] for x in caps),caps)
  rootcoords=m.coordinates(tuple(m.root));check('coordinate root '+variant+'/'+role,np.allclose(rootcoords,[0,59.2 if role=='body' else 0,0],rtol=0,atol=1e-12))
  if role=='body':
   a=m.material(0,0,0);check('LCL world mapping '+variant,abs(float(m.world(a,4)[1])-1180)<1e-10)
   check('base gate exact-zero '+variant,float(m.sample(a)[0])==0)
   a=m.material(0,20,0);check('density central deep maximum '+variant,float(m.sample(a)[0])==.75)
  records.append({'variant':variant,'role':role,'containment':guards,'caps':caps,'branch_sectors':{b.id:b.sectors.tolist() for b in m.branches}})
reference={4:[1.024,1.733,2.446,3.158],5:[.939,1.632,2.344,3.057],6:[.864,1.536,2.243,2.956]};table=[]
for b,expected in reference.items():
 values=[ideal_tau(w,b) for w in (100,150,200,250)];check('ideal optical table b'+str(b),max(abs(x-y) for x,y in zip(values,expected))<.00051,values);table.append({'b':b,'widths':[100,150,200,250],'tau':values})
check('width rule boundaries',[tau_min(w) for w in (99,100,149.999,150,199.999,200,250,400,401)]==[None,.75,.75,1.2,1.2,1.8,1.8,3.3,None])
# Frozen body gate alone can satisfy the screen, independently of any loft sampling.
check('ideal gate 10-90 width',abs(20*(.8041998943409083-.1958001056590917)-12.167995773636332)<1e-12)

shortest=[]
for variant,ids in [('A',{'A-crown-shoulder':(270.45337622159815,324.54405146591773)}),('B',{'B-crown-west':(287.06217242688626,344.4746069122635),'B-crown-east':(217.36866273207968,260.84239527849564)})]:
 m=Model(C,variant,'crown')
 for name,expected in ids.items():
  br=m.byid[name];h,cx,cz,rx,rz=br.k[-2];ph=np.arange(360)*math.pi/180;alpha=np.arctan2(np.sin(ph)/rz,np.cos(ph)/rx);rad=br.sector(alpha+br.spec['twistRadians']*(h-br.lo)/(br.H-br.lo))/np.sqrt((np.cos(ph)/rx)**2+(np.sin(ph)/rz)**2);width=float(np.min(rad+np.roll(rad,180)));values=[width*b for b in (5,6)];check('frozen shortest chord '+name,max(abs(a-b) for a,b in zip(values,expected))<1e-10,values);shortest.append({'branch':name,'width_b5_b6':values,'tau_min_b5_b6':[tau_min(w) for w in values]})
check('BODY mapped coarse grid',[v//2 for v in C['body']['dimensionsXYZ']]==[96,52,96])
check('crown mapped coarse grid',[v//2 for v in C['crown']['dimensionsXYZ']]==[56,48,56])
check('A-centre cap tip perturbation bound',all(28*float(smooth(e/40))<=.0525*e*e+1e-15 for e in (8,1,.1,.001)))
# Regression: a section ring has array X/Z but scalar Y; all returned axes must broadcast.
for role,b in [('body',4),('crown',6)]:
 m=Model(C,'A',role);x=m.root[0]+np.arange(360,dtype=float)/10;z=m.root[2]-np.arange(360,dtype=float)/20;y=float(m.root[1]+3);w=m.world((x,y,z),b)
 check('world ring broadcasts all axes '+role,all(v.shape==(360,) for v in w))
 expectedY=(m.cfg['rootWorldY'] if role=='body' else 0)+3*b
 check('world ring mapped values '+role,np.array_equal(w[0],b*(x-m.root[0])) and np.array_equal(w[2],b*(z-m.root[2])) and np.array_equal(w[1],np.full(360,expectedY)))
r={'status':'PASS','scope':'scalar, one-dimensional cap/sector/chord checks; no field grid, no field/candidate execution','test_count':len(tests),'versions':{'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,'scipy':scipy.__version__,'pillow':PIL.__version__},'tests':tests,'hash_vectors':vectors,'branches':records,'ideal_tau':table,'shortest_chords':shortest}
(P/'scalar-results.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'tests':len(tests),'field_executed':False,'versions':r['versions']}))
