"""Separately scheduled 100ms sampled process-tree RSS guard; NOT an OS memory cap."""
from pathlib import Path
import argparse,json,os,signal,subprocess,sys,time
P=Path(__file__).resolve().parent
def tree(root):
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines():
  p,pp,r=map(int,line.split());rows.append((p,pp,r*1024))
 ids={root};changed=True
 while changed:
  extra={p for p,pp,r in rows if pp in ids};changed=not extra.issubset(ids);ids|=extra
 return [(p,r) for p,pp,r in rows if p in ids]
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--authorize-field-run',action='store_true');parser.add_argument('--macro-only',action='store_true');a=parser.parse_args()
 if not a.authorize_field_run or not a.macro_only:parser.error('root first-run authorization required; --authorize-field-run is not authorization by itself')
 if (P/'results').exists() or (P/'guard.json').exists() or (P/'STOP').exists():raise RuntimeError('refuse overwrite/retry of any first-run state')
 pins=json.loads((P/'FREEZE.json').read_text())
 import hashlib
 for name,h in pins['files'].items():
  if hashlib.sha256((P/name).read_bytes()).hexdigest()!=h:raise ValueError('freeze mismatch '+name)
 cmd=[sys.executable,str(P/'screen.py'),'--execute-field','--macro-only'];log=open(P/'run.log','x');child=subprocess.Popen(cmd,cwd=P,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);samples=[];early=False;hard=False;start=time.monotonic();maximum=0
 while child.poll() is None:
  measured=tree(os.getpid());assert any(pid==os.getpid() for pid,_ in measured),'watchdog PID missing from full owned tree';rss=sum(r for _,r in measured);maximum=max(maximum,rss);samples.append({'monotonic_ns':time.monotonic_ns(),'elapsed_s':time.monotonic()-start,'processes':measured,'tree_rss_bytes':rss})
  if rss>=224*2**20:
   early=True;(P/'STOP').touch(exist_ok=True)
  if rss>=256*2**20:
   hard=True;os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=2)
   break
  time.sleep(.1)
 code=child.wait();log.close();out={'command':cmd,'sampling_interval_seconds':.1,'sampled_only_not_OS_cap':True,'early_stop_bytes':224*2**20,'termination_request_bytes':256*2**20,'sampled_tree_peak_bytes':maximum,'early_triggered':early,'hard_triggered':hard,'process_settled':child.poll() is not None,'exit_code':code,'elapsed_s':time.monotonic()-start,'samples':samples};(P/'guard.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='samples'}));return code or (1 if early or hard else 0)
if __name__=='__main__':raise SystemExit(main())
