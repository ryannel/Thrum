"""Small scalar/mocked phase checks. Never execute a scalar field grid."""
import ast,json,math,os,subprocess,sys
from pathlib import Path
from unittest.mock import patch
import numpy as np
from macro import Model,controls,world_chord_samples,classify_crests
from run_guard import tree
P=Path(__file__).resolve().parent;checks=[]
def check(name,v):
 assert v,name
 checks.append(name)
for role,b in [('body',4),('crown',5),('crown',6)]:
 m=Model(controls(),'A',role);branch=m.branches[0];h,cx,cz,_,_=branch.k[-2];centre=m.material(cx,h,cz);d=np.array([1.,.32,1.]);d/=np.linalg.norm(d);a,t,ds,iv=world_chord_samples(m,centre,d,b);x,hh,z=m.coordinates(a)
 expectedh=h+d[1]*t*(1 if role=='body' else 1/b)
 check('oblique h changes '+role+str(b),bool(np.allclose(hh,expectedh,rtol=0,atol=2e-13)) and float(np.ptp(hh))>0)
 for j in range(3):check('exact material coordinate '+role+str(b)+' axis'+str(j),bool(np.array_equal(a[j],centre[j]+d[j]*t/b)))
 check('complete domain endpoints '+role+str(b),all(m.origin[j]-1e-12<=centre[j]+d[j]*iv[0]/b<=m.origin[j]+m.span[j]+1e-12 and m.origin[j]-1e-12<=centre[j]+d[j]*iv[1]/b<=m.origin[j]+m.span[j]+1e-12 for j in range(3)))
 check('native chord spacing '+role+str(b),0<ds<=2*b)
m=Model(controls(),'A','body');w=[{'owner':'A-centre'},{'owner':'A-centre'},{'owner':'A-west-shoulder'}];r=classify_crests(w,m.branches)
check('shoulders and repeated scallops do not replace major heads',r['major_crest_count']==1 and r['major_peak_count']==2 and r['shoulder_peak_count']==1)
root=os.getpid();mock=f'{root} 1 100\n900001 {root} 200\n900002 900001 300\n900003 1 400\n'.encode()
with patch('subprocess.check_output',return_value=mock):got=tree(root)
check('full owned tree includes watchdog worker descendant only',got==[(root,102400),(900001,204800),(900002,307200)])
code=(P/'screen.py').read_text();parsed=ast.parse(code);calls=[n for n in ast.walk(parsed) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='field']
check('only macro field call exists',len(calls)==1 and len(calls[0].args)>=2 and isinstance(calls[0].args[1],ast.Constant) and calls[0].args[1].value is False)
check('no detailed field entry or detail probe implementation','def detail_probes' not in code and 'MACRO_SCREEN_ONLY_' in code and "'available':False" in code)
for script,args in [('screen.py',['--execute-field']),('run_guard.py',['--authorize-field-run'])]:
 completed=subprocess.run([sys.executable,str(P/script),*args],capture_output=True,text=True)
 check('missing macro-only flag rejects '+script,completed.returncode!=0 and 'macro' in completed.stderr.lower())
check('no full field result or guard created',not (P/'results').exists() and not (P/'guard.json').exists())
result={'status':'PASS','scope':'scalar/1D chord and mocked tree/AST/CLI phase guards only; no full scalar field','checks':checks,'count':len(checks)};(P/'phase-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
