"""Explicitly gated, serial coarse-field screen. NO EDT, R16 files or runtime assets.
Full execution is deliberately opt-in. See MEMORY.md and METHODS.md before launching.
"""
from pathlib import Path
import argparse,io,json,math,os,resource,sys,time
import numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import label,maximum_filter
from scipy.signal import find_peaks,peak_widths
from macro import Model,controls,sha,tau_min,smooth
P=Path(__file__).resolve().parent;OUT=P/'results';EVENTS=[]
def native(v):
 if isinstance(v,np.ndarray):return v.tolist()
 if isinstance(v,np.generic):return v.item()
 raise TypeError(str(type(v)))
def write(name,v): (OUT/name).write_text(json.dumps(v,indent=2,default=native,allow_nan=False)+'\n')
def save_image(image,name):
 buffer=io.BytesIO();image.save(buffer,format='PNG');payload=buffer.getvalue()
 retained=sum(f.stat().st_size for f in P.rglob('*') if f.is_file() and '__pycache__' not in f.parts)
 if retained+len(payload)>4*2**20:raise RuntimeError('selected code/JSON/PNG4MiB budget; refuse next PNG, retain partial negative')
 (OUT/name).write_bytes(payload)

def checkpoint(tag):
 import subprocess
 rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(os.getpid())]).strip())*1024
 EVENTS.append({'tag':tag,'monotonic_ns':time.monotonic_ns(),'pid':os.getpid(),'rss_bytes':rss,'ru_maxrss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
 if rss>=224*2**20 or (P/'STOP').exists():raise MemoryError('224MiB sampled early stop / watchdog STOP before next slab')
def axes(m,step=4):return [m.origin[i]+step*(np.arange(int(m.span[i]/step))+.5) for i in range(3)]
def field(m,detail):
 ax=axes(m);nx,ny,nz=map(len,ax);rho=np.empty((nz,ny,nx),np.float32);q=np.empty_like(rho);owner=np.empty(rho.shape,np.int8)
 for z in range(0,nz,8):
  checkpoint(f'{m.variant}/{m.role}/{detail}/before-slab-{z}')
  a=(ax[0][None,None,:],ax[1][None,:,None],ax[2][z:z+8,None,None]);r,v,o,_=m.sample(a,detail)
  rho[z:z+8]=r;q[z:z+8]=v;owner[z:z+8]=o
  del r,v,o,a;checkpoint(f'{m.variant}/{m.role}/{detail}/after-slab-{z}')
 return ax,rho,q,owner
POSES=json.loads((P/'poses.json').read_text());VIEWS={name:np.asarray(v,dtype=float)/np.linalg.norm(v) for name,v in POSES['directionsFromSource'].items()}
def view_basis(direction):
 f=-direction;right=np.cross(f,[0.,1.,0.]);right/=np.linalg.norm(right);up=np.cross(right,f);return right,up

def projection(m,ax,rho,q,owner,b,detail):
 """Raw metric contour from centre samples. Display splats never enter metrics.
 Beer proxy integrates voxel-centre amounts per metric screen-bin area; no beauty claim.
 """
 window=POSES[m.role]['orthographicWindowWorldM'];focus=np.array(POSES[m.role]['focusRootRelativeXZ_WorldY'] if m.role=='body' else POSES[m.role]['focusRelativeToCrownRootWorldM']);pixel=4*b*2
 n=math.ceil(window/pixel);rows={}
 for name,d in VIEWS.items():
  right,up=view_basis(d);rows[name]={'max':np.zeros((n,n),np.float32),'tau':np.zeros((n,n),np.float64),'top':np.full(n,-np.inf),'owner':np.full(n,-1,np.int8),'point':np.zeros((n,3)),'right':right,'up':up}
 for iz,z in enumerate(ax[2]):
  xx,yy=np.meshgrid(ax[0],ax[1]);wp=np.column_stack([b*(xx.ravel()-m.root[0]),b*(yy.ravel()-m.root[1])+(m.cfg['rootWorldY'] if m.role=='body' else 0),np.full(xx.size,b*(z-m.root[2]))]);delta=wp-focus
  rr=rho[iz].ravel();qq=q[iz].ravel();oo=owner[iz].ravel()
  for name,row in rows.items():
   horizontal=delta@row['right'];vertical=delta@row['up'];u=np.floor((horizontal+window/2)/window*n).astype(int);v=np.floor((window/2-vertical)/window*n).astype(int);good=(u>=0)&(u<n)&(v>=0)&(v<n)
   np.maximum.at(row['max'],(v[good],u[good]),rr[good]);np.add.at(row['tau'],(v[good],u[good]),qq[good]*.019*(4*b)**3/(window/n)**2)
   eligible=good&(rr>=.041)
   if eligible.any():
    ids=np.flatnonzero(eligible);order=np.lexsort((vertical[ids],u[ids]));ids=ids[order];last=np.r_[u[ids][1:]!=u[ids][:-1],True];ids=ids[last];hit=vertical[ids]>row['top'][u[ids]];ids=ids[hit];row['top'][u[ids]]=vertical[ids];row['owner'][u[ids]]=oo[ids];row['point'][u[ids]]=wp[ids]
 result={};panels=[]
 for name,row in rows.items():
  valid=np.isfinite(row['top']);height=np.where(valid,row['top'],-window/2);peaks,props=find_peaks(np.r_[-window/2,height,-window/2],prominence=40,distance=max(1,math.ceil(100/(window/n))));peaks=peaks-1;keep=(peaks>=0)&(peaks<n)&valid[np.clip(peaks,0,n-1)];peaks=peaks[keep]
  witnesses=[{'screen_column':int(i),'projected_height_relative_focus_m':float(height[i]),'worldXYZ':row['point'][i].tolist(),'owner':m.branches[int(row['owner'][i])].id,'prominence_m':float(props['prominences'][keep][j])} for j,i in enumerate(peaks)]
  result[name]={'metric_grid_pitch_world_m':window/n,'crest_witnesses':witnesses,'crest_count':len(witnesses),'fraction_metric_pixels_tau_gt_5':float(np.mean(row['tau']>5)),'max_tau_proxy':float(row['tau'].max()),'metric':'finite native-centre contour; voxel-volume/metric-pixel-area Beer proxy, not continuous ray quadrature'}
  for title,img in [('max rho',row['max']/.75),('Beer proxy',1-np.exp(-row['tau']))]:
   display=np.asarray(np.clip(img,0,1)*255,np.uint8);im=Image.fromarray(display);im=im.resize((512,512),Image.Resampling.NEAREST).convert('RGB');draw=ImageDraw.Draw(im);draw.text((8,8),f'{m.variant} {m.role} b{b:g} {name} {"detail" if detail else "macro"} {title}',fill=(255,80,80));panels.append(im)
 sheet=Image.new('RGB',(1536,1024));
 for j,im in enumerate(panels):sheet.paste(im,((j//2)*512,(j%2)*512))
 save_image(sheet,f'{m.variant}-{m.role}-b{b:g}-{"detail" if detail else "macro"}-scalar-projections.png')
 return result,rows

def base_gate(m):
 ax=axes(m);xx,zz=np.meshgrid(ax[0],ax[2]);a=(xx,np.full_like(xx,m.material(0,40,0)[1]),zz);r,_,_,_=m.sample(a);foot=r>=.041
 labs,n=label(foot);sizes=np.bincount(labs.ravel());sizes[0]=0
 iz,ix=np.nonzero(foot)
 if not len(ix):return {'pass':False,'reason':'empty_h40_footprint'},None
 x,z=xx[iz,ix],zz[iz,ix];rank=((x-x.mean())/m.span[0])**2+((z-z.mean())/m.span[2])**2;order=np.lexsort((z,x,rank))[:math.ceil(.8*len(x))];x,z=x[order],z[order]
 heights=np.arange(0.,82.,2.);curves=np.empty((len(heights),len(x)))
 for j,h in enumerate(heights):curves[j]=m.sample((x,np.full_like(x,m.material(0,h,0)[1]),z))[0]
 peaks=curves.max(axis=0);valid=peaks>=.041
 def crossing(frac):
  target=peaks*frac;above=curves>=target;idx=np.argmax(above,axis=0);out=np.full(len(x),np.nan)
  for i,k in enumerate(idx):
   if not valid[i] or not above[k,i]:continue
   out[i]=heights[k] if k==0 else heights[k-1]+2*(target[i]-curves[k-1,i])/(curves[k,i]-curves[k-1,i])
  return out
 lo,mid,hi=[crossing(f) for f in (.1,.5,.9)];rise=hi-lo;good=valid&(rise<=24);midrange=float(np.ptp(mid[valid])) if valid.any() else None;passed=n==1 and good.mean()>=.8 and midrange is not None and midrange<=16
 rows={'pass':bool(passed),'h40_components':int(n),'footprint_count':len(iz),'ROI_count':len(x),'peak_valid_fraction':float(valid.mean()),'valid_peak_and_rise_fraction':float(good.mean()),'h50_world_range_m':midrange,'rise_quantiles_m':np.quantile(rise[valid],[0,.5,.9,1]).tolist() if valid.any() else [],'crossing_method':'linear crossings of exact author samples at h0..80 step2worldm, own peak; central80% normalized squared-distance rank, X then Z ties'}
 return rows,(x,z,curves,heights)
def component_gates(m,ax,rho,owner):
 mask=rho>=.041;labs,n=label(mask);basey=int(np.argmin(abs(ax[1]-m.material(0,120 if m.role=='body' else 0,0)[1])));baseids=set(map(int,np.unique(labs[:,basey,:])))-{0};connected=[]
 for i,b in enumerate(m.branches):
  ids=set(map(int,np.unique(labs[(owner==i)&mask])))-{0};connected.append({'branch':b.id,'owned_positive_samples':int(np.count_nonzero((owner==i)&mask)),'base_component_ids':sorted(ids&baseids),'pass':bool(ids&baseids)})
 result={'rho_threshold':.041,'connectivity':6,'components':int(n),'base_plane_actual_material_Y':float(ax[1][basey]),'branches':connected,'all_branches_connected_to_base':all(v['pass'] for v in connected)}
 if m.role=='body':
  xx,zz=np.meshgrid(ax[0],ax[2]);r,_,_,_=m.sample((xx,np.full_like(xx,m.material(0,420,0)[1]),zz));sl,nsl=label(r>=.041);y=int(np.argmin(abs(ax[1]-m.material(0,420,0)[1])));w=[]
  for i in range(1,nsl+1):
   which=sl==i;fullids=set(map(int,np.unique(labs[:,y,:][which])))-{0};w.append({'component':i,'sample_count':int(which.sum()),'base_component_ids':sorted(fullids&baseids)})
  result['h420']={'components':int(nsl),'connections':w,'full_grid_correspondence_Y':float(ax[1][y]),'pass':nsl>=2 and sum(bool(x['base_component_ids']) for x in w)>=2}
 else:
  r,q,_,_=m.sample(tuple(m.root));nearest=tuple(int(np.argmin(abs(ax[j]-m.root[j]))) for j in (2,1,0));result['root']={'rho':float(r),'q0':float(q),'nearest_grid_label':int(labs[nearest]),'pass':bool(r>=.041 and labs[nearest]>0)}
 del labs,mask
 return result

def shoulder_gates(m,views):
 rows=[];angles=np.arange(360)*math.pi/180
 for branch in m.branches:
  if branch.spec['kind']!='shoulder':continue
  parent=m.byid[branch.spec['parent']];samples=[]
  for knot in branch.k[1:-1]:
   h,cx,cz,rx,rz=map(float,knot);alpha=np.arctan2(np.sin(angles)/rz,np.cos(angles)/rx);tw=branch.spec['twistRadians']*(h-branch.lo)/(branch.H-branch.lo);rad=branch.sector(alpha+tw)/np.sqrt((np.cos(angles)/rx)**2+(np.sin(angles)/rz)**2)
   # Inner .9-radius ring avoids a zero-density boundary; no threshold is lowered.
   x=cx+.9*rad*np.cos(angles);z=cz+.9*rad*np.sin(angles);a=m.material(x,h,z);r=m.sample(a,False,branch.id)[0];parentR=m.sample(a,False,parent.id)[0];exposed=(r>=.041)&(parentR<.041);wp=np.column_stack(m.world(a,4));vrows=[]
   for name,d in VIEWS.items():
    right,up=view_basis(d);width=float(np.ptp(wp@right));witnesses=[w for w in views[name]['crest_witnesses'] if w['owner']==branch.id and w['prominence_m']>=40]
    vrows.append({'view':name,'section_width_world_m':width,'positive_exterior_ring_samples':int(exposed.sum()),'projected_saddle_witnesses':witnesses,'pass':100<=width<=250 and bool(exposed.any()) and bool(witnesses)})
   samples.append({'h':h,'views':vrows})
  rows.append({'id':branch.id,'pass':any(v['pass'] for r in samples for v in r['views']),'fixed_positive_control_sections':samples,'limitation':'finite inner-ring support and owner-labelled silhouette prominence; human rejection of a hidden/round/button shoulder still applies'})
 return {'pass':all(r['pass'] for r in rows),'shoulders':rows}

def collar(m,detail):
 rows=[]
 # Every domain face and adjacent 2m-native-centre plane, 2m in-plane centres.
 for axis in range(3):
  others=[j for j in range(3) if j!=axis]
  for side in (0,1):
   for inset in (0.,1.):
    fixed=m.origin[axis]+(inset if side==0 else m.span[axis]-inset);peak=0.
    for start in np.arange(m.origin[others[1]]+1,m.origin[others[1]]+m.span[others[1]],16):
     u=m.origin[others[0]]+1+2*np.arange(int(m.span[others[0]]/2));v=np.arange(start,min(start+16,m.origin[others[1]]+m.span[others[1]]),2);a=[None]*3;a[axis]=fixed;a[others[0]]=u[None,:];a[others[1]]=v[:,None];peak=max(peak,float(m.sample(tuple(a),detail)[0].max()))
    rows.append({'axis':axis,'side':side,'inset_local_m':inset,'max_rho':peak})
 return {'pass':all(r['max_rho']==0 for r in rows),'faces_and_native_centre_planes':rows}
def slices(m,ax,rho,detail):
 coords={'X':[m.root[0]],'Y':[m.root[1]],'Z':[m.root[2]]}
 for b in m.branches:
  h,cx,cz,*_=b.k[-2];a=m.material(cx,h,cz)
  for j,name in enumerate(('X','Y','Z')):coords[name].append(float(a[j]))
 tiles=[];records=[]
 for axis,name in enumerate(('X','Y','Z')):
  for value in sorted(set(coords[name])):
   idx=int(np.argmin(abs(ax[axis]-value)));sl=np.take(rho,idx,axis=2-axis);im=Image.fromarray(np.asarray(np.clip(sl[::-1]/.75,0,1)*255,np.uint8)).resize((256,256)).convert('RGB');ImageDraw.Draw(im).text((3,3),f'{name} wanted{value:.2f} actual{ax[axis][idx]:.2f}',fill=(255,80,80));tiles.append(im);records.append({'axis':name,'requested_material_m':value,'sampled_material_m':float(ax[axis][idx])})
 canvas=Image.new('RGB',(1024,256*math.ceil(len(tiles)/4)))
 for i,im in enumerate(tiles):canvas.paste(im,((i%4)*256,(i//4)*256))
 save_image(canvas,f'{m.variant}-{m.role}-{"detail" if detail else "macro"}-fixed-slices.png');return records

def chords(m,b,detail):
 rows=[]
 for branch in m.branches:
  if branch.spec['kind']!='shoulder':continue
  h,cx,cz,rx,rz=map(float,branch.k[-2]);angles=np.arange(360)*math.pi/180;theta=np.arctan2(np.sin(angles)/rz,np.cos(angles)/rx)+branch.spec['twistRadians']*(h-branch.lo)/(branch.H-branch.lo);extent=branch.sector(theta)/np.sqrt((np.cos(angles)/rx)**2+(np.sin(angles)/rz)**2)
  # Exact macro support root at radial directions; native-centre 2localm optical samples.
  widths=extent+np.roll(extent,180);k=int(np.argmin(widths));direction=np.array([math.cos(angles[k]),0.,math.sin(angles[k])]);unit=1. if m.role=='crown' else .25;physical=b*unit;W=float(widths[k]*physical);ds=2*b;count=max(1,math.ceil(W/ds));ts=-extent[(k+180)%360]+(np.arange(count)+.5)*widths[k]/count;x=cx+ts*direction[0];z=cz+ts*direction[2];a=m.material(x,h,z);isolated=m.sample(a,detail,branch.id)[1];assembled=m.sample(a,detail)[1];tau=.019*float(isolated.sum())*W/count;minimum=tau_min(W)
  row={'id':branch.id,'b':b,'h':h,'chord_width_world_m':W,'shortest_angle_radians':float(angles[k]),'sample_spacing_world_m':W/count,'isolated_tau':tau,'isolated_T':math.exp(-tau),'assembled_tau_same_path':.019*float(assembled.sum())*W/count,'minimum_tau':minimum,'pass':minimum is not None and tau>=minimum,'support_width_basis':'macro sector-positive radial support at last positive-radius knot; exact360-angle minimum (finite angular screen)'}
  cam=[]
  for name,d in VIEWS.items():
   # Constant-height central horizontal camera chord, including oblique XZ projection.
   horizontal=d.copy();horizontal[1]=0;horizontal/=np.linalg.norm(horizontal);L=math.hypot(rx,rz)*2*1.2;tt=-L/2+(np.arange(max(1,math.ceil(L*physical/ds)))+.5)*L/max(1,math.ceil(L*physical/ds));aa=m.material(cx+tt*horizontal[0],h,cz+tt*horizontal[2]);q=m.sample(aa,detail)[1];qi=m.sample(aa,detail,branch.id)[1];ow=m.sample(aa,detail)[2];pos=qi>0;measured=float((np.flatnonzero(pos)[-1]-np.flatnonzero(pos)[0]+1)*L/len(tt)*physical) if pos.any() else 0.;t=.019*float(q.sum())*L/len(tt)*physical;mint=tau_min(measured);cam.append({'view':name,'positive_isolated_extent_world_m':measured,'assembled_tau':t,'isolated_tau':.019*float(qi.sum())*L/len(tt)*physical,'other_owner_fraction':float(np.mean(ow!=m.branches.index(branch))),'minimum_tau':mint,'pass':mint is not None and t>=mint and .019*float(qi.sum())*L/len(tt)*physical>=mint and bool(np.any(ow==m.branches.index(branch)))})
  row['central_camera_chords']=cam;row['camera_chord_pass']=any(v['pass'] for v in cam);rows.append(row)
 # Main foreground chord per major at its broad penultimate cross-section, front and horizontal-oblique.
 mains=[]
 for branch in m.branches:
  if branch.spec['kind']!='major':continue
  h,cx,cz,rx,rz=map(float,branch.k[-2])
  for name in ('front','oblique'):
   d=VIEWS[name].copy();d[1]=0;d/=np.linalg.norm(d);L=2.4*max(rx,rz);physical=b*(.25 if m.role=='body' else 1);n=max(1,math.ceil(L/2/(4 if m.role=='body' else 1)));tt=-L/2+(np.arange(n)+.5)*L/n;aa=m.material(cx+tt*d[0],h,cz+tt*d[2]);r,q,_,_=m.sample(aa,detail);pos=r>=.041;W=float(pos.sum()*L/n*physical);tau=.019*float(q.sum())*L/n*physical;mains.append({'branch':branch.id,'view':name,'width_rho041_world_m':W,'tau':tau,'pass':W>=250 and tau>=1.8})
 return {'shoulders':rows,'main_foreground_chords':mains,'pass':all(r['pass'] and r['camera_chord_pass'] for r in rows) and all(any(r['pass'] and r['view']==v for r in mains) for v in ('front','oblique'))}

def detail_probes(m):
 rows=[];shiftmax=0.;angles=np.arange(360)*math.pi/180
 for branch in m.branches:
  for h in sorted(set(list(branch.k[:-1,0])+[branch.H-v for v in (8,1,.1,.001)]+[branch.H])):
   cx,cz,rx,rz,live=branch.section(h)
   if not live:rows.append({'id':branch.id,'h':float(h),'live':False,'max_rho':0.,'positive_extent':0.});continue
   th=np.arctan2(np.sin(angles)/rz,np.cos(angles)/rx)+branch.spec['twistRadians']*(h-branch.lo)/(branch.H-branch.lo);base=branch.sector(th)/np.sqrt((np.cos(angles)/rx)**2+(np.sin(angles)/rz)**2)
   low=np.zeros(360);high=base+(80 if m.role=='body' else 10)
   # Last outside/inside bracket: fixed radial scan handles nonmonotone detail.
   radial=np.linspace(0,1,129)[:,None]*high[None,:];aa=m.material(cx+radial*np.cos(angles),h,cz+radial*np.sin(angles));scan=branch.margin(cx+radial*np.cos(angles),np.full_like(radial,h),cz+radial*np.sin(angles),aa,True,m.seed);positive=scan>0;last=np.max(np.where(positive,np.arange(129)[:,None],-1),axis=0);has=last>=0;idx=np.maximum(last,0);low=radial[idx,np.arange(360)];high=radial[np.minimum(idx+1,128),np.arange(360)];low=np.where(has,low,0.);high=np.where(has,high,0.)
   for _ in range(32):
    mid=(low+high)/2;a=m.material(cx+mid*np.cos(angles),h,cz+mid*np.sin(angles));d=branch.margin(cx+mid*np.cos(angles),np.full(360,h),cz+mid*np.sin(angles),a,True,m.seed);hit=d>0;low=np.where(hit,mid,low);high=np.where(hit,high,mid)
   shift=float(np.max(np.abs((low+high)/2-base)));shiftmax=max(shiftmax,shift);a=m.material(cx,h,cz);rho=m.sample(a,True,branch.id)[0]
   amp=(28*smooth((branch.H-h)/40)) if m.role=='body' else (3.5*smooth((branch.H-h)/8));bound=float(m.amount(1.2*min(rx,rz)+amp,h)[0]);diameter_bound=float(2*max(rx,rz)*(1.2+amp/min(rx,rz)))
   rows.append({'rho_section_upper_bound':bound,'diameter_upper_bound':diameter_bound,'id':branch.id,'h':float(h),'live':True,'max_rho_centre':float(rho),'sampled_radial_diameter_max':float(2*high.max()),'max_radial_shift':shift})
 tipcheck=[]
 for branch in m.branches:
  tip=[r for r in rows if r['id']==branch.id and r['h']>=branch.H-8];bounds=[r.get('rho_section_upper_bound',0.) for r in tip];sizes=[r.get('diameter_upper_bound',0.) for r in tip];tipcheck.append({'id':branch.id,'pass':tip[-1]['h']==branch.H and not tip[-1]['live'] and all(a>=b for a,b in zip(bounds,bounds[1:])) and all(a>=b for a,b in zip(sizes,sizes[1:]))})
 return {'tip_checks':tipcheck,'sample_angles':360,'maximum_radial_shift':shiftmax,'limit':40 if m.role=='body' else 5,'pass':shiftmax<=(40 if m.role=='body' else 5) and all(r['pass'] for r in tipcheck),'probes':rows,'limitation':'finite fixed knot and near-tip slices/angles, not continuous Hausdorff or medial-axis proof'}

def execute():
 OUT.mkdir(exist_ok=True)
 if (OUT/'results.json').exists():raise RuntimeError('refuse overwrite: first result already exists; no blind retries')
 c=controls();result={'status':'incomplete','label':'scalar pre-distance source screen; not beauty, native2m, final-q, lifecycle or accepted anatomy','inputs':{k:sha(P/'inputs'/k) for k in ('DECISION-v2.md','controls-v2.json','PREFLIGHT-COMMISSION-v2.md')},'assets':{},'gates_pending_human':['unequal natural masses, no button stack/tube/flat roof, visible A/B contrast in >=2 normalized views; no scalar count alone passes art'],'EDT_executed':False,'R16_outputs':0}
 try:
  macro_ok=True
  for variant in ('A','B'):
   for role in ('body','crown'):
    checkpoint('before '+variant+'/'+role);m=Model(c,variant,role);ax,rho,q,owner=field(m,False);stats={'shapeZYX':list(rho.shape),'coarse_pitch_local_m':4,'rho_sum':float(rho.sum(dtype=np.float64)),'q0_sum':float(q.sum(dtype=np.float64)),'rho_positive_count':int(np.count_nonzero(rho)),'support005_count':int(np.count_nonzero(rho>.005)),'support041_count':int(np.count_nonzero(rho>=.041)),'containment':m.containment(),'caps':m.cap_checks()};stats['components']=component_gates(m,ax,rho,owner);stats['collar']=collar(m,False);stats['slices']=slices(m,ax,rho,False)
    if role=='body':stats['base'],_=base_gate(m)
    stats['views']={};stats['optical']={}
    for b in ((4,) if role=='body' else (5,6)):
     p,_=projection(m,ax,rho,q,owner,b,False);stats['views'][str(b)]=p;stats['optical'][str(b)]=chords(m,b,False)
    if role=='body':stats['shoulders']=shoulder_gates(m,stats['views']['4'])
    counts={'A':{'front':3,'side':2,'oblique':2},'B':{'front':3,'side':2,'oblique':3}}
    stats['automated_pass']=all(r['pass'] for r in stats['containment']+stats['caps']) and stats['collar']['pass'] and stats['components']['all_branches_connected_to_base'] and all(o['pass'] for o in stats['optical'].values())
    if role=='body':stats['automated_pass'] &= stats['base']['pass'] and stats['shoulders']['pass'] and stats['components']['h420']['pass'] and all(stats['views']['4'][v]['crest_count']>=count for v,count in counts[variant].items())
    else:stats['automated_pass'] &= stats['components']['root']['pass']
    result['assets'][variant+'/'+role]={'macro':stats};macro_ok &= bool(stats['automated_pass']);del ax,rho,q,owner,m;checkpoint('released '+variant+'/'+role)
  for role in ('body','crown'):
   for b in ((4,) if role=='body' else (5,6)):
    aa=Image.open(OUT/f'A-{role}-b{b:g}-macro-scalar-projections.png').convert('RGB');bb=Image.open(OUT/f'B-{role}-b{b:g}-macro-scalar-projections.png').convert('RGB');pair=Image.new('RGB',(3072,1024));pair.paste(aa,(0,0));pair.paste(bb,(1536,0));save_image(pair,f'AB-{role}-b{b:g}-macro-comparison.png');aa.close();bb.close();pair.close()
  if not macro_ok:result['status']='REJECT_macro_or_amount_gate';return result
  # Detail is prohibited as rescue; only reached after every automatic macro screen passes.
  for variant in ('A','B'):
   for role in ('body','crown'):
    m=Model(c,variant,role);ax,rho,q,owner=field(m,True);s={'probes':detail_probes(m),'collar':collar(m,True),'components':component_gates(m,ax,rho,owner),'slices':slices(m,ax,rho,True),'views':{},'optical':{}}
    for b in ((4,) if role=='body' else (5,6)):s['views'][str(b)]=projection(m,ax,rho,q,owner,b,True)[0];s['optical'][str(b)]=chords(m,b,True)
    if role=='body':s['shoulders']=shoulder_gates(m,s['views']['4'])
    s['automated_pass']=s['probes']['pass'] and s['collar']['pass'] and s['components']['all_branches_connected_to_base'] and all(v['pass'] for v in s['optical'].values())
    if role=='body':s['automated_pass'] &= s['shoulders']['pass'] and s['components']['h420']['pass'] and all(s['views']['4'][v]['crest_count']>=counts[variant][v] for v in counts[variant])
    for b in ((4,) if role=='body' else (5,6)):
     aa=Image.open(OUT/f'{variant}-{role}-b{b:g}-macro-scalar-projections.png').convert('RGB');bb=Image.open(OUT/f'{variant}-{role}-b{b:g}-detail-scalar-projections.png').convert('RGB');pair=Image.new('RGB',(3072,1024));pair.paste(aa,(0,0));pair.paste(bb,(1536,0));save_image(pair,f'{variant}-{role}-b{b:g}-macro-detail-comparison.png');aa.close();bb.close();pair.close()
    result['assets'][variant+'/'+role]['detail']=s;del ax,rho,q,owner,m;checkpoint('released-detail '+variant+'/'+role)
  result['status']='AUTOMATED_screen_only_human_macro_review_REQUIRED' if all(a['detail']['automated_pass'] for a in result['assets'].values()) else 'REJECT_detail_gate'
 except BaseException as e:
  result['status']='INCOMPLETE_guard_or_error';result['error']={'type':type(e).__name__,'message':str(e)};raise
 finally:
  write('slab-rss.json',EVENTS);write('results.json',result)
 return result
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--execute-field',action='store_true');args=parser.parse_args()
 if not args.execute_field:parser.error('field execution requires explicit --execute-field and parent first-run authorization')
 print(json.dumps(execute(),default=native),flush=True)
