# Prepared code only — root review required before first full field

Selected inputs: DECISION91fc4a5e, controls7914491d, commissiona62671e2, copied and verified under inputs/. No recipe parameter was changed.

Implemented macro.py (PCHIP/radius closure, sector SHA/Catmull, material detail, calibrated quantized density/q0), screen.py (serial coarse grids, fixed scalar projections/slices/base/topology/shoulder/chord/detail gates), poses.json and separately scheduled run_guard.py. METHODS.md declares finite metric algorithms and human gates; MEMORY.md accounts phase maxima and sampled stop policy. FREEZE.json pins the exact implementation and inputs. A pending runtime base-anchor addendum does not change this mature static field; no runtime source was edited.

Focused checks: installed /opt/homebrew/bin/python3.14 test_scalar.py reports211PASS, including all exact knots, empty endpoints, closure joins/5% bounds, independent sector/noise hashes and negative-coordinate seam, all9contained starts, ideal tau table, actual crown shortest widths at5/6, role coordinate/grid mapping and tip perturbation bound. py_compile passes all four scripts. scalar-results.json pins dependency versions and results. **No full scalar grid has been executed**, no projected field PNG exists yet, no EDT/R16 was generated and no renderer/source91/viewer/canonical/Git file changed.

First-run command, ONLY after root code/scalar review and explicit authorization:

    /opt/homebrew/bin/python3.14 /Users/ryannel/Workspace/thrum/tmp/worktrees/cloud-system-design/tmp/cloud-swept-macro-preflight/run_guard.py --authorize-field-run

The flag does not itself supply authorization. It verifies frozen bytes, refuses an existing result, runs screen.py --execute-field once and retains full sampled RSS/failure. No retries/controls/seed/pose/profile search are authorized. Expected outcome is finite source screening, not accepted cloud anatomy or beauty. All final effective-q/native2m/EDT/root/neck/BVH/support/CPU/GPU/lifecycle/memory gates remain separate.
