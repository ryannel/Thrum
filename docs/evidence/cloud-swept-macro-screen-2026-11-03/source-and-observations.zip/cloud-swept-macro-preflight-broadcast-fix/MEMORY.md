# Pre-execution memory/work plan — no field execution yet

Owner/purpose: cloud_lifecycle_diagnosis; one fixed source-only A/B macro screen.
Inputs are the three hash-checked copies under inputs/. No old density/EDT/source asset is opened.
All four roles run serially, **macro only**. The current phase has an unconditional hard stop after macro fields/rendering/gates, even if all pass. No detail grid entry exists.
Full arrays are coarse only. No native2m field, R16, EDT, 3D coordinate matrix or argwhere list.

| Live category | Conservative planned bytes / bound |
| --- | ---: |
| Python3.14 + NumPy/SciPy/Pillow baseline/loaded arenas reserve | 117,440,512 (112MiB; estimate, not measured admission) |
| BODY rho F32 + q0 F32 + owner i8, 479232 cells | 4,313,088 |
| BODY bool threshold + int32 labels | 2,396,160 |
| Topology masks/reductions/temporary queues reserve | 8,388,608 |
| One <=8Z slab, max39936 cells, all F64 PCHIP/elliptical/noise operands/allocator reserve | 33,554,432 |
| 2D projections, base curves, radial probes, coordinates and scalar diagnostics reserve | 8,388,608 |
| Pillow image sheets/pairs/PNG encoding reserve (phase maximum, no slab live) | 33,554,432 |
| independent watchdog/ps process reserve | 16,777,216 |
| additional metadata/serialization/allocator reserve | 8,388,608 |

Phase maximum plan is **<=200MiB**: baseline112 + grids/labels6.4 + topology8 + max(slab32,images32) + diagnostics8 + watchdog16 + reserve8 =190.4MiB, rounded upward to200MiB. Crown arrays are smaller: rho+q+owner1,354,752B; bool+labels752,640B. This is a conservative working estimate, not a promised OS/driver/allocator bound. Freed NumPy/Pillow arenas may remain resident; every next role/slab rechecks actual RSS.

run_guard.py samples the full owned watchdog+worker+descendant process tree every100ms with ps, recording timestamp, PID set, total and maximum. It creates STOP at224MiB; worker checks before/after each slab and at role boundaries, refuses the next slab and retains INCOMPLETE. At256MiB the watchdog requests SIGTERM for the worker process group, then SIGKILL after2s if needed, retaining actual exit/settlement. These are sampled policies, not an OS hard cap: a transient between samples can be missed, and the log says so. screen.py also logs current ps RSS plus process ru_maxrss before/after slabs. No comparison to the 200MiB plan is relabelled a pass if actual usage exceeds it; report both plan and sampled guard outcome.

Bounded work: four coarse macro field evaluations, 1,259,520 total centre samples before per-branch evaluation; each one evaluates only the pinned <=7 branches. Separate finite 2m face/adjacent-centre planes, one-dimensional optical chords, base h0..80/2m profiles, <=4097 closure probes/channel and fixed360-angle knot/section checks are charged extras; detailed radial support searches are unavailable. No broad parameter/seed/site search. Image projection is voxel-centre splatting, not another 3D field. Native image and continuous geometry accuracy are unqualified.

Retained code/JSON/PNG goal <=4MiB. PNG is encoded once in bounded image scratch before checking retained total; refuse writing an over-budget image and retain incomplete diagnostics. Guard samples/logs/final failure JSON may add small explicitly reported overhead, rather than destroying first failure. No run overwrites existing results/, guard.json or STOP. No automatic rerun.
