# Macro-only broadcasting correction — code only, root authorization required

Ancestry: original tmp/cloud-swept-macro-preflight c06ebc4ae4bef45a4c8a639d94b4d72a70153a9904dc01bd5399146c0bcff1ef remains untouched in place, including root's first failed field run, guard, log, partial A-BODY PNGs and failure result. ANCESTRY-FIRST-FAILURE.json pins every original file after that run, not just the selected source. It records session5643/exit1 and sampled tree163790848B below both stop thresholds. Root inspected existing partial scalar views and rejected the shape (two broad front heads, side fork/cactus, broad oblique oval). Those are genuine negative scalar projections, not beauty or an accepted anatomy.

Only producer change: Model.world now broadcasts its three already-computed output coordinates with np.broadcast_arrays before returning. The numerical coordinate expressions, shape/knots/PCHIP, seeds, masks/density, κ, views, metrics/thresholds and macro-only hard stop are unchanged. This corrects array X/Z plus scalar section Y so shoulder_gates can form a360×3 world-coordinate ring. No recipe search, parameter rescue, EDT or R16 output. The copied screen/run_guard/poses/inputs/history bytes remain exact; scalar test adds four regression assertions only.

Checks in this fresh candidate: **215 scalar/structural PASS** (original211 plus BODY/crown ring shape and mapped-value assertions), existing **25 phase checks PASS**, five-script py_compile PASS. No full field/result/PNG/guard exists in the fresh directory. Both new regression axes are all shape360 and map the original exact scalar Y without numerical reassociation. versions: CPython3.14.10, NumPy2.4.6, SciPy1.17.1, Pillow12.2.0. scalar-results/phase-results and FREEZE.json pin this candidate.

No original failure byte was changed. The new freeze is implementation-only and does not reclassify root's structural rejection. Its purpose is to complete measured macro gates on the **same** A/B shape. Detailed field/support gates remain unavailable; no detail can execute, even if macro checks pass. Original first-review findings/dispositions remain under review-first.md and history/code-review-first, including the withdrawn RSS finding.

After root explicit first-run authorization and narrow reviewer closure ONLY:

    /opt/homebrew/bin/python3.14 /Users/ryannel/Workspace/thrum/tmp/worktrees/cloud-system-design/tmp/cloud-swept-macro-preflight-broadcast-fix/run_guard.py --authorize-field-run --macro-only

The flags do not supply authorization. The wrapper hash-checks this freeze and refuses an existing result; sampled224/256MiB policy and<=200MiB plan remain unchanged. No field execution has been performed by the author. No canonical/Git/renderer/source91/viewer/GPU/timing work.
