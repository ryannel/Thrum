# Pure analytic fog CPU slice

3 November2026. Implements PREFLIGHT §4 only. No clock/DOM/world/renderer dependency, no advection, WGSL, GPU, native fields, server, timing experiment or runtime integration. The selected simple whole-ray AP path and its superseded-certificate note remain separate.

## Exact API

Import `createFogProfile`, `DEFAULT_FOG_PROFILE`, `FOG_ENVELOPE`, `fogPoint`, `fogSegment` from `src/air/fog.js`.

`createFogProfile({centre,rotationColumns,radii,betaT,albedo,g})` validates and copies a plain record; omitted fields select the §4 example. Columns are three world vectors, right-handed orthonormal to1e-12. Scalar or RGB `betaT` is extinction/m; scalar or RGB albedo is0..1; derived betaS is owned by the resulting profile. All nested arrays are frozen, and a private WeakSet distinguishes these validated records from untrusted structural lookalikes. Invalid profile creation throws TypeError/RangeError; unknown fields reject typos. There is no normalization or silent correction of malformed parameters. Stored binary64 inputs define this CPU reference.

`fogPoint(profile,x)` returns `{valid,reason,f,errorF,sigma_tRGB,sigma_sRGB,g}` for a valid point, or `{valid:false,reason}`. ErrorF propagates the binary64 transform/norm envelope. Density is the declared `max(0,1-|diag(1/r)R^T(x-centre)|²)`; coefficients are profile coefficients times f. Its result is caller-owned, not a borrowed source buffer.

`fogSegment(profile,o,unitD,tMin,tMax)` returns `{valid,reason,interval,I_metres,errorI,tauRGB,T_RGB,errorTauRGB,errorT_RGB,averageSigmaT,averageSigmaS}`. `interval` is the nominal clipped fog interval, otherwise null. Requested t is forward world metres, `0<=tMin<=tMax<=1e9`; average coefficients divide by the **whole requested cell length**, even when fog occupies a small subinterval. Zero-length requests return zero averages without division. Empty proven geometry is identity; zero beta retains the nonzero geometric integral while giving identity optical transfer. Invalid input/numeric envelope returns `valid:false` and **null** integral/transfer/average fields, never clearT. Optional point/segment metadata/source time is the caller's responsibility.

Closest approach supplies the quadratic centre and roots; the clipped exact quadratic Simpson operator evaluates its density as a product of root distances. It does not perform a ray-march approximation. Local outward binary64 interval operations propagate coordinate subtraction, rotation/division, dot products, closest approach, roots, clipping, Simpson arithmetic and integral error. Unresolved tangency bounds the whole potentially missed chord using `(4/3)*deltaUpper*sqrt(deltaUpper)/sqrt(aLower)`. It may return identity with explicit nonzero error only when max(betaT)*errorI<=1e-5; larger uncertainty is invalid. Numeric bounds may be conservative. Interval work is bounded per query, with no native arrays, quadrature loop or retained history.

## Scope of numeric qualification

Selected radii25..8000m; betaT0...01/m; g[-.95,.95]; each encoded world coordinate magnitude<=1e9m; direction squared-length within1e-12 of1. No silent direction normalization. All basic arithmetic uses binary64 and outward adjacent representable numbers. The transcendental enclosure **assumes host sqrt/exp errors within four ulps**; ECMAScript does not provide a universal platform-specific proof of that bound. Focused Node v24.16.0 tests below pass; other JS engines, extreme cancellation beyond the selected envelope, formal platform qualification and a WGSL/F32 counterpart remain unqualified. `valid` is relative to this explicitly stated envelope/assumption, not a universal exact-arithmetic guarantee. ErrorI covers calculation against encoded inputs, not authoring/measurement uncertainty in world coordinates. Physical field semantics and eventual incident-light sampling quadrature are separate.

## Actual verification

Command: `node --test tmp/cloud-joint-media-proof/tests/air/fog.test.mjs` (or `npm run test:air` from this private proof directory). **9 tests pass**, zero failures. Full/half/offset axis closed forms; requested-cell average denominator; clipped/outside/zero/tangent cases and missed-chord bound; translated/rotated anisotropic covariance; tiny length/far origin; independent Simpson quadrature of the original ellipsoid formula on oblique/clipped rays; immutable inputs/zero density/point coefficients; malformed profile/direction/range rejection. The independent quadrature does not call fogPoint or the helper's closest-approach operator. Test-run durations are incidental runner output, not a benchmark or performance claim.

Raw latest output: `tests/air/last-run.txt`. Final pins: `FOG-PINS.json`. Root independent implementation review is still required before GPU integration. No full graph/atmosphere/source art/performance admission follows.

## Binding fit reconciled in PREFLIGHT

Mixed rays omit AP-S/AP-T/Sky. Four-template providers bind9native sampled textures; AirT/MS/point/BSM/blueNoise add5; depth/reflection add2, total16. Whole-clear AP/Sky roles have no native sampled bindings. Pristine8altitude×32Sun-angle responses move to a4096B separate GPU-owned range, preserving the earlier spherical lookup semantics; clouded SH has its own two256B ranges. All share one4608B readonly ray buffer but separate writer ranges/keys/fences, never CPU SceneTable uploads or Env feedback. Four source storage buffers +SceneTable +LightingBuffer +optional status +near list is8storage buffers. This is design/binding reconciliation only; no GPU code was authored.
