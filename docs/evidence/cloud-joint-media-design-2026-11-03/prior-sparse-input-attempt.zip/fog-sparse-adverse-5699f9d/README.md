# Adverse original fog attempt

Exact pre-fix implementation/tests/pins retained after independent review found sparse three-vectors accepted by Array.every. A valid result could contain NaN coefficients, or a sparse query could throw. Original9tests passed but omitted sparse inputs. Independent review reported no other findings and45high-precision scalar cases passed other math/error contracts; that external result is not a locally rerun proof. Current implementation is a separate corrected revision. No renderer/physics calibration change.
