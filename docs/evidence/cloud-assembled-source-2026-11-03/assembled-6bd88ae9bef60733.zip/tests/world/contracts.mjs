import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {configuration} from '../source/fixtures.mjs';
import {SourceModel,DEFAULT_CONTROLS} from '../../src/source/model.js';
import {SourceModel as Baseline} from '../../baseline/src/source/model.js';
import {SourceClock} from '../../src/source/clock.js';
import {TwoCellWorld,assertWorldPublication,snapshotWorldForProbe} from '../../src/source/world.js';
const config=await configuration(),wet={...DEFAULT_CONTROLS,dryGain:0},checks=[];
const run=(m,t)=>{while(m.time<t-1e-9)m.step();return m;};
const bytes=a=>new Uint8Array(a.buffer,a.byteOffset,a.byteLength);
const compareTuple=(a,b)=>{assert.deepEqual({...a,exposurePrevious:null,exposureCurrent:null},{...b,exposurePrevious:null,exposureCurrent:null});assert.deepEqual(bytes(a.exposurePrevious),bytes(b.exposurePrevious));assert.deepEqual(bytes(a.exposureCurrent),bytes(b.exposureCurrent));};
{
 const old=new Baseline(config),next=new SourceModel(config);for(const t of[0,70,120,220,480,550]){run(old,t);run(next,t);compareTuple(old.presentation(t+.125,2),next.presentation(t+.125,2));assert.deepEqual(old.metadata(),next.metadata());}checks.push('default_single_source_exact_to17f');
 const root=[12000,6700],m=new SourceModel(config,wet,{cellID:'remote',rootXZ:root});root[0]=0;assert.equal(m.region[0],12000);run(m,20);const fresh=m.fresh();assert.deepEqual(fresh.region,[12000,1239.2,6700]);assert.equal(fresh.cellId,'remote');assert.throws(()=>new SourceModel(config,wet,{rootXZ:[0,NaN]}));checks.push('absolute_origin_persistent_fresh');
}
{
 const w=new TwoCellWorld(config,wet),clock=new SourceClock(w);assert.equal(clock.tuple(),clock.tuple());const initial=clock.tuple();assert.notEqual(initial.groups[0].parts[0].ID,initial.groups[1].parts[0].ID);assert.equal(initial.groups[0].parts[0].localID,1);assert.equal(initial.groups[1].parts[0].localID,1);assert.deepEqual(initial.groups[0].parts[0].C,[0,1239.2,0]);assert.deepEqual(initial.groups[1].parts[0].C,[16,1239.2,0]);assert.equal(initial.groups[0].controls,initial.groups[1].controls);assert.equal(initial.groups[1].parts[0].globalSlot,8);assert.equal(initial.formationRanges[1].controlElementOffset,8*17**3);checks.push('qualified_ID_and_separate_slot_control_ranges');
 const before=w.metadata();assert.throws(()=>w.enqueueBatch([{patch:{meanX:1},requestedTime:1},{patch:{meanX:12,meanZ:12},requestedTime:2}]),/wind/);assert.deepEqual(w.metadata(),before);assert.equal(w.commands.length,0);checks.push('global_command_batch_rejected_atomically');
 const controller={...wet,meanX:0,meanZ:6,shearX:0,shearZ:-.0015,uplift:.25};w.enqueue(controller,150);controller.meanZ=0;
 run(w,149.75);assert.equal(w.presentation(150).controls.meanX,4);w.step();const p=w.presentation(150.125);assert.equal(p.time,149.875);assert.equal(p.controls.meanX,4);assert.equal(p.groups[0].controls,p.groups[1].controls);const end=w.presentation(150.25);assert.equal(end.controls.meanZ,6);for(const c of w.metadata().cells){assert.equal(c.committedRevision,1);assert.equal(c.controls.meanZ,6);}checks.push('shared_halfopen_interval_and_atomic_barrier');
 const cellDefs=w.cellDefinitions;clock.reset(wet);assert.deepEqual(clock.model.cellDefinitions,cellDefs);assert.notEqual(clock.tuple().groups[0].parts[0].ID,initial.groups[0].parts[0].ID);checks.push('reset_epoch_and_roots');
}
{
 const drive=rate=>{const c=new SourceClock(new TwoCellWorld(config,wet));c.setRate(rate,0);c.play(0);for(let t=.125;t<=120/rate+1e-9;t+=.125){c.wall(t*1000);c.pump(1e9,128);}return c;};const a=drive(1),b=drive(16);assert.equal(a.model.tick,b.model.tick);assert.deepEqual(a.model.metadata(),b.model.metadata());assert.deepEqual(a.tuple(),b.tuple());checks.push('1x16x_same_global_intervals');
}
{
 const w=new TwoCellWorld(config,wet,{cells:[{cellID:'A',rootXZ:[0,0]},{cellID:'B',rootXZ:[11992.715801343124,6779.681531943434]}]});w.enqueueBatch([{patch:{frontX:0,frontStart:1,frontSpeed:0,dryGain:1},requestedTime:1}]);run(w,1);const old=w.presentation(1.25),owned=snapshotWorldForProbe(old);assert.equal(old.groups[0].exposureAllZero,true);w.step();const next=w.presentation(1.5);assert.throws(()=>assertWorldPublication(old),/expired/);assertWorldPublication(owned);assert.notEqual(owned.groups[0].exposureCurrent.buffer,next.groups[0].exposureCurrent.buffer);assert.ok(next.groups[0].exposureCurrent.some(v=>v>0));assert.ok(owned.groups[0].exposureCurrent.every(v=>v===0));assert.equal(next.groups[1].exposureAllZero,true);const state=w.metadata();assert.ok(state.cells[0].parts.some(p=>p.maxE>0));assert.ok(state.cells[1].parts.every(p=>p.maxE===0));checks.push('borrowed_expires_owned_survives_world_commit_absolute_front');
 const clock=new SourceClock(w);await clock.seek(70);const at70=clock.tuple();assert.equal(at70.time,70);assert.equal(at70.groups[1].cellID,'B');assert.ok(at70.groups[1].parts[0].C[0]>11992);assert.equal(clock.model.commands.length,1);checks.push('existing_clock_seek_preserves_world_config_and_commands');
}
{
 const w=new TwoCellWorld(config,wet);run(w,70);const earlier=w.presentation(70.25);const first=earlier.groups[0].parts.find(p=>p.localID===2);run(w,220);const later=w.presentation(220.25);const replacement=later.groups[0].parts.find(p=>p.localID===7);assert.equal(first.globalSlot,replacement.globalSlot);assert.notEqual(first.ID,replacement.ID);assertWorldPublication(snapshotWorldForProbe(later));checks.push('slot_reuse_keeps_generation_identity');
}
{
 const w=new TwoCellWorld(config,wet,{cells:[{cellID:'A',rootXZ:[0,0]},{cellID:'B',rootXZ:[16,32]}]}),clock=new SourceClock(w);const prior=clock.tuple(),owned=snapshotWorldForProbe(prior),original=SourceModel.prototype.step;SourceModel.prototype.step=function(shared){if(this.cellId==='B')throw Error('injected B failure');return original.call(this,shared);};
 try{assert.throws(()=>w.step(),/quarantined/);}finally{SourceModel.prototype.step=original;}
 assert.equal(w.metadata().state,'faulted');assert.deepEqual(w.metadata().unsafeCellClocks.map(c=>c.tick),[1,0]);assert.throws(()=>w.presentation(.25),/quarantined/);assert.throws(()=>clock.tuple(),/quarantined/);assert.throws(()=>assertWorldPublication(prior),/quarantined/);assertWorldPublication(owned);assert.throws(()=>w.step(),/quarantined/);clock.reset(wet);assert.equal(clock.tuple().state,'ready');assert.deepEqual(clock.tuple().groups[1].parts[0].C,[16,1239.2,32]);checks.push('halfstep_failure_quarantines_cached_and_borrowed_publications_reset_recovers');
}
{
 const definitions=[{cellID:'A',rootXZ:[0,0]},{cellID:'B',rootXZ:[11992.715801343124,6779.681531943434]}],w=new TwoCellWorld(config,DEFAULT_CONTROLS,{cells:definitions}),single=definitions.map(d=>new SourceModel(config,DEFAULT_CONTROLS,d)),turn={...DEFAULT_CONTROLS,meanX:0,meanZ:6,shearX:0,shearZ:-.0015,uplift:.25,dryGain:0},dry={...turn,frontX:522,frontStart:500,frontSpeed:35,dryGain:1};
 w.enqueueBatch([{patch:turn,requestedTime:150},{patch:dry,requestedTime:500}]);for(const m of single){m.enqueue(turn,150);m.enqueue(dry,500);}
 for(const t of[0,70,149.75,150,150.25,220,499.75,500,500.25,550]){
  run(w,t);for(const m of single)run(m,t);const pair=w.presentation(t+.125,4);
  for(let i=0;i<2;i++){
   const g=pair.groups[i],{cellID,groupIndex,eventIdentityScope,...rest}=g;rest.parts=g.parts.map(p=>{const{localID,localParentID,cellID,worldEpoch,globalSlot,...base}=p;return{...base,ID:localID,parentID:localParentID};});compareTuple(rest,single[i].presentation(t+.125,4));assert.deepEqual(w.metadata().cells[i],single[i].metadata());
  }
 }
 checks.push('shared_interval_physics_exact_to_separately_commanded_sources');
}
const result={pass:true,checks,logicalControlBanksCPUBytes:1886592,observerExposureCopyBytes:628864,scope:'FocusedCPU world authority/causality/ownership tests; no native optical queries/GPU/art/scaling/timing admission',node:process.version,maxRSSKiB:process.resourceUsage().maxRSS};await writeFile(new URL('contracts-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
