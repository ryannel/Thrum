import test from 'node:test';import assert from 'node:assert/strict';
import {completedTraceRow} from '../../src/bench/trace.js';
test('completion after a fixture edit retains submitted frame revision and source time',()=>{
 const submitted={submissionPerformanceMs:100,fixtureRevision:0,source:{sourceTime:130,requestedTime:130.25,committedTime:130.25,sourceTick:521,alpha:0},presentation:{frame:17}};
 let currentRevision=0;const pendingFence=Promise.resolve().then(()=>{currentRevision=1;return 109;});
 return pendingFence.then(completed=>{const row=completedTraceRow(submitted,completed);assert.equal(currentRevision,1);assert.equal(row.fixtureRevision,0);assert.equal(row.sourceTime,130);assert.equal(row.completed,109);});
});
