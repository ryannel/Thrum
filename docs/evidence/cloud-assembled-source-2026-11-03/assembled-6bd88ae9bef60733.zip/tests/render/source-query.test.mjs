import test from 'node:test';import assert from 'node:assert/strict';
import {packParts,heldPoint,forwardPoint,sampleExposure,MAX_PARTS,GRID_COUNT} from '../../src/render/held-oracle.js';
const part={ID:'body-0',templateID:'body',C:[0,1239.2,0],Qcolumns:[[1,0,0],[0,1,0],[0,0,1]],s:4,g:1,b:4,K:[0,0,0],root:[299,233,167],Aseed:1,ageE:4,slot:0};
const asset={origin:[64,176,0],span:[384,128,512],pitch:2,dims:[2,2,2],density:new Uint16Array(8).fill(0x3c00),distance:new Uint16Array(8).fill(0x3c00)};
const noise=new Uint16Array(32**3).fill(0x0000),prev=new Float32Array(MAX_PARTS*GRID_COUNT),next=new Float32Array(MAX_PARTS*GRID_COUNT).fill(2);
test('integrated source state packs age and stable control slot',()=>{
 const a=packParts([part]);assert.equal(a[22],4);assert.equal(a[23],0);assert.equal(a[3],4);
 assert.throws(()=>packParts([{...part,slot:8}]),/slot/);
});
test('fixed material M and interpolated exposure erode once; raw source stays separate',()=>{
 const x=forwardPoint(part,[256,240,256]);const assets={body:asset};
 const q=heldPoint([part],assets,x,{noise,exposurePrevious:prev,exposureCurrent:next,alpha:.5});
 const u=(1-.3*(4+1)+8)/16,expected=u*u*(3-2*u);
 assert.ok(Math.abs(q-expected)<1e-12);
 assert.equal(heldPoint([part],assets,x,{raw:true,noise,exposurePrevious:prev,exposureCurrent:next,alpha:.5}),1);
 const q0=heldPoint([part],assets,x,{noise,exposurePrevious:prev,exposureCurrent:next,alpha:0});
 const q1=heldPoint([part],assets,x,{noise,exposurePrevious:prev,exposureCurrent:next,alpha:1});
 assert.ok(q0>q&&q>q1);
});
test('exposure samples each template domain, not a global 0..512 grid',()=>{
 const gradient=new Float32Array(MAX_PARTS*GRID_COUNT);
 for(let z=0;z<17;z++)for(let y=0;y<17;y++)for(let x=0;x<17;x++)gradient[(z*17+y)*17+x]=y;
 assert.equal(sampleExposure(gradient,0,[64,176,0],asset),0);
 assert.equal(sampleExposure(gradient,0,[64,240,0],asset),8);
 assert.equal(sampleExposure(gradient,0,[64,304,0],asset),16);
});
