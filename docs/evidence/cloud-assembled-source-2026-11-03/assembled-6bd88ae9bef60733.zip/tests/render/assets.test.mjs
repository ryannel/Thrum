import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {loadRenderAssets} from '../../src/render/assets.js';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../assets'),originalFetch=globalThis.fetch;
test('real integrated index verifies two LOCAL templates and pinned 32³ noise',async()=>{
 globalThis.fetch=async url=>{const n=String(url).replace(/^assets\//,'');if(n.startsWith('/')||n.includes('..'))return new Response('not found',{status:404});try{return new Response(await fs.readFile(path.join(base,n)),{status:200});}catch{return new Response('not found',{status:404});}};
 try{
  const x=await loadRenderAssets();assert.equal(x.indexSha256,'8744bca32b981b2e654f14b991bfe0c12f6504cb519cd1eaaf61f81af186ecf7');
  assert.equal(x.frozenSha256,'60054a49e5edb232177a40de2fe60ad18ff36ccb253d42345b360b6b5b30d62c');
  assert.deepEqual(Object.keys(x.assets),['body','crown-b']);
  assert.equal(x.assets.body.density.length,192*64*256);
  assert.equal(x.assets['crown-b'].distance.length,96*64*72);
  assert.equal(x.noise.length,32**3);
  assert.ok(x.admissionMetadata&&typeof x.admissionMetadata==='object');
  assert.ok(x.assets.body.manifest.reference.definition.includes('worldw=8*b'));
  assert.ok(x.assets['crown-b'].manifest.reference.definition.includes('worldw=8*b'));
 }finally{globalThis.fetch=originalFetch;}
});
