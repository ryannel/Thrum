import {configuration} from './fixtures.mjs';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {SourceModel,DEFAULT_CONTROLS} from '../../src/source/model.js';
const {admissionMetadata}=await configuration();
const model=new SourceModel({admissionMetadata},{...DEFAULT_CONTROLS,dryGain:0});
for(let i=0;i<16;i++){model.step();assert.ok(model.current.some(p=>p.active&&p.ID===1),'newborn seed must survive0..4s');}
assert.equal(model.current.find(p=>p.ID===1).Aseed,1);
while(model.time<1200)model.step();
console.log(JSON.stringify({time:model.time,stats:model.stats,eventCount:model.eventCount,overwrittenEvents:model.overwrittenEvents,events:model.events.map(e=>({...e,siteID:e.site?(admissionMetadata.templates.body.sites.find(s=>s.local.every((v,k)=>Math.abs(v-e.site[k])<1e-6))?.id??'body-root'):null}))},null,2));
