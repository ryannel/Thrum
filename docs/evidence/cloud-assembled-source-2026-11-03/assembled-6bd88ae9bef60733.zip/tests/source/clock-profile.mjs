import assert from 'node:assert/strict';
import {writeFile} from 'node:fs/promises';
import {configuration} from './fixtures.mjs';
import {SourceModel,DEFAULT_CONTROLS} from '../../src/source/model.js';
import {SourceClock} from '../../src/source/clock.js';
const config=await configuration(),initial={...DEFAULT_CONTROLS,dryGain:0},rejected=[];
for(const dt of [.125,.0625]){
 const model=new SourceModel(config,initial,{dt});
 assert.throws(()=>new SourceClock(model),/SourceClock requires model\.dt === 0\.25 seconds; use SourceModel directly for timestep refinement/);
 assert.equal(model.time,0);assert.equal(model.tick,0);assert.ok(model.current.some(p=>p.active&&p.ID===1));
 rejected.push(dt);
}
const fine=new SourceModel(config,initial,{dt:.125});
while(fine.time<120.125)fine.step();
assert.equal(fine.presentation(120.25).time,120,'Direct fine model still presents matching retained interval');
const clock=new SourceClock(new SourceModel(config,initial));
await clock.seek(120);assert.equal(clock.tuple().time,120);assert.equal(clock.model.dt,.25);
clock.reset(initial);assert.equal(clock.model.dt,.25);assert.equal(clock.tuple().time,0);
const result={pass:true,selectedClockDTSeconds:.25,rejectedClockDTSeconds:rejected,rejectionBeforeAnySourceStep:true,directSourceRefinementDTSeconds:.125,directRefinementPresentationTime:120,selectedClockSeekPresentationTime:120,selectedClockResetPresentationTime:0,scope:'Constructor rejects unsupported clock timesteps; direct SourceModel refinement remains available. Former seek-offset result belongs to archived73b.'};
await writeFile(new URL('clock-profile-results.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));
