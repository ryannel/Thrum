#!/usr/bin/env python3
"""Verify exact frozen source closure in server payload without starting HTTP/GPU."""
from pathlib import Path
import importlib.util,json,hashlib
P=Path(__file__).resolve().parents[2];s=importlib.util.spec_from_file_location('payload_only',P/'serve.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);data,i=m.payload();a=json.loads((P/'assets/assembly.json').read_text());rows=[]
for n,v in a['sourceApproval']['files'].items():
 assert n in data and len(data[n])==v['bytes']and hashlib.sha256(data[n]).hexdigest()==v['sha256'];rows.append(n)
assert len(rows)==16 and 'src/source/admission-policy.provenance.json'in rows and 'src/source/weather-zero.js'in rows
r={'pass':True,'build':i['build'],'servedFiles':len(data),'approvedSourceFiles':len(rows),'sourceProvenanceServedAndHashed':True,'scope':'Server payload closure only; noHTTP/server/GPU started'};(P/'results/provenance-payload.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
