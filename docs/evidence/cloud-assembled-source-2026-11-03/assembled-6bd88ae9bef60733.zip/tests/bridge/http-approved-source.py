#!/usr/bin/env python3
"""Real HTTP regression against ROOT's already-running frozen viewer. Starts no server."""
from pathlib import Path
import argparse,hashlib,json,urllib.request,urllib.error
P=Path(__file__).resolve().parents[2]
a=argparse.ArgumentParser(description=__doc__);a.add_argument('--base',default='http://127.0.0.1:8163/');args=a.parse_args()
f=json.loads((P/'FREEZE.json').read_text());assembly=json.loads((P/'assets/assembly.json').read_text());base=args.base.rstrip('/')+'/build/'+f['build']+'/'
def read(name):
 with urllib.request.urlopen(base+name,timeout=10)as response:
  assert response.status==200,(name,response.status)
  return response.read()
identity=json.loads(read('identity.json'));assert identity['build']==f['build']and identity['files']==f['files']
rows=[]
for name,pin in assembly['sourceApproval']['files'].items():
 b=read(name);actual=hashlib.sha256(b).hexdigest();assert len(b)==pin['bytes']and actual==pin['sha256'],name;assert identity['files'][name]==actual
 rows.append({'path':name,'httpStatus':200,'bytes':len(b),'sha256':actual})
assert len(rows)==16 and any(r['path'].endswith('admission-policy.provenance.json')for r in rows)
result={'pass':True,'build':f['build'],'base':base,'paths':rows,'scope':'Actual HTTP frozen routing/identity only; no source simulation/GPU/browser/timing','startsServer':False}
(P/'results/http-approved-source.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'pass':True,'build':f['build'],'approvedPaths':len(rows)}))
