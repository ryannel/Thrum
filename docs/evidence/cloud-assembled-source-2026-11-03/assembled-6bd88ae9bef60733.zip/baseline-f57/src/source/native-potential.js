// Pure CPU, pinned R16 loss-free field. No render/GPU imports or decoded volume cache.
import {inverse} from './math.js';
import {smooth} from './weather.js';
import {halfToFloat} from './reference.js';
const U=2**-53;
export function positionGuard(p){
 const max=Math.max(...p.C.map(Math.abs),p.b*512,Math.hypot(...p.K)*512,1);
 if(!Number.isFinite(max)||max>1e6||p.b<.05)throw Error('Spatial numeric guard outside qualified range');
 return 1e-4+1024*(128*U/(1-128*U))*max;
}
// Minimum native-cell corner values enclose the trilinear point even with coordinate error.
// This may miss occupancy, but sampled zeros are never an empty-support proof.
export function potentialLower(p,x,asset){
 if(!asset||p.Aseed<=0)return 0;
 const a=inverse(p,x),g=Math.hypot(...p.K)/p.b,minScale=p.b*(Math.sqrt(4+g*g)-g)/2;
 const eps=4*positionGuard(p)/minScale,lo=[],hi=[];
 for(let k=0;k<3;k++){
  if(a[k]-eps<asset.origin[k]||a[k]+eps>asset.origin[k]+asset.span[k])return 0;
  lo[k]=Math.max(0,Math.floor((a[k]-eps-asset.origin[k])/asset.pitch-.5));
  hi[k]=Math.min(asset.dims[k]-1,Math.floor((a[k]+eps-asset.origin[k])/asset.pitch-.5)+1);
  if(hi[k]-lo[k]>3)throw Error('Native witness coordinate bound too wide');
 }
 let rho=Infinity,d=Infinity;
 for(let z=lo[2];z<=hi[2];z++)for(let y=lo[1];y<=hi[1];y++)for(let x=lo[0];x<=hi[0];x++){
  const i=(z*asset.dims[1]+y)*asset.dims[0]+x,r=halfToFloat(asset.density[i]),v=halfToFloat(asset.distance[i]);
  if(!Number.isFinite(r)||!Number.isFinite(v)||r<0)throw Error('Invalid pinned native input');rho=Math.min(rho,r);d=Math.min(d,v);
 }
 const q=p.Aseed*rho*smooth(-8,8,d),round=1024*(128*U/(1-128*U))*(1+rho);
 return Math.max(0,q-round);
}
