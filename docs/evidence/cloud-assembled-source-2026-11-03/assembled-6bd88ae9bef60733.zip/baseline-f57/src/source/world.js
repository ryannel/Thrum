// Bounded two-cell producer. Existing SourceClock is the sole wall/source clock owner.
import {SourceModel,DEFAULT_CONTROLS,DT,MAX_PARTS,GRID_COUNT} from './model.js';
import {validateControls} from './weather.js';
import {snapshotForProbe} from './reference.js';
const EPS=1e-8,EMPTY=Object.freeze([]),leases=new WeakMap();
const CONTROL_KEYS=Object.keys(DEFAULT_CONTROLS);
const frozenControls=value=>Object.freeze(validateControls(value));
export const DEFAULT_CELLS=Object.freeze([Object.freeze({cellID:'A',rootXZ:Object.freeze([0,0])}),Object.freeze({cellID:'B',rootXZ:Object.freeze([16,0])})]);
export function qualifiedID(epoch,cellID,localID){if(!Number.isSafeInteger(epoch)||epoch<0||!Number.isSafeInteger(localID)||localID<1)throw Error('Invalid qualified source ID');return JSON.stringify([epoch,cellID,localID]);}
function patchCopy(value){if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))throw Error('Weather patch must be plain data');for(const k of Object.keys(value))if(!CONTROL_KEYS.includes(k))throw Error('Unknown weather control '+k);return Object.freeze({...value});}
function freezeObject(v){if(v&&typeof v==='object'&&!ArrayBuffer.isView(v)){for(const q of Object.values(v))freezeObject(q);Object.freeze(v);}return v;}
export function assertWorldPublication(tuple){const lease=leases.get(tuple);if(!lease||tuple.state!=='ready')throw Error('Missing valid world publication');if(!lease.owned&&(lease.state.fault||lease.state.serial!==lease.serial))throw Error('World publication exposure lease expired or quarantined');return tuple;}
export function snapshotWorldForProbe(tuple){assertWorldPublication(tuple);const out=Object.freeze({...tuple,groups:Object.freeze(tuple.groups.map(group=>freezeObject(snapshotForProbe(group)))),exposureOwnership:'owned observer copy'});leases.set(out,{owned:true});return out;}
export class TwoCellWorld {
 #cells;#definitions;#configuration;#time=0;#tick=0;#previousTime=0;#controls;#intervalControls;#revision=0;#intervalRevision=0;#commandRevision=0;#commands=[];#fault=null;#lease={serial:0,fault:null};#events=[];
 constructor(configuration,initial=DEFAULT_CONTROLS,{cells=DEFAULT_CELLS}={}){
  if(!Array.isArray(cells)||cells.length!==2)throw Error('Exactly two fixed cells required');const IDs=new Set();
  this.#definitions=Object.freeze(cells.map(d=>{if(!d||typeof d.cellID!=='string'||!/^[-A-Za-z0-9._:]{1,128}$/.test(d.cellID)||IDs.has(d.cellID))throw Error('Distinct persistent cellIDs required');IDs.add(d.cellID);if(!Array.isArray(d.rootXZ)||d.rootXZ.length!==2||!d.rootXZ.every(Number.isFinite))throw Error('Invalid cell rootXZ');return Object.freeze({cellID:d.cellID,rootXZ:Object.freeze([...d.rootXZ])});}));
  this.#configuration=configuration;this.initial=frozenControls(initial);this.#controls=this.initial;this.#intervalControls=this.initial;Object.defineProperty(this,'dt',{value:DT,enumerable:true});
  this.#cells=this.#definitions.map(d=>{const c=new SourceModel(configuration,this.initial,{cellID:d.cellID,rootXZ:d.rootXZ});c.controls=this.#controls;c.intervalControls=this.#controls;return c;});
 }
 #healthy(){if(this.#fault)throw Error('Two-cell publication quarantined: '+this.#fault.cause);}
 get time(){this.#healthy();return this.#time;} get previousTime(){this.#healthy();return this.#previousTime;} get tick(){this.#healthy();return this.#tick;}
 get cellDefinitions(){return this.#definitions;} get fault(){return this.#fault;}
 get commandRevision(){return this.#commandRevision;} set commandRevision(v){if(this.#tick!==0||v!==Math.max(0,...this.#commands.map(c=>c.revision)))throw Error('Invalid replay command revision');this.#commandRevision=v;for(const c of this.#cells)c.commandRevision=v;}
 get commands(){return Object.freeze(this.#commands.map(c=>Object.freeze({...c,patch:c.patch})));}
 set commands(list){
  this.#healthy();if(this.#tick!==0||!Array.isArray(list)||list.length>256)throw Error('Commands can only be restored onto a fresh world');const IDs=new Set(),copy=list.map(c=>{if(!Number.isSafeInteger(c.tick)||c.tick<1||!Number.isSafeInteger(c.revision)||c.revision<1||IDs.has(c.revision)||c.applied)throw Error('Invalid replay command');IDs.add(c.revision);return{tick:c.tick,revision:c.revision,patch:patchCopy(c.patch),applied:false};});
  this.#validatePending(copy);this.#commands=copy;this.#commandRevision=Math.max(0,...copy.map(c=>c.revision));for(const c of this.#cells)c.commandRevision=this.#commandRevision;
 }
 fresh(initial=this.initial){return new TwoCellWorld(this.#configuration,initial,{cells:this.#definitions});}
 #validatePending(list){let controls=this.#controls;for(const c of list.filter(v=>!v.applied).sort((a,b)=>a.tick-b.tick||a.revision-b.revision)){if(c.tick<=this.#tick)throw Error('Missed global command barrier');controls=frozenControls({...controls,...c.patch});}return controls;}
 enqueue(patch,requestedTime=this.#time){return this.enqueueBatch([{patch,requestedTime}])[0];}
 enqueueBatch(entries){
  this.#healthy();if(!Array.isArray(entries)||!entries.length||this.#commands.length+entries.length>256)throw Error('Global command history capacity256');
  const added=entries.map((v,i)=>{const t=v.requestedTime??this.#time;if(!Number.isFinite(t)||t<0)throw Error('Invalid global command time');return{tick:Math.max(this.#tick+1,Math.ceil((t-EPS)/DT)),patch:patchCopy(v.patch),revision:this.#commandRevision+i+1,applied:false};});
  const candidate=this.#validatePending([...this.#commands,...added]);this.#commands.push(...added);this.#commandRevision+=added.length;for(const c of this.#cells)c.commandRevision=this.#commandRevision;
  return Object.freeze(added.map(c=>Object.freeze({tick:c.tick,revision:c.revision,activationTime:c.tick*DT,candidate})));
 }
 #checkCells(time,tick,controls,revision){for(const c of this.#cells)if(c.time!==time||c.tick!==tick||c.controls!==controls||c.committedRevision!==revision)throw Error('Cell barrier divergence');}
 #quarantine(error){this.#fault=Object.freeze({state:'faulted',cause:String(error?.message??error),lastCommittedTime:this.#time,lastCommittedTick:this.#tick,unsafeCellClocks:Object.freeze(this.#cells.map(c=>Object.freeze({cellID:c.cellId,time:c.time,tick:c.tick})))});this.#lease.fault=this.#fault;this.#lease.serial++;throw Error('Two-cell publication quarantined: '+this.#fault.cause);}
 step(){
  this.#healthy();try{
   this.#checkCells(this.#time,this.#tick,this.#controls,this.#revision);
   const tick=this.#tick+1,time=this.#time+DT,pending=this.#commands.filter(c=>!c.applied&&c.tick===tick).sort((a,b)=>a.revision-b.revision);let end=this.#controls;const barrier=[];
   for(const cmd of pending){end=frozenControls({...end,...cmd.patch});barrier.push(Object.freeze({revision:cmd.revision,controls:end}));}
   const endRevision=barrier.length?barrier.at(-1).revision:this.#revision,interval=Object.freeze({time:this.#time,tick:this.#tick,dt:DT,controls:this.#controls,revision:this.#revision,endCommands:barrier.length?Object.freeze(barrier):EMPTY});
   for(const c of this.#cells)c.step(interval);
   this.#checkCells(time,tick,end,endRevision);
   this.#previousTime=this.#time;this.#time=time;this.#tick=tick;this.#intervalControls=interval.controls;this.#intervalRevision=interval.revision;this.#controls=end;this.#revision=endRevision;
   for(const cmd of pending){cmd.applied=true;const event=Object.freeze({time,revision:cmd.revision,type:'controls-committed',controls:barrier.find(b=>b.revision===cmd.revision).controls});this.#events.push(event);if(this.#events.length>128)this.#events.shift();}
   this.#lease.serial++;return this.#time;
  }catch(error){return this.#quarantine(error);}
 }
 presentation(requestedTime,epoch=0){
  const observerExplicitEpoch=arguments.length>=2;if(this.#configuration.observedGrowth&&observerExplicitEpoch&&(!Number.isSafeInteger(arguments[1])||arguments[1]<0))throw Error('Explicit observer epoch must be a nonnegative safe integer');
  this.#healthy();if(!Number.isFinite(requestedTime)||!Number.isSafeInteger(epoch)||epoch<0)throw Error('Invalid world presentation request');
  try{
   this.#checkCells(this.#time,this.#tick,this.#controls,this.#revision);const local=this.#cells.map(c=>this.#configuration.observedGrowth&&!observerExplicitEpoch?c.presentation(requestedTime):c.presentation(requestedTime,epoch)),first=local[0];
   if(local.some(t=>t.time!==first.time||t.alpha!==first.alpha||t.sourceTick!==first.sourceTick||t.previousTime!==first.previousTime||t.forcingRevision!==first.forcingRevision))throw Error('Mixed source publication interval');
   const controls=first.time<this.#time-EPS?this.#intervalControls:this.#controls;let partStart=0;
   const groups=Object.freeze(local.map((t,i)=>Object.freeze({...t,cellID:this.#definitions[i].cellID,groupIndex:i,controls,parts:Object.freeze(t.parts.map(p=>Object.freeze({...p,ID:qualifiedID(epoch,this.#definitions[i].cellID,p.ID),parentID:p.parentID?qualifiedID(epoch,this.#definitions[i].cellID,p.parentID):null,localID:p.ID,localParentID:p.parentID,cellID:this.#definitions[i].cellID,worldEpoch:epoch,globalSlot:i*MAX_PARTS+p.slot}))),eventIdentityScope:'Local event IDs are scoped by group cellID and world epoch'})));
   const ranges=Object.freeze(groups.map((g,i)=>{const r=Object.freeze({cellID:g.cellID,partStart,partCount:g.parts.length,slotStart:i*MAX_PARTS,slotCount:MAX_PARTS,controlElementOffset:i*MAX_PARTS*GRID_COUNT});partStart+=g.parts.length;return r;}));
   const lo=[0,1,2].map(k=>Math.min(...groups.map(g=>g.bounds[0][k]))),hi=[0,1,2].map(k=>Math.max(...groups.map(g=>g.bounds[1][k])));
   const tuple=Object.freeze({state:'ready',epoch,sourceTick:this.#tick,time:first.time,alpha:first.alpha,requestedTime,committedTime:this.#time,previousTime:this.#previousTime,forcingRevision:first.forcingRevision,committedRevision:this.#revision,queuedRevision:this.#commandRevision,controls,groups,formationRanges:ranges,bounds:Object.freeze([Object.freeze(lo),Object.freeze(hi)]),exposureAllZero:groups.every(g=>g.exposureAllZero),exposureOwnership:'borrowed until next world commit; snapshotWorldForProbe before await/commit',controlBytesCPU:1886592,observerControlCopyBytes:628864});
   leases.set(tuple,{owned:false,state:this.#lease,serial:this.#lease.serial});return tuple;
  }catch(error){return this.#quarantine(error);}
 }
 metadata(){if(this.#fault)return this.#fault;return{state:'ready',time:this.#time,previousTime:this.#previousTime,tick:this.#tick,dt:DT,cellDefinitions:this.#definitions,controls:this.#controls,intervalControls:this.#intervalControls,committedRevision:this.#revision,queuedRevision:this.#commandRevision,cells:this.#cells.map(c=>c.metadata()),events:[...this.#events],controlBytesCPU:1886592,scope:'Fixed two-cell CPU source only; local events are scoped by cellID; source art/GPU/air/fog/environment/cost admission unrun'};}
}
