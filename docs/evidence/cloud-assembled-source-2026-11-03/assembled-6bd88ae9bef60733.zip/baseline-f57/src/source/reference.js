// Independent native scalar-field oracle. Never called by ordinary model stepping/render frames.
import {inverse,GRID_COUNT} from './math.js';
import {smooth,clamp} from './weather.js';
export function halfToFloat(h){const s=h&32768?-1:1,e=(h>>>10)&31,m=h&1023;return e===0?s*2**-14*(m/1024):e===31?(m?NaN:s*Infinity):s*2**(e-15)*(1+m/1024);}
export function sampleHalf(data,dims,uv){const p=uv.map((u,k)=>u*dims[k]-.5),lo=p.map(Math.floor),f=p.map((v,k)=>v-lo[k]);let out=0;for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++){const ix=clamp(lo[0]+x,0,dims[0]-1),iy=clamp(lo[1]+y,0,dims[1]-1),iz=clamp(lo[2]+z,0,dims[2]-1);out+=halfToFloat(data[(iz*dims[1]+iy)*dims[0]+ix])*(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);}return out;}
export function sampleExposure(grid,slot,a,asset){const p=a.map((v,k)=>clamp((v-asset.origin[k])/asset.span[k]*16,0,16)),lo=p.map(v=>Math.min(15,Math.floor(v))),f=p.map((v,k)=>v-lo[k]);let out=0;for(let z=0;z<2;z++)for(let y=0;y<2;y++)for(let x=0;x<2;x++)out+=grid[slot*GRID_COUNT+((lo[2]+z)*17+lo[1]+y)*17+lo[0]+x]*(x?f[0]:1-f[0])*(y?f[1]:1-f[1])*(z?f[2]:1-f[2]);return out;}
// assets[templateID]={origin,span,dims,density:Uint16Array,distance:Uint16Array}; noise is shared32³ R16 bits.
export function evaluatePoint(tuple,x,assets,noise,{raw=false,zero=false}={}){
 if(zero)return 0;if(!x.every(Number.isFinite))throw Error('Nonfinite oracle point');let result=0;
 for(const p of tuple.parts){if(p.Aseed<=0)continue;const asset=assets[p.templateID];if(!asset)throw Error('Missing native basis '+p.templateID);const a=inverse(p,x),uv=a.map((v,k)=>(v-asset.origin[k])/asset.span[k]);if(uv.some(v=>v<0||v>1))continue;let q=p.Aseed*sampleHalf(asset.density,asset.dims,uv);if(!q)continue;
  if(!raw){const E=(1-tuple.alpha)*sampleExposure(tuple.exposurePrevious,p.slot,a,asset)+tuple.alpha*sampleExposure(tuple.exposureCurrent,p.slot,a,asset),loss=p.ageE+E;if(loss>0&&!noise)throw Error('Loss oracle requires shared material noise');const M=loss>0?.3+.7*sampleHalf(noise,[32,32,32],a.map(v=>clamp(v/512,0,1))):1,d=sampleHalf(asset.distance,asset.dims,uv);q*=smooth(-8,8,d-M*loss);}
  result=Math.max(result,q);
 }return result;
}
export function snapshotForProbe(tuple){return{...tuple,parts:tuple.parts.map(p=>({...p,C:[...p.C],K:[...p.K],root:[...p.root],Qcolumns:p.Qcolumns.map(v=>[...v])})),exposurePrevious:new Float32Array(tuple.exposurePrevious),exposureCurrent:new Float32Array(tuple.exposureCurrent)};}
