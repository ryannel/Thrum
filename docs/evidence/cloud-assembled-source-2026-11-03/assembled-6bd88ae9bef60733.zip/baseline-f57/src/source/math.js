import {smooth} from './weather.js';
export const DT=.25, LAG=.25, MAX_PARTS=8, GRID=17, GRID_COUNT=17**3, G0=1/64;
export const ROLES=Object.freeze({BODY:Object.freeze({templateID:'body',s:4,life:300,cadence:100,mature:60,lossStart:180,lease:60}),BILLOW:Object.freeze({templateID:'crown-b',life:150,cadence:50,first:70,mature:45,lossStart:100,lease:45})});
export const identity = () => [[1,0,0],[0,1,0],[0,0,1]];
export const sigmaMin = g => (Math.sqrt(4+g*g)-Math.abs(g))/2;
export const sigmaMax = g => (Math.sqrt(4+g*g)+Math.abs(g))/2;
export function growth(role,tau) { return G0+(1-G0)*smooth(4,ROLES[role].mature,tau); }
export function growthDerivative(role,tau) { const T=ROLES[role].mature,u=(tau-4)/(T-4); return u>0&&u<1 ? (1-G0)*6*u*(1-u)/(T-4) : 0; }
export function response(mu,tau,target,dt) { const e=Math.exp(-dt/2); return {mu:target+(mu-target)*e,tau:tau+target*dt+2*(mu-target)*(1-e)}; }
export function growthIntegral(p,target,dt) {
 const at=t=>growth(p.role,response(p.mu,p.tau,target,t).tau);
 return dt/12*(at(0)+4*at(dt/4)+2*at(dt/2)+4*at(3*dt/4)+at(dt));
}
// The point field uses stored Q^T exactly. Use its numerical dual, not an assumed perfect rotation.
export function fieldColumns(Q) {
 const M=[0,1,2].map(i=>Q.map(c=>c[i])),[[a,b,c],[d,e,f],[g,h,i]]=M,det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);
 if(!Number.isFinite(det)||Math.abs(det)<.99)throw Error('Invalid material frame');
 return [[(e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],[(f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],[(d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]];
}
// Only birth-owned deeply frozen Q arrays are registered: no transient pose keys.
const birthFrames=new WeakMap();
export function registerBirthFrame(p){
 const Q=Object.freeze(p.Qcolumns.map(c=>Object.freeze([...c])));
 const dual=Object.freeze(fieldColumns(Q).map(c=>Object.freeze(c)));
 p.Qcolumns=Q;birthFrames.set(Q,Object.freeze({dual}));
}
export function copyBirthFrame(source,target){
 if(!birthFrames.has(source.Qcolumns))return false;
 target.Qcolumns=source.Qcolumns;return true;
}
function poseColumns(p){return birthFrames.get(p.Qcolumns)?.dual??fieldColumns(p.Qcolumns);}
// Public descriptors keep independent Q clones. No ephemeral descriptor registry entry.
export function boundsForFrozenDescriptor(p,t,source){
 const frame=birthFrames.get(source.Qcolumns);if(!frame)return bounds(p,t);
 const Q=p.Qcolumns;
 if(!Object.isFrozen(p)||!Object.isFrozen(Q)||Q.length!==3)throw Error('Frame descriptor must be frozen');
 for(let j=0;j<3;j++){
  if(!Object.isFrozen(Q[j])||Q[j].length!==3)throw Error('Frame rows must be frozen');
  for(let i=0;i<3;i++)if(!Object.is(Q[j][i],source.Qcolumns[j][i]))throw Error('Frame descriptor changed Qcolumns');
 }
 const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity],s=t.potentialSupport;
 for(const x of[s.local_support_bbox_min_xyz_m[0],s.local_support_bbox_max_xyz_m[0]])for(const y of[s.local_support_bbox_min_xyz_m[1],s.local_support_bbox_max_xyz_m[1]])for(const z of[s.local_support_bbox_min_xyz_m[2],s.local_support_bbox_max_xyz_m[2]]){
  // Same eight-corner arithmetic and operand order as forward()/bounds().
  const d=[x,y,z].map((v,i)=>v-p.root[i]);
  const v=[0,1,2].map(i=>frame.dual.reduce((sum,col,j)=>sum+col[i]*d[j],0));
  const point=p.C.map((c,i)=>c+p.b*v[i]+p.K[i]*v[1]);
  for(let k=0;k<3;k++){lo[k]=Math.min(lo[k],point[k]);hi[k]=Math.max(hi[k],point[k]);}
 }
 return[lo,hi];
}
export function rotated(p,a) { const d=a.map((v,i)=>v-p.root[i]); const Q=poseColumns(p); return [0,1,2].map(i=>Q.reduce((s,col,j)=>s+col[i]*d[j],0)); }
export function forward(p,a) { const v=rotated(p,a); return p.C.map((x,i)=>x+p.b*v[i]+p.K[i]*v[1]); }
export function inverse(p,x) { const h=(x[1]-p.C[1])/p.b,v=x.map((q,i)=>(q-p.C[i]-p.K[i]*h)/p.b); return p.root.map((q,i)=>q+p.Qcolumns[i].reduce((s,z,k)=>s+z*v[k],0)); }
export function matrix(p) { const Q=poseColumns(p); return [0,1,2].map(i=>[0,1,2].map(j=>p.b*Q[j][i]+p.K[i]*Q[j][1])); }
export function fullVelocity(p,a,c) {
 const v=rotated(p,a),bd=p.s*growthDerivative(p.role,p.tau)*p.mu;
 return [c.meanX+c.shearX*(p.C[1]-1500)+p.u[0]+bd*v[0]+c.shearX*p.b*v[1],p.u[1]+bd*v[1],c.meanZ+c.shearZ*(p.C[1]-1500)+p.u[2]+bd*v[2]+c.shearZ*p.b*v[1]];
}
export function advancePose(p,c,dt,ig,{zeroShear=false}={}) {
 const e=Math.exp(-dt/10),target=p.role==='BODY'?0:c.uplift,uy=p.u[1],iy=target*dt+10*(uy-target)*(1-e),intY=p.C[1]*dt+.5*target*dt*dt+10*(uy-target)*(dt-10*(1-e));
 const sx=zeroShear?0:c.shearX,sz=zeroShear?0:c.shearZ;
 p.C[0]+=c.meanX*dt+sx*(intY-1500*dt)+10*p.u[0]*(1-e); p.C[2]+=c.meanZ*dt+sz*(intY-1500*dt)+10*p.u[2]*(1-e); p.C[1]+=iy;
 p.u[0]*=e; p.u[2]*=e; p.u[1]=target+(uy-target)*e; p.K[0]+=sx*p.s*ig; p.K[2]+=sz*p.s*ig;
}
export function cloneGeometry(p) { const q={...p}; for(const k of ['C','K','u','root']) q[k]=[...p[k]]; if(!copyBirthFrame(p,q))q.Qcolumns=p.Qcolumns.map(a=>[...a]); delete q.E; return q; }
export function bounds(p,t) { const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity],s=t.potentialSupport; for(const x of [s.local_support_bbox_min_xyz_m[0],s.local_support_bbox_max_xyz_m[0]]) for(const y of [s.local_support_bbox_min_xyz_m[1],s.local_support_bbox_max_xyz_m[1]]) for(const z of [s.local_support_bbox_min_xyz_m[2],s.local_support_bbox_max_xyz_m[2]]) { const v=forward(p,[x,y,z]); for(let k=0;k<3;k++){lo[k]=Math.min(lo[k],v[k]);hi[k]=Math.max(hi[k],v[k]);} } return [lo,hi]; }
