// Condensation supply is not relative humidity: off inhibits growth/birth, never erases E.
export const ROOT_Y = 1239.2;
export const DEFAULT_CONTROLS = Object.freeze({meanX:4,meanZ:0,shearX:.002,shearZ:0,uplift:.15,moist:true,lift:true,frontX:-2500,frontStart:420,frontSpeed:50,frontWidth:800,dryGain:1});
export const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
export function smooth(lo, hi, x) { const u=clamp((x-lo)/(hi-lo),0,1); return u*u*(3-2*u); }
export function validateControls(value) {
 const c={...DEFAULT_CONTROLS,...value};
 for(const [k,v] of Object.entries(c)) if(k!=='moist'&&k!=='lift'&&!Number.isFinite(v)) throw Error('Nonfinite weather control '+k);
 if(typeof c.moist!=='boolean'||typeof c.lift!=='boolean') throw Error('Supply/lift must be Boolean');
 if(Math.hypot(c.meanX,c.meanZ)>12+1e-12) throw Error('Mean wind magnitude exceeds12m/s');
 if(Math.hypot(c.shearX,c.shearZ)>.002+1e-12) throw Error('Shear magnitude exceeds.002/s');
 if(c.uplift<0||c.uplift>.3) throw Error('Uplift outside0...3m/s');
 if(c.frontX< -8000||c.frontX>8000||c.frontStart<0||c.frontStart>3600||c.frontSpeed<0||c.frontSpeed>80||c.frontWidth<800||c.frontWidth>16000||c.dryGain<0||c.dryGain>1) throw Error('Dry-front control outside admitted range');
 return c;
}
export function windAt(y,c) { return [c.meanX+c.shearX*(y-1500),0,c.meanZ+c.shearZ*(y-1500)]; }
export function dryAt(x,t,c) { if(t<c.frontStart||c.dryGain===0) return 0; const f=c.frontX+c.frontSpeed*(t-c.frontStart); return c.dryGain*(1-smooth(f-c.frontWidth/2,f+c.frontWidth/2,x)); }
export function growthTarget(x,t,c) { return c.moist&&c.lift ? 1-dryAt(x,t,c) : 0; }
export function regionAdvance(R,c,dt) { const v=windAt(ROOT_Y,c); return [R[0]+v[0]*dt,ROOT_Y,R[2]+v[2]*dt]; }
