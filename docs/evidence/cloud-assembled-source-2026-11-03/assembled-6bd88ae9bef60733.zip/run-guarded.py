#!/usr/bin/env python3
"""Sequential functional checks with sampled aggregate process-tree RSS guards; not a benchmark."""
from pathlib import Path
import argparse,subprocess,os,time,json,signal,resource
R=Path(__file__).resolve().parent;EARLY=224*2**20;HARD=256*2**20
ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['contracts','native','source','render','all'],default='all');args=ap.parse_args()
commands={'contracts':['node','tests/world/contracts.mjs'],'native':['node','tests/world/native.mjs'],'source':['node','tests/source/run.mjs'],'render':['node','--test',*map(str,sorted(Path('tests/render').glob('*.test.mjs')))]}
# Glob relative to the proof, independent of invocation cwd.
commands['render']=['node','--test','--test-concurrency=1',*[str(p.relative_to(R))for p in sorted((R/'tests/render').glob('*.test.mjs'))]]
result={'scope':'Functional tests only; monitor/elapsed instrumentation is not throughput or target-runtime admission','earlyBytes':EARLY,'hardBytes':HARD,'sampleIntervalMs':25,'phases':[]};(R/'run-logs').mkdir(exist_ok=True)
for phase in commands if args.phase=='all'else[args.phase]:
 command=commands[phase];log=R/'run-logs'/((phase+'-serial'if phase=='render'else phase)+'.log');peak=0;samples=0;adverse=None;start=time.perf_counter()
 with log.open('w')as output:
  worker=subprocess.Popen(command,cwd=R,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  while worker.poll()is None:
   table=subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True);rows={int(a[0]):(int(a[1]),int(a[2])*1024)for line in table.splitlines()if len(a:=line.split())==3};tree={os.getpid()}
   changed=True
   while changed:
    new={pid for pid,(parent,rss)in rows.items()if parent in tree};changed=not new.issubset(tree);tree|=new
   total=sum(rows[pid][1]for pid in tree if pid in rows);peak=max(peak,total);samples+=1
   if total>=EARLY or total>=HARD:
    adverse={'reason':'aggregate process-tree RSS reservation guard','observedBytes':total};os.killpg(worker.pid,signal.SIGTERM);break
   time.sleep(.025)
  try:exitCode=worker.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(worker.pid,signal.SIGKILL);exitCode=worker.wait()
 entry={'phase':phase,'command':command,'exitCode':exitCode,'sampledProcessTreePeakBytes':peak,'samples':samples,'elapsedSeconds':time.perf_counter()-start,'log':str(log.relative_to(R)),'adverse':adverse};result['phases'].append(entry);result['pass']=all(p['exitCode']==0 and p['adverse']is None for p in result['phases']);(R/('guarded-'+args.phase+'-results.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(entry),flush=True)
 if not result['pass']:raise SystemExit(1)
