// Private per-opportunity preparation. Formula bodies below are verbatim legacy helpers.
import {validateMetadata,validatePose,sigmaMin,sigmaMax} from './admission-policy.js';
const norm=a=>Math.hypot(...a),sub=(a,b)=>a.map((v,i)=>v-b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const finite=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(Number.isFinite);
function requireValue(ok,message){if(!ok)throw Error(message);}
function qBounds(Q){
 requireValue(Array.isArray(Q)&&Q.length===3&&Q.every(v=>finite(v,3)),'Qcolumns missing/nonfinite');let lo=Infinity,hi=0;
 for(let i=0;i<3;i++){let off=0;for(let j=0;j<3;j++)if(i!==j)off+=Math.abs(dot(Q[i],Q[j]));lo=Math.min(lo,dot(Q[i],Q[i])-off);hi=Math.max(hi,dot(Q[i],Q[i])+off);}
 requireValue(lo>.999&&hi<1.001,'Qcolumns must be orthogonal');return{min:Math.sqrt(lo),max:Math.sqrt(hi)};
}
function fieldColumns(Q){const M=[0,1,2].map(i=>Q.map(c=>c[i])),[[a,b,c],[d,e,f],[g,h,i]]=M,det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);requireValue(Math.abs(det)>.99,'Singular Q');const inverseRows=[[(e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],[(f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],[(d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]];return inverseRows;}
function scaleBounds(p,bRange=[p.b,p.b],KRadius=0){const q=qBounds(p.Qcolumns),lo=bRange[0],hi=bRange[1],K=norm(p.K)+KRadius;return{min:lo*sigmaMin(K/lo)/q.max,max:hi*sigmaMax(K/hi)/q.min};}
function validateSweep(s){validatePose(s.pose);requireValue(finite(s.bRange,2)&&s.bRange[0]>0&&s.bRange[0]<=s.pose.b&&s.pose.b<=s.bRange[1],'Invalid sweep growth range');requireValue(Number.isFinite(s.KRadius)&&s.KRadius>=0&&Number.isFinite(s.centerRadius)&&s.centerRadius>=0,'Invalid sweep uncertainty');return s;}
function maxNodeOffsets(node,root,Q,frameMax){let r2=0,low=0,high=0;for(let j=0;j<3;j++){const a=node.lo[j]-root[j],b=node.hi[j]-root[j],h=Q[j][1];r2+=Math.max(a*a,b*b);low+=Math.min(a*h,b*h);high+=Math.max(a*h,b*h);}return{radius:Math.sqrt(r2)*frameMax,height:Math.max(Math.abs(low),Math.abs(high))};}

const distanceBox=(x,n)=>Math.hypot(...x.map((v,i)=>Math.max(n.lo[i]-v,0,v-n.hi[i])));
function ownedSweep(s){
 return{...s,pose:{...s.pose,C:[...s.pose.C],K:[...s.pose.K],Qcolumns:s.pose.Qcolumns.map(c=>[...c])},bRange:[...s.bRange]};
}
function prepareOld(template,input){
 const s=ownedSweep(input);validateSweep(s);return{template,s,p:s.pose,root:template.rootLocal,ready:false};
}
function readyOld(o){
 const{s,p,root,template}=o;
 // Same first-query order as legacy supportExcludesBall after local inverse.
 o.minScale=scaleBounds(p).min;o.deltaB=Math.max(p.b-s.bRange[0],s.bRange[1]-p.b);o.frame=fieldColumns(p.Qcolumns);o.frameMax=qBounds(o.frame).max;
 o.zeroOffsets=s.bRange[0]===p.b&&s.bRange[1]===p.b&&s.KRadius===0&&[...root,...template.support.nodes[0].lo,...template.support.nodes[0].hi].every(v=>Math.abs(v)<=1e6);
 o.valid=o.zeroOffsets?null:new Uint8Array(template.support.nodes.length);o.radii=o.zeroOffsets?null:new Float64Array(template.support.nodes.length);o.heights=o.zeroOffsets?null:new Float64Array(template.support.nodes.length);o.ready=true;
}

function excludes(o,center,radius){
 const{s,p,root}=o,h=(center[1]-p.C[1])/p.b,v=center.map((z,i)=>(z-p.C[i]-p.K[i]*h)/p.b),local=root.map((z,i)=>z+dot(p.Qcolumns[i],v)),stack=[0];if(!o.ready)readyOld(o);const{minScale,deltaB,frame,frameMax}=o;let nodes=0;
 while(stack.length){const index=stack.pop(),n=o.template.support.nodes[index];nodes++;requireValue(nodes<=255,'BVH work overflow');
  if(!o.zeroOffsets&&!o.valid[index]){const offset=maxNodeOffsets(n,root,frame,frameMax);o.radii[index]=offset.radius;o.heights[index]=offset.height;o.valid[index]=1;}
  const uncertain=o.zeroOffsets?s.centerRadius+0+0:s.centerRadius+deltaB*o.radii[index]+s.KRadius*o.heights[index],testRadius=(radius+uncertain)/minScale;
  if(distanceBox(local,n)>testRadius+1e-6)continue;
  if(n.left===-1)return{pass:false,nodes};stack.push(n.left,n.right);
 }return{pass:true,nodes};
}
export function prepareEndpoint(metadata,oldSweeps){
 validateMetadata(metadata);requireValue(Array.isArray(oldSweeps)&&oldSweeps.length<=8,'Old reference overflow/missing');const IDs=new Set(),olds=[];
 for(const o of oldSweeps){validateSweep(o);requireValue(!o.referenceOnly&&o.pose.ID!==undefined&&!IDs.has(o.pose.ID),'Invalid frozen reference ID/membership');IDs.add(o.pose.ID);requireValue(metadata.templates[o.pose.templateID],'Unknown old template');olds.push(prepareOld(metadata.templates[o.pose.templateID],o));}
 // All inputs are owned exact stored-pose copies, bounded to this synchronous opportunity.
 return function test(candidateSweep,resolvedLocalRadius=6){
  validateSweep(candidateSweep);requireValue(candidateSweep.pose.templateID==='crown-b','Exterior witness requires crown-b');requireValue(resolvedLocalRadius>=6&&Number.isFinite(resolvedLocalRadius),'Unresolved exterior subball');
  const t=metadata.templates['crown-b'],p=candidateSweep.pose,sc=scaleBounds(p,candidateSweep.bRange,candidateSweep.KRadius),deltaB=Math.max(p.b-candidateSweep.bRange[0],candidateSweep.bRange[1]-p.b),frame=fieldColumns(p.Qcolumns),qmin=qBounds(p.Qcolumns).min;let nodes=0;const failures=[];
  for(const h of t.headWitnesses){if(h.radiusLocal<resolvedLocalRadius)continue;const offset=sub(h.centerLocal,t.rootLocal),v=[0,1,2].map(i=>frame.reduce((s,col,j)=>s+col[i]*offset[j],0)),center=p.C.map((v0,i)=>v0+p.b*v[i]+p.K[i]*v[1]),headUncertainty=candidateSweep.centerRadius+deltaB*norm(offset)/qmin+candidateSweep.KRadius*Math.abs(v[1]),radius=sc.min*resolvedLocalRadius;
   if(2*radius<4*t.domain.pitch*sc.max){failures.push({headID:h.id,reason:'unresolved transformed subball'});continue;}
   let pass=true;for(const old of olds){const r=excludes(old,center,radius+headUncertainty);nodes+=r.nodes;if(!r.pass){pass=false;failures.push({headID:h.id,oldID:old.p.ID,reason:'conservative old support overlaps head'});break;}}
   if(pass)return{pass:true,headID:h.id,centerWorld:center,radiusWorldLower:radius,headUncertaintyWorld:headUncertainty,nodes,referenceIDs:[...IDs],scope:'Resolved positive subball outside conservative loss-free old support at45s; no camera/projection/beauty claim'};
  }return{pass:false,reason:'no certified resolved exterior head patch',failures,nodes};
 };
}
