// On-demand owned observer data. Caller supplies clock epoch; source stepping owns none.
export const MAX_CAPTURE_BYTES=256*1024;
function qualifyGeometry(p,epoch,cellID,qualifiedID){
 if(!p)return p;const localID=p.ID,parentLocalID=p.parentID;
 return{...p,localID,parentLocalID,ID:qualifiedID(epoch,cellID,localID),parentID:parentLocalID?qualifiedID(epoch,cellID,parentLocalID):null};
}
function qualifyDetail(raw,epoch,cellID,qualifiedID,scope){
 const out=structuredClone(raw);out.identityScope='clock-qualified-owned-observation';out.scope=scope;out.epoch=epoch;out.ID=qualifiedID(epoch,cellID,out.localID);out.parentID=out.parentLocalID?qualifiedID(epoch,cellID,out.parentLocalID):null;out.referenceQualifiedIDs=out.referenceIDs.map(id=>qualifiedID(epoch,cellID,id));
 out.actualChild=qualifyGeometry(out.actualChild,epoch,cellID,qualifiedID);out.actualReferences=out.actualReferences.map(p=>qualifyGeometry(p,epoch,cellID,qualifiedID));
 out.prediction.child=qualifyGeometry(out.prediction.child,epoch,cellID,qualifiedID);out.prediction.old=out.prediction.old.map(p=>qualifyGeometry(p,epoch,cellID,qualifiedID));
 out.provenance=out.provenance.map(p=>({...p,qualifiedID:qualifiedID(epoch,cellID,p.localID)}));return out;
}
export function captureCellObservation(model,presentationTime,epoch,qualifiedID,interruptionReason){
 const cellID=model.cellId;if(!model.observed)return{cellID,enabled:false,reason:'legacy-policy-disabled',summary:null,presentedActual:{available:false,reason:'legacy-policy-disabled'},committedAudit:null,interruption:null};
 const summaryTime=presentationTime<model.time?model.previousTime:model.time;
 const summary=structuredClone(model.observed.publication(summaryTime,epoch));
 const raw=model.observed.receipt(),presentedActual=raw&&raw.time<=presentationTime?{available:true,scope:'presented-actual',detail:qualifyDetail(raw,epoch,cellID,qualifiedID,'presented-actual')}:{available:false,reason:raw?'unavailable-after-presentation':'no-completed-observation'};
 const committedAudit=raw?{scope:'committed-audit-not-presented',detail:qualifyDetail(raw,epoch,cellID,qualifiedID,'committed-audit-not-presented')}:null;
 let interruption=null;const l=model.referenceLease;
 if(interruptionReason&&l)interruption={identityScope:'clock-qualified-owned-observation',scope:'committed-pending-interruption-not-presented',epoch,cellID,localID:l.childID,ID:qualifiedID(epoch,cellID,l.childID),birthTick:l.birthTick,birthTime:l.birthTime,committedTime:model.time,referenceTime:l.referenceTime,deadline:l.deadline,referenceIDs:[...l.IDs],referenceQualifiedIDs:l.IDs.map(id=>qualifiedID(epoch,cellID,id)),cancellation:structuredClone(l.cancelled),outcome:'interrupted',reason:interruptionReason};
 return{cellID,enabled:true,summary,presentedActual,committedAudit,interruption};
}
export function validateCaptureRequest(presentationTime,epoch,previousTime,time,reason){
 if(!Number.isSafeInteger(epoch)||epoch<0)throw Error('Observation capture requires explicit validated clock epoch');
 if(!Number.isFinite(presentationTime)||presentationTime<previousTime||presentationTime>time)throw Error('Observation capture outside retained source interval');
 if(reason!==undefined&&(typeof reason!=='string'||reason.length<1||reason.length>128||/[\u0000-\u001f\u007f]/u.test(reason)))throw Error('Invalid bounded observation interruption reason');
}
export function ownCaptureEnvelope(value){
 value.serializedBytes=0;
 for(let n=0;n<4;n++){const bytes=new TextEncoder().encode(JSON.stringify(value)).byteLength;if(bytes>MAX_CAPTURE_BYTES)throw Error('Observation capture exceeds256KiB owned serialized limit');if(bytes===value.serializedBytes)return value;value.serializedBytes=bytes;}
 throw Error('Observation capture size failed to settle');
}
