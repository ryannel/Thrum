// Private X-only held-front midpoint query. Full source motion law is unchanged.
import {advancePose,fieldColumns,matrix} from './math.js';
import {regionAdvance} from './weather.js';
const D=.125;
const vector=v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite);
function minX(cx,row,p,metadata){const d=metadata.templates[p.templateID].domain;return cx+[0,1,2].reduce((s,j)=>s+Math.min(row[j]*(d.origin[j]-p.root[j]),row[j]*(d.origin[j]+d.span[j]-p.root[j])),0);}
export function originalMidMinX(p,mid,c,work,R,metadata){
 mid.Qcolumns=p.Qcolumns;
 for(const k of ['C','u','K'])for(let i=0;i<3;i++)mid[k][i]=p[k][i];
 mid.role=p.role;mid.s=p.s;mid.b=p.b;advancePose(mid,c,D,work.halfIg);mid.g=work.halfG;mid.b=p.s*mid.g;
 if(R){mid.C=regionAdvance(R,c,D);mid.u=[0,0,0];}
 const A=matrix(mid);return minX(mid.C[0],A[0],p,metadata);
}
export function createHealthCursor(){return{ready:false};}
function eligible(p,mid,c,work,R){
 return ['BODY','BILLOW'].includes(p.role)&&[4,5,6].includes(p.s)&&['C','u','K','root'].every(k=>vector(p[k])&&p[k].every(v=>Math.abs(v)<=1e6))&&Array.isArray(mid.Qcolumns)&&mid.Qcolumns.length===3&&mid.Qcolumns.every(vector)&&['meanX','meanZ','shearX','shearZ','uplift'].every(k=>Number.isFinite(c[k])&&Math.abs(c[k])<=1e6)&&Number.isFinite(work.halfIg)&&Number.isFinite(work.halfG)&&Math.abs(work.halfIg)<=1e6&&Math.abs(work.halfG)<=1e6&&(!R||(vector(R)&&R.every(v=>Math.abs(v)<=1e6)));
}
export function healthMidMinX(p,mid,c,work,R,metadata,cursor){
 if(p.Qcolumns!==mid.Qcolumns||!eligible(p,mid,c,work,R))return originalMidMinX(p,mid,c,work,R,metadata);
 if(cursor.ready&&(cursor.Q!==mid.Qcolumns||mid.Qcolumns.some((col,j)=>cursor.rows[j]!==col||col.some((v,i)=>!Object.is(v,cursor.values[j][i])))))return originalMidMinX(p,mid,c,work,R,metadata);
 const e=Math.exp(-D/10),target=p.role==='BODY'?0:c.uplift,uy=p.u[1],intY=p.C[1]*D+.5*target*D*D+10*(uy-target)*(D-10*(1-e));
 let cx=p.C[0]+(c.meanX*D+c.shearX*(intY-1500*D)+10*p.u[0]*(1-e));
 const kx=p.K[0]+(c.shearX*p.s*work.halfIg),b=p.s*work.halfG;
 if(R)cx=regionAdvance(R,c,D)[0];
 // Exact original fieldColumns result, lazily at the original matrix point.
 if(!cursor.ready){const dual=fieldColumns(mid.Qcolumns);cursor.Q=mid.Qcolumns;cursor.rows=[...mid.Qcolumns];cursor.values=mid.Qcolumns.map(c=>[...c]);cursor.dual=dual;cursor.ready=true;}
 const row=[0,1,2].map(j=>b*cursor.dual[j][0]+kx*cursor.dual[j][1]);
 return minX(cx,row,p,metadata);
}
