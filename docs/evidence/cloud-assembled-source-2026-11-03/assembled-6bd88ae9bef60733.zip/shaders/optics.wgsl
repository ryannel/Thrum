struct Params  {
  camera:vec4f, focus:vec4f, sun:vec4f, bmin:vec4f, bmax:vec4f, weather:vec4f, control:vec4f, front:vec4f, image:vec4f, domain:vec4f, lifecycle:vec4f, receiver:vec4f, lightBmin:vec4f, lightBmax:vec4f
}
;
@group(0) @binding(0) var<uniform> p:Params;
@group(0) @binding(1) var densityTex:texture_3d<f32>;
@group(0) @binding(2) var basis:texture_3d<f32>;
@group(0) @binding(3) var linearClamp:sampler;
@group(0) @binding(4) var restTex:texture_3d<f32>;
@group(0) @binding(5) var voxelLight:texture_3d<f32>;
@group(0) @binding(27) var voxelLightB:texture_3d<f32>;
@group(0) @binding(7) var airTrans:texture_2d<f32>;
@group(0) @binding(10) var previousQ:texture_3d<f32>;
@group(0) @binding(11) var previousRest:texture_3d<f32>;
@group(0) @binding(13) var receiverMap:texture_2d<f32>;
@group(0) @binding(14) var linearRepeat:sampler;
@group(0) @binding(16) var restB:texture_3d<f32>;
@group(0) @binding(17) var previousRestB:texture_3d<f32>;
const PI:f32=3.141592653589793;
fn rayBox(o:vec3f,d:vec3f,lo:vec3f,hi:vec3f)->vec2f {
  var start=-1e30;var end=1e30;
  for(var k=0u;k<3u;k++){
    if(abs(d[k])<1e-7){if(o[k]<lo[k]||o[k]>hi[k]){return vec2f(1.,-1.);}}
    else {let a=(lo[k]-o[k])/d[k];let b=(hi[k]-o[k])/d[k];start=max(start,min(a,b));end=min(end,max(a,b));}
  }return vec2f(start,end);
}
fn uvw(x:vec3f)->vec3f {
  return(x-p.bmin.xyz)/(p.bmax.xyz-p.bmin.xyz);
}
// Held static component query. Two local R16F template pairs serve sixteen poses in two independent formations.
@group(0) @binding(18) var bodyDistance:texture_3d<f32>;
@group(0) @binding(19) var crownBDensity:texture_3d<f32>;
@group(0) @binding(20) var crownBDistance:texture_3d<f32>;
struct HeldPart {
  C_b:vec4f, Q0_A:vec4f, Q1_asset:vec4f, Q2_active:vec4f,
  K_rootX:vec4f, rootYZ:vec4f
};
struct AssetDomain { origin_pitch:vec4f, span:vec4f };
@group(0) @binding(21) var<storage,read> heldParts:array<HeldPart,16>;
@group(0) @binding(22) var<storage,read> assetDomains:array<AssetDomain,2>;
@group(0) @binding(23) var<storage,read> cohortExposure:array<f32>;
fn exposureValue(slot:u32,i:vec3u)->f32 {
  let index=slot*4913u+(i.z*17u+i.y)*17u+i.x;
  return mix(cohortExposure[index],cohortExposure[78608u+index],p.lifecycle.y);
}
fn materialExposure(slot:u32,a:vec3f,domain:AssetDomain)->f32 {
  let grid=clamp((a-domain.origin_pitch.xyz)/domain.span.xyz*16.,vec3f(0),vec3f(16));
  let lo=min(vec3u(floor(grid)),vec3u(15));let f=grid-vec3f(lo);
  let z0=mix(mix(exposureValue(slot,lo),exposureValue(slot,lo+vec3u(1,0,0)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,0)),exposureValue(slot,lo+vec3u(1,1,0)),f.x),f.y);
  let z1=mix(mix(exposureValue(slot,lo+vec3u(0,0,1)),exposureValue(slot,lo+vec3u(1,0,1)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,1)),exposureValue(slot,lo+vec3u(1,1,1)),f.x),f.y);
  return mix(z0,z1,f.z);
}
fn partDensity(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(densityTex,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDensity,linearClamp,uv,0.).x;
}
fn partDistance(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(bodyDistance,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDistance,linearClamp,uv,0.).x;
}
fn formationQuery(group:u32,x:vec3f,raw:bool)->f32 {
  var q=0.;
  for(var i=0u;i<8u;i++) {
    let s=heldParts[group*8u+i];
    if(s.Q2_active.w<.5||s.Q0_A.w<=0.||s.C_b.w<=0.){continue;}
    let h=(x.y-s.C_b.y)/s.C_b.w;
    let v=(x-s.C_b.xyz-s.K_rootX.xyz*h)/s.C_b.w;
    let a=vec3f(dot(s.Q0_A.xyz,v),dot(s.Q1_asset.xyz,v),dot(s.Q2_active.xyz,v))
      +vec3f(s.K_rootX.w,s.rootYZ.x,s.rootYZ.y);
    let index=u32(s.Q1_asset.w);
    if(index>=2u){continue;}
    let domain=assetDomains[index];
    let uv=(a-domain.origin_pitch.xyz)/domain.span.xyz;
    if(any(uv<vec3f(0.))||any(uv>vec3f(1.))){continue;}
    let rho=partDensity(index,uv);
    var mask=1.;
    if(!raw){
      let material=.3+.7*clamp(textureSampleLevel(basis,linearClamp,clamp(a/512.,vec3f(0),vec3f(1)),0.).x,0.,1.);
      let loss=s.rootYZ.z+materialExposure(u32(s.rootYZ.w),a,domain);
      mask=smoothstep(-8.,8.,partDistance(index,uv)-material*loss);
    }
    q=max(q,s.Q0_A.w*rho*mask);
  }
  return q;
}
fn componentQuery(x:vec3f,raw:bool)->f32 {
  var q=0.;for(var g=0u;g<2u;g++){if((u32(p.lifecycle.w)&(1u<<g))!=0u){q+=formationQuery(g,x,raw);}}return q;
}
fn rawQ(x:vec3f)->vec4f {return vec4f(componentQuery(x,true),0.,0.,0.);}
fn coefficients(x:vec3f,detail:f32)->vec2f {
  if(p.domain.w>.5){return vec2f(0.);}
  return vec2f(componentQuery(x,false)*p.bmin.w,0.);
}

struct SourceGroup { lo:vec4f, hi:vec4f };
@group(0) @binding(24) var<storage,read> sourceGroups:array<SourceGroup,2>;
struct Intervals { spans:array<vec2f,2>, count:u32 };
fn sourceIntervals(o:vec3f,d:vec3f,terminal:f32)->Intervals {
  var r:Intervals;r.count=0u;
  for(var g=0u;g<2u;g++){
    if(sourceGroups[g].lo.w<.5||(u32(p.lifecycle.w)&(1u<<g))==0u){continue;}
    let iv=rayBox(o,d,sourceGroups[g].lo.xyz,sourceGroups[g].hi.xyz);
    let a=max(0.,iv.x);let b=min(terminal,iv.y);if(b>a){r.spans[r.count]=vec2f(a,b);r.count++;}
  }
  if(r.count==2u){
    if(r.spans[1].x<r.spans[0].x){let tmp=r.spans[0];r.spans[0]=r.spans[1];r.spans[1]=tmp;}
    if(r.spans[1].x<=r.spans[0].y){r.spans[0].y=max(r.spans[0].y,r.spans[1].y);r.count=1u;}
  }return r;
}

fn tauRay(x:vec3f,d:vec3f,count:u32,detail:f32)->f32 {
  let iv=sourceIntervals(x,d,1e8);var tau=0.;
  for(var k=0u;k<iv.count;k++){let span=iv.spans[k];let ds=(span.y-span.x)/f32(count);
    for(var j=0u;j<count;j++){let c=coefficients(x+d*(span.x+(f32(j)+.5)*ds),detail);tau+=(c.x+c.y)*ds;}
  }return tau;
}
// Independent thin-plane attenuation provider. There is no density field in this profile.
fn analyticShadowT(x:vec3f)->f32 {
  if(x.y>=2200.){return 1.;}
  let caster=x+p.sun.xyz*((2200.-x.y)/max(p.sun.y,.03));
  let wave=.55+.35*sin((caster.x-p.weather.w)*.0012)*cos(caster.z*.001);
  let front=1.-.85*smoothstep(p.front.x-400.,p.front.x+400.,caster.x);
  let amount=max(0.,wave)*p.control.x*(1.-p.control.y)*front;
  return exp(-amount*1.8);
}
fn directT(x:vec3f)->vec2f {
  if(p.domain.w>1.5){return vec2f(1);}
  if(p.domain.w>.5){let t=analyticShadowT(x);return vec2f(t,pow(t,p.domain.y));}
  let tau=tauRay(x,p.sun.xyz,32u,1.);
  return exp(-vec2f(tau,tau*p.domain.y));
}
// A chart contributes only when every interpolation corner exists. A one-voxel
// smooth collar blends to the other chart or COMPLETE current-source fallback.
fn chartWeight(x:vec3f,lo:vec3f,hi:vec3f)->f32 {
  let pitch=(hi-lo)/vec3f(32.,24.,24.);
  let edge=min(x-(lo+.5*pitch),hi-.5*pitch-x);
  let w=smoothstep(vec3f(0),pitch,edge);return w.x*w.y*w.z;
}
fn lightWeights(x:vec3f)->vec3f {
  let a=chartWeight(x,p.bmin.xyz,p.bmax.xyz);let b=chartWeight(x,p.lightBmin.xyz,p.lightBmax.xyz);let sum=a+b;
  if(sum>=1.){return vec3f(a/sum,b/sum,0.);}return vec3f(a,b,1.-sum);
}
fn cacheT(x:vec3f)->vec2f {
  if(p.domain.w>.5){return directT(x);}
  let w=lightWeights(x);var t=vec2f(0.);
  if(w.x>0.){t+=w.x*textureSampleLevel(voxelLight,linearClamp,uvw(x),0.).xy;}
  if(w.y>0.){let uv=(x-p.lightBmin.xyz)/(p.lightBmax.xyz-p.lightBmin.xyz);t+=w.y*textureSampleLevel(voxelLightB,linearClamp,uv,0.).xy;}
  if(w.z>0.){t+=w.z*directT(x);}return t;
}
fn cloudSun(x:vec3f)->vec2f {
  var tau=0.;
  let ds=100.;
  for(var i=0u;i<2u;i++) {
    let c=coefficients(x+p.sun.xyz*((f32(i)+.5)*ds),1.);
    tau+=(c.x+c.y)*ds;
  }
  return exp(-vec2f(tau,p.domain.y*tau))*cacheT(x+p.sun.xyz*200.);
}
fn directAmbientA(x:vec3f)->f32 {
  let dirs=array<vec3f,4>(vec3f(.6,.8,0.),vec3f(-.6,.8,0.),vec3f(0.,.8,.6),vec3f(0.,.8,-.6));
  var a=0.;for(var j=0u;j<4u;j++){a+=exp(-tauRay(x,dirs[j],20u,1.));}return a*.25;
}
fn ambientA(x:vec3f)->f32 {
  let w=lightWeights(x);var a=0.;
  if(w.x>0.){a+=w.x*textureSampleLevel(voxelLight,linearClamp,uvw(x),0.).z;}
  if(w.y>0.){let uv=(x-p.lightBmin.xyz)/(p.lightBmax.xyz-p.lightBmin.xyz);a+=w.y*textureSampleLevel(voxelLightB,linearClamp,uv,0.).z;}
  if(w.z>0.){a+=w.z*directAmbientA(x);}return a;
}
fn hg(g:f32,mu:f32)->f32 {
  return(1.-g*g)/(4.*PI*pow(max(1.+g*g-2.*g*mu,.001),1.5));
}
fn phase(mu:f32,ice:f32,factor:f32)->f32 {
  let a=mix(.8,.85,ice)*factor;
  let b=mix(-.2,-.15,ice)*factor;
  let w=mix(.8,.85,ice);
  return w*hg(a,mu)+(1.-w)*hg(b,mu);
}
fn airAt(x:vec3f)->mat3x3f {
  let h=max(x.y,0.);
  let ray=exp(-h/8000.)*vec3f(5.802e-6,13.558e-6,33.1e-6);
  let mie=vec3f(4e-6*exp(-h/1200.));
  let ozone=vec3f(.65e-6,1.881e-6,.085e-6)*max(0.,1.-abs(h-25000.)/15000.);
  return mat3x3f(ray+mie+ozone,ray,mie*.9);
}
fn atmosphereExit(x:vec3f,d:vec3f)->f32 {
  let o=x+vec3f(0,6371000.,0);
  let b=dot(o,d);
  let c=dot(o,o)-6471000.*6471000.;
  return max(0.,-b+sqrt(max(b*b-c,0.)));
}
fn airRayT(x:vec3f,dir:vec3f)->vec3f {
  let o=x+vec3f(0,6371000.,0);
  let dotSun=dot(o,dir);
  if(dotSun<0.) {
    if(dotSun*dotSun-dot(o,o)+6371000.*6371000.>0.) {
      return vec3f(0);
    }
  }
  let total=atmosphereExit(x,dir);
  var tau=vec3f(0);
  for(var i=0u;i<48u;i++) {
    let t0=pow(f32(i)/48.,2.)*total;
    let t1=pow(f32(i+1u)/48.,2.)*total;
    let point=x+dir*((t0+t1)*.5);
    let h=length(point+vec3f(0,6371000.,0))-6371000.;
    tau+=airAt(vec3f(0,h,0))[0]*(t1-t0);
  }
  return exp(-tau);
}
fn airSun(x:vec3f)->vec3f {
  let o=x+vec3f(0,6371000.,0);
  let h=max(length(o)-6371000.,0.);
  let mu=dot(normalize(o),p.sun.xyz);
  if(mu<0.) {
    let b=dot(o,p.sun.xyz);
    if(b*b-dot(o,o)+6371000.*6371000.>0.) {
      return vec3f(0);
    }
  }
  let uv=vec2f(mu*.5+.5,sqrt(clamp(h/100000.,0.,1.)));
  return textureSampleLevel(airTrans,linearClamp,uv,0.).rgb;
}
fn solar()->vec3f {
  return vec3f(6.8,6.55,6.3);
}
fn skyMean()->vec3f {
  return vec3f(.42,.49,.58)*(.2+.8*smoothstep(-.08,.4,p.sun.y));
}
