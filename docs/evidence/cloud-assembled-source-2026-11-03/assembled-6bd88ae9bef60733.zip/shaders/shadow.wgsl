@group(0) @binding(12) var receiverOut:texture_storage_2d<rgba16float,write>;
@compute @workgroup_size(8,8) fn main(@builtin(global_invocation_id) id:vec3u) {
  let n=textureDimensions(receiverOut);
  if(any(id.xy>=n)) {
    return;
  }
  let uv=(vec2f(id.xy)+.5)/vec2f(n);
  let x=vec3f(p.receiver.x+(uv.x-.5)*p.receiver.z,2.,p.receiver.y+(uv.y-.5)*p.receiver.w);
  let tau=tauRay(x,p.sun.xyz,64u,1.);
  textureStore(receiverOut,id.xy,vec4f(exp(-tau),tau,0,1));
}
