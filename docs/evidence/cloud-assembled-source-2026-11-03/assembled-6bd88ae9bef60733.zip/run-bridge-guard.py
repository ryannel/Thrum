#!/usr/bin/env python3
import subprocess,sys,time,json,os,pathlib
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];cmd=sys.argv[2:];log=root/'results'/f'{name}.log';receipt=root/'results'/f'{name}.guard.json';peak=0;stopped=None
with log.open('w') as out:
 p=subprocess.Popen(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  rows=subprocess.check_output(['ps','-axo','pid=,ppid=,rss='],text=True).splitlines();data={}
  for row in rows:
   try:pid,ppid,rss=map(int,row.split());data[pid]=(ppid,rss)
   except ValueError:pass
  ids={p.pid,os.getpid()};change=True
  while change:
   before=len(ids);ids.update(pid for pid,(ppid,rss) in data.items() if ppid in ids);change=len(ids)>before
  rss=sum(data[pid][1] for pid in ids if pid in data)*1024;peak=max(peak,rss)
  if rss>=224*1024**2:stopped='early224MiB';os.killpg(p.pid,15);break
  time.sleep(.05)
 code=p.wait()
r={'pass':code==0 and stopped is None,'command':cmd,'exitCode':code,'sampledTreePeakBytes':peak,'earlyBytes':224*1024**2,'hardBytes':256*1024**2,'stopped':stopped,'scope':'Serial functional correctness only; process-tree sampled RSS, not timing admission'};receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));sys.exit(0 if r['pass'] else 1)
