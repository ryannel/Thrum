# Fresh working Cu assembly candidate

**CPU SCREEN PASSED · GPU/ART UNQUALIFIED**. Root commissions this bounded integration, not production/source-art/family/full-sky/provider/device acceptance. The current127/7bf visual reference and all evidence remain unchanged. Root exclusively starts the server/browser/GPU and commissions independent implementation review.

Frozen build `6bd88ae9bef60733`,63served files/15,273,218B. `FREEZE.json` SHA `36519dc40b06fa78aaa07b3c435ebcc584449af4c81d93a143c3fe40c03764d1`. Assembly SHA `83465b4ae18a0a5a83440ca97eeea6a368aa877542f4ab356348ed74952f4108`. Exact selected source marker `91b967209009f0a19b4f25380d437f2c4c9f48b426c9655b5027721c504339a1`,16source files via COPYMAP `ca0cd4f73b25b708098e5c277351fc3552f0a71929ea55743e04bf18e9dde546`.

Natural index: `8744bca32b981b2e654f14b991bfe0c12f6504cb519cd1eaaf61f81af186ecf7`.

Before selection, all30weather-zero package manifest files/170archive members, all16source pins/COPYMAP and61baseline7bf served hashes were checked. `INPUT-INTEGRITY.json` retains receipts. Source was extracted from the verified retained archive, not inferred from an unpinned live tree. Source provenanceJSON and newweather-zero.js are both served and hashed. All WGSL and all render JS/Scene are byte-identical7bf; native source/noise/admission/spec/fixtures/rates/clock/optical coefficients unchanged. Only source forecast-work optimization and execution authorization/classification change. No extra air/fog/environment feature.

Both original/supplementary4ms NodeCPU protocols passed on their first retained runs, maximum two-dry3.979667ms leaving20.333µs. Exact current receipts and COPYMAP are independently verified before source construction/GPU allocation. Failed cost, mismatched source/native/policy/COPYMAP/handoff/hash or missing root-source selection rejects; “production” execution rejects. Source `independentReviewClosed` means the exact CPUsource review, not an assembled/GPU/art review. Receipt/title/status say CPU SCREEN PASSED · GPU/ART UNQUALIFIED; no Production approval label. Prior127 reference remains explicitly COST FAIL.

## Root launch and matched inspection

From this directory, when ready:

```sh
python3 serve.py --port 8163
```

Open `http://127.0.0.1:8163/` (redirects to the frozen build URL). Author started no server/GPU/browser/timing. Current8162reference remains untouched. Root can run the real HTTP source closure check after launch:

```sh
python3 tests/bridge/http-approved-source.py --base http://127.0.0.1:8163/
```

Default paused100s, observed Cu, wet-held/no queued front, separated pair8km. Match7bf source100 with the same camera/Sun30°/azimuth−.7/lighting/rays/options; single-A fixture2km is explicit. Remote opens120s/Sun5°/.5; main-hidden retains source/receiver/light/mirror demand. B mask is diagnostic omission, not natural retirement. Policy/fixture/forcing changes are fresh-only; old epoch actual interruption journal is captured before discard. Source controls synchronize at explicit lifecycle boundaries; ordinary editable drafts are not overwritten every frame.

Recording windows unchanged: first130→22090s1×; renewal320→430110s1×; dry500→59090s1× requires programme; full0→1200at16×75s with explicit regionfollow. Native ordinary/accelerated observations and sampled-frame/art acceptance remain separate. Requesting16× does not drop source steps or promise delivered frame rate. Live shared wind150/front500 is explicitly selected; wet-held schedules neither front nor drying.

## Verification and limits

Scoped serial checks PASS: bridge7, additional changed approval2, world12/native6/source8/render16. Same224MiBearly/256MiBhard guards; max sampled process-tree196,444,160B. `results/matched100.json`: exact source state/pose/control byte/native-input equality against preserved127 at100s for the pair wet-held fixture; this is CPU only. `results/actual-reference.json`: actual415summary/presented-detail split, borrowed expiry/owned survival, epoch interruption/reset/seek, currentcoverage. `results/provenance-payload.json`: all16approved source files are in63-file server payload with exact bytes/hashes. Actual HTTP/GPU compile/render/images are unrun by author. Source package's full weather-zero/f57/cost evidence remains external and immutable; no cost rerun.

Initial harness launch had unresolved-relative reference path and missing fresh results directory before tests could run; retained under results/adverse. Corrected test harness paths only; no source, thresholds or cadence changed.

Shared native corpus14,352,384B+noise65,536B; CPU/GPU input arrays shared across both source cells. No extra per-cell raw field. Existing GPU controls628,864B,poses1536B,groups/domains128B,lights294,912B,receiver131,072B,air131,072B,view7,372,800B, plus bounded uniforms/timing/staging and unmeasured driver/heap/captures. Profile10,080scalarB+references/objects; Node cost includes first cold observed call. Logical allocations are not OSphysical residency or whole GPU costs.

Cache accuracy, historical Metal failures/qualification, full Hillaire air/jointfog/BSM/environment/P4a, anatomy/renewal/breakup, source variation/Cb/fullsky and device/5ms admission remain open. Source optimization does not repair or promote artwork. Failure journal/partial recording/counter qualification semantics remain7bf.
