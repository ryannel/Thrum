// CPU evidence path: never waits for GPU health/settlement.
const message=e=>String(e?.message??e);
const safe=fn=>{try{return structuredClone(fn());}catch(e){return{unavailable:message(e)};}};
export function failureSnapshot(error,{identity,observation,fixtureRevision,clockSnapshot,lastSubmitted,lastCompleted,recordingStart,hostSnapshot,gpuErrors}){
 return Object.freeze({status:'FAILED',originalError:{message:message(error),stack:String(error?.stack??'')},identity:safe(()=>identity),observation,fixtureRevision,detectedPerformanceMs:performance.now(),source:safe(clockSnapshot),lastSubmitted:safe(()=>lastSubmitted),lastCompleted:safe(()=>lastCompleted),recordingStart:safe(()=>recordingStart),host:safe(hostSnapshot),gpuErrors:safe(()=>gpuErrors),scope:'Detected failure only; last submitted and completed are distinct. No GPU drain or fabricated completed frame. A fence with no loss/error/rejection event remains an observability gap.'});
}
export async function postFailure(record,post=fetch){const response=await post('/receipt',{method:'POST',body:JSON.stringify(record)});if(!response.ok)throw Error('Failure receipt save '+response.status);}
export async function settleRecording(isFatal,drain){if(isFatal())return{gpuSettled:false,reason:'fatal: GPU drain not attempted'};try{await drain();}catch(e){if(!isFatal())throw e;return{gpuSettled:false,reason:'fatal during drain: '+message(e)};}return isFatal()?{gpuSettled:false,reason:'fatal after drain'}:{gpuSettled:true,reason:null};}

