export function completedTraceRow(submitted,completedPerformanceMs){
  return {submitted:submitted.submissionPerformanceMs,completed:completedPerformanceMs,sourceTime:submitted.source.sourceTime,requestedTime:submitted.source.requestedTime,committedTime:submitted.source.committedTime,sourceTick:submitted.source.sourceTick,alpha:submitted.source.alpha,frame:submitted.presentation.frame,fixtureRevision:submitted.fixtureRevision};
}
