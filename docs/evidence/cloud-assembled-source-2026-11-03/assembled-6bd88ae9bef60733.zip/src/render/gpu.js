const textureBytes = { rgba16float: 8, rgba8unorm: 4 };
export class Gpu {
  constructor(device, adapter, context, format, onFailure = () => {}) {
    this.device = device;
    this.adapter = adapter;
    this.context = context;
    this.format = format;
    this.allocations = [];
    this.errors = [];
    this.pending = 0;
    this.completed = 0;
    this.submitted = 0;
    this.epoch = 1;
    device.addEventListener("uncapturederror", (e) => {
      this.errorCount = (this.errorCount ?? 0) + 1;
      if (this.errors.length < 64)
        this.errors.push(e.error.message ?? String(e.error));
      onFailure(e.error ?? Error("Uncaptured GPU error"));
    });
    device.lost.then((v) => {
      this.errors.push("Device lost: " + v.message);
      this.lost = true;
      onFailure(Error("GPU device lost: " + v.message));
    });
  }
  static async open(canvas, onFailure = () => {}) {
    if (!navigator.gpu) throw Error("WebGPU is unavailable in this browser.");
    const adapter = await navigator.gpu.requestAdapter({
      powerPreference: "high-performance",
    });
    if (!adapter) throw Error("No WebGPU adapter");
    const features = adapter.features.has("timestamp-query")
      ? ["timestamp-query"]
      : [];
    const device = await adapter.requestDevice({ requiredFeatures: features });
    const context = canvas.getContext("webgpu");
    const format = navigator.gpu.getPreferredCanvasFormat();
    context.configure({ device, format, alphaMode: "opaque" });
    return new Gpu(device, adapter, context, format, onFailure);
  }
  texture(label, size, format = "rgba16float", extra = 0, mipLevelCount = 1) {
    const tex = this.device.createTexture({
      label,
      size,
      dimension: size.length === 3 ? "3d" : "2d",
      mipLevelCount,
      format,
      usage:
        GPUTextureUsage.TEXTURE_BINDING |
        GPUTextureUsage.STORAGE_BINDING |
        GPUTextureUsage.COPY_SRC |
        GPUTextureUsage.COPY_DST |
        extra,
    });
    this.allocations.push({
      label,
      bytes: Array.from(
        { length: mipLevelCount },
        (_, level) =>
          size.reduce(
            (a, b) => a * Math.max(1, Math.floor(b / 2 ** level)),
            1,
          ) * textureBytes[format],
      ).reduce((a, b) => a + b, 0),
      format,
      size,
    });
    return tex;
  }
  buffer(label, size, usage) {
    const b = this.device.createBuffer({ label, size, usage });
    this.allocations.push({ label, bytes: size });
    return b;
  }
  async module(label, text) {
    const module = this.device.createShaderModule({ label, code: text });
    const info = await module.getCompilationInfo();
    const errors = info.messages.filter((m) => m.type === "error");
    if (errors.length)
      throw Error(
        label +
          ": " +
          errors
            .map((m) => `${m.lineNum}:${m.linePos} ${m.message}`)
            .join("\n"),
      );
    return module;
  }
  async compute(label, code) {
    return this.device.createComputePipelineAsync({
      label,
      layout: "auto",
      compute: { module: await this.module(label, code), entryPoint: "main" },
    });
  }
  async render(label, code, format) {
    const module = await this.module(label, code);
    return this.device.createRenderPipelineAsync({
      label,
      layout: "auto",
      vertex: { module, entryPoint: "vs" },
      fragment: { module, entryPoint: "fs", targets: [{ format }] },
      primitive: { topology: "triangle-list" },
    });
  }
  group(pipeline, entries) {
    return this.device.createBindGroup({
      layout: pipeline.getBindGroupLayout(0),
      entries: entries.map(([binding, value]) => ({
        binding,
        resource: value instanceof GPUBuffer ? { buffer: value } : value,
      })),
    });
  }
  submit(encoder) {
    if (this.pending >= 3) throw Error("In-flight graph capacity exceeded");
    const submittedAt = performance.now();
    this.device.queue.submit([encoder.finish()]);
    this.pending++;
    this.submitted++;
    this.device.queue.onSubmittedWorkDone().then(
      () => {
        this.pending--;
        this.completed++;
        this.lastCompletionLatencyMs = performance.now() - submittedAt;
      },
      (e) => {
        this.pending--;
        this.errors.push(String(e));
      },
    );
  }
  get bytes() {
    return this.allocations.reduce((a, b) => a + b.bytes, 0);
  }
}
// Actual counters must respect resource dependencies, regardless of descriptor placement.
// Receiver and light may overlap each other; view consumes both, display consumes view.
export function decodeOpticalTimestamps(q){
 const names=q.length===8?['receiverMs','lightMs','viewMs','displayMs']:['receiverMs','lightAMs','lightBMs','viewMs','displayMs'],rejectionReasons=[];
 if(q.length!==8&&q.length!==10)rejectionReasons.push('Expected eight historical or ten two-chart timestamp counters');
 else{
  for(let i=0;i<names.length;i++)if(q[2*i+1]<=q[2*i])rejectionReasons.push(names[i]+': nonpositive within-pass interval');
  const edges=q.length===8?[[4,1,'view begins before required receiver end'],[4,3,'view begins before required light end'],[6,5,'display begins before required view end']]:[[6,1,'view begins before required receiver end'],[6,3,'view begins before required lightA end'],[6,5,'view begins before required lightB end'],[8,7,'display begins before required view end']];
  for(const[start,end,label]of edges)if(q[start]<q[end])rejectionReasons.push(label);
 }
 const accepted=rejectionReasons.length===0,result={validPairs:accepted,dependencyOrderValid:accepted,rejectionReasons,wholeMs:null,timingScope:accepted?'Positive within-pass counters satisfy required receiver/light→view→display dependencies; independent compute may overlap; whole graph unqualified.':'Unqualified timestamp generation: positive pairs alone cannot establish pass durations when required dependencies fail.',rawNanoseconds:Array.from(q,String)};
 for(let i=0;i<names.length;i++)result[names[i]]=accepted?Number(q[i*2+1]-q[i*2])/1e6:null;
 return result;
}
// Three independent readback generations. No cross-pass aggregate is called GPU time.
export class Timings {
 constructor(gpu){this.gpu=gpu;this.supported=gpu.device.features.has('timestamp-query');this.completed=[];this.serial=0;this.latest=null;this.slots=this.supported?Array.from({length:3},(_,i)=>({busy:false,query:gpu.device.createQuerySet({type:'timestamp',count:10}),resolve:gpu.buffer('timestamp resolve '+i,256,GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC),read:gpu.buffer('timestamp read '+i,256,GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST)})):[];}
 begin(meta){const s=this.slots.find(s=>!s.busy);if(!s)return null;s.busy=true;s.generation=++this.serial;s.meta=structuredClone(meta);return s;}
 descriptor(s,pair){return s?{querySet:s.query,beginningOfPassWriteIndex:pair*2,endOfPassWriteIndex:pair*2+1}:undefined;}
 encode(e,s){if(!s)return;e.resolveQuerySet(s.query,0,10,s.resolve,0);e.copyBufferToBuffer(s.resolve,0,s.read,0,80);}
 collect(s){if(!s)return;s.read.mapAsync(GPUMapMode.READ).then(()=>{const q=new BigUint64Array(s.read.getMappedRange().slice(0,80));s.read.unmap();const result={generation:s.generation,...s.meta,...decodeOpticalTimestamps(q)};this.completed.push(Object.freeze(result));if(this.completed.length>16)this.completed.shift();this.latest=result;},error=>{this.completed.push({generation:s.generation,...s.meta,error:String(error),wholeMs:null});if(this.completed.length>16)this.completed.shift();}).finally(()=>s.busy=false);}
 dispose(){for(const s of this.slots){s.query.destroy();s.resolve.destroy();s.read.destroy();}}
}
