// On-demand independent CPU midpoint reference, never ordinary frame work.
import {evaluateWorld} from '../source/world-reference.js';import {rayIntervals} from './world-optics.js';
export const AMBIENT_DIRECTIONS=Object.freeze([[.6,.8,0],[-.6,.8,0],[0,.8,.6],[0,.8,-.6]].map(Object.freeze));
export function lightReference(t,x,sun,assets,noise,{includeB=true}={}){
 const integrate=(dir,count)=>{const intervals=rayIntervals(t,x,dir,1e8,includeB);let tau=0;for(const[a,b]of intervals)for(let i=0;i<count;i++){const p=x.map((v,k)=>Math.fround(v+dir[k]*(a+(i+.5)*(b-a)/count))),q=evaluateWorld(t,p,assets,noise);tau+=.019*(includeB?q.q:q.groups[0].q)*(b-a)/count;}return{tau,intervals};};
 const direct=integrate(sun,32),ambient=AMBIENT_DIRECTIONS.map(dir=>Math.exp(-integrate(dir,20).tau));return{tau:direct.tau,direct:Math.exp(-direct.tau),ambient:ambient.reduce((a,b)=>a+b,0)/4,ambientDirections:ambient,intervals:direct.intervals};
}
export function positiveOffChartWitness(t,assets,noise){for(const p of t.groups[1].parts.filter(p=>p.templateID==='body'&&p.Aseed>0)){const q=evaluateWorld(t,p.C,assets,noise).groups[1].q;if(q>.041)return{available:true,root:[...p.C],qBAtRoot:q,point:[p.C[0]-.75*(p.C[1]-399),399,p.C[2]].map(Math.fround),direction:[.6,.8,0],definition:'Y399 below both charts; +(.6,.8,0) passes through positive BODY Broot'};}return{available:false,reason:'No actual B BODY root with q>.041; meaningful light witness unavailable'};}
