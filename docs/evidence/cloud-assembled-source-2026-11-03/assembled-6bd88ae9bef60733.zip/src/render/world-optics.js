// Optical adapter only; immutable source equations/world/clock remain frozen.
import {packParts as packLocal,packDomains} from './held-oracle.js';
import {assertWorldPublication} from '../source/world.js';
export {packDomains};
export const GROUPS=2,MAX_PARTS=16,GRID_COUNT=4913,PART_FLOATS=24,EXPOSURE_FLOATS=2*MAX_PARTS*GRID_COUNT;
export function packWorldParts(tuple){
 assertWorldPublication(tuple);const out=new Float32Array(MAX_PARTS*PART_FLOATS);
 for(const g of tuple.groups){if(g.groupIndex<0||g.groupIndex>=2)throw Error('Unknown formation');const local=packLocal(g.parts);
  for(let j=0;j<g.parts.length;j++){const part=g.parts[j];if(part.globalSlot!==g.groupIndex*8+part.slot)throw Error('Global control slot mismatch');local[j*24+23]=part.globalSlot;}
  out.set(local,g.groupIndex*8*24);
 }return out;
}
export function packGroupBounds(tuple){assertWorldPublication(tuple);const out=new Float32Array(16);for(const g of tuple.groups){out.set([...g.bounds[0],g.parts.some(p=>p.Aseed>0)?1:0],g.groupIndex*8);out.set([...g.bounds[1],0],g.groupIndex*8+4);}return out;}
// Exact CPU interval counterpart; slab-parallel rays must not invent a hit.
export function rayIntervals(tuple,o,d,terminal=Infinity,includeB=true){
 assertWorldPublication(tuple);const spans=[];
 for(const g of tuple.groups){if(!includeB&&g.groupIndex===1||!g.parts.some(p=>p.Aseed>0))continue;let a=0,b=terminal;for(let k=0;k<3;k++){if(Math.abs(d[k])<1e-7){if(o[k]<g.bounds[0][k]||o[k]>g.bounds[1][k]){b=-1;break;}}else{const x=(g.bounds[0][k]-o[k])/d[k],y=(g.bounds[1][k]-o[k])/d[k];a=Math.max(a,Math.min(x,y));b=Math.min(b,Math.max(x,y));}}if(b>a)spans.push([a,b]);}
 spans.sort((a,b)=>a[0]-b[0]);if(spans.length===2&&spans[1][0]<=spans[0][1])return[[spans[0][0],Math.max(spans[0][1],spans[1][1])]];return spans;
}
export function summary(tuple){assertWorldPublication(tuple);return Object.freeze({sourceTime:tuple.time,sourceTick:tuple.sourceTick,previousTime:tuple.previousTime,committedTime:tuple.committedTime,requestedTime:tuple.requestedTime,alpha:tuple.alpha,epoch:tuple.epoch,forcingRevision:tuple.forcingRevision,controls:tuple.controls,formationRanges:tuple.formationRanges,groups:tuple.groups.map(g=>({cellID:g.cellID,groupIndex:g.groupIndex,bounds:g.bounds,region:g.region,parts:g.parts,exposureRevision:g.exposureRevision,stats:g.stats,statsTime:g.statsTime??tuple.committedTime,statsScope:'Committed source counters; observer outcomes use causal growthPolicy publication',growthPolicy:g.growthPolicy??null,eventCount:g.eventCount,overwrittenEvents:g.overwrittenEvents})),exposureOwnership:'GPU writes copied synchronously; no borrowed CPU arrays retained across await'});}
