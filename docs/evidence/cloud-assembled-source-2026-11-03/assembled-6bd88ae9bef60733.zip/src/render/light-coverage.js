import {assertWorldPublication} from '../source/world.js';
export const LIGHT_DIMS=Object.freeze([32,24,24]),LIGHT_SPAN=Object.freeze([4000,2600,4000]);
export const LIGHT_PITCH=Object.freeze(LIGHT_SPAN.map((v,k)=>v/LIGHT_DIMS[k]));
export function coveredCharts(tuple){assertWorldPublication(tuple);return tuple.groups.map(g=>{const centre=[0,1,2].map(k=>(g.bounds[0][k]+g.bounds[1][k])*.5),lo=[Math.round(centre[0]/LIGHT_PITCH[0])*LIGHT_PITCH[0]-2000,400,Math.round(centre[2]/LIGHT_PITCH[2])*LIGHT_PITCH[2]-2000],hi=lo.map((v,k)=>v+LIGHT_SPAN[k]);const bounds=[lo.map(Math.fround),hi.map(Math.fround)],fullWeightSourceCoverage=g.bounds[0].every((v,k)=>v>=bounds[0][k]+1.5*LIGHT_PITCH[k]&&g.bounds[1][k]<=bounds[1][k]-1.5*LIGHT_PITCH[k]);return Object.freeze({cellID:g.cellID,bounds:Object.freeze(bounds.map(Object.freeze)),fullWeightSourceCoverage,spacing:LIGHT_PITCH});});}
const smooth=x=>{const u=Math.max(0,Math.min(1,x));return u*u*(3-2*u);};
export function chartWeight(bounds,x){return x.reduce((w,v,k)=>{const pitch=(bounds[1][k]-bounds[0][k])/LIGHT_DIMS[k],edge=Math.min(v-(bounds[0][k]+.5*pitch),bounds[1][k]-.5*pitch-v);return w*smooth(edge/pitch);},1);}
export function lightWeights(charts,x){let a=chartWeight(charts[0].bounds,x),b=chartWeight(charts[1].bounds,x),sum=a+b;if(sum>=1){a/=sum;b/=sum;return[a,b,0];}return[a,b,1-sum];}
