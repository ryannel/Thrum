import {assetIds} from './held-oracle.js';
export const sha=async bytes=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),v=>v.toString(16).padStart(2,'0')).join('');
async function read(file,pin){
  if(!pin?.sha256||!Number.isInteger(pin.bytes))throw Error('Missing input pin '+file);
  const r=await fetch('assets/'+file);if(!r.ok)throw Error('Missing input '+file+' '+r.status);
  const bytes=await r.arrayBuffer();
  if(bytes.byteLength!==pin.bytes||await sha(bytes)!==pin.sha256)throw Error('Input hash/byte mismatch '+file);
  return bytes;
}
export async function loadRenderAssets(progress=()=>{}){
  progress('Verifying frozen native templates and material field…');
  const r=await fetch('assets/input-index.json');if(!r.ok)throw Error('Missing integrated input index');
  const indexBytes=await r.arrayBuffer(),index=JSON.parse(new TextDecoder().decode(indexBytes));
  if(index.version!==1||Object.keys(index.templates??{}).sort().join(',')!=='body,crown-b'||index.rendering?.kappa_per_world_m!==.019||index.rendering?.additional_scattering_abc?.join(',')!=='0.5,0.5,0.5')throw Error('Integrated render input contract mismatch');
  const frozen=await read('templates/original-FROZEN-INPUTS.json',{sha256:index.source_geometry_frozen_inputs_sha256,bytes:index.source_geometry_frozen_inputs_bytes});
  const sourcePins=JSON.parse(new TextDecoder().decode(frozen));
  const assets={};
  for(const id of assetIds){
    const entry=index.templates[id],raw=await read(entry.metadata.file,entry.metadata),m=JSON.parse(new TextDecoder().decode(raw));
    const original=await read(entry.original_metadata.file,entry.original_metadata);
    if(sourcePins.files[id+'.json']?.sha256!==await sha(original))throw Error('Original metadata source pin mismatch '+id);
    if(m.reference?.definition?.includes('worldw32')||!m.reference?.definition?.includes('worldw=8*b'))throw Error('Uncorrected local taper annotation '+id);
    const dims=m.dimensions_xyz,origin=m.domain_origin_global_xyz_local_m,span=m.domain_span_local_m,pitch=m.pitch_local_m;
    if(!Array.isArray(dims)||!Array.isArray(origin)||!Array.isArray(span)||dims.length!==3||origin.length!==3||span.length!==3||!Number.isFinite(pitch)||!Number.isFinite(m.reference?.reference_integral_local_m3))throw Error('Missing local asset domain '+id);
    for(let i=0;i<3;i++)if(Math.abs(span[i]-dims[i]*pitch)>1e-5)throw Error('Inconsistent local asset pitch '+id);
    if(!String(m.distance?.definition).startsWith('EDT(rho>='))throw Error('Unqualified SDF sign '+id);
    const a={id,origin,span,pitch,dims,manifest:m,metadataSha256:entry.metadata.sha256};
    for(const kind of ['density','distance']){
      const pin=entry[kind];if(pin.sha256!==m[kind]?.sha256||pin.bytes!==m[kind]?.bytes||sourcePins.files[m[kind].file]?.sha256!==pin.sha256)throw Error('Native source pin mismatch '+id+'/'+kind);
      const bytes=await read(pin.file,pin);if(bytes.byteLength!==dims.reduce((x,y)=>x*y,1)*2)throw Error('R16 dimensions mismatch '+id+'/'+kind);
      a[kind]=new Uint16Array(bytes);
    }
    assets[id]=a;
  }
  const noiseInfo=index.noise,noiseMeta=JSON.parse(new TextDecoder().decode(await read(noiseInfo.metadata.file,noiseInfo.metadata)));
  if(noiseMeta.sha256!==noiseInfo.sha256||noiseInfo.bytes!==65536||noiseInfo.dimensions_xyz.join(',')!=='32,32,32')throw Error('Material noise pin mismatch');
  const noise=new Uint16Array(await read(noiseInfo.file,noiseInfo));
  const admissionMetadata=JSON.parse(new TextDecoder().decode(await read(index.admission.file,index.admission)));
  return {index,assets,noise,admissionMetadata,indexSha256:await sha(indexBytes),frozenSha256:index.source_geometry_frozen_inputs_sha256};
}
export function uploadHalf3d(gpu,label,dims,data){
  const row=dims[0]*2,stride=Math.ceil(row/256)*256,src=new Uint8Array(data.buffer,data.byteOffset,data.byteLength),padded=new Uint8Array(stride*dims[1]*dims[2]);
  for(let z=0;z<dims[2];z++)for(let y=0;y<dims[1];y++){const offset=(z*dims[1]+y)*row;padded.set(src.subarray(offset,offset+row),(z*dims[1]+y)*stride);}
  const tex=gpu.device.createTexture({label,size:dims,dimension:'3d',format:'r16float',usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST});
  gpu.device.queue.writeTexture({texture:tex},padded,{bytesPerRow:stride,rowsPerImage:dims[1]},dims);
  gpu.allocations.push({label,bytes:data.byteLength,format:'r16float',size:dims,role:'Frozen shared native source input'});
  return tex;
}
