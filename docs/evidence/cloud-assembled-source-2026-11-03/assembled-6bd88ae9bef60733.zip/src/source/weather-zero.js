// Sufficient held-control weather emptiness, local to one owned synchronous forecast.
import {fieldColumns} from './math.js';
import {windAt,ROOT_Y} from './weather.js';
export const WEATHER_RESERVE=1;
const H=.25,D=.125,G=1+1024*Number.EPSILON,K_PAD=1e-8,Y_PAD=1e-3,V_PAD=1e-6;
const vec=(v,bound)=>Array.isArray(v)&&v.length===3&&v.every(x=>Number.isFinite(x)&&Math.abs(x)<=bound);
const controlKeys=['meanX','meanZ','shearX','shearZ','uplift','moist','lift','frontX','frontStart','frontSpeed','frontWidth','dryGain'];
function controlsValid(c){return c&&controlKeys.every(k=>k==='moist'||k==='lift'?typeof c[k]==='boolean':Number.isFinite(c[k]))&&Math.hypot(c.meanX,c.meanZ)<=12+1e-12&&Math.hypot(c.shearX,c.shearZ)<=.002+1e-12&&c.uplift>=0&&c.uplift<=.3&&c.frontX>=-8000&&c.frontX<=8000&&c.frontStart>=0&&c.frontStart<=3600&&c.frontSpeed>=0&&c.frontSpeed<=80&&c.frontWidth>=800&&c.frontWidth<=16000&&c.dryGain>=0&&c.dryGain<=1;}
function edge(c,t){return c.frontX+c.frontSpeed*(t-c.frontStart)+c.frontWidth/2;}
function coefficientCheck(){for(const h of[H,D]){const e=Math.exp(-h/10),a=10*(1-e),A=h-a;if(!(e>=1-h/10&&e<=1-h/10+h*h/200&&a>=0&&a<=h&&10*A>=0&&10*A<=.5*h*h))return false;}return true;}
function signature(p,c,domain,now,remaining,R){return{pose:{role:p.role,templateID:p.templateID,s:p.s,b:p.b,g:p.g,mu:p.mu,tau:p.tau,C:[...p.C],u:[...p.u],K:[...p.K],root:[...p.root],Qcolumns:p.Qcolumns.map(v=>[...v])},controls:Object.fromEntries(controlKeys.map(k=>[k,c[k]])),domain:{origin:[...domain.origin],span:[...domain.span]},now,remaining,region:R?[...R]:null};}
function equal(a,b){if(typeof a!=='object'||a===null)return Object.is(a,b);if(typeof b!=='object'||b===null)return false;const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>equal(a[k],b[k]));}
// Validation for activation/reuse tests; not a per-point check in the owned forecast loop.
export function matchesClearInputs(proof,p,c,domain,now,remaining,R){try{return equal(proof.signature,signature(p,c,domain,now,remaining,R));}catch{return false;}}
export function proveClearWeather(p,c,domain,now,remaining,R=null){
 try{
  if(!['BODY','BILLOW'].includes(p.role)||![4,5,6].includes(p.s)||!vec(p.C,1e6)||!vec(p.u,100)||!vec(p.K,100)||!vec(p.root,4096)||!controlsValid(c)||!domain||!vec(domain.origin,4096)||!vec(domain.span,8192)||domain.span.some(v=>v<1)||!Number.isFinite(now)||now<0||!Number.isInteger(now*4)||!Number.isFinite(remaining)||remaining<=0||remaining>45||!Number.isInteger(remaining*4)||now+remaining+D>4096||!Number.isFinite(p.mu)||p.mu<0||p.mu>1||!Number.isFinite(p.tau)||p.tau<0||p.tau>4096||!Number.isFinite(p.b)||p.b<0||p.b>p.s*G)return null;
  const hi=domain.origin.map((v,i)=>v+domain.span[i]);if(!vec(hi,4096))return null;
  if(R&&(!vec(R,1e6)||p.role!=='BODY'||p.C.some((v,i)=>!Object.is(v,R[i]))||p.u.some(v=>v!==0)))return null;
  const F=edge(c,now),Fend=edge(c,now+remaining+D);if(!Number.isFinite(F)||!Number.isFinite(Fend)||Math.abs(F)>2**19||Math.abs(Fend)>2**19||!coefficientCheck())return null;
  const dual=fieldColumns(p.Qcolumns);if(!Array.isArray(dual)||dual.length!==3||!dual.every(v=>vec(v,2)))return null;
  const U=p.role==='BODY'?0:c.uplift,uBound=Math.max(Math.abs(p.u[1]),Math.abs(U)),ylo=p.C[1]-uBound*(remaining+H)-Y_PAD,yhi=p.C[1]+uBound*(remaining+H)+Y_PAD;
  const vmin=(R?windAt(ROOT_Y,c)[0]:c.meanX+Math.min(c.shearX*(ylo-1500),c.shearX*(yhi-1500))+Math.min(p.u[0],0))-V_PAD;
  const relativeCenter=p.C[0]-F+remaining*Math.min(vmin-c.frontSpeed,0)-c.frontSpeed*D;
  const deltaK=c.shearX*p.s*remaining*G,klo=p.K[0]+Math.min(0,deltaK)-K_PAD,khi=p.K[0]+Math.max(0,deltaK)+K_PAD,bhi=p.s*G;
  let offset=Infinity;for(const b of[0,bhi])for(const k of[klo,khi]){const value=[0,1,2].reduce((sum,j)=>{const row=b*dual[j][0]+k*dual[j][1];return sum+Math.min(row*(domain.origin[j]-p.root[j]),row*(domain.origin[j]+domain.span[j]-p.root[j]));},0);offset=Math.min(offset,value);}
  const lower=relativeCenter+offset;if(!Number.isFinite(lower)||!(lower>WEATHER_RESERVE+1e-7))return null;
  const rootCovered=p.root.every((v,i)=>v>=domain.origin[i]&&v<=hi[i]);
  return Object.freeze({clear:true,rootCovered,lowerMargin:lower-WEATHER_RESERVE-1e-7,now,remaining,reserve:WEATHER_RESERVE,signature:signature(p,c,domain,now,remaining,R)});
 }catch{return null;}
}
