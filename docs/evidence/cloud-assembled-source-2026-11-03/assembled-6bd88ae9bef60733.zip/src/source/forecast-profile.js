// Private forecast work reuse; actual source/reference stepping remains unchanged.
import {response,growth,growthIntegral,ROLES} from './math.js';
let shared=null;
export function healthyProfileState(){return{allocated:shared!==null,rows:shared?.length??0,logicalScalarBytes:shared?180*7*8:0};}
export function makeHealthyProfile(){
 if(shared)return shared;
 const rows=[];
 for(let i=0;i<180;i++){
  const p={role:'BILLOW',mu:1,tau:i*.25},end=response(1,p.tau,1,.25),half=response(1,p.tau,1,.125);
  rows.push(Object.freeze({tau:p.tau,end:Object.freeze(end),ig:growthIntegral(p,1,.25),g:growth(p.role,end.tau),halfG:growth(p.role,half.tau),halfIg:growthIntegral(p,1,.125)}));
 }
 shared=Object.freeze(rows);return shared;
}
export function forecastWork(p,target,needMid,profile){
 const i=p.tau/.25,row=profile?.[i];
 if(p.role==='BILLOW'&&[5,6].includes(p.s)&&target===1&&p.mu===1&&row&&Object.is(row.tau,p.tau))return row;
 const mature=[4,5,6].includes(p.s)&&p.tau>=ROLES[p.role]?.mature&&p.tau<=3600&&p.mu>=0&&p.mu<=1&&target>=0&&target<=1;
 const end=response(p.mu,p.tau,target,.25),out={end,ig:mature?.25:growthIntegral(p,target,.25),g:mature?1:growth(p.role,end.tau)};
 if(needMid){out.halfG=mature?1:growth(p.role,response(p.mu,p.tau,target,.125).tau);out.halfIg=mature?.125:growthIntegral(p,target,.125);}
 return out;
}
