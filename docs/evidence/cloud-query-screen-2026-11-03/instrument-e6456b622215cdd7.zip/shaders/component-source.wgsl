// Held static component query. Two local R16F template pairs serve eight poses.
@group(0) @binding(18) var bodyDistance:texture_3d<f32>;
@group(0) @binding(19) var crownBDensity:texture_3d<f32>;
@group(0) @binding(20) var crownBDistance:texture_3d<f32>;
struct HeldPart {
  C_b:vec4f, Q0_A:vec4f, Q1_asset:vec4f, Q2_active:vec4f,
  K_rootX:vec4f, rootYZ:vec4f
};
struct AssetDomain { origin_pitch:vec4f, span:vec4f };
@group(0) @binding(21) var<storage,read> heldParts:array<HeldPart,8>;
@group(0) @binding(22) var<storage,read> assetDomains:array<AssetDomain,2>;
@group(0) @binding(23) var<storage,read> cohortExposure:array<f32>;
fn exposureValue(slot:u32,i:vec3u)->f32 {
  let index=slot*4913u+(i.z*17u+i.y)*17u+i.x;
  return mix(cohortExposure[index],cohortExposure[39304u+index],p.lifecycle.y);
}
fn materialExposure(slot:u32,a:vec3f,domain:AssetDomain)->f32 {
  let grid=clamp((a-domain.origin_pitch.xyz)/domain.span.xyz*16.,vec3f(0),vec3f(16));
  let lo=min(vec3u(floor(grid)),vec3u(15));let f=grid-vec3f(lo);
  let z0=mix(mix(exposureValue(slot,lo),exposureValue(slot,lo+vec3u(1,0,0)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,0)),exposureValue(slot,lo+vec3u(1,1,0)),f.x),f.y);
  let z1=mix(mix(exposureValue(slot,lo+vec3u(0,0,1)),exposureValue(slot,lo+vec3u(1,0,1)),f.x),mix(exposureValue(slot,lo+vec3u(0,1,1)),exposureValue(slot,lo+vec3u(1,1,1)),f.x),f.y);
  return mix(z0,z1,f.z);
}
fn partDensity(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(densityTex,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDensity,linearClamp,uv,0.).x;
}
fn partDistance(index:u32,uv:vec3f)->f32 {
  if(index==0u){return textureSampleLevel(bodyDistance,linearClamp,uv,0.).x;}
  return textureSampleLevel(crownBDistance,linearClamp,uv,0.).x;
}
fn componentQuery(x:vec3f,raw:bool)->f32 {
  var q=0.;
  for(var i=0u;i<8u;i++) {
    let s=heldParts[i];
    if(s.Q2_active.w<.5||s.Q0_A.w<=0.||s.C_b.w<=0.){continue;}
    let h=(x.y-s.C_b.y)/s.C_b.w;
    let v=(x-s.C_b.xyz-s.K_rootX.xyz*h)/s.C_b.w;
    let a=vec3f(dot(s.Q0_A.xyz,v),dot(s.Q1_asset.xyz,v),dot(s.Q2_active.xyz,v))
      +vec3f(s.K_rootX.w,s.rootYZ.x,s.rootYZ.y);
    let index=u32(s.Q1_asset.w);
    if(index>=2u){continue;}
    let domain=assetDomains[index];
    let uv=(a-domain.origin_pitch.xyz)/domain.span.xyz;
    if(any(uv<vec3f(0.))||any(uv>vec3f(1.))){continue;}
    let rho=partDensity(index,uv);
    if(rho<=0.){continue;}
    var mask=1.;
    if(!raw){
      var weatherLoss=0.;
      if(p.lifecycle.z<.5){weatherLoss=materialExposure(u32(s.rootYZ.w),a,domain);}
      let loss=s.rootYZ.z+weatherLoss;
      var scaledLoss=0.;
      if(loss!=0.){
        let material=.3+.7*clamp(textureSampleLevel(basis,linearClamp,clamp(a/512.,vec3f(0),vec3f(1)),0.).x,0.,1.);
        scaledLoss=material*loss;
      }
      mask=smoothstep(-8.,8.,partDistance(index,uv)-scaledLoss);
    }
    q=max(q,s.Q0_A.w*rho*mask);
  }
  return q;
}
fn rawQ(x:vec3f)->vec4f {return vec4f(componentQuery(x,true),0.,0.,0.);}
fn coefficients(x:vec3f,detail:f32)->vec2f {
  if(p.domain.w>.5){return vec2f(0.);}
  return vec2f(componentQuery(x,false)*p.bmin.w,0.);
}
