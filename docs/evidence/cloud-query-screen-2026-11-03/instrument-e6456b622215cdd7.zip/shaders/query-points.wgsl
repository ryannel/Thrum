@group(0) @binding(25) var<storage,read> queryPoints:array<vec4f>;
@group(0) @binding(26) var<storage,read_write> queryOut:array<vec4f>;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id:vec3u) {
  if(id.x>=arrayLength(&queryPoints)){return;}
  let x=queryPoints[id.x].xyz;
  let c=coefficients(x,1.);
  queryOut[id.x]=vec4f(componentQuery(x,false),componentQuery(x,true),c);
}
