import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs/promises';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {loadRenderAssets} from '../../src/render/assets.js';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../assets'),originalFetch=globalThis.fetch;
test('real integrated index verifies two LOCAL templates and pinned 32³ noise',async()=>{
 globalThis.fetch=async url=>{const n=String(url).replace(/^assets\//,'');if(n.startsWith('/')||n.includes('..'))return new Response('not found',{status:404});try{return new Response(await fs.readFile(path.join(base,n)),{status:200});}catch{return new Response('not found',{status:404});}};
 try{
  const x=await loadRenderAssets();assert.equal(x.indexSha256,'2f7186b74253fc4c141e30a53113abd723fbb078c40893aac8cc5ce3be3a84d8');
  assert.equal(x.frozenSha256,'dbb633512b543f74016a023080b6c64a00bb6d14fa898ff596ca032bd0a24d8c');
  assert.deepEqual(Object.keys(x.assets),['body','crown-b']);
  assert.equal(x.assets.body.density.length,192*64*256);
  assert.equal(x.assets['crown-b'].distance.length,96**3);
  assert.equal(x.noise.length,32**3);
  assert.ok(x.admissionMetadata&&typeof x.admissionMetadata==='object');
  assert.ok(x.assets.body.manifest.reference.definition.includes('worldw=8*b'));
  assert.ok(x.assets['crown-b'].manifest.reference.definition.includes('worldw=8*b'));
 }finally{globalThis.fetch=originalFetch;}
});
