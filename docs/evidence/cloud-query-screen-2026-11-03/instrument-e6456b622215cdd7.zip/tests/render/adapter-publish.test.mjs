import test from 'node:test';import assert from 'node:assert/strict';
import {RenderAdapter} from '../../src/render/adapter.js';import {MAX_PARTS,GRID_COUNT} from '../../src/render/held-oracle.js';
const part={ID:'body-0',templateID:'body',C:[0,1239.2,0],Qcolumns:[[1,0,0],[0,1,0],[0,0,1]],s:4,g:1,b:4,K:[0,0,0],root:[299,233,167],Aseed:1,ageE:0,slot:0};
const zero=new Float32Array(MAX_PARTS*GRID_COUNT),nonzero=new Float32Array(MAX_PARTS*GRID_COUNT);nonzero[123]=1;
const tuple={epoch:1,sourceTick:0,exposureRevision:0,exposureAllZero:true,time:0,alpha:1,forcingRevision:0,bounds:[[-1000,0,-1000],[1000,3000,1000]],parts:[part],exposurePrevious:zero,exposureCurrent:zero};
test('presentation uploads are keyed; paused camera redraw does not clone/upload grids',()=>{
 const calls=[],a=Object.create(RenderAdapter.prototype);a.gpu={device:{queue:{writeBuffer:(...v)=>calls.push(v)}}};a.poseBuffer={label:'pose'};a.exposureBuffer={label:'control'};a.zeroExposure=new Float32Array(2*MAX_PARTS*GRID_COUNT);a.scene={};a.controlWasZero=true;a.poseUploadCount=0;a.poseUploadBytes=0;a.controlUploadCount=0;a.controlUploadBytes=0;
 a.publish(tuple);assert.equal(calls.length,1);assert.equal(a.poseUploadCount,1);assert.equal(a.controlUploadCount,0);
 a.publish(tuple);assert.equal(calls.length,1);
 const moving={...tuple,time:.1,alpha:.4};a.publish(moving);assert.equal(calls.length,2);assert.equal(a.controlUploadCount,0);
 const wet={...moving,sourceTick:1,exposureRevision:1,time:.25,alpha:1,exposureAllZero:false,exposureCurrent:nonzero};a.publish(wet);
 assert.equal(a.controlUploadCount,2);assert.equal(a.poseUploadCount,3);assert.equal(calls.filter(x=>x[0]===a.exposureBuffer).length,2);
 const off={...wet,sourceTick:2,exposureRevision:2,time:.5,exposureAllZero:true,exposureCurrent:zero};a.publish(off);
 assert.equal(a.controlUploadCount,3);assert.equal(calls.filter(x=>x[0]===a.exposureBuffer).length,3);
 a.publish(off);assert.equal(a.controlUploadCount,3);
});
