import test from 'node:test';import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {SourceModel,DEFAULT_CONTROLS} from '../../src/source/model.js';
import {SourceClock} from '../../src/source/clock.js';
import {RenderAdapter} from '../../src/render/adapter.js';
import {MAX_PARTS,GRID_COUNT,heldPoint,forwardPoint} from '../../src/render/held-oracle.js';
const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../assets');
const templates=Object.fromEntries(['body','crown-b'].map(id=>[id,JSON.parse(fs.readFileSync(path.join(dir,'templates',id+'.json')))]));
const admissionMetadata=JSON.parse(fs.readFileSync(path.join(dir,'admission/admission.json')));
test('actual source clock presents retained seed through growth onset to common renderer packing',()=>{
 const clock=new SourceClock(new SourceModel({templates,admissionMetadata},DEFAULT_CONTROLS));clock.reset(DEFAULT_CONTROLS);
 const a=Object.create(RenderAdapter.prototype),writes=[];a.gpu={device:{queue:{writeBuffer:(...v)=>writes.push(v)}}};a.poseBuffer={};a.exposureBuffer={};a.zeroExposure=new Float32Array(2*MAX_PARTS*GRID_COUNT);a.scene={};a.controlWasZero=true;a.poseUploadCount=0;a.poseUploadBytes=0;a.controlUploadCount=0;a.controlUploadBytes=0;
 for(let n=0;n<=20;n++){
   clock.requested=n*.25;clock.pump(Infinity,2);const t=clock.tuple();a.publish(t);
   assert.ok(t.parts.some(p=>p.ID===1&&p.templateID==='body'),`first BODY lost at source tick ${n}`);
   assert.equal(t.exposurePrevious.length,MAX_PARTS*GRID_COUNT);
 }
 assert.ok(a.poseUploadCount>1);assert.equal(a.controlUploadCount,0);
});
test('actual 100s source poses query positive native BODY and B without a remap',()=>{
 const clock=new SourceClock(new SourceModel({templates,admissionMetadata},DEFAULT_CONTROLS));clock.reset(DEFAULT_CONTROLS);clock.requested=100.25;
 while(clock.model.time+.25<=clock.requested+1e-9)clock.pump(Infinity,128);
 const tuple=clock.tuple(),assets={};
 for(const id of['body','crown-b']){const m=templates[id],read=n=>{const b=fs.readFileSync(path.join(dir,'templates',n));return new Uint16Array(b.buffer,b.byteOffset,b.byteLength/2);};assets[id]={origin:m.domain_origin_global_xyz_local_m,span:m.domain_span_local_m,dims:m.dimensions_xyz,density:read(m.density.file),distance:read(m.distance.file)};}
 const nb=fs.readFileSync(path.join(dir,'noise/channels-32.r16f')),noise=new Uint16Array(nb.buffer,nb.byteOffset,nb.byteLength/2);
 assert.equal(tuple.time,100);assert.ok(tuple.parts.some(p=>p.templateID==='body'&&p.Aseed>0));assert.ok(tuple.parts.some(p=>p.templateID==='crown-b'&&p.Aseed>0));
 for(const p of tuple.parts.filter(p=>p.Aseed>0)){
   const x=forwardPoint(p,p.root),q=heldPoint([p],assets,x,{noise,exposurePrevious:tuple.exposurePrevious,exposureCurrent:tuple.exposureCurrent,alpha:tuple.alpha});
   assert.ok(q>0,`source ${p.ID} root has no native q`);
 }
});
