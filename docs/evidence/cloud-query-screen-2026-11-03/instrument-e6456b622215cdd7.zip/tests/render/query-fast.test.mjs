import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Scene} from '../../src/render/scene.js';
import {RenderAdapter,classifyTimestampPair} from '../../src/render/adapter.js';
import {MAX_PARTS,GRID_COUNT} from '../../src/render/held-oracle.js';

const grids=()=>new Float32Array(MAX_PARTS*GRID_COUNT);
const tuple=zero=>({epoch:1,sourceTick:1,exposureRevision:1,exposureAllZero:zero,time:100,alpha:.5,forcingRevision:0,bounds:[[-1000,0,-1000],[1000,3000,1000]],parts:[],exposurePrevious:grids(),exposureCurrent:grids(),controls:{}});

test('held uniform writes explicit current-tuple zero exposure, including true to false',()=>{
  const writes=[],scene=Object.create(Scene.prototype);
  Object.assign(scene,{heldMode:true,scratch:new Float32Array(44),bounds:()=>[[-1000,0,-1000],[1000,3000,1000]],cameraPosition:()=>[0,1500,3000],target:()=>[0,1500,0],viewSize:[1280,720],steps:0,family:0,gpu:{device:{queue:{writeBuffer:(_buffer,_offset,data)=>writes.push(Float32Array.from(data))}}}});
  const ui={lightingProfile:'selected-production',sun:30,mirror:true,mode:0,materialSpace:'world',viewSteps:96,main:true,alpha:1,cohorts:true};
  scene.write({}, {time:100,wind:0,windIntegral:0,moist:1,dry:0,lift:1,frontX:0,storm:0},{...ui,zeroExposure:true},null,100);
  scene.write({}, {time:100,wind:0,windIntegral:0,moist:1,dry:0,lift:1,frontX:0,storm:0},{...ui,zeroExposure:false},null,100);
  scene.heldMode=false;scene.write({}, {time:100,wind:0,windIntegral:0,moist:1,dry:0,lift:1,frontX:0,storm:0},ui,null,100);
  assert.deepEqual(writes.map(v=>v[42]),[1,0,256]);
});

test('render and diagnostic probe both pass same published tuple flag',async()=>{
  const adapter=Object.create(RenderAdapter.prototype),flags=[];adapter.queryWitnesses={body:[],'crown-b':[]};adapter.scene={codes:{optics:'fast', 'baseline-optics':'baseline','query-points':'kernel'},render:(_weather,ui)=>{flags.push(ui.zeroExposure);return true;},write:(_buffer,_weather,ui)=>flags.push(ui.zeroExposure),heldDensity:{createView:()=>({})},clamp:{},heldInputs:()=>[]};
  const stop=Error('stop after uniform binding');adapter.gpu={device:{createBuffer:()=>({destroy(){}}),createCommandEncoder:()=>{throw stop;},queue:{writeBuffer(){}}},compute:async()=>({})};
  const previous=globalThis.GPUBufferUsage;globalThis.GPUBufferUsage={UNIFORM:1,COPY_DST:2,STORAGE:4,COPY_SRC:8,MAP_READ:16};
  try{
    for(const zero of [true,false]){adapter.published=tuple(zero);assert.equal(adapter.render({}),true);await assert.rejects(adapter.probe({}),error=>error===stop);}
    assert.deepEqual(flags,[true,true,false,false]);
  }finally{globalThis.GPUBufferUsage=previous;}
});

test('held alpha and prior/current exposure variants restore actual publication',async()=>{
  const adapter=Object.create(RenderAdapter.prototype),original=tuple(true),seen=[];adapter.published=original;
  adapter.publish=function(value){this.published=value;seen.push(value);return value;};
  adapter.probe=async function(){return {pass:true,flag:this.published.exposureAllZero};};
  const result=await adapter.compareVariants({});
  assert.equal(result.pass,true);assert.deepEqual(result.cases.map(x=>x.case),['actual','alpha-zero','alpha-half','alpha-one','previous-only-one-metre','current-only-one-metre']);
  assert.deepEqual(result.cases.map(x=>x.alpha),[.5,0,.5,1,.5,.5]);
  assert.deepEqual(result.cases.map(x=>x.exposureAllZero),[true,true,true,true,false,false]);
  assert.equal(seen[4].exposurePrevious[0],1);assert.equal(seen[4].exposureCurrent[0],0);
  assert.equal(seen[5].exposurePrevious[0],0);assert.equal(seen[5].exposureCurrent[0],1);
  assert.strictEqual(adapter.published,original);
});

test('receipt preserves control upload bytes and timing rejects zero or nonmonotone readings',()=>{
  const adapter=Object.create(RenderAdapter.prototype);adapter.published=tuple(false);
  adapter.input={indexSha256:'index',frozenSha256:'source',index:{noise:{sha256:'noise'}},assets:{body:{manifest:{density:{sha256:'rho'},distance:{sha256:'d'}},metadataSha256:'body-meta'},'crown-b':{manifest:{density:{sha256:'rho-b'},distance:{sha256:'d-b'}},metadataSha256:'b-meta'}}};
  adapter.gpu={bytes:500,allocations:[]};adapter.poseUploadCount=2;adapter.poseUploadBytes=3;adapter.controlUploadCount=4;adapter.controlUploadBytes=1234;
  assert.equal(adapter.metadata().controlUploadBytes,1234);
  assert.deepEqual(classifyTimestampPair(10n,20n,9n),{beginNs:'10',endNs:'20',durationNs:'10',timingValid:true,issues:[]});
  assert.equal(classifyTimestampPair(0n,20n,null).timingValid,false);
  assert.equal(classifyTimestampPair(10n,10n,null).timingValid,false);
  assert.equal(classifyTimestampPair(10n,20n,15n).timingValid,false);
});

test('timed kernel invokes one production coefficient query per point',()=>{
  const code=readFileSync(new URL('../../shaders/query-benchmark.wgsl',import.meta.url),'utf8');
  assert.equal((code.match(/\bcoefficients\s*\(/g)??[]).length,1);
  assert.doesNotMatch(code,/\b(?:rawQ|componentQuery)\s*\(/);
  assert.match(code,/queryOut\[id\.x\]\s*=\s*vec4f\(c,0\.,0\.\)/);
});
