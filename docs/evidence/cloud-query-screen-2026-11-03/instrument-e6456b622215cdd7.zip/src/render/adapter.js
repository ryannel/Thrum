import {Gpu} from './gpu.js';import {Scene} from './scene.js';
import {frameFence,assertGpuHealthy} from './frame-lifecycle.js';
import {loadRenderAssets,uploadHalf3d} from './assets.js';
import {assetIds,packParts,packDomains,forwardPoint,MAX_PARTS,GRID_COUNT,EXPOSURE_FLOATS} from './held-oracle.js';
import {halfToFloat} from './reference.js';
import {evaluatePoint,snapshotForProbe} from '../source/reference.js';
const shaderNames=['optics','baseline-optics','query-points','query-benchmark','light','shadow','air','view','display'];
const staticWeather={wind:0,windIntegral:0,moist:0,dry:0,lift:0,frontX:0,storm:0};
function frameWeather(tuple){
  const c=tuple.controls??{},region=tuple.weatherRegion??tuple.region??[0,0,0];
  return {time:tuple.time,wind:c.meanX??0,windIntegral:Array.isArray(region)?region[0]:0,moist:Number(Boolean(c.moist)),dry:c.dry??0,lift:Number(Boolean(c.lift)),frontX:c.frontX??0,storm:c.storm??0};
}
function validateTuple(tuple){
  if(!tuple||!Array.isArray(tuple.parts)||tuple.parts.length>MAX_PARTS||!Array.isArray(tuple.bounds)||tuple.bounds.length!==2)throw Error('Invalid common source presentation');
  if(!Number.isFinite(tuple.time)||!Number.isFinite(tuple.alpha)||tuple.alpha<0||tuple.alpha>1||!Number.isInteger(tuple.sourceTick)||!Number.isInteger(tuple.epoch))throw Error('Invalid common source clock');
  if(tuple.exposurePrevious?.length!==MAX_PARTS*GRID_COUNT||tuple.exposureCurrent?.length!==MAX_PARTS*GRID_COUNT||!Number.isInteger(tuple.exposureRevision))throw Error('Invalid common source control grids');
  for(let i=0;i<3;i++)if(!Number.isFinite(tuple.bounds[0][i])||!Number.isFinite(tuple.bounds[1][i])||tuple.bounds[1][i]<=tuple.bounds[0][i])throw Error('Invalid common source bounds');
  const slots=new Set(),ids=new Set();for(const p of tuple.parts){if(slots.has(p.slot)||ids.has(p.ID))throw Error('Duplicate presented source slot or ID');slots.add(p.slot);ids.add(p.ID);}
}
function localQueryWitnesses(asset){
  const [nx,ny]=asset.dims,{density,distance,origin,pitch}=asset,started=performance.now();
  let tinyIndex=-1,tinyBits=0x7c00,lowerIndex=-1,lowerError=Infinity,upperIndex=-1,upperError=Infinity,positiveFinite=0;
  for(let i=0;i<density.length;i++){
    const bits=density[i];if(bits===0||bits>=0x7c00)continue;
    const d=halfToFloat(distance[i]);if(!Number.isFinite(d))continue;
    positiveFinite++;
    if(d>-8&&bits<tinyBits){tinyIndex=i;tinyBits=bits;}
    const lower=Math.abs(d+8),upper=Math.abs(d-8);
    if(lower<lowerError){lowerIndex=i;lowerError=lower;}
    if(upper<upperError){upperIndex=i;upperError=upper;}
  }
  const witnesses=[['tiny-positive',tinyIndex],['taper-minus-eight',lowerIndex],['taper-plus-eight',upperIndex]].filter(([,i])=>i>=0).map(([kind,i])=>{
    const x=i%nx,y=Math.floor(i/nx)%ny,z=Math.floor(i/(nx*ny));
    return {kind,local:[origin[0]+(x+.5)*pitch,origin[1]+(y+.5)*pitch,origin[2]+(z+.5)*pitch],rho:halfToFloat(density[i]),distanceLocalM:halfToFloat(distance[i])};
  });
  return {witnesses,scan:{voxels:density.length,positiveFinite,elapsedCpuMs:performance.now()-started,scope:'One-time observer witness preparation; excluded from GPU query benchmark'}};
}
export function classifyTimestampPair(begin,end,previousEnd){
  const issues=[];
  if(begin===0n||end===0n)issues.push('zero timestamp');
  if(end<=begin)issues.push('nonpositive pass duration');
  if(previousEnd!==null&&begin<previousEnd)issues.push('nonmonotone pass order');
  return {beginNs:String(begin),endNs:String(end),durationNs:issues.length?null:String(end-begin),timingValid:issues.length===0,issues};
}
export class RenderAdapter{
  static async create(canvas,progress=()=>{}){
    const input=await loadRenderAssets(progress),gpu=await Gpu.open(canvas);
    if(gpu.device.limits.maxSampledTexturesPerShaderStage<8)throw Error('Device lacks eight sampled textures per stage for the common view');
    const codes=Object.fromEntries(await Promise.all(shaderNames.map(async n=>{const r=await fetch('shaders/'+n+'.wgsl');if(!r.ok)throw Error('Missing shader '+n);return[n,await r.text()];})));
    const a=new RenderAdapter();Object.assign(a,{input,gpu,codes,published:null,poseUploadCount:0,poseUploadBytes:0,controlUploadCount:0,controlUploadBytes:0,controlWasZero:true});
    const s=new Scene(gpu,codes,0,0);a.scene=s;s.heldMode=true;s.bounds=()=>a.published?.bounds??[[-2000,0,-2000],[2000,4000,2000]];s.fixedFocus=[0,1300,0];s.target=()=>[s.fixedFocus[0]+s.camera.panX,s.fixedFocus[1]+s.camera.panY,s.fixedFocus[2]];s.camera={yaw:.3,pitch:-.05,distance:3000,panX:0,panY:0};
    try{
      await s.init(progress);
      a.textures={};for(const id of assetIds){const v=input.assets[id];a.textures[id]={density:uploadHalf3d(gpu,id+' rho',v.dims,v.density),distance:uploadHalf3d(gpu,id+' d',v.dims,v.distance)};}
      a.noise=uploadHalf3d(gpu,'fixed material M noise',[32,32,32],input.noise);
      s.heldDensity=a.textures.body.density;
      a.poseBuffer=gpu.buffer('8 common presented part maps',MAX_PARTS*24*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.domainBuffer=gpu.buffer('2 local asset domains',2*8*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.exposureBuffer=gpu.buffer('prior/current local weather loss',EXPOSURE_FLOATS*4,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST);
      a.zeroExposure=new Float32Array(EXPOSURE_FLOATS);
      gpu.device.queue.writeBuffer(a.domainBuffer,0,packDomains(input.assets));
      s.heldInputs=()=>[[2,a.noise.createView()],[18,a.textures.body.distance.createView()],[19,a.textures['crown-b'].density.createView()],[20,a.textures['crown-b'].distance.createView()],[21,a.poseBuffer],[22,a.domainBuffer],[23,a.exposureBuffer]];
      await frameFence(gpu);return a;
    }catch(error){await s.dispose();throw error;}
  }
  publish(tuple){
    validateTuple(tuple);
    const g=this.gpu,sourceKey=tuple.epoch+'/'+tuple.sourceTick+'/'+tuple.exposureRevision;
    if(this.controlKey!==sourceKey){
      if(tuple.exposureAllZero){
        if(!this.controlWasZero){g.device.queue.writeBuffer(this.exposureBuffer,0,this.zeroExposure);this.controlUploadCount++;this.controlUploadBytes+=this.zeroExposure.byteLength;}
        this.controlWasZero=true;
      }else{
        g.device.queue.writeBuffer(this.exposureBuffer,0,tuple.exposurePrevious);
        g.device.queue.writeBuffer(this.exposureBuffer,MAX_PARTS*GRID_COUNT*4,tuple.exposureCurrent);
        this.controlUploadCount+=2;this.controlUploadBytes+=2*MAX_PARTS*GRID_COUNT*4;this.controlWasZero=false;
      }
      this.controlKey=sourceKey;
    }
    const poseKey=[tuple.epoch,tuple.sourceTick,tuple.time,tuple.alpha,tuple.forcingRevision].join('/');
    if(this.poseKey!==poseKey){
      this.packed=packParts(tuple.parts);g.device.queue.writeBuffer(this.poseBuffer,0,this.packed);this.poseUploadCount++;this.poseUploadBytes+=this.packed.byteLength;this.poseKey=poseKey;
    }
    this.published=tuple;this.scene.time=tuple.time;this.scene.steps=0;this.scene.epoch=tuple.epoch;
    return tuple;
  }
  render(ui){
    if(!this.published)throw Error('No common presentation published');
    const tuple=this.published,options={...ui,cohorts:true,sourceAlpha:tuple.alpha,zeroExposure:tuple.exposureAllZero===true,provider:0,family:0,alpha:1,extinctionScale:.019/.0045};
    const snapshot=frameWeather(tuple);return this.scene.render({sample:()=>snapshot},options,0,tuple.time);
  }
  metadata(){
    const t=this.published;if(!t)throw Error('No common presentation');
    return {sourceTime:t.time,sourceTick:t.sourceTick,previousTime:t.previousTime,committedTime:t.committedTime,requestedTime:t.requestedTime,alpha:t.alpha,exposureAllZero:t.exposureAllZero===true,epoch:t.epoch,cellId:t.cellId,forcingRevision:t.forcingRevision,parts:t.parts.map(p=>({...p})),bounds:t.bounds,controls:t.controls,events:t.events,stats:t.stats,inputIndexSha256:this.input.indexSha256,sourceFrozenSha256:this.input.frozenSha256,assetHashes:Object.fromEntries(assetIds.map(id=>[id,{rho:this.input.assets[id].manifest.density.sha256,distance:this.input.assets[id].manifest.distance.sha256,correctedMetadata:this.input.assets[id].metadataSha256}])),noiseSha256:this.input.index.noise.sha256,poseUploadCount:this.poseUploadCount,poseUploadBytes:this.poseUploadBytes,controlUploadCount:this.controlUploadCount,controlUploadBytes:this.controlUploadBytes,logicalGpuBytes:this.gpu.bytes,logicalGpuAllocations:this.gpu.allocations,scope:'One common immutable liquid source query; source/art/performance/full sky not qualified'};
  }
  async probe(ui){
    const t=this.published&&snapshotForProbe(this.published);if(!t)throw Error('No common presentation');
    const s=this.scene,g=this.gpu,d=g.device,points=[];
    for(const p of t.parts)for(const delta of[[0,0,0],[4,0,0],[-4,0,0],[0,4,0],[0,-4,0],[0,0,4],[0,0,-4],[20,10,10]])points.push(forwardPoint(p,p.root.map((v,i)=>v+delta[i])));
    this.queryWitnesses??=Object.fromEntries(assetIds.map(id=>[id,localQueryWitnesses(this.input.assets[id])]));
    for(const p of t.parts)for(const witness of this.queryWitnesses[p.templateID].witnesses)points.push(forwardPoint(p,witness.local));
    const [lo,hi]=t.bounds;for(let z=0;z<12;z++)for(let y=0;y<12;y++)for(let x=0;x<12;x++)points.push(lo.map((v,i)=>v+(hi[i]-v)*([x,y,z][i]+.5)/12));
    const input=new Float32Array(points.length*4);for(let i=0;i<points.length;i++)input.set(points[i],i*4);
    const bytes=input.byteLength,uniform=d.createBuffer({size:176,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),positions=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),fastOutput=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),baselineOutput=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),read=d.createBuffer({size:2*bytes,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
    try{
      this.probePipeline??=await g.compute('fast common coefficient oracle',s.codes.optics+s.codes['query-points']);
      this.baselineProbePipeline??=await g.compute('baseline common coefficient oracle',s.codes['baseline-optics']+s.codes['query-points']);
      const options={...ui,cohorts:true,sourceAlpha:t.alpha,zeroExposure:t.exposureAllZero===true,provider:0,family:0,extinctionScale:.019/.0045};s.write(uniform,frameWeather(t),options,null,t.time);
      d.queue.writeBuffer(positions,0,input);
      const bindings=output=>[[0,uniform],[1,s.heldDensity.createView()],[3,s.clamp],...s.heldInputs(),[25,positions],[26,output]];
      const e=d.createCommandEncoder();for(const [pipeline,output] of [[this.baselineProbePipeline,baselineOutput],[this.probePipeline,fastOutput]]){const pass=e.beginComputePass();pass.setPipeline(pipeline);pass.setBindGroup(0,g.group(pipeline,bindings(output)));pass.dispatchWorkgroups(Math.ceil(points.length/64));pass.end();}
      e.copyBufferToBuffer(baselineOutput,0,read,0,bytes);e.copyBufferToBuffer(fastOutput,0,read,bytes,bytes);g.submit(e);
      await read.mapAsync(GPUMapMode.READ);const mapped=read.getMappedRange(),data=new Float32Array(mapped,bytes,points.length*4),baseline=new Float32Array(mapped,0,points.length*4),bits=new Uint32Array(mapped);let maxQ=0,maxRaw=0,maxSigma=0,invalid=0,invalidBaseline=0,positive=0,bitMismatches=0,maxBaselineFast=0;const examples=[],mismatches=[];
      for(let i=0;i<points.length;i++){
        const x=Array.from(input.subarray(i*4,i*4+3)),v=data.subarray(i*4,i*4+4),q=evaluatePoint(t,x,this.input.assets,this.input.noise),raw=evaluatePoint(t,x,this.input.assets,this.input.noise,{raw:true});
        for(let j=0;j<4;j++){const k=i*4+j;if(!Number.isFinite(baseline[k]))invalidBaseline++;if(bits[k]!==bits[points.length*4+k]){bitMismatches++;const delta=Math.abs(baseline[k]-data[k]);if(Number.isFinite(delta))maxBaselineFast=Math.max(maxBaselineFast,delta);if(mismatches.length<12)mismatches.push({point:i,component:j,x,baseline:baseline[k],fast:data[k],baselineBits:bits[k],fastBits:bits[points.length*4+k]});}}
        maxQ=Math.max(maxQ,Math.abs(v[0]-q));maxRaw=Math.max(maxRaw,Math.abs(v[1]-raw));maxSigma=Math.max(maxSigma,Math.abs(v[2]-q*.019));
        if(!Array.from(v).every(Number.isFinite)||v[3]!==0||v[0]<0||v[1]<0||v[2]<0)invalid++;if(v[0]>0)positive++;
        if(examples.length<12&&q>0)examples.push({x,gpu:v[0],cpu:q,rawGpu:v[1],rawCpu:raw});
      }read.unmap();assertGpuHealthy(g);
      return {pass:invalid===0&&invalidBaseline===0&&bitMismatches===0&&maxQ<=.002&&maxRaw<=.002&&maxSigma<=.002*.019,points:points.length,positive,invalid,invalidBaseline,bitMismatches,maxFiniteAbsBaselineFast:maxBaselineFast,mismatches,maxAbsQ:maxQ,maxAbsRaw:maxRaw,maxAbsSigma:maxSigma,toleranceQ:.002,toleranceSigma:.002*.019,localQueryWitnesses:this.queryWitnesses,examples,scope:'Same-device baseline and fast GPU outputs compared bitwise in one diagnostic, then fast output versus independent CPU; separate pipelines, including native tiny-positive and taper witnesses; no timing or art pass'};
    }finally{for(const x of[uniform,positions,fastOutput,baselineOutput,read])x.destroy();}
  }
  async compareVariants(ui){
    const original=this.published;if(!original)throw Error('No common presentation');
    const held=snapshotForProbe(original),ones=grids=>{const out=new Float32Array(grids.length);out.fill(1);return out;},zeros=grids=>new Float32Array(grids.length),cases=[
      {name:'actual',alpha:held.alpha,prior:held.exposurePrevious,current:held.exposureCurrent,allZero:held.exposureAllZero===true},
      {name:'alpha-zero',alpha:0,prior:held.exposurePrevious,current:held.exposureCurrent,allZero:held.exposureAllZero===true},
      {name:'alpha-half',alpha:.5,prior:held.exposurePrevious,current:held.exposureCurrent,allZero:held.exposureAllZero===true},
      {name:'alpha-one',alpha:1,prior:held.exposurePrevious,current:held.exposureCurrent,allZero:held.exposureAllZero===true},
      {name:'previous-only-one-metre',alpha:.5,prior:ones(held.exposurePrevious),current:zeros(held.exposureCurrent),allZero:false},
      {name:'current-only-one-metre',alpha:.5,prior:zeros(held.exposurePrevious),current:ones(held.exposureCurrent),allZero:false},
    ],results=[];
    try{
      for(let i=0;i<cases.length;i++){
        const c=cases[i],variant={...held,alpha:c.alpha,exposurePrevious:c.prior,exposureCurrent:c.current,exposureAllZero:c.allZero,sourceTick:held.sourceTick+10000+i,exposureRevision:held.exposureRevision+10000+i};
        this.publish(variant);const result=await this.probe(ui);
        results.push({case:c.name,alpha:c.alpha,exposureAllZero:c.allZero,synthetic:c.name!=='actual',sourceTick:variant.sourceTick,result});
      }
    }finally{this.publish(original);}
    return {pass:results.every(x=>x.result.pass),originalSourceTime:held.time,originalSourceTick:held.sourceTick,originalEpoch:held.epoch,originalAlpha:held.alpha,originalExposureAllZero:held.exposureAllZero===true,cases:results,scope:'Actual frozen tuple plus held-pose alpha and explicit one-metre prior/current exposure diagnostic variants. Full source state and packed GPU buffers restored in finally; synthetic cases are not source evolution or timing evidence.'};
  }
  async benchmarkQuery(ui){
    const t=this.published&&snapshotForProbe(this.published);if(!t)throw Error('No common presentation');
    const s=this.scene,g=this.gpu,d=g.device;
    if(!d.features.has('timestamp-query'))return {supported:false,reason:'Enabled WebGPU device lacks timestamp-query; no GPU kernel duration claimed'};
    const side=32,count=side**3,bytes=count*16,points=new Float32Array(count*4),[lo,hi]=t.bounds;
    for(let z=0;z<side;z++)for(let y=0;y<side;y++)for(let x=0;x<side;x++){
      const i=(z*side+y)*side+x;points.set([lo[0]+(hi[0]-lo[0])*(x+.5)/side,lo[1]+(hi[1]-lo[1])*(y+.5)/side,lo[2]+(hi[2]-lo[2])*(z+.5)/side,0],4*i);
    }
    const uniform=d.createBuffer({size:176,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),positions=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),output=d.createBuffer({size:bytes,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC}),read=d.createBuffer({size:6*bytes,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST}),query=d.createQuerySet({type:'timestamp',count:12}),resolved=d.createBuffer({size:96,usage:GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC}),queryRead=d.createBuffer({size:96,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
    try{
      this.fastBenchmarkPipeline??=await g.compute('fast one-coefficient query benchmark',s.codes.optics+s.codes['query-benchmark']);
      this.baselineBenchmarkPipeline??=await g.compute('baseline one-coefficient query benchmark',s.codes['baseline-optics']+s.codes['query-benchmark']);
      s.write(uniform,frameWeather(t),{...ui,cohorts:true,sourceAlpha:t.alpha,zeroExposure:t.exposureAllZero===true,provider:0,family:0,extinctionScale:.019/.0045},null,t.time);
      d.queue.writeBuffer(positions,0,points);
      const group=pipeline=>g.group(pipeline,[[0,uniform],[1,s.heldDensity.createView()],[3,s.clamp],...s.heldInputs(),[25,positions],[26,output]]),baselineGroup=group(this.baselineBenchmarkPipeline),fastGroup=group(this.fastBenchmarkPipeline),blocks=[],timingIssues=[];
      let previousEnd=null;
      for(let block=0;block<10;block++){
        const sequence=[...(block%2?['B','A','A','B']:['A','B','B','A']),'A','A'],e=d.createCommandEncoder();
        if(block===0)for(const [pipeline,bg] of [[this.baselineBenchmarkPipeline,baselineGroup],[this.fastBenchmarkPipeline,fastGroup]]){const warm=e.beginComputePass();warm.setPipeline(pipeline);warm.setBindGroup(0,bg);warm.dispatchWorkgroups(count/64);warm.end();}
        for(let i=0;i<sequence.length;i++){
          const baseline=sequence[i]==='A',pipeline=baseline?this.baselineBenchmarkPipeline:this.fastBenchmarkPipeline,bg=baseline?baselineGroup:fastGroup;
          const pass=e.beginComputePass({timestampWrites:{querySet:query,beginningOfPassWriteIndex:2*i,endOfPassWriteIndex:2*i+1}});pass.setPipeline(pipeline);pass.setBindGroup(0,bg);pass.dispatchWorkgroups(count/64);pass.end();e.copyBufferToBuffer(output,0,read,i*bytes,bytes);
        }
        e.resolveQuerySet(query,0,12,resolved,0);e.copyBufferToBuffer(resolved,0,queryRead,0,96);g.submit(e);
        const mapped=await Promise.allSettled([read.mapAsync(GPUMapMode.READ),queryRead.mapAsync(GPUMapMode.READ)]);
        if(mapped.some(x=>x.status==='rejected')){if(mapped[0].status==='fulfilled')read.unmap();if(mapped[1].status==='fulfilled')queryRead.unmap();throw mapped.find(x=>x.status==='rejected').reason;}
        try{
          const values=new Uint32Array(read.getMappedRange()),stamps=new BigUint64Array(queryRead.getMappedRange()),passes=[];
          for(let i=0;i<sequence.length;i++){
            const slice=values.subarray(i*count*4,(i+1)*count*4);let hash=2166136261,positive=0;for(let j=0;j<slice.length;j++){hash=Math.imul(hash^slice[j],16777619)>>>0;if(j%4===0&&slice[j]!==0)positive++;}
            const begin=stamps[2*i],end=stamps[2*i+1],timing=classifyTimestampPair(begin,end,previousEnd);
            if(timing.issues.length)timingIssues.push({block,order:i,pipeline:sequence[i],issues:timing.issues});
            passes.push({order:i,pipeline:sequence[i],beginNs:timing.beginNs,endNs:timing.endNs,durationNs:timing.durationNs,timingValid:timing.timingValid,outputHash32:hash,positivePointCount:positive,outputSampleBits:Array.from(slice.subarray(0,16))});
            previousEnd=end;
          }
          blocks.push({block,sequence,passes});
        }finally{read.unmap();queryRead.unmap();}
        assertGpuHealthy(g);await frameFence(g);
      }
      return {supported:true,timingValid:timingIssues.length===0,timingIssues,sourceTime:t.time,sourceTick:t.sourceTick,epoch:t.epoch,alpha:t.alpha,exposureAllZero:t.exposureAllZero===true,points:count,fieldGrid:[side,side,side],blocks,logicalGpuInstrumentationBytes:bytes*8+96*3+176,cpuInputBytes:points.byteLength,scope:'Each timed point invokes coefficients(x,1.) exactly once and writes two coefficients plus fixed padding; the separate bit/CPU diagnostic also queries raw and is not timed here. Ten alternating A/B/B/A and B/A/A/B paired blocks, each with A/A control; separate warmed pipelines, one timestamped compute pass each, output copied/read each pass, buffers unmapped before reuse. Raw within-pass nanoseconds only; invalid/zero/nonmonotone timestamps reject timing. No cross-pass sum, complete-frame or queue-fence GPU timing claim.'};
    }finally{for(const x of[uniform,positions,output,read,resolved,queryRead,query])x.destroy();}
  }
}
