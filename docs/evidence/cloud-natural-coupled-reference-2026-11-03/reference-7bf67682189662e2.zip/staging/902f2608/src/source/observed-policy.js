import {prepareEndpoint} from './prepared-endpoint.js';
import {makeHealthyProfile,forecastWork} from './forecast-profile.js';
import * as spatial from './admission-policy.js';
import {cloneGeometry,response,growth,growthIntegral,advancePose,matrix,forward,sigmaMin,sigmaMax,fullVelocity} from './math.js';
import {growthTarget,regionAdvance,dryAt,smooth,windAt} from './weather.js';
import {positionGuard,potentialLower} from './native-potential.js';
export const POLICY_ID='cu-held-predict-observe-v1';
const H=.25,N=180,EPS=1e-8;
const freeze=x=>{if(x&&typeof x==='object'){for(const v of Object.values(x))freeze(v);Object.freeze(x);}return x;};
export function geometry(p){
 const out={};for(const k of ['ID','parentID','templateID','role','slot','s','b','g','Aseed','mu','tau','born','active'])out[k]=p[k];
 for(const k of ['C','u','K','root'])out[k]=[...p[k]];out.Qcolumns=p.Qcolumns;return out;
}
function pose(p){return{ID:p.ID,templateID:p.templateID,C:[...p.C],Qcolumns:p.Qcolumns.map(c=>[...c]),b:p.b,K:[...p.K]};}
function sweep(p){return{pose:pose(p),bRange:[p.b,p.b],KRadius:0,centerRadius:positionGuard(p)};}
export function advanceReference(p,c,t,h=H){
 const target=growthTarget(p.C[0],t+h/2,c),end=response(p.mu,p.tau,target,h),ig=growthIntegral(p,target,h);
 advancePose(p,c,h,ig);p.mu=end.mu;p.tau=end.tau;p.g=growth(p.role,p.tau);p.b=p.s*p.g;p.Aseed=smooth(0,4,p.tau);
}
function forecast(p,c,t,metadata,{health=false,region=null,profile=null}={}){
 let R=region?[...region]:null;const mid=health?geometry(p):null;
 for(let n=0;n<N;n++){
  const now=t+n*H,target=growthTarget(p.C[0],now+H/2,c),needMid=health&&!(c.dryGain===0||now+H<c.frontStart),work=forecastWork(p,target,needMid,profile);
  if(needMid){
   for(const k of ['C','u','K'])for(let i=0;i<3;i++)mid[k][i]=p[k][i];
   mid.role=p.role;mid.s=p.s;mid.b=p.b;advancePose(mid,c,H/2,work.halfIg);mid.g=work.halfG;mid.b=p.s*mid.g;
   if(R){mid.C=regionAdvance(R,c,H/2);mid.u=[0,0,0];}
   const A=matrix(mid),d=metadata.templates[p.templateID].domain;
   const minX=mid.C[0]+[0,1,2].reduce((s,j)=>s+Math.min(A[0][j]*(d.origin[j]-p.root[j]),A[0][j]*(d.origin[j]+d.span[j]-p.root[j])),0);
   if(!(c.dryGain===0||now+H<c.frontStart||dryAt(minX-1e-7,now+H,c)===0))return{healthy:false,poseSteps:n,healthChecks:n+1};
  }
  advancePose(p,c,H,work.ig);p.mu=work.end.mu;p.tau=work.end.tau;p.g=work.g;p.b=p.s*p.g;p.Aseed=smooth(0,4,p.tau);
  if(R){R=regionAdvance(R,c,H);p.C=[...R];p.u=[0,0,0];}
 }
 return{healthy:true,poseSteps:N,healthChecks:health?N:0};
}
export function guardedRootRadius(q,template){
 const p=q.candidateSweep.pose,Q=p.Qcolumns;let qmax2=0;
 for(let i=0;i<3;i++){let off=0;for(let j=0;j<3;j++)if(i!==j)off+=Math.abs(Q[i].reduce((sum,v,k)=>sum+v*Q[j][k],0));qmax2=Math.max(qmax2,Q[i].reduce((sum,v)=>sum+v*v,0)+off);}
 const lo=q.candidateSweep.bRange[0],K=Math.hypot(...p.K)+q.candidateSweep.KRadius;
 // Same Q-aware lower scale as legacy scaleBounds; round toward smaller radius.
 const qmax=Math.sqrt(qmax2)+16*Number.EPSILON;
 const radius=template.rootBall.radiusLocal*(lo*sigmaMin(K/lo)/qmax);
 return Math.max(0,radius-32*Number.EPSILON*Math.max(1,radius));
}
function sphere(p,h,t){
 let qlo=Infinity,qhi=0;for(let i=0;i<3;i++){let off=0;for(let j=0;j<3;j++)if(i!==j)off+=Math.abs(p.Qcolumns[i].reduce((s,v,k)=>s+v*p.Qcolumns[j][k],0));const diag=p.Qcolumns[i].reduce((s,v)=>s+v*v,0);qlo=Math.min(qlo,diag-off);qhi=Math.max(qhi,diag+off);}
 const k=Math.hypot(...p.K)/p.b,min=p.b*sigmaMin(k)/Math.sqrt(qhi),max=p.b*sigmaMax(k)/Math.sqrt(qlo),r=6*min-positionGuard(p);
 return{headID:h.id,center:forward(p,h.centerLocal),radius:r,resolved:2*r>=4*t.domain.pitch*max+2*positionGuard(p)};
}
export function endpointTest(metadata,child,old){
 if(child.Aseed!==1)return{pass:false,reason:'seed-not-established',nodes:0};
 return prepareEndpoint(metadata,old.map(sweep))(sweep(child),6);
}
export function captureOld(model,old){
 if(model.time!==model.tick*model.dt||model.previousTime!==model.time-model.dt)throw Error('Observation capture is not a complete source barrier');
 const ids=old.map(p=>p.ID),expected=model.oldMembers().map(p=>p.ID);if(ids.length!==expected.length||ids.some((v,i)=>v!==expected[i]))throw Error('Incomplete frozen all-old identity set');if(new Set(ids).size!==ids.length||ids.length>8)throw Error('Invalid frozen old membership');
 const members=[];
 for(const p of old){
  const current=model.current.find(a=>a.active&&a.ID===p.ID);
  if(!current)throw Error('Unsupported previous-only-positive old member '+p.ID);
  const prior=model.previous[current.slot],previousPositive=prior.active&&prior.ID===p.ID&&!model.zero(prior,model.previousTime);
  for(const k of ['C','u','K','root'])if(p[k].some((v,i)=>!Object.is(v,current[k][i])))throw Error('Old capture does not use exact current pose');
  if(p.mu!==current.mu||p.tau!==current.tau||p.b!==current.b||p.Aseed!==current.Aseed||p.g!==current.g||p.s!==current.s||p.born!==current.born||p.templateID!==current.templateID||p.role!==current.role||p.Qcolumns.some((c,j)=>c.some((v,i)=>!Object.is(v,current.Qcolumns[j][i]))))throw Error('Old response time/frame mismatch');
  members.push({localID:p.ID,slot:current.slot,stateOrigin:'current',captureTime:model.time,currentStateTime:model.time,previousStateTime:model.previousTime,captureTick:model.tick,previousPositive,currentZero:model.zero(current,model.time),inclusion:model.zero(current,model.time)?'current-with-previous-positive':'current-nonzero'});
 }
 // Assert the defensive legacy previous-only branch is unreachable, never silently omit it.
 for(const p of model.previous)if(p.active&&!model.zero(p,model.previousTime)&&!model.current.some(c=>c.active&&c.ID===p.ID))throw Error('Unsupported previous-only-positive producer state '+p.ID);
 return members;
}
const directions=[];for(let z=-1;z<=1;z++)for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++){const n=Math.hypot(x,y,z);directions.push(n?[x/n,y/n,z/n]:[0,0,0]);}
export function observedEndpoint(metadata,child,old,assets){
 const result=endpointTest(metadata,child,old);if(result.pass)return{outcome:'exposed',exterior:result,nativeQueries:0};
 const heads=[],t=metadata.templates['crown-b'];let nativeQueries=0;
 for(const h of t.headWitnesses){
  const s=sphere(child,h,t);let witness=null;
  if(s.resolved)for(const direction of directions){const x=s.center.map((v,k)=>v+.95*s.radius*direction[k]);for(const p of old){nativeQueries++;const lower=potentialLower(p,x,assets[p.templateID]);if(lower>.005){witness={oldID:p.ID,point:x,qLower:lower,definition:'native-cell-corner-lower'};break;}}if(witness)break;}
  heads.push({...s,witness});
 }
 return{outcome:heads.every(h=>h.resolved&&h.witness)?'occluded':'uncertified',exterior:result,heads,nativeQueries};
}
export function summarizeDeclines(sites){
 const kinds=[...new Set(sites.map(s=>s.reason))],reason=kinds.length===1?({'held-exterior-uncertified':'held-endpoint-not-certified'}[kinds[0]]??kinds[0]):kinds.length?'mixed-forecast-decline':'no-attachment-safe-candidate';
 const siteReasonCounts={};for(const site of sites)siteReasonCounts[site.reason]=(siteReasonCounts[site.reason]??0)+1;
 return{reason,siteReasonCounts};
}
export class ObservedPolicy {
 constructor(model,options){
  if(model.admission.templates['crown-b'].headWitnesses.some(h=>h.qMin<.041))throw Error('Observed heads lack declared .041 field facts');
  if(options.policyID!==POLICY_ID||model.dt!==H||!options.nativeAssets?.body||!options.nativeAssets?.['crown-b'])throw Error('Observed policy configuration/native inputs missing');
  this.model=model;this.options=options;this.pins=freeze(structuredClone(options.pins??null));this.assets=options.nativeAssets;this.latest=null;this.previousSnapshot=null;this.latestDetail=null;this.lastPrediction=null;
  for(const[id,a]of Object.entries(options.nativeAssets)){const d=model.templates[id]?.domain;if(!d||a.density.byteLength!==d.dims.reduce((x,y)=>x*y,1)*2||a.distance.byteLength!==a.density.byteLength||a.pitch!==d.pitch||a.origin.some((v,k)=>v!==d.origin[k])||a.span.some((v,k)=>v!==d.span[k]))throw Error('Native input domain mismatch '+id);}
  this.stats={opportunities:0,weatherSkipped:0,capacityFailed:0,noParent:0,forecastDeclined:0,births:0,exposed:0,occluded:0,uncertified:0,weatherCancelled:0,invalid:0,predictionPoseSteps:0,forecastHealthChecks:0,declineReasons:{},siteDeclineCounts:{},predictionNodes:0,observationNodes:0,nativeQueries:0,referenceSteps:0};
 }
 opportunity(){this.stats.opportunities++;this.lastPrediction=null;captureOld(this.model,this.model.oldMembers());}
 beforeStep(){this.previousSnapshot=this.raw();}
 choose(parent,build,scale,controls,old){
  const m=this.model,metadata=m.admission,provenance=captureOld(m,old),predOld=old.map(geometry),profile=makeHealthyProfile();
  const ran=(p,options={})=>{const r=forecast(p,controls,m.time,metadata,{...options,profile});this.stats.predictionPoseSteps+=r.poseSteps;this.stats.forecastHealthChecks+=r.healthChecks;return r.healthy;};
  for(const p of predOld)ran(p);
  const predParent=geometry(parent),healthyParent=ran(predParent,{health:true,region:m.region});
  if(!healthyParent){this.lastPrediction=freeze({time:m.time,pass:false,reason:'held-parent-weather-unqualified',sites:[]});this.stats.declineReasons['held-parent-weather-unqualified']=(this.stats.declineReasons['held-parent-weather-unqualified']??0)+1;return{pass:false,reason:'held-parent-weather-unqualified',nodes:0};}
  let endpointQuery=null;
  const candidates=spatial.candidatePoses({metadata,parent:m.normalizePose(parent),scale,startIndex:m.billowOrdinal});let nodes=0;const sites=[];const recordSite=(entry)=>{sites.push(entry);this.stats.siteDeclineCounts[entry.reason]=(this.stats.siteDeclineCounts[entry.reason]??0)+1;};
  for(const c of candidates){
   const child=build(c.Qcolumns,c.Cbirth,parent.ID),velocity=fullVelocity(parent,c.siteGlobal,controls),W=windAt(c.Cbirth[1],controls);child.u=velocity.map((v,i)=>v-W[i]);
   const q=m.prospective(parent,c.site,child,scale,'BILLOW',old),root=guardedRootRadius(q,metadata.templates['crown-b']),neck=Math.min(q.parentRadiusWorldLower,root,(q.parentRadiusWorldLower+root-q.rootSeparationMax)/2);
   if(!q.parentLossFree||q.rootSeparationMax>11+1e-6||q.parentRadiusWorldLower<q.rootSeparationMax+q.seedRadiusWorldUpper||neck<16){recordSite({siteID:c.siteID,reason:'safe-attachment-declined'});continue;}
   const predicted=geometry(child),healthy=ran(predicted,{health:true});
   if(!healthy){recordSite({siteID:c.siteID,reason:'held-child-weather-unqualified'});continue;}
   const exterior=predicted.Aseed===1?(endpointQuery??=prepareEndpoint(metadata,predOld.map(sweep)))(sweep(predicted),6):{pass:false,reason:'seed-not-established',nodes:0};nodes+=exterior.nodes;
   if(exterior.pass){this.lastPrediction=freeze({time:m.time,pass:true,siteID:c.siteID,headID:exterior.headID,sites});this.stats.predictionNodes+=nodes;return{pass:true,...c,certificate:{parentRadiusWorldLower:q.parentRadiusWorldLower,rootSeparationMax:q.rootSeparationMax,seedRadiusWorldUpper:q.seedRadiusWorldUpper,parentLossFree:true,exterior:{...exterior,siteID:c.siteID},placement:'predicted-held-controls'},prediction:{controls:{...controls},forcingRevision:m.committedRevision,endpoint:m.time+45,child:geometry(predicted),old:predOld.map(geometry),provenance,headID:exterior.headID},nodes};}
   recordSite({siteID:c.siteID,reason:'held-exterior-uncertified',failures:exterior.failures});
  }
  this.stats.predictionNodes+=nodes;const {reason,siteReasonCounts}=summarizeDeclines(sites);
  this.stats.declineReasons[reason]=(this.stats.declineReasons[reason]??0)+1;this.lastPrediction=freeze({time:m.time,pass:false,reason,siteReasonCounts,sites});return{pass:false,reason,nodes};
 }
 start(child,old,chosen){
  const m=this.model;if(m.referenceLease)throw Error('Overlapping observation leases');this.stats.births++;
  return{kind:POLICY_ID,childID:child.ID,parentID:child.parentID,birthTick:m.tick,birthTime:m.time,deadline:m.time+45,referenceTime:m.time,lastAdvancedTick:m.tick,IDs:old.map(p=>p.ID),parts:old.map(geometry),provenance:chosen.prediction.provenance,prediction:chosen.prediction,cancelled:null};
 }
 advance(t,h,c){
  const l=this.model.referenceLease;if(!l)return;
  if(l.kind!==POLICY_ID||l.referenceTime!==t||l.lastAdvancedTick!==this.model.tick-1)throw Error('Observation reference time/interval mismatch');
  for(const p of l.parts)advanceReference(p,c,t,h);l.referenceTime=t+h;l.lastAdvancedTick=this.model.tick;this.stats.referenceSteps+=l.parts.length;
 }
 afterMonitor(){
  const m=this.model,l=m.referenceLease;if(!l)return;
  const child=m.current.find(p=>p.active&&p.ID===l.childID);
  if(!l.cancelled&&(!child||child.establishment==='cancelled'))l.cancelled={time:m.time,reason:m.events.findLast(e=>e.type==='establishment-cancelled'&&e.ID===l.childID)?.reason??'actual-child-retired'};
  if(m.time<l.deadline-EPS)return;
  if(m.time!==l.deadline||l.referenceTime!==m.time||l.lastAdvancedTick!==m.tick)throw Error('Unaligned observation deadline');
  let result;if(l.cancelled)result={outcome:'weather-cancelled',cancellation:l.cancelled};else if(!child||child.Aseed!==1||child.maxE!==0||m.ageE(child)!==0)result={outcome:'invalid',reason:'actual-positive-head-assumptions-missing'};else result=observedEndpoint(m.admission,child,l.parts,this.assets);
  const key={'weather-cancelled':'weatherCancelled'}[result.outcome]??result.outcome;this.stats[key]++;this.stats.observationNodes+=result.exterior?.nodes??0;this.stats.nativeQueries+=result.nativeQueries??0;
  this.latestDetail=freeze({identityScope:'model-instance',cellID:m.cellId,localID:l.childID,parentLocalID:l.parentID,birthTick:l.birthTick,birthTime:l.birthTime,time:m.time,referenceTime:l.referenceTime,referenceIDs:[...l.IDs],provenance:structuredClone(l.provenance),prediction:structuredClone(l.prediction),actualChild:child?geometry(child):null,actualReferences:l.parts.map(geometry),forcingRevision:m.committedRevision,...result});
  this.latest=freeze({identityScope:'model-instance',cellID:m.cellId,localID:l.childID,birthTick:l.birthTick,birthTime:l.birthTime,time:m.time,referenceTime:l.referenceTime,referenceIDs:[...l.IDs],outcome:result.outcome,predictedHeadID:l.prediction.headID,observedHeadID:result.exterior?.headID??null,forcingRevision:m.committedRevision,cancellation:l.cancelled});
  m.event('growth-observed',{ID:l.childID,outcome:result.outcome,predictedHeadID:l.prediction.headID,observedHeadID:result.exterior?.headID??null});m.referenceLease=null;
 }
 raw(){const l=this.model.referenceLease;return freeze({policyID:POLICY_ID,configurationPins:this.pins,identityScope:'model-instance',stats:{...this.stats,declineReasons:{...this.stats.declineReasons},siteDeclineCounts:{...this.stats.siteDeclineCounts}},statsTime:this.model.time,latest:this.latest,pending:l?{cellID:this.model.cellId,localID:l.childID,birthTick:l.birthTick,birthTime:l.birthTime,deadline:l.deadline,referenceTime:l.referenceTime,referenceIDs:[...l.IDs]}:null});}
 publication(time,epoch){const raw=time<this.model.time-EPS?(this.previousSnapshot??this.raw()):this.raw();if(epoch===undefined)return raw;if(!Number.isSafeInteger(epoch)||epoch<0)throw Error('Observation qualification requires explicit valid epoch');const bind=r=>r?{...r,ID:JSON.stringify([epoch,r.cellID,r.localID]),referenceQualifiedIDs:r.referenceIDs.map(id=>JSON.stringify([epoch,r.cellID,id]))}:null;return freeze({...raw,identityScope:'clock-qualified',epoch,latest:bind(raw.latest),pending:bind(raw.pending)});}
 receipt(){return this.latestDetail?structuredClone(this.latestDetail):null;}
 interruption(reason,namespace){if(!namespace)throw Error('Offline interruption requires explicit test namespace');const l=this.model.referenceLease;return l?{namespace,identityScope:'explicit-test-namespace',cellID:this.model.cellId,localID:l.childID,birthTick:l.birthTick,time:this.model.time,outcome:'interrupted',reason}:null;}
}
