# First-run source cost result

Both unchanged4ms whole-step-plus-publication maximum protocols PASS. Root selected source91b967 for subsequent fresh optical integration only. The two-dry maximum3.979667ms leaves20.333µs; this is narrow headroom, not production/device admission. No reruns or tails were removed.

| Case | Legacy max ms | Observed max ms | Observed p99 ms |
|---|---:|---:|---:|
| single-wet1200 | 1.831625 | 1.868791 | 0.230917 |
| single-dry900 | 1.993375 | 2.678500 | 0.312583 |
| two-wet1200 | 2.738250 | 3.187666 | 0.430792 |
| two-dry900 | 3.201375 | 3.979667 | 0.531584 |

Original and supplement receipts/raw GC/durations remain separate. Sampled process-tree peaks were174,473,216B and168,755,200B under224MiB early/256MiB hard guards. The guard wrapper retains its generic functional-only scope label; timing gates are evaluated by the separately pinned cost scripts/receipts. No per-tail GC attribution is justified.

The shared lazy profile retains10,080scalar bytes plus180references,180row and180end objects; JS overhead/transient allocations are unmeasured. Cold construction is included in first observed70 whole-step results1.868791ms original/2.452500ms supplement, not measured in isolation. Native14,352,384B inputs remain shared once.

SOURCE-COPY-MAP.json pins all16source files; SOURCE-API.md defines the unchanged interfaces and on-demand causal capture. REVIEW.md records independent functional closure. COST-HANDOFF.json pins both evaluators, all8raw arrays, functional commands and limits. Prior failures and phaseUNRUN metadata are preserved. No current viewer was modified.
