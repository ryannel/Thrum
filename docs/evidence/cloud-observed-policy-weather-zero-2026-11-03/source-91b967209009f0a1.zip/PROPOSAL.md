# Held-front clear-weather earlyout — before implementation

Separate exact candidate;12777301/results stay unchanged. No timing until independent review/root grant. Existing outputs, logical counters, decisions, sites/cadence/thresholds and originalb4d2+supplementabc99/4ms gates stay unchanged.

## One remaining-window bound, in front-relative X

Attempt once per forecast, lazily **after the first original needMid/matrix succeeds and that full step completes**. The starting state is then current p/R at a real quarter barrier; BODY override has made p.C==R/u0. A failed proof leaves the original path for all remaining steps. No per-point revalidation or temporal subdivision is selected. The proof is local to that owned synchronous forecast; no global/state/slot cache.

Let remaining T<=45, d=.125, F(t)=frontX+frontSpeed*(t-frontStart)+width/2 (extend line before activation). Source queries health at midpoint geometry but end-of-step weather, and growthTarget at start position but midpoint weather. Certify the stronger whole-window bound with front shifted by d:

`relativeCenterLower = Cx0-F(now) + T*min(vMin-frontSpeed,0) - frontSpeed*d`.

This covers every queried center/native point at elapsed t in[0,T] against F(now+t+d); it deliberately includes unused endpoints. It retains forward center drift rather than comparing initial Cx to the final edge.

For generic motion, use uyAbs=max(abs(uy0),abs(roleTarget)), Ylo/hi=Cy0 +/-uyAbs*(T+.25), and

`vMin=meanX + min(Sx*(Ylo-1500),Sx*(Yhi-1500)) + min(ux0,0)`.

This follows directly from discrete advancePose: `10*(1-exp(-h/10))` lies in[0,h], and `10*(h-10*(1-exp(-h/10)))` lies in[0,.5h²] for h=.25/.125. Thus vertical displacement and averaged intY obey that Y envelope; the ux convolution factor lies in[0,h]. Check those inequalities on the actual runtime exponential constants. Add the explicit FP reserve below. BODY/R uses exact current regionAdvance wind for vMin and requires p.C==R/u0 at proof entry; no proof if those invariants fail. This avoids the first pre-override root-target mismatch.

With G=1+1024*Number.EPSILON, bound b in[0,s*G] and Kx between `Kx0+min(0,Sx*s*T*G)` and the corresponding max, expanded by its roundoff allowance. Growth/simpson weights are nonnegative and <=G; actual growth response need not be assumed wet to obtain these bounds.

For fixed exact numerical dual D (the successful original matrix's dual), native X-offset is

`h(b,K)=sum_j min((b*D[j][0]+K*D[j][1])*(origin[j]-root[j]), (b*D[j][0]+K*D[j][1])*(origin[j]+span[j]-root[j]))`.

This is concave piecewise-linear in b/K; minimum on the rectangle is bounded by its four vertex values. Subtract proof/arithmetic reserve. Require `relativeCenterLower + minOffset > 1e-7 + FP_RESERVE` strictly. Then original minX−1e-7 lies beyond the original monotone front right edge for every remaining health test, so dryAt is exactly0. If root lies inside the native domain too, the same all-time domain bound covers source-root start geometry against midpoint weather; with moist/lift true target1 is exact. Otherwise keep original root target (health earlyout only).

## Useful domain and numerical allowance

Guard ordinary finite arrays/scalars: abs(C)<=65536m, abs(u)<=16m/s, abs(Kx)<=8, s in4/5/6, local root/domain endpoints abs<=1024m, positive spans, abs(dual entries)<=2, actual held controls within admitted mean/shear/uplift/front ranges, T<=45 and quarter-aligned times. Outside/failed frame ownership/validation: no proof. Q/root/domain/held controls are fixed owned/pinned data throughout the synchronous forecast; never reuse proof after a new forecast or input mutation.

The real-shadow bound uses actual binary64 exp constants, not ideal ODE integration. Useful bounds give abs(C)<=75000 over the window; native offset terms<2^18m, front terms<2^19m. A conservative expanded absolute-monomial/dependency bound is2^26m and at most8192 relevant arithmetic operations over180 full/half updates plus proof/support arithmetic: gamma8192*2^26<6.2e-5m. Reserve **.01m** (not an opacity/shape tolerance) covers source/bound/support/front arithmetic with ample slack; K rectangle separately expanded by gamma8192*(abs(K0)+abs(Sx*s*T*G)+1). The existing1e-7 is additional. Nonfinite, inequality or range failure declines the proof, never the forecast. This is a sufficient clear certificate, not a changed loss rule or arbitrary-future trajectory theorem.

Construction is constant work: <=4support corners*3axes plus scalar bounds/checks, once after first successful required midpoint; remaining steps skip only redundant midpoint/zero-dry work while full poses and logical step/health counters still advance identically. No recursive interval machinery or new field scan. Root substitution requires true moist/lift and rootCovered flag. Tests compare every original180 midpoint decision AND root target whenever proof succeeds, with boundary/negative-wind/S signs/BODY overrides/mutations. State/output differentials all6+twoDry remain strict againstf57.

## Shared profile

makeHealthyProfile lazily constructs the same180 deeply frozen rows once per module/provider, only on observed-mode demand; legacy-only source never calls it. It depends only on fixed math constants/role, not scale, pose, controls, IDs or metadata; scale multiplication/guards stay as before. First observed opportunity includes cold construction in the unchanged evaluator. Charge180 rows (~11,520B scalar payload plus JS objects/arrays), no per-cell duplication. Tests verify all bits, identity/deep freeze, guard fallbacks and legacy zero-allocation state. No source/epoch/lifecycle authority is added.
