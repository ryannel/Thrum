import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {SourceModel,DEFAULT_CONTROLS} from '../../src/source/model.js';
const metadata=JSON.parse(await readFile(new URL('../../../cloud-system-admission/admission.json',import.meta.url)));
const model=new SourceModel({admissionMetadata:metadata},{...DEFAULT_CONTROLS,dryGain:0});
for(let i=0;i<16;i++){model.step();assert.ok(model.current.some(p=>p.active&&p.ID===1),'newborn seed must survive0..4s');}
assert.equal(model.current.find(p=>p.ID===1).Aseed,1);
while(model.time<1200)model.step();
console.log(JSON.stringify({time:model.time,stats:model.stats,events:model.events.slice(-12)},null,2));
