from pathlib import Path
import argparse,json,hashlib,resource,platform,time,threading,os,subprocess,gc,math
import numpy as np
from scipy import ndimage as ndi
R=Path(__file__).resolve().parent;INPUT=R.parent/'cloud-component-content-v2';FROZEN_SHA='dbb633512b543f74016a023080b6c64a00bb6d14fa898ff596ca032bd0a24d8c';LIMIT=256*1024**2;DONE=False

def sha(p):
 with open(p,'rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def watch():
 while not DONE:
  try:
   rss=int(subprocess.check_output(['ps','-o','rss=','-p',str(os.getpid())]).strip())*1024
   if rss>LIMIT:
    (R/f'cost-failure-{os.getpid()}.json').write_text(json.dumps({'rssBytes':rss,'limitBytes':LIMIT}));os._exit(72)
  except Exception:pass
  time.sleep(.1)
threading.Thread(target=watch,daemon=True).start()
def smooth(x):
 x=np.clip(x,0,1);return x*x*(3-2*x)
def verify(name):
 assert sha(INPUT/'FROZEN-INPUTS.json')==FROZEN_SHA
 frozen=json.loads((INPUT/'FROZEN-INPUTS.json').read_text());m=json.loads((INPUT/(name+'.json')).read_text())
 for n in [name+'.json',name+'.density.r16f',name+'.distance.r16f']:
  p=INPUT/n;assert p.stat().st_size==frozen['files'][n]['bytes'] and sha(p)==frozen['files'][n]['sha256']
 shape=tuple(m['dimensions_xyz'][::-1]);rho=np.memmap(INPUT/m['density']['file'],mode='r',dtype='<f2',shape=shape);d=np.memmap(INPUT/m['distance']['file'],mode='r',dtype='<f2',shape=shape)
 return m,rho,d

def cells(rho,d,name):
 shape=tuple(np.array(rho.shape)-1);lower=np.memmap(R/(name+'.lower.f32'),mode='w+',dtype='<f4',shape=shape);occ=np.zeros(shape,bool)
 for z in range(shape[0]):
  rr=rho[z:z+2].astype('f4');dd=d[z:z+2].astype('f4');corners=[rr[k,j:j+shape[1],i:i+shape[2]]for k in[0,1]for j in[0,1]for i in[0,1]];dc=[dd[k,j:j+shape[1],i:i+shape[2]]for k in[0,1]for j in[0,1]for i in[0,1]]
  lower[z]=np.minimum.reduce(corners)*smooth((np.minimum.reduce(dc)+8)/16);occ[z]=np.maximum.reduce(corners).astype('f8')*smooth((np.maximum.reduce(dc).astype('f8')+8)/16)>.005-1e-9
 lower.flush();return lower,occ

def box(mask,lo,hi):
 sub=mask[lo[0]:hi[0],lo[1]:hi[1],lo[2]:hi[2]]
 if not sub.any():return None
 a=[];b=[]
 for k in range(3):
  line=np.any(sub,axis=tuple(i for i in range(3)if i!=k));ids=np.flatnonzero(line);a.append(lo[k]+int(ids[0]));b.append(lo[k]+int(ids[-1])+1)
 return a,b

def bvh(mask,origin):
 initial=box(mask,[0,0,0],list(mask.shape));assert initial is not None,'empty support';leaves=[initial]
 # Split the largest conservative occupied bounding volume; no list is silently truncated.
 while len(leaves)<128:
  candidates=sorted(range(len(leaves)),key=lambda i:np.prod(np.subtract(leaves[i][1],leaves[i][0])),reverse=True);split=False
  for i in candidates:
   lo,hi=leaves[i];length=np.subtract(hi,lo);axes=np.argsort(length)[::-1]
   for ax in axes:
    if length[ax]<=1:continue
    mid=(lo[ax]+hi[ax])//2;left_hi=hi.copy();left_hi[ax]=mid;right_lo=lo.copy();right_lo[ax]=mid;a=box(mask,lo,left_hi);b=box(mask,right_lo,hi)
    if a is not None and b is not None:leaves[i:i+1]=[a,b];split=True;break
   if split:break
  if not split:break
 nodes=[]
 def add(items):
  i=len(nodes);nodes.append(None);lo=np.min([x[0]for x in items],axis=0);hi=np.max([x[1]for x in items],axis=0)
  # Cell i covers [origin+1+2i,origin+3+2i]; include both native vertices.
  n={'lo':(np.array(origin)+(lo[::-1]*2+1)).tolist(),'hi':(np.array(origin)+(hi[::-1]*2+1)).tolist(),'left':-1,'right':-1}
  if len(items)>1:
   ax=int(np.argmax(hi-lo));items=sorted(items,key=lambda x:x[0][ax]+x[1][ax]);cut=len(items)//2;n['left']=add(items[:cut]);n['right']=add(items[cut:])
  nodes[i]=n;return i
 add(leaves);assert len(nodes)<=255
 # The partition covers all occupied cells exactly once (coarse boxes may also cover empty cells).
 covered=0
 for lo,hi in leaves:covered+=int(mask[lo[0]:hi[0],lo[1]:hi[1],lo[2]:hi[2]].sum())
 assert covered==int(mask.sum())
 return {'threshold':.005,'definition':'cell upper=max(decoded rho corners)*smoothstep(-8,8,max(decoded d corners)); occupied iff float64 upper>.005−1e-9 safety guard; loss-free A<=1; outside domain zero','root':0,'leafCount':len(leaves),'occupiedCells':int(mask.sum()),'nodes':nodes}

def ball(good,p,origin):
 p=np.array(p,float);origin=np.array(origin,float);nx=good.shape[2];ny=good.shape[1];cx=origin[0]+2*(np.arange(nx)+1);cy=origin[1]+2*(np.arange(ny)+1);dx=np.maximum(np.abs(cx-p[0])-1,0)**2;dy=np.maximum(np.abs(cy-p[1])-1,0)**2;best=math.inf;closest=None
 for z in range(good.shape[0]):
  bad=~good[z]
  if not bad.any():continue
  cz=origin[2]+2*(z+1);dd=dx[None,:]+dy[:,None]+max(abs(cz-p[2])-1,0)**2;dd[~bad]=np.inf;k=int(dd.argmin());v=float(dd.flat[k])
  if v<best:
   best=v;y,x=divmod(k,nx);c=np.array([cx[x],cy[y],cz]);closest=np.minimum(np.maximum(p,c-1),c+1)
 low=origin+1;high=origin+2*np.array(good.shape[::-1])+1;edges=np.r_[p-low,high-p];edge=float(edges.min());radius=max(0,min(math.sqrt(best),edge)-.001)
 if closest is None or edge<math.sqrt(best):
  closest=p.copy();k=int(edges.argmin());closest[k%3]=(low if k<3 else high)[k%3]
 return radius,(closest-p).tolist()

def frame(up):
 up=np.array(up,float);up/=np.linalg.norm(up);right=np.cross(up,[0,0,1.]);right/=np.linalg.norm(right);forward=np.cross(right,up);return [right.tolist(),up.tolist(),forward.tolist()]

def sites(good,origin,meta):
 fixed=meta['shoulder_catalogue'];out=[]
 for s in fixed[:2]:
  r,_=ball(good,s['root_global_xyz_m'],origin);assert r>=7
  out.append({'id':s['id'],'local':s['root_global_xyz_m'],'positiveRadiusLocal':r,'qMin':.041,'desiredFrameColumns':s['desired_crown_world_frame_columns'],'selection':'frozen held site, unchanged'})
 y0=max(0,int((224-origin[1])/2)-1);y1=min(good.shape[1],int((282-origin[1])/2));band=good[:,y0:y1,:];dist=ndi.distance_transform_edt(np.pad(band,1),sampling=2)[1:-1,1:-1,1:-1].astype('f4');cert=dist-np.sqrt(3)-.001;Y=origin[1]+2*(np.arange(y0,y1)+1);eligible=band&(cert>=7.1)&(Y[None,:,None]>=242)
 for j in range(2,8):
  best=None
  for z in range(band.shape[0]):
   yy,xx=np.nonzero(eligible[z]);
   if not len(xx):continue
   X=origin[0]+2*(xx+1);YY=Y[yy];Z=np.full(len(xx),origin[2]+2*(z+1));score=np.full(len(xx),np.inf)
   for prior in out:
    a=prior['local'];score=np.minimum(score,(X-a[0])**2+(YY-a[1])**2+(Z-a[2])**2)
   # Maximin first, deterministic preference for higher shoulder then coordinate order.
   k=int(np.argmax(score+YY*.001));value=float(score[k]+YY[k]*.001)
   if best is None or value>best[0]:best=(value,[float(X[k]),float(YY[k]),float(Z[k])])
  if best is None:break
  _,p=best;r,n=ball(good,p,origin);assert r>=7;n=np.array(n);n/=max(np.linalg.norm(n),1e-30);up=[n[0],max(n[1],1.),n[2]]
  if min(np.linalg.norm(np.array(p)-np.array(s['local']))for s in out)<12:break
  out.append({'id':f'body-admission-{j}','local':p,'positiveRadiusLocal':r,'qMin':.041,'desiredFrameColumns':frame(up),'outwardGuide':n.tolist(),'selection':'upper-band certified radius>=7.1; maximin distance to previous sites; deterministic coordinates, no camera'})
 assert 4<=len(out)<=8,'not enough distinct certified BODY sites';return out

def heads(good,origin,meta):
 dist=ndi.distance_transform_edt(np.pad(good,1),sampling=2)[1:-1,1:-1,1:-1].astype('f4');radii=dist-np.sqrt(3)-.001;eligible=good&(radii>=6.05);shape=good.shape;root=np.array(meta['root_global_xyz_local_m']);start_xyz=np.rint((root-np.array(origin))/2-1).astype(int);start=tuple(start_xyz[::-1]);assert eligible[start]
 size=int(np.prod(shape));parent=np.full(size,-2,'i4');queue=np.empty(size,'i4');startflat=int(np.ravel_multi_index(start,shape));queue[0]=startflat;parent[startflat]=-1;tail=1;head=0;flat=eligible.ravel();nz,ny,nx=shape;stride=nx*ny
 while head<tail:
  u=int(queue[head]);head+=1;z,rem=divmod(u,stride);y,x=divmod(rem,nx)
  for valid,v in[(x>0,u-1),(x+1<nx,u+1),(y>0,u-nx),(y+1<ny,u+nx),(z>0,u-stride),(z+1<nz,u+stride)]:
   if valid and flat[v] and parent[v]==-2:parent[v]=u;queue[tail]=v;tail+=1
 connected=parent.reshape(shape)!=-2;F=np.array(meta['root_to_crown_frame']['root_to_crown_orthoframe_columns']).T;chosen=[]
 primary=np.array(meta['head_certificate']['head_global_xyz_local_m']);yy=origin[1]+2*(np.arange(ny)+1);xx=origin[0]+2*(np.arange(nx)+1)
 def choose(direction,minimum_up):
  best=None
  for z in range(nz):
   iy,ix=np.nonzero(connected[z]);
   if not len(ix):continue
   X=xx[ix];Y=yy[iy];Z=np.full(len(ix),origin[2]+2*(z+1));up=(X-root[0])*F[0,1]+(Y-root[1])*F[1,1]+(Z-root[2])*F[2,1];score=(X-root[0])*direction[0]+(Y-root[1])*direction[1]+(Z-root[2])*direction[2];score[up<minimum_up]=-np.inf
   for a in chosen:score[(X-a[0])**2+(Y-a[1])**2+(Z-a[2])**2<10**2]=-np.inf
   k=int(np.argmax(score))
   if np.isfinite(score[k])and(best is None or score[k]>best[0]):best=(float(score[k]),[float(X[k]),float(Y[k]),float(Z[k])],int(np.ravel_multi_index((z,int(iy[k]),int(ix[k])),shape)))
  assert best is not None,'no distinct resolved head patch';return best[1],best[2]
 # Upper pole and two lateral upper patches precede the dense central head.
 head_specs=[]
 for direction in[F[:,1],F[:,0]+.35*F[:,1],-F[:,0]+.35*F[:,1],F[:,2]+.35*F[:,1]]:
  p,index=choose(direction,20);chosen.append(p);head_specs.append((p,index))
 out=[];root_ball,_=ball(good,root,origin)
 for j,(p,index)in enumerate(head_specs):
  path=[];u=index
  while u>=0:
   z,rem=divmod(u,stride);y,x=divmod(rem,nx);path.append([origin[0]+2*(x+1),origin[1]+2*(y+1),origin[2]+2*(z+1)]);u=int(parent[u])
  path=list(reversed(path));balls=[{'centerLocal':root.tolist(),'radiusLocal':root_ball,'qMin':.041}];position=0
  while position<len(path):
   previous=balls[-1];best=None
   for k in range(position,len(path)):
    c=path[k];z=int((c[2]-origin[2])/2-1);y=int((c[1]-origin[1])/2-1);x=int((c[0]-origin[0])/2-1);r=float(radii[z,y,x]);
    if np.linalg.norm(np.array(c)-previous['centerLocal'])<=previous['radiusLocal']+r-.02:best=(k,c,r)
   assert best is not None,'disconnected chain';k,c,r=best;balls.append({'centerLocal':c,'radiusLocal':r,'qMin':.041});position=k+1
   assert len(balls)<=16,'root-head chain exceeds16 balls'
  actual,_=ball(good,p,origin);assert actual>=6
  out.append({'id':f'head-{j}','centerLocal':p,'radiusLocal':actual,'resolvedSubballRadiusLocal':6.,'qMin':.041,'chain':balls,'selection':['upper pole','upper right','upper left','upper forward'][j]})
 return out

def prepare(name):
 meta,rho,d=verify(name);origin=meta['domain_origin_global_xyz_local_m'];lower,occ=cells(rho,d,name);good=np.asarray(lower)>=.041;root=meta['root_global_xyz_local_m'];radius,_=ball(good,root,origin);result={'templateID':name,'domain':{'origin':origin,'span':meta['domain_span_local_m'],'dims':meta['dimensions_xyz'],'pitch':2},'rootLocal':root,'rootBall':{'centerLocal':root,'radiusLocal':radius,'qMin':.041},'support':bvh(occ,origin),'potentialSupport':meta['potential_support'],'endpointLocal':meta['finite_extinction']['endpoint_local_m'],'maxDecodedDLocal':meta['distance']['max_decoded_local_m'],'supportRadiusLocal':meta['potential_support']['conservative_radius_about_root_local_m'],'sourcePins':{'metadata':{'file':name+'.json','sha256':sha(INPUT/(name+'.json'))},**{k:meta[k]for k in['density','distance']}}}
 del occ;gc.collect()
 if name=='body':result['sites']=sites(good,origin,meta);result['wetCore']=meta['wet_core']
 else:result['assetFrameColumns']=meta['root_to_crown_frame']['root_to_crown_orthoframe_columns'];result['headWitnesses']=heads(good,origin,meta)
 result['proof']={'cellLowerSha256':sha(R/(name+'.lower.f32')),'cellShapeZYX':list(lower.shape),'processPeakRssBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'toolVersions':{'python':platform.python_version(),'numpy':np.__version__},'recipeSha256':sha(Path(__file__))};assert result['proof']['processPeakRssBytes']<=LIMIT
 (R/(name+'.prepared.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'template':name,'peak':result['proof']['processPeakRssBytes'],'supportLeaves':result['support']['leafCount'],'sites':len(result.get('sites',[])),'heads':[(v['centerLocal'],v['radiusLocal'],len(v['chain']))for v in result.get('headWitnesses',[])]}))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('stage',choices=['body','crown-b','assemble']);args=ap.parse_args()
 if args.stage=='assemble':
  out={'schemaVersion':1,'frozenInputsSha256':FROZEN_SHA,'preflightSha256':sha(R/'PREFLIGHT.md'),'recipeSha256':sha(Path(__file__)),'kappaPerWorldM':.019,'scope':'Offline conservative admission data only; optical q>0 uses original native field/potential bounds, never q>.005 BVH; content/runtime/art/cost acceptance separate','limits':{'maxSites':8,'maxOldReferences':8,'maxHeads':4,'maxLeaves':128,'maxNodes':255,'maxChainBalls':16,'leaseSeconds':45,'resolvedSubballRadiusLocal':6},'templates':{n:json.loads((R/(n+'.prepared.json')).read_text())for n in['body','crown-b']}};(R/'admission.json').write_text(json.dumps(out,indent=2)+'\n');print('admission.json',sha(R/'admission.json'))
 else:prepare(args.stage)
 DONE=True
