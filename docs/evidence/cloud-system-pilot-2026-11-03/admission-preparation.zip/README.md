# Prepared finite Cu admission data

Owner cloud_core_review. This directory contains the commissioned source-pinned metadata producer and pure geometry helpers for the integrated liquid-Cu pilot. It changes no density/distance/κ and owns no clock, forcing, renderer, GPU resource or source state. Source content is provisionally selected by root; actual lifecycle appearance remains a separate motion gate.

## Frozen handoff

- `admission.json`: SHA256 `5ae9c1152d720d8fd6ae00fb2a74f02d477400898c12cd348e5c99314b127697`.
- `admission.js`: SHA256 `86b8ef7e852c62c8300d05eb22764956ce5e3a24c120180042ab1662c8e5101e`.
- Inputs: `../cloud-component-content-v2/FROZEN-INPUTS.json`, SHA256 `dbb633512b543f74016a023080b6c64a00bb6d14fa898ff596ca032bd0a24d8c`; four original native half payloads and two LOCAL metadata manifests pinned individually inside the output.

Copy the JSON to integrated `assets/admission/admission.json`. Source owner copies the helper byte-for-byte to its owned source path with provenance. Rendering never uses this BVH for q>0 bounds, field evaluation or optical culling. Its threshold isq>.005; the native check explicitly found2,102BODY and42B positive tail samples outside it. Render the original native q/d using exact full potential support/domain bounds.

Producer uses separate fresh BODY/B processes, a streamed Float32 lower-cell proof, bounded occupied-cell mask and one fixed upper-band/one B EDT. Measured process peaks are recorded in each prepared JSON (~204MB BODY/~134MB B), below256MiB plan. No3D coordinate list or per-birth field scan. `*.lower.f32` files are disposable reproduction/proof scratch and are not render dependencies.

## Schema

All `Local`/`local` coordinates are GLOBAL material coordinates in metres before subtracting each template domain origin. BODY compressionη=.6 is already baked. All inputs pitch2local metres; runtime b=s*g, B instances6/5 share one template. Reference taper halfwidth8local metres; κ=.019/worldmetre.

`templates[id]` contains:

- `domain {origin,span,dims,pitch}`, `rootLocal`, guarded `rootBall {centerLocal,radiusLocal,qMin:.041}`.
- `maxDecodedDLocal`, `endpointLocal`, `supportRadiusLocal`, and full `potentialSupport` for the source's conservative q>0 bounds.
- `support {threshold:.005,root:0,leafCount,nodes}`. Each node has `lo,hi,left,right` in local metres. A leaf has both children−1. Each template has128leaves/255nodes. Occupancy uses separate trilinear cell maxima `maxrho*smoothstep(-8,8,maxd)` in Float64 with1e-9q safety slack, not interpolation of native q products. Merging boxes may conservatively fill holes.
- Source and recipe pins plus measured preparation cost.

BODY has8sites in fixed order `{id,local,positiveRadiusLocal,qMin,desiredFrameColumns}`. The first two frozen held sites are unchanged. Six further sites maximize minimum spatial separation over the pinned dense upper band, with valid radius≥7.1localm. Actual exact radii are≥7.61m. Frames are world-owned fixed outward/upward authoring guides, not camera values or claims of a globally exact surface normal.

B has4distinct head patches (upper pole/right/left/forward), actual radius≥6.556m, each with a resolved6localm subball and a root-to-head chain of4–5overlapping positive balls. Chain/heads are selected only from the root-connected q>=.041 cell region supporting≥6.05m positive balls. No disconnected density island qualifies. Guarded ball radii cover actual separate rho/d sampling, not native product interpolation.

## Pure helper API

Canonical pose: `{templateID,ID,C[3],Qcolumns[3][3],b,K[3]}`. Ky=0, positive b, Q outer list=column vectors. Helpers use the actual field inverse `a=r+Qᵀ A⁻¹(X−C)` and its algebraic inverse; this remains conservative for tiny non-orthogonality in pinned frames rather than assuming perfect floating-point Q.

A sweep is `{pose,bRange:[min,max],KRadius,centerRadius}`. Pose is the nominal endpoint, bRange must enclose actual endpoint growth, KRadius bounds norm difference from its nominal K, centerRadius bounds world displacement from nominal C. ALL candidate and older nominal C must use the same frame with common mean-wind translation removed. Never pass b_now..scale blindly when the healthy endpoint growth is known; never assume mature support contains smaller-scale support.

- `candidatePoses({metadata,parent,scale,startIndex})` returns≤8fixed site/Q candidates, rotating catalogue order by startIndex; scale must be5or6.
- `chooseBillow({metadata,parent,time,scale,startIndex,prospect})` loops those candidates and invokes the source-owned pure `prospect(candidate)` callback.
- Callback returns `{candidateSweep,oldSweeps,parentRadiusWorldLower,rootSeparationMax,seedRadiusWorldUpper,parentLossFree:true}`. It must supply oldSweeps including the actual parent even for an attachment rejection. Parent is the newest qualified mature loss-free BODY, supplied by source. Loss-free/Aseed1 and future protected interval are source obligations; metadata does not infer current erosion from pixels.
- Return is `{pass,parentID,siteID,siteGlobal,Qcolumns,Cbirth,certificate,exteriorWitness}` or an explicit finite-catalogue rejection with reasons/work. No fallback site, threshold reduction or cadence change.
- `chooseBody({metadata,parent,rootR,prospect})` requires rootR equal actual parent.C, actual root/seed attachment bounds and loss-free parent; it does not demand global maturity.
- `certifyExterior({metadata,candidateSweep,oldSweeps,resolvedLocalRadius:6})` finds a positive resolved6m local head subball outside every older conservative support. Old-ID count≤8, unique IDs, no reference-only lease may enter membership. Checks transformed4-native-voxel diameter. Returns node work and witness or honest rejection.
- `supportExcludesBall` is the lower-level conservative query. Each old node is inflated for center uncertainty, growth interval and differential K over all its local corners. Maximum per birth8poses*8old*255nodes*4heads=65,280node visits; no mesh/volume query. CPU millisecond cost remains to be measured in the integrated source.
- `makeSweep` adds `.002*bMax*seconds` (or lower admitted shear) to K norm uncertainty; nominal future K must not already charge that same uncertainty. `relativeCenterGuard` bounds height-affine shear and internal horizontal decay with shared mean removed. Source must add correct endpoint vertical uncertainty and own its healthy forcing/growth constraints.

U_old membership, continuation and cancellation are source-owned. Freeze only actual contributing/publication-retained older IDs at birth; exclude reference-only histories. Continue immutable same-forcing counterfactual geometry≤45s after optical retirement; no Eweather volume is needed for a loss-free reference. Those CPU descriptors are not optical slots. Fifty-second B cadence supports at most one45s exposure certificate. Two fixed-view5%area/3Dreach are offline content/recipe cue tests, not camera-driven runtime policy.

## Verification and reproduction

```
/opt/homebrew/bin/python3.14 prepare.py body
/opt/homebrew/bin/python3.14 prepare.py crown-b
/opt/homebrew/bin/python3.14 prepare.py assemble
/opt/homebrew/bin/python3.14 check_native.py
node --test admission.test.mjs
```

Run from this directory. All5JS tests pass: source metadata/positive chains, rotated inverse and swept possible-occupancy rejection, exterior/uncertainty behavior, empty/missing/overflow/reused-reference rejection, and finite-catalogue honest failure. Native reference check streams planes, peak45,236,224B:337,928BODY+51,937B native samples above.005 are all covered;243BODY+594B sampled ball directions have minimum q.05597/.05905. These point checks supplement the conservative continuous cell/box construction; they are not a sampled theorem or GPU precision qualification.

Default1200s wet continuous-birth feasibility belongs to the source owner's integrated replay and must be reported before calling renewal complete. A catalogue count alone does not prove that its prospective uncertainty guards permit every birth. The supplied helpers must report rejection; no fake pass, silent list drop or motion/art acceptance follows from this metadata.
