// Pure geometry/admission. Source owns clocks, forcing, lifetime and reference membership.
export const LIMITS=Object.freeze({sites:8,old:8,heads:4,nodes:255,leaves:128,chain:16,lease:45});
const norm=a=>Math.hypot(...a),sub=(a,b)=>a.map((v,i)=>v-b[i]),add=(a,b)=>a.map((v,i)=>v+b[i]),dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const finite=(a,n)=>Array.isArray(a)&&a.length===n&&a.every(Number.isFinite);
function requireValue(ok,message){if(!ok)throw Error(message);}
export const sigmaMin=g=>(Math.sqrt(4+g*g)-Math.abs(g))/2;
export const sigmaMax=g=>(Math.sqrt(4+g*g)+Math.abs(g))/2;
function qBounds(Q){
 requireValue(Array.isArray(Q)&&Q.length===3&&Q.every(v=>finite(v,3)),'Qcolumns missing/nonfinite');let lo=Infinity,hi=0;
 for(let i=0;i<3;i++){let off=0;for(let j=0;j<3;j++)if(i!==j)off+=Math.abs(dot(Q[i],Q[j]));lo=Math.min(lo,dot(Q[i],Q[i])-off);hi=Math.max(hi,dot(Q[i],Q[i])+off);}
 requireValue(lo>.999&&hi<1.001,'Qcolumns must be orthogonal');return{min:Math.sqrt(lo),max:Math.sqrt(hi)};
}
export function validatePose(p){requireValue(p&&typeof p.templateID==='string'&&finite(p.C,3)&&finite(p.K,3)&&Number.isFinite(p.b)&&p.b>0,'Missing/nonfinite pose');requireValue(Math.abs(p.K[1])<1e-9,'K.y must be zero');qBounds(p.Qcolumns);return p;}
function fieldColumns(Q){const M=[0,1,2].map(i=>Q.map(c=>c[i])),[[a,b,c],[d,e,f],[g,h,i]]=M,det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g);requireValue(Math.abs(det)>.99,'Singular Q');const inverseRows=[[(e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],[(f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],[(d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]];return inverseRows;}
export function forward(p,a,root){validatePose(p);const Q=fieldColumns(p.Qcolumns),v=[0,1,2].map(i=>Q.reduce((s,col,j)=>s+col[i]*(a[j]-root[j]),0));return p.C.map((v0,i)=>v0+p.b*v[i]+p.K[i]*v[1]);}
export function inverse(p,x,root){validatePose(p);const h=(x[1]-p.C[1])/p.b,v=x.map((z,i)=>(z-p.C[i]-p.K[i]*h)/p.b);return root.map((z,i)=>z+dot(p.Qcolumns[i],v));}
function scaleBounds(p,bRange=[p.b,p.b],KRadius=0){const q=qBounds(p.Qcolumns),lo=bRange[0],hi=bRange[1],K=norm(p.K)+KRadius;return{min:lo*sigmaMin(K/lo)/q.max,max:hi*sigmaMax(K/hi)/q.min};}
function validateSweep(s){validatePose(s.pose);requireValue(finite(s.bRange,2)&&s.bRange[0]>0&&s.bRange[0]<=s.pose.b&&s.pose.b<=s.bRange[1],'Invalid sweep growth range');requireValue(Number.isFinite(s.KRadius)&&s.KRadius>=0&&Number.isFinite(s.centerRadius)&&s.centerRadius>=0,'Invalid sweep uncertainty');return s;}
function maxNodeOffsets(node,root,Q,frameMax){let r2=0,low=0,high=0;for(let j=0;j<3;j++){const a=node.lo[j]-root[j],b=node.hi[j]-root[j],h=Q[j][1];r2+=Math.max(a*a,b*b);low+=Math.min(a*h,b*h);high+=Math.max(a*h,b*h);}return{radius:Math.sqrt(r2)*frameMax,height:Math.max(Math.abs(low),Math.abs(high))};}
const distanceBox=(x,n)=>Math.hypot(...x.map((v,i)=>Math.max(n.lo[i]-v,0,v-n.hi[i])));
export function validateMetadata(m){
 requireValue(m?.schemaVersion===1&&m.templates?.body&&m.templates?.['crown-b'],'Missing admission metadata/templates');
 for(const id of['body','crown-b']){const t=m.templates[id];requireValue(t.templateID===id&&finite(t.rootLocal,3)&&t.rootBall?.radiusLocal>0,'Missing positive root');const tree=t.support;requireValue(tree?.threshold===.005&&Array.isArray(tree.nodes)&&tree.nodes.length>0&&tree.nodes.length<=255&&tree.root===0,'Missing/oversize support BVH');let leaves=0;const visited=new Set();
  function walk(i){requireValue(Number.isInteger(i)&&i>=0&&i<tree.nodes.length&&!visited.has(i),'Invalid BVH child/cycle');visited.add(i);const n=tree.nodes[i];requireValue(finite(n.lo,3)&&finite(n.hi,3)&&n.lo.every((v,j)=>v<=n.hi[j]),'Invalid support box');if(n.left===-1&&n.right===-1){leaves++;return;}requireValue(n.left>=0&&n.right>=0,'Incomplete BVH');walk(n.left);walk(n.right);for(const k of[n.left,n.right])requireValue(tree.nodes[k].lo.every((v,j)=>v>=n.lo[j])&&tree.nodes[k].hi.every((v,j)=>v<=n.hi[j]),'BVH parent does not enclose child');}
  walk(0);requireValue(visited.size===tree.nodes.length&&leaves<=128&&leaves===tree.leafCount,'Invalid BVH leaf count');
 }
 const sites=m.templates.body.sites;requireValue(Array.isArray(sites)&&sites.length>=4&&sites.length<=8,'BODY site catalogue missing/overflow');for(const s of sites){requireValue(finite(s.local,3)&&s.positiveRadiusLocal>=7,'Uncertified BODY site');qBounds(s.desiredFrameColumns);}
 const heads=m.templates['crown-b'].headWitnesses;requireValue(Array.isArray(heads)&&heads.length>0&&heads.length<=4,'Crown heads missing/overflow');for(const h of heads){requireValue(finite(h.centerLocal,3)&&h.radiusLocal>=6&&Array.isArray(h.chain)&&h.chain.length>0&&h.chain.length<=16,'Invalid head witness/chain');for(const b of h.chain)requireValue(finite(b.centerLocal,3)&&b.radiusLocal>0&&b.qMin>=.04,'Invalid positive chain ball');for(let i=1;i<h.chain.length;i++)requireValue(norm(sub(h.chain[i].centerLocal,h.chain[i-1].centerLocal))<h.chain[i].radiusLocal+h.chain[i-1].radiusLocal,'Disconnected head chain');requireValue(norm(sub(h.chain[0].centerLocal,m.templates['crown-b'].rootLocal))<1e-6&&norm(sub(h.chain.at(-1).centerLocal,h.centerLocal))<1e-6,'Chain endpoint mismatch');}
 return m;
}
// Tests every conservative BVH leaf; no empty support or omitted leaf can pass validation.
export function supportExcludesBall(template,sweep,center,radius){
 validateSweep(sweep);requireValue(finite(center,3)&&Number.isFinite(radius)&&radius>=0,'Invalid exterior ball');const p=sweep.pose,root=template.rootLocal,local=inverse(p,center,root),minScale=scaleBounds(p).min,deltaB=Math.max(p.b-sweep.bRange[0],sweep.bRange[1]-p.b),frame=fieldColumns(p.Qcolumns),frameMax=qBounds(frame).max,stack=[0];let nodes=0;
 while(stack.length){const n=template.support.nodes[stack.pop()];nodes++;requireValue(nodes<=255,'BVH work overflow');const offset=maxNodeOffsets(n,root,frame,frameMax),uncertain=sweep.centerRadius+deltaB*offset.radius+sweep.KRadius*offset.height,testRadius=(radius+uncertain)/minScale;
  if(distanceBox(local,n)>testRadius+1e-6)continue;
  if(n.left===-1)return{pass:false,nodes};stack.push(n.left,n.right);
 }return{pass:true,nodes};
}
export function certifyExterior({metadata,candidateSweep,oldSweeps,resolvedLocalRadius=6}){
 validateMetadata(metadata);validateSweep(candidateSweep);requireValue(candidateSweep.pose.templateID==='crown-b','Exterior witness requires crown-b');requireValue(Array.isArray(oldSweeps)&&oldSweeps.length<=8,'Old reference overflow/missing');requireValue(resolvedLocalRadius>=6&&Number.isFinite(resolvedLocalRadius),'Unresolved exterior subball');const IDs=new Set();for(const o of oldSweeps){validateSweep(o);requireValue(!o.referenceOnly&&o.pose.ID!==undefined&&!IDs.has(o.pose.ID),'Invalid frozen reference ID/membership');IDs.add(o.pose.ID);requireValue(metadata.templates[o.pose.templateID],'Unknown old template');}
 const t=metadata.templates['crown-b'],p=candidateSweep.pose,sc=scaleBounds(p,candidateSweep.bRange,candidateSweep.KRadius),deltaB=Math.max(p.b-candidateSweep.bRange[0],candidateSweep.bRange[1]-p.b);let nodes=0;const failures=[];
 for(const h of t.headWitnesses){if(h.radiusLocal<resolvedLocalRadius)continue;const offset=sub(h.centerLocal,t.rootLocal),frame=fieldColumns(p.Qcolumns),v=[0,1,2].map(i=>frame.reduce((s,col,j)=>s+col[i]*offset[j],0)),center=forward(p,h.centerLocal,t.rootLocal),headUncertainty=candidateSweep.centerRadius+deltaB*norm(offset)/qBounds(p.Qcolumns).min+candidateSweep.KRadius*Math.abs(v[1]),radius=sc.min*resolvedLocalRadius;
  if(2*radius<4*t.domain.pitch*sc.max){failures.push({headID:h.id,reason:'unresolved transformed subball'});continue;}
  let pass=true;for(const old of oldSweeps){const r=supportExcludesBall(metadata.templates[old.pose.templateID],old,center,radius+headUncertainty);nodes+=r.nodes;if(!r.pass){pass=false;failures.push({headID:h.id,oldID:old.pose.ID,reason:'conservative old support overlaps head'});break;}}
  if(pass)return{pass:true,headID:h.id,centerWorld:center,radiusWorldLower:radius,headUncertaintyWorld:headUncertainty,nodes,referenceIDs:[...IDs],scope:'Resolved positive subball outside conservative loss-free old support at45s; no camera/projection/beauty claim'};
 }return{pass:false,reason:'no certified resolved exterior head patch',failures,nodes};
}
export function candidatePoses({metadata,parent,scale,startIndex=0}){
 validateMetadata(metadata);validatePose(parent);requireValue(parent.templateID==='body'&&[5,6].includes(scale)&&Number.isInteger(startIndex),'Invalid crown parent/scale/catalogue phase');const t=metadata.templates['crown-b'],Fasset=t.assetFrameColumns,sites=metadata.templates.body.sites,out=[];
 for(let j=0;j<sites.length;j++){const site=sites[((startIndex+j)%sites.length+sites.length)%sites.length],F=site.desiredFrameColumns,Q=[0,1,2].map(k=>[0,1,2].map(i=>F.reduce((s,col,n)=>s+col[i]*Fasset[n][k],0)));out.push({parentID:parent.ID,siteID:site.id,siteGlobal:site.local,site,scale,Qcolumns:Q,Cbirth:forward(parent,site.local,metadata.templates.body.rootLocal)});}
 return out;
}
function attachment(q){requireValue(q&&q.parentLossFree===true,'Prepared positive balls require loss-free parent');for(const k of['parentRadiusWorldLower','rootSeparationMax','seedRadiusWorldUpper'])requireValue(Number.isFinite(q[k])&&q[k]>=0,'Missing attachment bound '+k);if(q.rootSeparationMax>11+1e-6)return{pass:false,reason:'root separation guard exceeded'};if(q.parentRadiusWorldLower<q.rootSeparationMax+q.seedRadiusWorldUpper)return{pass:false,reason:'seed support not buried'};return{pass:true};}
export function chooseBillow({metadata,parent,time,scale,startIndex=0,prospect}){
 requireValue(typeof prospect==='function'&&Number.isFinite(time),'Missing prospective source geometry');let nodes=0;const rejected=[];
 for(const c of candidatePoses({metadata,parent,scale,startIndex})){const q=prospect(c),a=attachment(q);requireValue(Array.isArray(q.oldSweeps)&&q.oldSweeps.some(o=>o.pose?.ID===parent.ID),'Frozen old references omit actual parent');if(!a.pass){rejected.push({siteID:c.siteID,reason:a.reason});continue;}const rootRadius=metadata.templates['crown-b'].rootBall.radiusLocal*scaleBounds(q.candidateSweep.pose,q.candidateSweep.bRange,q.candidateSweep.KRadius).min,matureNeck=Math.min(q.parentRadiusWorldLower,rootRadius,(q.parentRadiusWorldLower+rootRadius-q.rootSeparationMax)/2);if(matureNeck<16){rejected.push({siteID:c.siteID,reason:'mature root neck below16m'});continue;}const exterior=certifyExterior({metadata,candidateSweep:q.candidateSweep,oldSweeps:q.oldSweeps});nodes+=exterior.nodes;if(exterior.pass)return{pass:true,...c,certificate:{...q,exterior,nodes},exteriorWitness:exterior};rejected.push({siteID:c.siteID,reason:exterior.reason});}
 return{pass:false,reason:'finite catalogue has no certified candidate',rejected,nodes};
}
export function chooseBody({metadata,parent,rootR,prospect}){validateMetadata(metadata);validatePose(parent);requireValue(parent.templateID==='body'&&finite(rootR,3)&&typeof prospect==='function','Invalid BODY request');requireValue(norm(sub(parent.C,rootR))<1e-5,'BODY birth root differs from actual parent anchor');const q=prospect({parentID:parent.ID,Cbirth:[...rootR],Qcolumns:[[1,0,0],[0,1,0],[0,0,1]],scale:4}),a=attachment(q);return a.pass?{pass:true,parentID:parent.ID,Cbirth:[...rootR],Qcolumns:[[1,0,0],[0,1,0],[0,0,1]],certificate:q}:a;}
// Source supplies a consistent common-mean-removed frame and endpoint growth range.
export function makeSweep({pose,bRange=[pose.b,pose.b],bMax=bRange[1],seconds=45,shearMax=.002,centerRadius=0,KRadius=0}){requireValue(seconds>=0&&seconds<=45&&shearMax>=0&&shearMax<=.002,'Sweep admission outside lease/forcing');return validateSweep({pose,bRange,KRadius:KRadius+shearMax*bMax*seconds,centerRadius});}
export function relativeCenterGuard({heightFromRegion,verticalDisplacementMax,internalHorizontalSpeed=0,seconds=45,shearMax=.002}){requireValue([heightFromRegion,verticalDisplacementMax,internalHorizontalSpeed,seconds,shearMax].every(Number.isFinite)&&verticalDisplacementMax>=0&&internalHorizontalSpeed>=0&&seconds>=0&&seconds<=45&&shearMax>=0&&shearMax<=.002,'Invalid relative motion guard');const horizontal=shearMax*seconds*(Math.abs(heightFromRegion)+verticalDisplacementMax)+10*internalHorizontalSpeed*(1-Math.exp(-seconds/10));return Math.hypot(horizontal,verticalDisplacementMax);}
