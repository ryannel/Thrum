"""Exact, independent first terrain certificate falsifier; no engine API."""

from fractions import Fraction as Q
from itertools import product


def cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def clip_polygon(poly, a, b):
    """Clip a CCW polygon against the left half-plane of directed edge ab."""
    result = []
    for p, q in zip(poly, poly[1:] + poly[:1]):
        dp, dq = cross(a, b, p), cross(a, b, q)
        if dp >= 0:
            result.append(p)
        if (dp < 0 < dq) or (dq < 0 < dp):
            result.append(tuple(p[i] + (q[i] - p[i]) * (-dp) / (dq - dp) for i in (0, 1)))
    return result


def overlay_polygon(a, b):
    poly = [v[:2] for v in a]
    for p, q in zip(b, b[1:] + b[:1]):
        poly = clip_polygon(poly, p[:2], q[:2])
        if not poly:
            break
    return poly


def height(tri, point):
    a, b, c = tri
    den = cross(a, b, c)
    assert den > 0
    w_a = cross(b, c, point) / den
    w_b = cross(c, a, point) / den
    w_c = 1 - w_a - w_b
    return w_a * a[2] + w_b * b[2] + w_c * c[2]


def certified_vertical_error(reference, candidate):
    """The affine difference reaches its max absolute value at an overlay vertex."""
    for mesh in (reference, candidate):
        for tri in mesh:
            assert cross(*tri) > 0
        for i in range(len(mesh)):
            for j in range(i + 1, len(mesh)):
                if polygon_area(overlay_polygon(mesh[i], mesh[j])):
                    raise ValueError("triangles overlap")
    if sum(polygon_area([v[:2] for v in t]) for t in reference) != sum(
        polygon_area([v[:2] for v in t]) for t in candidate
    ):
        raise ValueError("support area differs")
    largest = Q(0)
    witness = None
    comparisons = 0
    for ref, cand in product(reference, candidate):
        for point in overlay_polygon(ref, cand):
            delta = abs(height(ref, point) - height(cand, point))
            comparisons += 1
            if delta > largest:
                largest, witness = delta, point
    for ref in reference:
        covered = sum(polygon_area(overlay_polygon(ref, cand)) for cand in candidate)
        if covered != polygon_area([v[:2] for v in ref]):
            raise ValueError("reference support uncovered")
    return largest, witness, comparisons


def triangulate(sw, se, ne, nw, diagonal):
    if diagonal == "sw-ne":
        return [(sw, se, ne), (sw, ne, nw)]
    if diagonal == "se-nw":
        return [(sw, se, nw), (se, ne, nw)]
    raise AssertionError(diagonal)


def polygon_area(poly):
    if len(poly) < 3:
        return Q(0)
    return abs(sum(p[0] * q[1] - q[0] * p[1] for p, q in zip(poly, poly[1:] + poly[:1]))) / 2


def wet_area_volume(tris, stage):
    area = volume = Q(0)
    for tri in tris:
        # Clip the triangle against h <= stage, using affine edge intersections.
        poly = list(tri)
        wet = []
        for p, q in zip(poly, poly[1:] + poly[:1]):
            p_inside, q_inside = p[2] <= stage, q[2] <= stage
            if p_inside:
                wet.append(p)
            if p_inside != q_inside:
                t = (stage - p[2]) / (q[2] - p[2])
                wet.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1]), stage))
        if len(wet) < 3:
            continue
        # Fan triangles: linear depth integrates to area * mean vertex depth.
        for i in range(1, len(wet) - 1):
            fan = (wet[0], wet[i], wet[i + 1])
            a = polygon_area([v[:2] for v in fan])
            area += a
            volume += a * sum(stage - v[2] for v in fan) / 3
    return area, volume


def bank_strip_mesh():
    # One metre of Z support, 256 exact quarter-metre source cells in X.
    tris = []
    for k in range(256):
        x0 = Q(-32) + Q(k, 4)
        x1 = x0 + Q(1, 4)
        sw, se = (x0, Q(0), x0 / 20), (x1, Q(0), x1 / 20)
        ne, nw = (x1, Q(1), x1 / 20), (x0, Q(1), x0 / 20)
        tris.extend(triangulate(sw, se, ne, nw, "sw-ne"))
    return tris


def main():
    crest = Q(1, 8)
    sw, se, ne, nw = (Q(0), Q(0), Q(0)), (Q(1), Q(0), crest), (Q(1), Q(1), Q(0)), (Q(0), Q(1), crest)
    reference = triangulate(sw, se, ne, nw, "sw-ne")
    same = triangulate(sw, se, ne, nw, "sw-ne")
    wrong = triangulate(sw, se, ne, nw, "se-nw")
    assert certified_vertical_error(reference, same)[0] == 0
    error, witness, comparisons = certified_vertical_error(reference, wrong)
    assert error == crest and witness == (Q(1, 2), Q(1, 2))
    try:
        certified_vertical_error(reference, wrong[:1])
        raise AssertionError("missing triangle passed")
    except ValueError:
        pass
    try:
        certified_vertical_error(reference, wrong + wrong[:1])
        raise AssertionError("duplicate triangle passed")
    except ValueError:
        pass
    assert all(a[2] == b[2] for a, b in zip((sw, se, ne, nw), (sw, se, ne, nw)))
    print(f"wrong-diagonal: corner error 0; exact overlay max {error} at {witness}; {comparisons} vertex evaluations")

    bank = bank_strip_mesh()
    for h in [Q(-8, 5), Q(-1), Q(0), Q(1, 2), Q(8, 5)]:
        area_strip, volume_strip = wet_area_volume(bank, h)
        area, volume = 64 * area_strip, 64 * volume_strip
        expected_area = 64 * (20 * h + 32)
        expected_volume = 640 * (h + Q(8, 5)) ** 2
        assert (area, volume) == (expected_area, expected_volume)
        print(f"bank H={h}: area={area} m2 volume={volume} m3; 512 exact source triangles")


if __name__ == "__main__":
    main()
