# Exact first terrain falsifiers

Run `python3 proof.py` with Python 3. The script uses rational coordinates,
heights, polygon clipping, barycentric interpolation and triangle integration;
it imports no engine code. It has no random seed or external dependencies.

The diagonal fixture gives identical authored corner heights to two different
final triangulations. A vertex-only check sees zero error; exact overlay
finds a 0.125 m interior error at the square centre. The height is exactly
representable in f32, so a later encoding allowance cannot explain this
topological/interpolation difference. Missing and duplicate
candidate triangles are rejected by support/partition checks. This tests the
need to certify the *final* product triangulation, including its interior
overlay vertices.

The planar-bank fixture constructs 512 source triangles for a 64 m by 1 m
strip at exact 0.25 m X spacing, with the selected SW–NE diagonal and bank
height `x/20`. Exact clipping and affine-depth integration at five stages,
scaled by the other 64 m of identical Z support, match the independent
closed-form wet area `64(20H+32)` and volume `640(H+1.6)^2` on the stated
stage interval.

These are offline falsifiers only. The full 257² sample terrain, shelf/sill
component graph, roof/deck receiver ordering, f32 output conversion, seam
certificate, P3/P5 consumers, F3/F4 binding, runtime and device cost are not
proved here. The exact overlay's pairwise partition check is quadratic and
is deliberately confined to the two-triangle diagnostic, not a proposed
full-region implementation.
