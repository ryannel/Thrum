"""Rebuild bytes, certify final product, and run deliberate falsifiers."""
import hashlib
import json
import platform
import resource
import struct
import sys
import time
from pathlib import Path
import checker
import producer

ROOT=Path(__file__).resolve().parent

def changed_product(blob,kind):
    magic,nv,nt=struct.unpack_from('<4sII',blob)
    prefix=bytearray(blob[:12+nv*12])
    ts=list(struct.iter_unpack('<3I',blob[12+nv*12:]))
    if kind=='omitted-triangle': ts.pop(0)
    elif kind=='duplicate-triangle': ts[1]=ts[0]  # Count unchanged: overlap, not just count failure.
    elif kind=='wrong-diagonal':
        sw=16*257+16; se=sw+1; nw=sw+257; ne=nw+1
        a=ts.index((sw,se,ne)); b=ts.index((sw,ne,nw))
        ts[a]=(sw,se,nw); ts[b]=(se,ne,nw)
    elif kind=='decimated-sill':
        for z in range(113,144):
            for x in (112,113):
                struct.pack_into('<f',prefix,12+(z*257+x)*12+4,0)
    elif kind=='shore-bias':
        # Only bank support z=[0,1m]; 10mm bias exceeds its 5mm vertical allowance.
        for z in range(5):
            for x in range(257):
                off=12+(z*257+x)*12+4
                y=struct.unpack_from('<f',prefix,off)[0]
                struct.pack_into('<f',prefix,off,y+0.01)
    elif kind=='wrong-height-under-geometric-budget':
        off=12+(32*257+32)*12+4
        y=struct.unpack_from('<f',prefix,off)[0]
        struct.pack_into('<f',prefix,off,y+0.001)
    elif kind=='off-grid-position':
        struct.pack_into('<f',prefix,12,-31.9999)
    elif kind=='seam-displacement':
        off=12+(256*257+100)*12+4
        y=struct.unpack_from('<f',prefix,off)[0]
        struct.pack_into('<f',prefix,off,y+0.001)
    else: raise AssertionError(kind)
    struct.pack_into('<I',prefix,8,len(ts))
    return bytes(prefix)+b''.join(struct.pack('<3I',*t) for t in ts)

def run():
    started=time.perf_counter(); times={}
    counts=producer.make(ROOT)
    times['produce_s']=time.perf_counter()-started
    start=time.perf_counter()
    positive=checker.verify(ROOT)
    times['positive_certificate_s']=time.perf_counter()-start
    print('positive certificate passed',flush=True)
    original=(ROOT/'product.bin').read_bytes()
    binding=json.loads((ROOT/'binding.json').read_text())
    negatives=[]
    for kind in ('wrong-diagonal','omitted-triangle','duplicate-triangle','decimated-sill','shore-bias','seam-displacement','wrong-height-under-geometric-budget','off-grid-position','source-hash-mismatch','product-hash-mismatch','source-unit-binding-mismatch','source-diagonal-binding-mismatch','water-profile-binding-mismatch'):
        start=time.perf_counter()
        b=dict(binding)
        candidate=original
        if kind.endswith('binding-mismatch'):
            field,value={'source-unit-binding-mismatch':('source_unit_m','1/1000'),
                         'source-diagonal-binding-mismatch':('source_diagonal','se-nw'),
                         'water-profile-binding-mismatch':('water','dynamic-stage; visual residual 1m')}[kind]
            b[field]=value
        elif kind.endswith('hash-mismatch'):
            b[kind.split('-')[0]+'_sha256']='0'*64
        else:
            candidate=changed_product(original,kind)
            b['product_sha256']=hashlib.sha256(candidate).hexdigest()
        (ROOT/'product.bin').write_bytes(candidate)
        extra={}
        try:
            checker.verify(ROOT,b)
            raise AssertionError(kind+' incorrectly passed')
        except (checker.Rejected,checker.Unavailable) as err:
            reason=str(err)
            outcome='certificate-unavailable' if isinstance(err,checker.Unavailable) else 'rejected'
        finally:
            (ROOT/'product.bin').write_bytes(original)
        if kind in ('wrong-diagonal','decimated-sill','shore-bias'):
            # Quantify the failure without acceptance gates, using actual mutated bytes.
            (ROOT/'product.bin').write_bytes(candidate)
            try:
                _,h,v,t,_=checker.decode(ROOT,b)
                geom=checker.partition_and_error(h,v,t)
                extra={k:geom[k] for k in ('signed_final_minus_source_min_m','signed_final_minus_source_max_m','max_absolute_error_m','bank_shore_bound_m')}
                if kind=='decimated-sill':
                    extra['source_at_H_1_16']=checker.wet_statistics(checker.shelf_mesh(h),checker.F(1,16))
                    extra['decimated_at_H_1_16']=checker.wet_statistics(checker.shelf_mesh(h,v,t),checker.F(1,16))
            finally:
                (ROOT/'product.bin').write_bytes(original)
        negatives.append({'mutation':kind,'outcome':outcome,'reason':reason,'seconds':time.perf_counter()-start,**extra})
        print(kind+': '+reason,flush=True)
    # Demonstrate finite-envelope refusal rather than rounding uncertainty to pass.
    try:
        checker.template([((0,0),(2,0),(2,2))]*9)
        raise AssertionError('work limit passed')
    except checker.Rejected as err:
        negatives.append({'mutation':'nine-triangles-in-block','outcome':'rejected','reason':str(err)})
    report={'fixture':counts,'positive':positive,'negative_tests':negatives,
            'offline_measurements':{'stage_seconds':times,'total_seconds':time.perf_counter()-started,
                'process_peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024),
                'rss_scope':'whole Python producer/checker/mutations process, OS ru_maxrss; not allocator bytes or device memory',
                'python':sys.version,'platform':platform.platform(), 'machine':platform.machine()},
            'scope':'offline final-f32 geometry certificate only; no engine admission, runtime, contact, nav, render or device claim'}
    (ROOT/'results.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report['offline_measurements'],indent=2),flush=True)

if __name__=='__main__': run()
