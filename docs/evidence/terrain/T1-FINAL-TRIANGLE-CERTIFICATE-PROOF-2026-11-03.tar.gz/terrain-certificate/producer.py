"""Candidate producer, deliberately separate from the exact checker. Stdlib only."""
import hashlib
import json
import struct
from pathlib import Path

N = 257

def digest(b):
    return hashlib.sha256(b).hexdigest()

def make(root):
    root = Path(root)
    heights = []
    for j in range(N):
        for i in range(N):
            h = (i - 128) * 125  # x/20 in integer 0.0001 m units.
            if 96 <= i <= 128 and 112 <= j <= 144:
                h = 2500 if i in (96, 128) or j in (112, 144) else 0
                if i in (112, 113) and 112 < j < 144:
                    h = 1250  # 0.25 m-wide flat crest at 0.125 m.
            # Protected diagnostic cell with noncoplanar dyadic corner heights.
            if (i, j) in ((16, 16), (17, 17)):
                h = 0
            if (i, j) in ((17, 16), (16, 17)):
                h = 1250
            heights.append(h)
    source = struct.pack('<4s6i', b'T1S1', N, 10000, 2500, -320000, 0, 0)
    source += struct.pack('<%di' % len(heights), *heights)
    def vid(i, j):
        return j * N + i
    def fine(bx, bz):
        return (bx in (0, 127) or bz in (0, 127) or
                (47 <= bx <= 64 and 55 <= bz <= 72) or (7 <= bx <= 9 and 7 <= bz <= 9))
    triangles = []
    for bz in range(128):
        for bx in range(128):
            i, j = bx * 2, bz * 2
            if fine(bx, bz):
                for z in (j, j + 1):
                    for x in (i, i + 1):
                        a, b, c, d = vid(x,z), vid(x+1,z), vid(x+1,z+1), vid(x,z+1)
                        triangles.extend(((a,b,c), (a,c,d)))
                continue
            # Ring contains edge midpoint exactly when neighbouring block is fine.
            ring = [vid(i,j)]
            if fine(bx,bz-1): ring.append(vid(i+1,j))
            ring.append(vid(i+2,j))
            if fine(bx+1,bz): ring.append(vid(i+2,j+1))
            ring.append(vid(i+2,j+2))
            if fine(bx,bz+1): ring.append(vid(i+1,j+2))
            ring.append(vid(i,j+2))
            if fine(bx-1,bz): ring.append(vid(i,j+1))
            if len(ring) == 4:
                triangles.extend(((ring[0],ring[1],ring[2]), (ring[0],ring[2],ring[3])))
            else:
                centre = vid(i+1,j+1)
                triangles.extend((centre,a,b) for a,b in zip(ring,ring[1:]+ring[:1]))
    product = struct.pack('<4sII', b'T1F1', len(heights), len(triangles))
    product += b''.join(struct.pack('<3f', (i-128)/4, heights[j*N+i]/10000, j/4)
                        for j in range(N) for i in range(N))
    product += b''.join(struct.pack('<3I', *t) for t in triangles)
    # Neighbour has its own local z=0 datum; the world z origin is 64 m.
    neighbour = b''.join(struct.pack('<3f', (i-128)/4, heights[256*N+i]/10000, 0)
                         for i in range(N))
    binding = {
        'profile': 't1-final-triangle-exact-v1',
        'source_sha256': digest(source), 'product_sha256': digest(product),
        'neighbour_sha256': digest(neighbour), 'neighbour_origin_z_m': 64,
        'source_unit_m': '1/10000', 'source_diagonal': 'sw-ne',
        'water': 'prescribed-constant-stage; zero render residual',
        'shelf_grid_roi': [96,112,128,144], 'protected_crest_m': '1/8',
        'max_vertical_error_m': '1/200', 'max_bank_shore_error_m': '1/10',
        'max_blocks': 16384, 'max_triangles_per_block': 8,
        'max_rational_bits': 256, 'max_overlay_vertex_evaluations': 2000000,
    }
    for name, data in [('source.bin',source), ('product.bin',product), ('neighbour.bin',neighbour)]:
        (root/name).write_bytes(data)
    (root/'binding.json').write_text(json.dumps(binding, indent=2, sort_keys=True)+'\n')
    return {'source_samples': len(heights), 'product_triangles':len(triangles),
            'source_bytes': len(source), 'product_bytes': len(product), 'neighbour_bytes':len(neighbour)}
