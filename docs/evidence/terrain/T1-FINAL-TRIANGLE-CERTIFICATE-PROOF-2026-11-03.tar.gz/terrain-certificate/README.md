# T1 final-triangle exact offline certificate v1

Owner: Thrum terrain programme, 2026-11-03. Hand-written proof code and an
explicit deterministic synthetic fixture; no third-party assets/dependencies.
Python 3.11+ standard library. Selected run versions and exact artifact hashes
are retained in results.json and MANIFEST.json. No engine API is implemented.

Before regenerating anything, verify MANIFEST.json member SHA-256 values, then:

```sh
python3 checker.py
```

This checks the archived source.bin against the archived final-f32 product.bin
and binding.json, independent of the candidate producer. To regenerate the
fixture and run all deliberate mutations (about one minute on the measured
host; timing varies), run:

```sh
python3 run.py
```

run.py overwrites source/product/binding/results. Regenerated source/product
bytes must match their archived hashes. results.json contains single-run
measurements, so its timing/platform bytes will differ after regeneration.

source.bin: little-endian `<4s6i` header (T1S1, 257, denominator 10000,
spacing 2500, X origin -320000, Z origin 0, SW-NE enum 0), followed by 66049
row-major i32 height units of 0.0001 m. Support is X [-32,32], Z [0,64] m.
product.bin: `<4sII` (T1F1, vertex count, triangle count), f32 XYZ triples,
then u32 index triples. All 66049 vertices are retained, including unused
coarse samples; only indices are reduced. Coordinates use the same local
datum. The checker reads f32 as exact dyadic rationals. neighbour.bin is
257 f32 XYZ triples at neighbour-local Z=0 with exact world origin Z=64.
It is one shared boundary record, not a second full region or a halo proof.

Contradictory source-unit, diagonal, or water-profile metadata refuses explicitly.
The independent checker owns source triangulation, clipping, partition,
exact barycentric overlay evaluation, manifold/boundary checks and strict
wet-set connectivity. It imports nothing from producer.py. It accepts only
on-lattice, aligned 2x2-block heightfield triangles, at most 8 per block;
it rejects unsupported XZ encodings rather than applying approximate tests.
Each distinct XY overlay is computed once and reused for actual block
heights; no height error is cached. Both nominal unrounded final connectivity
and actual final-f32 values are evaluated. Pure output rounding is certified only
after an independent exact-rational nearest-even binary32 oracle verifies raw
Y bits at every source-attached vertex; arbitrary Y differences are total vertex
displacements, not rounding. A 1mm wrong-height mutation inside the 5mm geometric
budget must still fail that encoding gate. The 256-bit arithmetic cap is
checked on each error; lattice predicates have bounded small integer inputs.
The fixture's error is conversion alone, not a measured simplification gain.

The 8m x 8m protected shelf is X grid [96,128], Z grid [112,144]. Its walls
are 0.25m, floor 0m, and the two central sample columns form a 0.25m-wide
0.125m crest. Exact face correspondence proves identical wet sets, area and
volume for *all* stages; critical/equality/open-interval graph checks are
additional falsifiers. No polynomial-root bound for a changed sill is claimed.
Its west/east seeds are source locations, not runtime triangle IDs. Wet means
b < H, including at critical levels. Constant prescribed H is geometry only,
with no flood-arrival or hydraulic-storage-dynamics claim.

The bank is the full-width 64m x 1m strip Z [0,1]. It is independently checked
against b=x/20, A(H)=20H+32 m2, V(H)=10(H+8/5)^2 m3. Four exact contours and
area/volume witnesses supplement the all-stage bounds for H in [-1,1/2].
The area difference is at most 40e m2, volume difference at most 64e m3,
and horizontal shoreline difference at most 20e m, for vertical bound e m;
water and coordinate residuals are zero. These do not certify the rest of
the region as a planar coast.

Input caps: source 264224 B, product 2400000 B, neighbour 3084 B, binding
4096 B; source height absolute bound 2m; fixed 257² positions and <=131072
triangles. Limits cannot be enlarged by changing binding.json. Predicate
uncertainty, off-grid XZ, >256-bit error fractions, or >2000000 overlay vertex
evaluations do not pass. Capacity/structural violations reject. All stage
and memory measurements are offline Python diagnostics. Logical packed
resident bytes exclude Python object overhead; ru_maxrss includes the full
producer/checker/mutation process and observer work. It is neither allocator
accounting nor a shipping runtime/device/thermal budget.

Not covered: arbitrary triangulations/remeshing, holes/volumetric terrain,
full B/halo dependencies, physical admission/activation, roofs/decks, material
or patch IDs, source-tree S->G engine manifests, collision/nav consumers,
first-hit rain, runtime water, rendering/visual acceptance, device performance.
Keep these obligations open. No production code, canonical contract or
maturity status is changed by this proof.
