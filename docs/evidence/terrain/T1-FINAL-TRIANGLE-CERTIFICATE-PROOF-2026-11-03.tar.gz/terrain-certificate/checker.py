"""Independent bounded checker of serialized source and final f32 product.

Does not import candidate producer. All predicates and bounds use exact integers
or Fraction. Only timing/RSS and product decoding use floating-point operations.
XZ must be exactly the declared quarter-metre lattice; off-grid is unavailable.
"""
import hashlib
import json
import math
import struct
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path

class Rejected(ValueError):
    pass
class Unavailable(ValueError):
    pass

def require(ok, why):
    if not ok:
        raise Rejected(why)

def cross(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])

def area(poly):
    return abs(F(sum(p[0]*q[1]-p[1]*q[0] for p,q in zip(poly,poly[1:]+poly[:1])),2)) if len(poly)>2 else F(0)

def intersect(a,b):
    poly = list(a)
    for u,v in zip(b,b[1:]+b[:1]):
        out=[]
        for p,q in zip(poly,poly[1:]+poly[:1]):
            s,t=cross(u,v,p),cross(u,v,q)
            if s>=0: out.append(p)
            if (s<0<t) or (t<0<s):
                f=F(-s,t-s)
                out.append((p[0]+f*(q[0]-p[0]),p[1]+f*(q[1]-p[1])))
        poly=out
        if not poly: break
    return poly

def weights(t,p):
    den=cross(*t)
    return F(cross(t[1],t[2],p),den), F(cross(t[2],t[0],p),den), F(cross(t[0],t[1],p),den)

def source_cell_triangles(x,z):
    # Independent source-format interpretation: the fixed SW-NE diagonal.
    return [((x,z),(x+1,z),(x+1,z+1)), ((x,z),(x+1,z+1),(x,z+1))]

REFERENCE = [t for z in range(2) for x in range(2) for t in source_cell_triangles(x,z)]

def template(candidates):
    """Memoizable exact XY geometry only; never caches height or error results."""
    require(1 <= len(candidates) <= 8, 'triangle-count-per-block')
    for t in candidates:
        require(cross(*t)>0, 'degenerate-or-clockwise-triangle')
        require(all(0<=x<=2 and 0<=z<=2 for x,z in t), 'outside-block')
    for k,a in enumerate(candidates):
        for b in candidates[k+1:]:
            require(area(intersect(a,b))==0, 'overlapping-triangles')
    require(sum(area(t) for t in candidates)==4, 'support-area')
    evaluations=[]
    for r in REFERENCE:
        covered=F(0)
        for k,c in enumerate(candidates):
            poly=intersect(r,c)
            covered+=area(poly)
            # Zero-area overlays still constrain shared-edge heights.
            for p in set(poly):
                evaluations.append((r,k,weights(r,p),weights(c,p),p))
        require(covered==area(r), 'reference-support-uncovered')
    return evaluations

def exact_f32(value):
    require(math.isfinite(value), 'nonfinite-product-position')
    return F(value)

def decode(root, binding=None):
    root=Path(root)
    require((root/'binding.json').stat().st_size<=4096, 'binding-byte-limit')
    b=json.loads((root/'binding.json').read_text()) if binding is None else binding
    # These are fixed checker limits, not limits that input can enlarge.
    require(b['profile']=='t1-final-triangle-exact-v1', 'profile')
    require(b['source_unit_m']=='1/10000','source-unit-metadata')
    require(b['source_diagonal']=='sw-ne','source-diagonal-metadata')
    require(b['water']=='prescribed-constant-stage; zero render residual','water-profile-metadata')
    require(b['max_blocks']==16384 and b['max_triangles_per_block']==8 and
            b['max_rational_bits']==256 and b['max_overlay_vertex_evaluations']==2000000,
            'incompatible-work-limits')
    for name,limit in (('source',264224),('product',2400000),('neighbour',3084)):
        require((root/(name+'.bin')).stat().st_size<=limit, name+'-byte-limit')
    blobs={name:(root/(name+'.bin')).read_bytes() for name in ('source','product','neighbour')}
    for name,data in blobs.items():
        require(hashlib.sha256(data).hexdigest()==b[name+'_sha256'], name+'-hash-mismatch')
    s=blobs['source']
    require(len(s)==28+257*257*4, 'source-length')
    require(struct.unpack_from('<4s6i',s)==(b'T1S1',257,10000,2500,-320000,0,0), 'source-envelope')
    h=list(struct.unpack_from('<66049i',s,28))
    require(all(abs(v)<=20000 for v in h), 'source-height-envelope')
    p=blobs['product']
    require(len(p)>=12, 'product-header')
    magic,nv,nt=struct.unpack_from('<4sII',p)
    require(magic==b'T1F1' and nv==66049 and nt<=131072, 'product-count-envelope')
    require(len(p)==12+nv*12+nt*12, 'product-length')
    vertices=[]
    for (x,y,z) in struct.iter_unpack('<3f',p[12:12+nv*12]):
        x,y,z=exact_f32(x),exact_f32(y),exact_f32(z)
        gx,gz=(x+32)*4,z*4
        if gx.denominator!=1 or gz.denominator!=1:
            raise Unavailable('off-grid-XZ-conversion')
        require(0<=gx<=256 and 0<=gz<=256 and abs(y)<=2, 'product-position-envelope')
        vertices.append((int(gx),int(gz),y))
    require(len({v[:2] for v in vertices})==nv, 'duplicate-XZ-vertex')
    tris=list(struct.iter_unpack('<3I',p[12+nv*12:]))
    require(all(max(t)<nv for t in tris), 'index-out-of-range')
    require(len(blobs['neighbour'])==257*12, 'neighbour-length')
    return b,h,vertices,tris,blobs

def make_blocks(vertices,tris):
    blocks=defaultdict(list)
    for t in tris:
        pts=[vertices[v][:2] for v in t]
        # Positive extent on each axis; a triangle cannot straddle the broadphase.
        lx,lz=min(p[0] for p in pts),min(p[1] for p in pts)
        ux,uz=max(p[0] for p in pts),max(p[1] for p in pts)
        require(lx<ux and lz<uz, 'degenerate-XY')
        bx,bz=lx//2,lz//2
        require(ux<=2*bx+2 and uz<=2*bz+2, 'triangle-crosses-block')
        blocks[bx,bz].append(t)
        require(len(blocks[bx,bz])<=8, 'triangle-count-per-block')
    require(len(blocks)==16384, 'missing-block')
    return blocks

def partition_and_error(h,vertices,tris):
    blocks=make_blocks(vertices,tris)
    templates={}
    low=high=None
    witness_low=witness_high=None
    evaluations=0
    conversions=F(0)
    for x,z,y in vertices:
        conversions=max(conversions,abs(y-F(h[z*257+x],10000)))
    shelf_error=F(0)
    bank_error=F(0)
    nominal_error=F(0)
    for (bx,bz),ts in blocks.items():
        ox,oz=2*bx,2*bz
        shape=tuple(tuple((vertices[v][0]-ox,vertices[v][1]-oz) for v in t) for t in ts)
        if shape not in templates:
            templates[shape]=template(shape)
        heights_by_triangle=[tuple(vertices[v][2] for v in t) for t in ts]
        nominal_by_triangle=[tuple(F(h[vertices[v][1]*257+vertices[v][0]],10000) for v in t) for t in ts]
        source_height={(x,z):F(h[(oz+z)*257+ox+x],10000) for z in range(3) for x in range(3)}
        for r,k,wr,wc,p in templates[shape]:
            source=sum((source_height[q]*w for q,w in zip(r,wr)),F(0))
            final=sum((y*w for y,w in zip(heights_by_triangle[k],wc)),F(0))
            delta=final-source
            nominal=sum((y*w for y,w in zip(nominal_by_triangle[k],wc)),F(0))
            nominal_error=max(nominal_error,abs(nominal-source))
            at=(F(ox)+p[0],F(oz)+p[1])
            if low is None or delta<low: low,witness_low=delta,at
            if high is None or delta>high: high,witness_high=delta,at
            if 96<=ox and ox+2<=128 and 112<=oz and oz+2<=144:
                shelf_error=max(shelf_error,abs(delta))
            # z in [0, 1m] is an unmodified full-width analytic bank support.
            if oz+2<=4:
                bank_error=max(bank_error,abs(delta))
            evaluations+=1
            if evaluations>2000000:
                raise Unavailable('overlay-work-limit')
            if delta.numerator.bit_length()>256 or delta.denominator.bit_length()>256:
                raise Unavailable('rational-bit-limit')
    return {
        'blocks':len(blocks), 'xy_templates':len(templates),
        'logical_overlay_vertex_evaluations':evaluations,
        'exact_height_dot_products':3*evaluations,
        'exact_xy_template_overlay_calls':sum(8*len(shape)+len(shape)*(len(shape)-1)//2 for shape in templates),
        'nominal_unrounded_final_triangulation_max_error_m':str(nominal_error),
        'vertex_displacement_bound_definition':'total final vertex deviation from source-attached integer height, before encoding validation; barycentric convexity bounds displacement everywhere on each final triangle',
        'signed_final_minus_source_min_m':str(low), 'signed_final_minus_source_max_m':str(high),
        'max_absolute_error_m':str(max(-low,high)),
        'minimum_witness_grid':list(map(str,witness_low)) if witness_low else None,
        'maximum_witness_grid':list(map(str,witness_high)) if witness_high else None,
        'max_final_vertex_displacement_from_source_m':str(conversions),
        'protected_shelf_max_error_m':str(shelf_error),
        'bank_max_vertical_error_m':str(bank_error),
        'bank_shore_bound_m':str(20*bank_error),
    }

def manifold_and_seam(vertices,tris,neighbour):
    edges={}
    for a,b,c in tris:
        for u,v in ((a,b),(b,c),(c,a)):
            key=(min(u,v),max(u,v))
            count,balance=edges.get(key,(0,0))
            edges[key]=(count+1,balance+(1 if u<v else -1))
    expected=set()
    pos_to_id={v[:2]:k for k,v in enumerate(vertices)}
    for k in range(256):
        for a,b in (((k,0),(k+1,0)),((k,256),(k+1,256)),((0,k),(0,k+1)),((256,k),(256,k+1))):
            u,v=pos_to_id[a],pos_to_id[b]
            expected.add((min(u,v),max(u,v)))
    actual=set()
    for edge,(count,balance) in edges.items():
        if count==1: actual.add(edge)
        else: require(count==2 and balance==0,'nonmanifold-edge')
    require(actual==expected,'boundary-or-T-junction')
    require(len(neighbour)==257*12,'neighbour-length')
    for i,(x,y,z) in enumerate(struct.iter_unpack('<3f',neighbour)):
        vx,vz,vy=vertices[pos_to_id[i,256]]
        require((exact_f32(x),exact_f32(y),exact_f32(z)+64)==(F(vx-128,4),vy,F(vz,4)), 'seam-world-position')
    return {'unique_edges':len(edges),'boundary_segments':len(actual),'seam_vertices':257,
            'seam_encoding':'exact dyadic f32 local positions + exact 64 m neighbour datum'}

def shelf_mesh(h,vertices=None,tris=None):
    if vertices is None:
        out=[]
        for z in range(112,144):
            for x in range(96,128):
                for t in source_cell_triangles(x,z):
                    out.append(tuple((F(a,4),F(b,4),F(h[b*257+a],10000)) for a,b in t))
        return out
    out=[]
    for t in tris:
        vs=[vertices[k] for k in t]
        if all(96<=a<=128 and 112<=b<=144 for a,b,y in vs):
            out.append(tuple((F(a,4),F(b,4),y) for a,b,y in vs))
    return out

def wet_statistics(mesh,stage):
    """Exact strict b<H connectivity; continuous area/volume use <= clipping.

    Open sublevel triangles connect iff their shared edge contains a positive-
    length wet interval. Pure equal-height contacts never connect components.
    """
    parent=list(range(len(mesh)))
    def find(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]]; i=parent[i]
        return i
    edge_owner={}
    active=set()
    total_area=total_volume=F(0)
    for idx,tri in enumerate(mesh):
        if min(v[2] for v in tri)>=stage: continue
        active.add(idx)
        for p,q in zip(tri,tri[1:]+tri[:1]):
            if min(p[2],q[2])>=stage: continue
            key=tuple(sorted((p[:2],q[:2])))
            if key in edge_owner:
                a,b=find(idx),find(edge_owner[key]); parent[a]=b
            else: edge_owner[key]=idx
        poly=[]
        for p,q in zip(tri,tri[1:]+tri[:1]):
            if p[2]<=stage: poly.append(p)
            if (p[2]<stage<q[2]) or (q[2]<stage<p[2]):
                t=(stage-p[2])/(q[2]-p[2])
                poly.append(tuple(p[d]+t*(q[d]-p[d]) for d in range(3)))
        for k in range(1,len(poly)-1):
            fan=(poly[0],poly[k],poly[k+1])
            a=area([v[:2] for v in fan])
            total_area+=a
            total_volume+=a*sum(stage-v[2] for v in fan)/3
    # Stable left/right source seed coordinates are on the zero-height floor.
    seeds={'west':(F(100,4),F(120,4)), 'east':(F(120,4),F(120,4))}
    labels={}
    for name,p in seeds.items():
        hit=[]
        for k in active:
            tri=mesh[k]; xy=tuple(v[:2] for v in tri)
            if all(w>=0 for w in weights(xy,p)) and sum(w*v[2] for w,v in zip(weights(xy,p),tri))<stage:
                hit.append(find(k))
        require(len(set(hit))<=1,'ambiguous-seed-connectivity')
        labels[name]=hit[0] if hit else None
    connected=labels['west'] is not None and labels['west']==labels['east']
    return {'components':len({find(k) for k in active}), 'seeds_connected':connected,
            'wet_area_m2':str(total_area),'storage_geometry_m3':str(total_volume)}

def shelf_certificate(h,vertices,tris):
    source=shelf_mesh(h)
    final=shelf_mesh(h,vertices,tris)
    require(len(source)==len(final)==2048,'protected-shelf-triangle-count')
    # Set of full XYZ triangles, canonical up to cyclic order, independent of IDs.
    canon=lambda t: min(tuple(t[k:]+t[:k]) for k in range(3))
    require({canon(t) for t in source}=={canon(t) for t in final},'protected-sill-correspondence')
    critical=sorted({v[2] for t in source for v in t})
    require(critical==[F(0),F(1,8),F(1,4)],'protected-critical-levels')
    # Open intervals have unchanged topology between these PL vertex events.
    levels=[F(-1,16),F(0),F(1,16),F(1,8),F(3,16),F(1,4),F(5,16)]
    rows=[]
    for stage in levels:
        a,b=wet_statistics(source,stage),wet_statistics(final,stage)
        require(a==b,'protected-wet-set-mismatch')
        expected=0 if stage<=0 else 2 if stage<=F(1,8) else 1
        require(a['components']==expected,'source-sill-oracle')
        rows.append({'stage_m':str(stage),**a})
    return {'critical_levels_m':list(map(str,critical)), 'rows':rows,
            'all_stage_identity':'exact same source/final XYZ faces on protected support; all wet sets and area/volume curves identical for every H',
            'equality_convention':'b < H; adjacent open intervals and equality checked at every critical height'}

def bank_shore_certificate(h,vertices,tris):
    # All source vertices over the full 64 m x 1 m strip lie on b=x/20.
    require(all(h[z*257+x]==(x-128)*125 for z in range(5) for x in range(257)),
            'analytic-bank-source-oracle')
    support=[]
    for t in tris:
        vs=[vertices[k] for k in t]
        if all(0<=z<=4 for x,z,y in vs):
            support.append(tuple((F(x-128,4),F(z,4),y) for x,z,y in vs))
    source=[]
    for z in range(4):
        for x in range(256):
            for t in source_cell_triangles(x,z):
                source.append(tuple((F(a-128,4),F(b,4),F(h[b*257+a],10000)) for a,b in t))
    rows=[]
    for H in (F(-1),F(0),F(1,3),F(1,2)):
        segments=[]
        deviation=F(0)
        for t in support:
            pts=set()
            for p,q in zip(t,t[1:]+t[:1]):
                if p[2]==H: pts.add(p[:2])
                if (p[2]<H<q[2]) or (q[2]<H<p[2]):
                    a=(H-p[2])/(q[2]-p[2])
                    pts.add((p[0]+a*(q[0]-p[0]),p[1]+a*(q[1]-p[1])))
            if len(pts)>=2:
                zs=[p[1] for p in pts]
                segments.append((min(zs),max(zs)))
                deviation=max(deviation,max(abs(p[0]-20*H) for p in pts))
        # The exact contour covers every z in [0,1]. Every segment has affine
        # x(z), so endpoint extrema give its true maximum horizontal deviation.
        reached=F(0)
        for a,b in sorted(segments):
            require(a<=reached,'bank-contour-gap')
            reached=max(reached,b)
        require(reached==1,'bank-contour-support')
        require(deviation<=F(1,10),'actual-bank-contour-budget')
        source_stats=wet_statistics(source,H)
        final_stats=wet_statistics(support,H)
        expected_area=20*H+32
        expected_volume=10*(H+F(8,5))**2
        require(F(source_stats['wet_area_m2'])==expected_area and
                F(source_stats['storage_geometry_m3'])==expected_volume,'analytic-bank-area-volume-oracle')
        # Independent Lipschitz bounds valid at every H, not fitted samples.
        e=max(abs(v[2]-F(h[v[1]*257+v[0]],10000)) for v in vertices if v[1]<=4)
        require(abs(F(final_stats['wet_area_m2'])-expected_area)<=40*e,'bank-area-bound')
        require(abs(F(final_stats['storage_geometry_m3'])-expected_volume)<=64*e,'bank-volume-bound')
        rows.append({'H_m':str(H),'source_shore_x_m':str(20*H),
                     'source_area_formula_m2':str(expected_area), 'source_volume_formula_m3':str(expected_volume),
                     'final_area_m2':final_stats['wet_area_m2'], 'final_volume_m3':final_stats['storage_geometry_m3'],
                     'final_contour_max_horizontal_deviation_m':str(deviation),
                     'contour_segments':len(segments)})
    return {'source_gradient':'1/20', 'support_m':'x=[-32,32], z=[0,1]',
            'stage_interval_m':'[-1,1/2]',
            'all_stage_bound':'20 * exact final-source vertical error; source planar with no water/coordinate residual; endpoints bracket every stage',
            'all_stage_area_bound_m2':'40 * bank vertical bound',
            'all_stage_volume_bound_m3':'64 * bank vertical bound; max(H-b,0) is 1-Lipschitz in b over 64 m2 support',
            'independent_source_formulas':'A(H)=20H+32 m2; V(H)=10*(H+8/5)^2 m3 for 1 m Z strip',
            'exact_contour_witnesses':rows}

def nearest_even_binary32(q):
    """Exact rational rounding oracle, independent of producer's float division.

    Binary search ordered positive IEEE754 encodings, compare exact distances,
    break midpoint ties by significand parity. Source profile is |q| <= 2m.
    """
    negative=q<0
    q=abs(q)
    def dyadic(bits):
        return F(struct.unpack('<f',struct.pack('<I',bits))[0])
    lo,hi=0,0x40000000
    while lo<hi:
        mid=(lo+hi+1)//2
        if dyadic(mid)<=q: lo=mid
        else: hi=mid-1
    lower=dyadic(lo)
    if lower==q:
        chosen=lo
    else:
        upper=dyadic(lo+1)
        dl,du=q-lower,upper-q
        chosen=lo if dl<du or (dl==du and lo%2==0) else lo+1
    bits=chosen|(0x80000000 if negative else 0)
    return bits,(-dyadic(chosen) if negative else dyadic(chosen))

def enforce_source_attached_encoding(h,vertices,product):
    cache={}
    pure=F(0)
    for k,(x,z,y) in enumerate(vertices):
        units=h[z*257+x]
        if units not in cache:
            q=F(units,10000)
            bits,rounded=nearest_even_binary32(q)
            cache[units]=(bits,abs(rounded-q))
        bits,error=cache[units]
        require(struct.unpack_from('<I',product,12+k*12+4)[0]==bits,
                'source-attached-f32-encoding')
        pure=max(pure,error)
    return {'enforced_vertex_encodings':len(vertices),
            'independent_rounding_oracle_unique_heights':len(cache),
            'max_pure_f32_height_rounding_m':str(pure),
            'f32_rounding':'exact rational nearest-even IEEE754 binary32; raw y bits verified at every source-attached vertex, including unused vertices'}

def verify(root,binding=None):
    b,h,vertices,tris,blobs=decode(root,binding)
    require(b['neighbour_origin_z_m']==64 and b['shelf_grid_roi']==[96,112,128,144] and
            b['protected_crest_m']=='1/8' and b['max_vertical_error_m']=='1/200' and
            b['max_bank_shore_error_m']=='1/10','binding-policy')
    report=partition_and_error(h,vertices,tris)
    report['manifold_seam']=manifold_and_seam(vertices,tris,blobs['neighbour'])
    require(F(report['bank_shore_bound_m'])<=F(1,10),'bank-shore-budget')
    require(F(report['max_absolute_error_m'])<=F(1,200),'vertical-error-budget')
    require(F(report['protected_shelf_max_error_m'])==0,'protected-sill-shift')
    report['output_encoding']=enforce_source_attached_encoding(h,vertices,blobs['product'])
    report['bank_shore']=bank_shore_certificate(h,vertices,tris)
    report['shelf']=shelf_certificate(h,vertices,tris)
    report['source_sha256']=b['source_sha256']; report['product_sha256']=b['product_sha256']
    report['logical_resident_bytes']={'source_i32_heights':66049*4, 'final_f32_XYZ':66049*12, 'final_u32_indices':len(tris)*12, 'neighbour_f32_XYZ':257*12,
        'packed_decoded_payload_total':66049*4+66049*12+len(tris)*12+257*12,
        'retained_serialized_input_bytes':sum(len(x) for x in blobs.values()),
        'scope':'packed payload lower account, not Python object allocation or RSS; source and product blobs coexist with decoded Python objects during checker'}
    report['manifold_directed_edge_visits']=3*len(tris)
    report['status']='passed-bounded-offline-certificate'
    return report

if __name__=='__main__':
    import sys
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent),indent=2,sort_keys=True))
