# Two-cell optical interaction — allocation plan

Source revision 1a0a01c2c8735b74 and all source equations unchanged. Old v2 anatomy is a coupling reference, not art adoption. No server/browser/GPU started by author.

GPU shared R16 pairs/noise 16,187,392 B once. Poses16*96=1,536 B; domains64 B; source group boxes64 B; prior/current controls628,864 B. GPU controls are indexed by global slot, independently from dense pose rows. CPU source banks1,886,592 B; observer copy628,864 B only on demand; ordinary frames borrow synchronously then release. No512-cell allocation.

Held-only graph: cache32*24*24*8=147,456 B focused on A; receiver128²*8=131,072 B with separately declared16km domain; air256*64*8=131,072 B; view1280*720*8=7,372,800 B. Three192B uniform slots=576 B. Three timestamp generations each query8*8 +resolve256+read256 (logical buffers1,536 B plus query implementation cost unknown). Native assets stay CPU-side for explicit probes. Temporary probe storage/readback is bounded by2,000vec4 points (<128KiB total); disposed after fence.

Point query MAX within each eight-slot group, ADD between. Strict-positive group support boxes define sorted/merged ray intervals, max2; use sample count per merged occupied span and never spend samples across the14km empty gap. Per-ray count ceilings up to2*count; no fidelity or timing claim. Sun/ambient misses outside A cache directly traverse all source intervals; no clear-outside-cache sentinel. Receiver and reflected rays share field/time, main-hidden only disables main camera cloud. Clear-air/fog prototype retained, full P4a/four-LUT/environment incomplete.

Functional source/native tests serial:224MiB early/256MiB hard sampled process-tree guard; no throughput benchmark. Preexisting concurrent failure retained in CPU slice; do not repeat concurrent harness. Timestamp pairs are strictly within receiver/light/view/display passes; bounded3 generations with immutable source/fixture submission keys, whole graph time null.

Lifetime: resources persist until drained disposal;3frame uniforms may recycle only after graph queue drain/capacity. Fixture switch rebuilds world+clock/fresh optical epoch after fence, invalidates uploads. Pause/camera changes publish without stepping. Submission receipts copy immutable small facts before await; deep metadata/exposure only requested capture/probe.
