// Synthetic no-UI output wrapper around unchanged pinned FXAA operator.
fn output_decode(v: f32) -> f32 {
    if v <= .04045 { return v / 12.92; }
    return pow((v+.055)/1.055, 2.4);
}
fn output_encode(v: f32) -> f32 {
    if v <= .0031308 { return 12.92*v; }
    return 1.055*pow(v, 1./2.4)-.055;
}
@fragment fn fs_output(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32> {
    let e = fxaa_encoded(position).rgb;
    let linear = vec3(output_decode(e.r), output_decode(e.g), output_decode(e.b));
    return vec4(output_encode(linear.r), output_encode(linear.g), output_encode(linear.b), 1.);
}
