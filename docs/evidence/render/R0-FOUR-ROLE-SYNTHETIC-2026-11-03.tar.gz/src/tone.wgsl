@group(0) @binding(0) var scene: texture_2d<f32>;
@vertex fn vs_full(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    let xy = array<vec2<f32>, 3>(vec2(-1., -1.), vec2(3., -1.), vec2(-1., 3.));
    return vec4(xy[i], 0., 1.);
}
fn encode(v: f32) -> f32 {
    if v <= .0031308 { return 12.92*v; }
    return 1.055*pow(v, 1./2.4)-.055;
}
@fragment fn fs_tone(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
    let l = textureLoad(scene, vec2<i32>(pos.xy), 0).rgb * 1024.;
    let t = l / (1. + dot(l, vec3(.2126, .7152, .0722)));
    let d = t / max(1., max(t.r, max(t.g, t.b)));
    let e = vec3(encode(d.r), encode(d.g), encode(d.b));
    return vec4(e, dot(e, vec3(.299, .587, .114)));
}
