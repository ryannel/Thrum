//! One-frame synthetic four-role R0 dependency chain. No authored-game,
//! GPU-incomplete hold, credit, resize, residency or performance claim.
use std::{error::Error, sync::mpsc, time::Duration};
use wgpu::*;
const HD: (u32, u32) = (1280, 720);
type AnyResult<T> = Result<T, Box<dyn Error>>;

fn texture(
    d: &Device,
    name: &str,
    extent: (u32, u32),
    format: TextureFormat,
    usage: TextureUsages,
) -> Texture {
    println!(
        "texture={name} extent={extent:?} format={format:?} usage={usage:?} mips=1 samples=1 layers=1"
    );
    d.create_texture(&TextureDescriptor {
        label: Some(name),
        size: Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format,
        usage,
        view_formats: &[],
    })
}
fn pipeline(
    d: &Device,
    m: &ShaderModule,
    vs: &str,
    fs: &str,
    format: Option<TextureFormat>,
    depth: Option<bool>,
) -> RenderPipeline {
    let targets = format.map(|format| {
        [Some(ColorTargetState {
            format,
            blend: None,
            write_mask: ColorWrites::ALL,
        })]
    });
    d.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(fs),
        layout: None,
        vertex: VertexState {
            module: m,
            entry_point: Some(vs),
            buffers: &[],
            compilation_options: Default::default(),
        },
        primitive: Default::default(),
        depth_stencil: depth.map(|write| DepthStencilState {
            format: TextureFormat::Depth32Float,
            depth_write_enabled: Some(write),
            depth_compare: Some(CompareFunction::Greater),
            stencil: Default::default(),
            bias: Default::default(),
        }),
        multisample: Default::default(),
        fragment: Some(FragmentState {
            module: m,
            entry_point: Some(fs),
            targets: targets.as_ref().map_or(&[], |x| x.as_slice()),
            compilation_options: Default::default(),
        }),
        multiview_mask: None,
        cache: None,
    })
}
fn color_attachment(view: &TextureView) -> RenderPassColorAttachment<'_> {
    RenderPassColorAttachment {
        view,
        depth_slice: None,
        resolve_target: None,
        ops: Operations {
            load: LoadOp::Clear(Color {
                r: 1.,
                g: 0.,
                b: 1.,
                a: 1.,
            }),
            store: StoreOp::Store,
        },
    }
}
fn write_depth(e: &mut CommandEncoder, name: &str, view: &TextureView, pipe: &RenderPipeline) {
    let mut p = e.begin_render_pass(&RenderPassDescriptor {
        label: Some(name),
        color_attachments: &[],
        depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
            view,
            depth_ops: Some(Operations {
                load: LoadOp::Clear(0.),
                store: StoreOp::Store,
            }),
            stencil_ops: None,
        }),
        ..Default::default()
    });
    p.set_pipeline(pipe);
    p.draw(0..3, 0..1);
}
fn draw_color(
    e: &mut CommandEncoder,
    name: &str,
    view: &TextureView,
    pipe: &RenderPipeline,
    group: &BindGroup,
) {
    let mut p = e.begin_render_pass(&RenderPassDescriptor {
        label: Some(name),
        color_attachments: &[Some(color_attachment(view))],
        ..Default::default()
    });
    p.set_pipeline(pipe);
    p.set_bind_group(0, group, &[]);
    p.draw(0..3, 0..1);
}

// CPU oracle uses f64 and arithmetic binary16 rounding, independently of WGSL.
// Only positive normalized values in this fixture are accepted.
fn half_round(v: f64) -> f64 {
    assert!(v.is_finite() && (2f64.powi(-14)..=65504.).contains(&v));
    let step = 2f64.powi(v.log2().floor() as i32 - 10);
    (v / step).round_ties_even() * step
}
fn srgb(v: f64) -> f64 {
    if v <= 0.0031308 {
        12.92 * v
    } else {
        1.055 * v.powf(1. / 2.4) - 0.055
    }
}
fn oracle() -> [u8; 4] {
    // .5 > .75 is false in the Sun comparator. Forward draw at .875 passes
    // view depth .75; later draw at .5 fails. Blue is immutable fixture tag 0.5. The low radiance keeps gamut
    // normalization inactive, so the tone denominator remains observable.
    let l = [0.125, 0.125, 0.5].map(|x| half_round(x / 1024.) * 1024.);
    let y = 0.2126 * l[0] + 0.7152 * l[1] + 0.0722 * l[2];
    let t = l.map(|x| x / (1. + y));
    let normalization = t.into_iter().fold(1f64, f64::max);
    let e = t.map(|x| half_round(srgb(x / normalization)));
    // Uniform FXAA takes its selected early exit and returns center.rgb.
    [
        (e[0] * 255.).round() as u8,
        (e[1] * 255.).round() as u8,
        (e[2] * 255.).round() as u8,
        255,
    ]
}
fn verify(d: &Device, b: &Buffer) -> AnyResult<()> {
    let (tx, rx) = mpsc::channel();
    b.slice(..).map_async(MapMode::Read, move |r| {
        let _ = tx.send(r);
    });
    d.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(10)),
    })?;
    rx.recv_timeout(Duration::from_secs(2))??;
    let mapped = b.slice(..).get_mapped_range()?;
    let bytes = mapped.as_ref();
    assert_eq!(bytes.len(), HD.0 as usize * HD.1 as usize * 4);
    let expected = oracle();
    let mut worst = 0;
    let (pixels, remainder) = bytes.as_chunks::<4>();
    assert!(remainder.is_empty());
    for (i, pixel) in pixels.iter().enumerate() {
        for c in 0..4 {
            let delta = pixel[c].abs_diff(expected[c]);
            worst = worst.max(delta);
            assert!(
                delta <= if c == 3 { 0 } else { 1 },
                "pixel {i} channel {c}: got {}, expected {} +/- 1",
                pixel[c],
                expected[c]
            );
        }
    }
    println!(
        "synthetic every-pixel oracle passed: expected={expected:?} first={:?} pixels={} max_code_error={worst}",
        &bytes[..4],
        HD.0 * HD.1
    );
    drop(mapped);
    b.unmap();
    Ok(())
}
fn payload(extent: (u32, u32), bytes_per_texel: u64) -> AnyResult<u64> {
    u64::from(extent.0)
        .checked_mul(u64::from(extent.1))
        .and_then(|pixels| pixels.checked_mul(bytes_per_texel))
        .ok_or_else(|| "logical texture payload overflow".into())
}
fn main() -> AnyResult<()> {
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let instance = Instance::new(desc);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let info = adapter.get_info();
    let rt = TextureUsages::RENDER_ATTACHMENT;
    let sampled = rt | TextureUsages::TEXTURE_BINDING;
    for (format, usage, filter) in [
        (TextureFormat::Depth32Float, sampled, false),
        (TextureFormat::Rgba16Float, sampled, true),
        (
            TextureFormat::Rgba8Unorm,
            rt | TextureUsages::COPY_SRC,
            false,
        ),
    ] {
        let support = adapter.get_texture_format_features(format);
        assert!(support.allowed_usages.contains(usage));
        assert!(
            !filter
                || support
                    .flags
                    .contains(TextureFormatFeatureFlags::FILTERABLE)
        );
    }
    assert!(adapter.limits().max_texture_dimension_2d >= 2048);
    let (d, q) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    assert!(d.limits().max_texture_dimension_2d >= 2048);
    println!(
        "adapter={} backend={:?} max2d={}",
        info.name,
        info.backend,
        d.limits().max_texture_dimension_2d
    );
    let view_depth_bytes = payload(HD, 4)?;
    let hdr_bytes = payload(HD, 8)?;
    let sun_bytes = payload((2048, 2048), 4)?;
    let scratch = sun_bytes
        .checked_add(view_depth_bytes)
        .and_then(|b| b.checked_add(hdr_bytes))
        .and_then(|b| b.checked_add(hdr_bytes))
        .ok_or("scratch sum overflow")?;
    let output_bytes = payload(HD, 4)?;
    let readback_bytes = output_bytes; // Pitch 5120 is aligned; no row padding.
    let total = scratch
        .checked_add(output_bytes)
        .and_then(|b| b.checked_add(readback_bytes))
        .ok_or("total sum overflow")?;
    let scope = d.push_error_scope(ErrorFilter::Validation);
    let sun = texture(
        &d,
        "Sun D32",
        (2048, 2048),
        TextureFormat::Depth32Float,
        sampled,
    );
    let depth = texture(&d, "View D32", HD, TextureFormat::Depth32Float, rt);
    let scene = texture(&d, "Scene linear", HD, TextureFormat::Rgba16Float, sampled);
    let encoded = texture(&d, "Encoded scene", HD, TextureFormat::Rgba16Float, sampled);
    let output = texture(
        &d,
        "Independent harness output",
        HD,
        TextureFormat::Rgba8Unorm,
        rt | TextureUsages::COPY_SRC,
    );
    let [sun_v, depth_v, scene_v, encoded_v, output_v] =
        [&sun, &depth, &scene, &encoded, &output].map(|t| t.create_view(&Default::default()));
    let module = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("synthetic depth/forward"),
        source: ShaderSource::Wgsl(include_str!("chain.wgsl").into()),
    });
    let tone = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("selected tone/encode formula"),
        source: ShaderSource::Wgsl(include_str!("tone.wgsl").into()),
    });
    // Keep the pinned file unchanged; make its entry an ordinary function so
    // a tiny output wrapper can decode to display-linear and explicitly encode
    // once for the UNORM output. No extra display intermediate is allocated.
    let pinned_fxaa = include_str!("fxaa.wgsl");
    let entry =
        "@fragment fn fs_fxaa(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32>";
    assert_eq!(pinned_fxaa.matches(entry).count(), 1);
    let mut output_source =
        pinned_fxaa.replace(entry, "fn fxaa_encoded(position: vec4<f32>) -> vec4<f32>");
    output_source.push_str(include_str!("output.wgsl"));
    let fxaa = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("pinned FXAA quality12 v1 plus explicit output wrapper"),
        source: ShaderSource::Wgsl(output_source.into()),
    });
    let depth_p = pipeline(&d, &module, "vs_depth", "fs_depth", None, Some(true));
    let first_p = pipeline(
        &d,
        &module,
        "vs_first",
        "fs_first",
        Some(TextureFormat::Rgba16Float),
        Some(false),
    );
    let second_p = pipeline(
        &d,
        &module,
        "vs_second",
        "fs_second",
        Some(TextureFormat::Rgba16Float),
        Some(false),
    );
    let tone_p = pipeline(
        &d,
        &tone,
        "vs_full",
        "fs_tone",
        Some(TextureFormat::Rgba16Float),
        None,
    );
    let fxaa_p = pipeline(
        &d,
        &fxaa,
        "vs_fxaa",
        "fs_output",
        Some(TextureFormat::Rgba8Unorm),
        None,
    );
    let comparison = d.create_sampler(&SamplerDescriptor {
        label: Some("Sun greater comparison"),
        compare: Some(CompareFunction::Greater),
        ..Default::default()
    });
    let filtering = d.create_sampler(&SamplerDescriptor {
        label: Some("FXAA linear clamp"),
        min_filter: FilterMode::Linear,
        mag_filter: FilterMode::Linear,
        ..Default::default()
    });
    let sun_g = d.create_bind_group(&BindGroupDescriptor {
        label: Some("Sun read"),
        layout: &first_p.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&sun_v),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&comparison),
            },
        ],
    });
    // Auto layouts are pipeline-exclusive, even for structurally identical shaders.
    let sun_g2 = d.create_bind_group(&BindGroupDescriptor {
        label: Some("Sun second draw read"),
        layout: &second_p.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&sun_v),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&comparison),
            },
        ],
    });
    let tone_g = d.create_bind_group(&BindGroupDescriptor {
        label: Some("Scene last read"),
        layout: &tone_p.get_bind_group_layout(0),
        entries: &[BindGroupEntry {
            binding: 0,
            resource: BindingResource::TextureView(&scene_v),
        }],
    });
    let fxaa_g = d.create_bind_group(&BindGroupDescriptor {
        label: Some("Encoded last read"),
        layout: &fxaa_p.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&encoded_v),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&filtering),
            },
        ],
    });
    let readback = d.create_buffer(&BufferDescriptor {
        label: Some("Separate harness readback"),
        size: readback_bytes,
        usage: BufferUsages::MAP_READ | BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });
    let mut e = d.create_command_encoder(&CommandEncoderDescriptor::default());
    write_depth(&mut e, "Sun first write", &sun_v, &depth_p);
    write_depth(&mut e, "View depth first write", &depth_v, &depth_p);
    {
        let mut p = e.begin_render_pass(&RenderPassDescriptor {
            label: Some("Forward: Sun/view last read; scene first write"),
            color_attachments: &[Some(color_attachment(&scene_v))],
            depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
                view: &depth_v,
                depth_ops: None,
                stencil_ops: None,
            }),
            ..Default::default()
        });
        p.set_pipeline(&first_p);
        p.set_bind_group(0, &sun_g, &[]);
        p.draw(0..3, 0..1);
        p.set_pipeline(&second_p);
        p.set_bind_group(0, &sun_g2, &[]);
        p.draw(0..3, 0..1);
    }
    draw_color(
        &mut e,
        "Tone: scene last read; encoded first write",
        &encoded_v,
        &tone_p,
        &tone_g,
    );
    draw_color(
        &mut e,
        "FXAA uniform early exit to independent encoded UNORM output",
        &output_v,
        &fxaa_p,
        &fxaa_g,
    );
    e.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: &output,
            mip_level: 0,
            origin: Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: &readback,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(HD.0 * 4),
                rows_per_image: Some(HD.1),
            },
        },
        Extent3d {
            width: HD.0,
            height: HD.1,
            depth_or_array_layers: 1,
        },
    );
    let serial = q.submit([e.finish()]);
    d.poll(PollType::Wait {
        submission_index: Some(serial),
        timeout: Some(Duration::from_secs(10)),
    })?;
    if let Some(error) = pollster::block_on(scope.pop()) {
        return Err(format!("wgpu validation: {error}").into());
    }
    verify(&d, &readback)?;
    println!(
        "logical scratch={scratch}; independent output={output_bytes}; readback={readback_bytes}; total explicit payload={total} bytes"
    );
    println!(
        "synthetic one-frame four-role chain only; no authored R0, resize/credits, residency or performance claim"
    );
    Ok(())
}
