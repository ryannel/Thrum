# Synthetic single-frame four-role chain — 3 November 2026

Implemented and ran only in this owned scratch directory. Developed from
repository base `0ba7cd94eb56331f0cfecf44348634c14968b9a2`; final source
run with local main at `e507d93574aaedd01e04ba050bf0c27b3e84da43`.
Rust 1.99.1, pinned wgpu
30.0.1, Metal, Apple M3 Max, reported max2d 8192. No tracked file was changed.
The standalone manifest/lock includes only the direct wgpu and pollster
dependencies; this slice does not install a native gate.

## Descriptors and passes

All textures: 2D, one layer, one mip, one sample, empty view_formats.

| Role | Exact format and extent | Usage |
| --- | --- | --- |
| Sun | Depth32Float, 2048x2048 | RENDER_ATTACHMENT + TEXTURE_BINDING |
| View depth | Depth32Float, 1280x720 | RENDER_ATTACHMENT |
| Scene linear | Rgba16Float, 1280x720 | RENDER_ATTACHMENT + TEXTURE_BINDING |
| Encoded scene | Rgba16Float, 1280x720 | RENDER_ATTACHMENT + TEXTURE_BINDING |
| Independent harness output | Rgba8Unorm, 1280x720 | RENDER_ATTACHMENT + COPY_SRC |
| Separate readback buffer | 3,686,400 bytes, row pitch 5120 | COPY_DST + MAP_READ |

1. Sun: clear reverse-Z depth 0, full-screen draw at .75, store. Its later four
   equal-weight comparison samples at reference .5 all return zero.
2. View depth: clear 0, full-screen draw at .75, store.
3. Forward: use view depth read-only (`depth_ops: None` and pipeline depth writes
   false), compare Greater. Full-screen draw at .875 passes, then .5 fails;
   both shader variants sample Sun. RGB codes independently expose Sun comparison,
   surviving draw and immutable synthetic tag. Scene stored RGB is
   `[.125, .125, .5]/1024`, alpha 1. The scene is cleared magenta before drawing,
   so missing forward coverage is also observable.
4. Tone reads scene, undoes p=1/1024, uses exposure 1 and selected Rec.709
   luminance/Reinhard/gamut formula, encodes sRGB and writes encoded-luma alpha.
   Radiance is deliberately low enough that gamut normalization remains inactive;
   the tone denominator therefore affects the checked result.
5. The pinned FXAA Quality12 v1 operator takes its uniform early-exit path.
   Its unchanged archived source has SHA-256
   `5f26af44c01e3e605c7822b1881b4200ec8bebb6dfcdbabd41fe850cacb64384`.
   At shader assembly only, the exact entry signature is changed into an ordinary
   function; a small separate wrapper decodes to display-linear and explicitly
   encodes for the UNORM output, alpha 1. No extra target is introduced.
   The decode/encode pair cancels for this uniform fixture; the result does
   not independently verify both transfer functions or encoded-luma/edge use.
6. Copy output to the separately charged buffer, wait/map and verify all pixels.

`src/fxaa.wgsl` is an exact copy of
`docs/evidence/render/fxaa-quality12-v1/fxaa.wgsl`; the upstream notices and Intel
Apache notice/license are retained beside this result. No production code is added.

## Verification and result

The CPU oracle uses f64 and independent arithmetic binary16 rounding for the scene
and encoded targets, then final UNORM rounding. It admits at most one code value of
RGB numerical difference and requires exact alpha. The fixture only uses positive
normal half values. Expected output `[93,93,176,255]` matched every one of 921,600
pixels with **maximum code error 0**. The wgpu validation error scope was empty.
All textures/readback and shader bindings remain owned through verification.

Checked arithmetic before allocation derives scratch 35,209,216 B, output
3,686,400 B and readback 3,686,400 B: **42,582,016 B explicit logical payload**.
This excludes driver alignment/overhead and pipelines; it is not measured residency.
There are no packet/upload uniform buffers in this fixed-tag slice.

Build and run from repository root:

```sh
RUSTC_WRAPPER= rustup run 1.99.1 cargo build --offline --locked --release --manifest-path tmp/r0-four-role/Cargo.toml
tmp/r0-four-role/target/release/r0-four-role-synthetic
```

Native GPU access was required: the sandboxed run returned adapter NotFound; the
same compiled binary passed with native GPU access. The initial compile error for
an unavailable Color::MAGENTA constant was corrected to an explicit color.

Scope remains one synthetic frame and the uniform FXAA branch. No authored R0
geometry/material/mask/light correctness, edge-filter equivalence, F4 product
binding, graph validator, two-credit admission, GPU-incomplete hold, resize,
retirement, loading transaction, surface presentation, device loss, physical
high-water, frame timing or performance claim is made.

Final source passed pinned rustfmt and isolated release Clippy with `-D warnings`;
the final rebuilt binary then passed again with output retained in `run.log`.
Repository-wide checks are left to parent integration; no tracked code was changed.
