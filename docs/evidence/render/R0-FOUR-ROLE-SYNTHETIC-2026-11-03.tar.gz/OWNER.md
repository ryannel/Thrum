Owner: R0 synthetic four-role GPU diagnostic, 3 November 2026.
Purpose: isolated wgpu 30.0.1 Metal format/usage/dependency chain.
Expected peak disk: under 2 GiB including isolated Cargo target.
Selected inputs: committed R0 schedule candidate, selected FXAA package and pinned wgpu/pollster crates.
Retained output: small source archive/hash and compact evidence record if the run passes.
Closeout: retain selected source/evidence, then inspect owned build output for cleanup.

Current commission: /root/r0_gpu_narrow_review owns this scratch directory only.
Purpose: single-frame synthetic four-role dependency chain (no credit/resize work).
The archived native-event harness was the pinned dependency starting point;
the current main does not use native gates. Parent integrates/extensions sequentially.
