#!/usr/bin/env python3
"""Generate the small, exact-byte source-like geometry for the R0 shadow study."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def quad(x0, x1, y0, y1, z, role):
    return {
        "role": role,
        "positions_m": [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]],
        "triangles": [[0, 1, 2], [0, 2, 3]],
    }


fixture = {
    "format": "r0-first-shadow-geometry-v1",
    "camera": {"position_m": [0, 0, 5], "vertical_fov_rad": 1.0471975511965976,
               "aspect": [16, 9], "near_m": 0.1, "far_m": 20},
    "sun_toward_source_unit": [0.6, 0, 0.8],
    "light_box_m": {"xi": [-2.5, 2.5], "eta": [-2.1, 2.1], "zeta": [-2, 4]},
    "map_extent": 2048,
    "mask_alpha_4x4": [[1 if (x + y) % 2 == 0 else 0 for x in range(4)]
                       for y in range(4)],
    "mask_cutoff": 0.5,
    "quads": [
        quad(-3, 3, -2, 2, 0, "receiver"),
        quad(-0.6, 0.6, -1, 1, 1, "masked-fence"),
        quad(3.4, 3.8, -0.4, 0.4, 2, "offscreen-caster"),
    ],
}
out = ROOT / "fixture_geometry.json"
data = (json.dumps(fixture, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode()
out.write_bytes(data)
print("fixture_bytes", len(data))
print("fixture_sha256", hashlib.sha256(data).hexdigest())
