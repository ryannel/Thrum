#!/usr/bin/env python3
"""Separate geometric and mutation checks on the retained shadow result."""
import hashlib
import json
import math
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
raw = (ROOT / "fixture_geometry.json").read_bytes()
fixture = json.loads(raw)
result = json.loads((ROOT / "results.json").read_text())
assert result["fixture_sha256"] == hashlib.sha256(raw).hexdigest()
assert len(fixture["quads"]) == 3
assert sum(len(q["triangles"]) for q in fixture["quads"]) == 6
assert result["sample_count"] == 8 * (12 + 41 * 41)

sun_x = F.from_float(fixture["sun_toward_source_unit"][0])
sun_z = F.from_float(fixture["sun_toward_source_unit"][2])
caster = fixture["quads"][2]
caster_x = [F.from_float(caster["positions_m"][i][0]) for i in (0, 1)]
shadow_x = [x - F(2) * sun_x / sun_z for x in caster_x]
assert F(-3) < shadow_x[0] < shadow_x[1] < F(3)
wrong_x = [x + F(2) * sun_x / sun_z for x in caster_x]
assert wrong_x[0] > 3
assert abs(float(wrong_x[0]) - result["wrong_sun_sign_mutant_shadow_x_m"][0]) < 1e-14

camera = fixture["camera"]
depth = camera["position_m"][2] - caster["positions_m"][0][2]
half_x = depth * math.tan(camera["vertical_fov_rad"] / 2) * (
    camera["aspect"][0] / camera["aspect"][1]
)
assert caster_x[0] > F.from_float(half_x)

cases = result["tap_cases"]
assert cases["caster_shadow"]["beta1"]["lit_fraction"] == 0.0
assert cases["caster_shadow"]["camera_cull_mutant"]["lit_fraction"] == 1.0
assert cases["caster_shadow"]["compare_sign_mutant"]["lit_fraction"] == 1.0
assert cases["lit_left"]["beta0"]["lit_fraction"] < 1.0
assert cases["lit_left"]["beta1"]["lit_fraction"] == 1.0
assert 0 < cases["fence_region"]["beta1"]["lit_fraction"] < 1
assert result["worst"]["depth"]["error"] < 1e-4
assert result["worst"]["map_texel_x"]["error"] < 0.1
assert result["worst"]["map_texel_y"]["error"] < 0.1
print("six source-like triangles, offscreen-caster, reverse-Z, four-tap and three mutants pass")
print("rational_shadow_x_m", [str(x) for x in shadow_x])
print("camera_half_x_m", half_x)
