#!/usr/bin/env python3
"""Independent source-rational vs explicit f32 R0 shadow projection study."""
import hashlib
import json
import math
import struct
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = ROOT / "fixture_geometry.json"
fixture = json.loads(source.read_text())


def f32(x):
    return struct.unpack("<f", struct.pack("<f", float(x)))[0]


def frac(x):
    return F.from_float(float(x))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def rounded_dot4(row, vec):
    acc = f32(f32(row[0] * vec[0]) + f32(row[1] * vec[1]))
    acc = f32(acc + f32(row[2] * vec[2]))
    return f32(acc + f32(row[3] * vec[3]))


raw_s = fixture["sun_toward_source_unit"]
length = math.sqrt(((raw_s[0] * raw_s[0]) + (raw_s[1] * raw_s[1])) + (raw_s[2] * raw_s[2]))
s = tuple(v / length for v in raw_s)
cross_y_s = (s[2], 0.0, -s[0])
r_length = math.sqrt(((cross_y_s[0] * cross_y_s[0]) + 0.0) +
                     (cross_y_s[2] * cross_y_s[2]))
r = tuple(v / r_length for v in cross_y_s)
u = (s[1] * r[2] - s[2] * r[1],
     s[2] * r[0] - s[0] * r[2],
     s[0] * r[1] - s[1] * r[0])
box = fixture["light_box_m"]
xi0, xi1 = box["xi"]
eta0, eta1 = box["eta"]
zeta0, zeta1 = box["zeta"]
lx, ly, lz = xi1 - xi0, eta1 - eta0, zeta1 - zeta0

# The f64 producer matrix uses explicit operations. The rational lane below
# instead evaluates the expression over the exact decoded binary64 inputs.
world_rows = [
    (2.0 * r[0] / lx, 2.0 * r[1] / lx, 2.0 * r[2] / lx,
     -((xi1 + xi0) / lx)),
    (2.0 * u[0] / ly, 2.0 * u[1] / ly, 2.0 * u[2] / ly,
     -((eta1 + eta0) / ly)),
    (s[0] / lz, s[1] / lz, s[2] / lz,
     -zeta0 / lz),
]


def exact_clip(p):
    p = tuple(frac(x) for x in p)
    rf, uf, sf = tuple(map(frac, r)), tuple(map(frac, u)), tuple(map(frac, s))
    xi, eta, zeta = dot(rf, p), dot(uf, p), dot(sf, p)
    return (
        2 * (xi - frac(xi0)) / (frac(xi1) - frac(xi0)) - 1,
        2 * (eta - frac(eta0)) / (frac(eta1) - frac(eta0)) - 1,
        (zeta - frac(zeta0)) / (frac(zeta1) - frac(zeta0)),
    )


def packed_clip(p, origin):
    # ObjectRecord for identity source instance: mesh-local vertex + -origin.
    obj = tuple(f32(f32(p[i]) + f32(-origin[i])) for i in range(3)) + (1.0,)
    rows = []
    for row in world_rows:
        shift = ((row[0] * origin[0]) + (row[1] * origin[1]) +
                 (row[2] * origin[2]))
        rows.append(tuple(map(f32, row[:3] + (row[3] + shift,))))
    return tuple(rounded_dot4(row, obj) for row in rows)


def cpu_f64_clip(p):
    vec = tuple(map(float, p)) + (1.0,)
    return tuple((((row[0] * vec[0]) + (row[1] * vec[1])) +
                  (row[2] * vec[2])) + (row[3] * vec[3]) for row in world_rows)


vertices = [p for q in fixture["quads"] for p in q["positions_m"]]
receiver = fixture["quads"][0]
for q in fixture["quads"]:
    a, b, c = (q["positions_m"][i] for i in q["triangles"][0])
    ab, ac = [b[i] - a[i] for i in range(3)], [c[i] - a[i] for i in range(3)]
    assert ab[0] * ac[1] - ab[1] * ac[0] > 0  # +Z winding
receiver_points = [[-3 + 6 * ix / 40, -2 + 4 * iy / 40, 0]
                   for ix in range(41) for iy in range(41)]
origins = [[0, 0, 0], [0, 0, 5], [500, 0, 0], [-500, 0, 0],
           [0, 0, 500], [0, 0, -500], [300, 300, 0],
           [0.125, -0.25, 4.875]]
worst = {name: {"error": -1.0} for name in
         ("clip_x", "clip_y", "depth", "map_texel_x", "map_texel_y",
          "cpu_f64_depth", "d32_direct_cast_depth")}
for oi, origin in enumerate(origins):
    for pi, p in enumerate(vertices + receiver_points):
        exact = exact_clip(p)
        packed = packed_clip(p, origin)
        cpu = cpu_f64_clip(p)
        for name, value in (("cpu_f64_depth", cpu[2]),
                            ("d32_direct_cast_depth", f32(float(exact[2])))):
            err = abs(float(exact[2]) - value)
            if err > worst[name]["error"]:
                worst[name] = {"error": err, "origin_index": oi,
                               "point_index": pi, "source_point_m": p}
        for k, name in enumerate(("clip_x", "clip_y", "depth")):
            err = abs(float(exact[k]) - packed[k])
            if err > worst[name]["error"]:
                worst[name] = {"error": err, "origin_index": oi, "point_index": pi,
                               "source_point_m": p, "exact": float(exact[k]), "packed": packed[k]}
        for k, name in ((0, "map_texel_x"), (1, "map_texel_y")):
            err = abs(float(exact[k]) - packed[k]) * 1024.0
            if err > worst[name]["error"]:
                worst[name] = {"error": err, "origin_index": oi, "point_index": pi,
                               "source_point_m": p}


def uv_and_depth(p):
    x, y, d = exact_clip(p)
    return ((x + 1) / 2, (1 - y) / 2), d


def contains(q, x, y):
    xs = [p[0] for p in q["positions_m"]]
    ys = [p[1] for p in q["positions_m"]]
    return frac(min(xs)) <= x <= frac(max(xs)) and frac(min(ys)) <= y <= frac(max(ys))


def shadow_texel_depth(ix, iy, include_caster=True):
    # Exact rational light ray through the chosen texel center. For this
    # fixture r.y=s.y=u.x=u.z=0; solve intersection with each z-plane.
    uv_x = F(2 * ix + 1, 2 * 2048)
    uv_y = F(2 * iy + 1, 2 * 2048)
    clip_x, clip_y = 2 * uv_x - 1, 1 - 2 * uv_y
    xi = (clip_x + 1) * (frac(xi1) - frac(xi0)) / 2 + frac(xi0)
    eta = (clip_y + 1) * (frac(eta1) - frac(eta0)) / 2 + frac(eta0)
    depths = [F(0)]  # clear depth
    for q in fixture["quads"]:
        if q["role"] == "offscreen-caster" and not include_caster:
            continue
        z = frac(q["positions_m"][0][2])
        x = (xi - frac(r[2]) * z) / frac(r[0])
        y = eta / frac(u[1])
        if not contains(q, x, y):
            continue
        if q["role"] == "masked-fence":
            # Source-like 4x4 nearest alpha pattern; this is not yet an
            # admitted F3 material/texture or target GPU sample.
            tx = max(0, min(3, int((x + F(3, 5)) * F(10, 3))))
            ty = max(0, min(3, int((y + 1) * 2)))
            if fixture["mask_alpha_4x4"][ty][tx] < fixture["mask_cutoff"]:
                continue
        p = (x, y, z)
        depths.append(exact_clip(p)[2])
    return max(depths)


def four_taps(receiver_p, beta, b0_m=0, include_caster=True, comparator="greater-equal"):
    (uvx, uvy), receiver_d = uv_and_depth(receiver_p)
    ix = math.floor(float(uvx * 2048 - F(1, 2)))
    iy = math.floor(float(uvy * 2048 - F(1, 2)))
    assert 0 <= ix <= 2046 and 0 <= iy <= 2046
    n = (F(0), F(0), F(1))
    ns, nr, nu = dot(tuple(map(frac, s)), n), dot(tuple(map(frac, r)), n), dot(tuple(map(frac, u)), n)
    bias_m = frac(b0_m) + frac(beta) * (abs(nr / ns) * (frac(lx) / 2048) +
                                      abs(nu / ns) * (frac(ly) / 2048))
    ref = receiver_d + bias_m / frac(lz)
    samples = []
    for dx, dy in ((0, 0), (1, 0), (0, 1), (1, 1)):
        stored = shadow_texel_depth(ix + dx, iy + dy, include_caster)
        lit = ref >= stored if comparator == "greater-equal" else ref <= stored
        samples.append({"stored": float(stored), "lit": lit})
    return {"uv": [float(uvx), float(uvy)], "base_i": [ix, iy],
            "receiver_depth": float(receiver_d), "bias_m": float(bias_m),
            "reference_depth": float(ref), "samples": samples,
            "lit_fraction": sum(t["lit"] for t in samples) / 4}


query = {
    "caster_shadow": [2.1, 0, 0],
    "lit_left": [-2.0, 0, 0],
    "fence_region": [-0.75, 0.5, 0],
}
caster = fixture["quads"][2]


def ray_to_receiver_plane(point, direction):
    """Forward ray only; None denotes no receiver-plane intersection."""
    p = tuple(map(frac, point))
    d = tuple(map(frac, direction))
    if d[2] == 0:
        return None
    t = -p[2] / d[2]
    if t < 0:
        return None
    return tuple(p[i] + t * d[i] for i in range(3))


caster_corners = caster["positions_m"]
correct_ray = tuple(-v for v in s)
full_negated_ray = tuple(s)
horizontal_only_flip_ray = (s[0], -s[1], -s[2])
correct_hits = [ray_to_receiver_plane(p, correct_ray) for p in caster_corners]
full_negated_hits = [ray_to_receiver_plane(p, full_negated_ray) for p in caster_corners]
horizontal_flip_hits = [ray_to_receiver_plane(p, horizontal_only_flip_ray)
                        for p in caster_corners]
assert all(p is not None and frac(-3) <= p[0] <= frac(3) for p in correct_hits)
assert all(p is None for p in full_negated_hits)
assert all(p is not None and p[0] > frac(3) for p in horizontal_flip_hits)
tap_results = {name: {"beta0": four_taps(p, 0), "beta1": four_taps(p, 1)}
               for name, p in query.items()}
tap_results["caster_shadow"]["camera_cull_mutant"] = four_taps(query["caster_shadow"], 1, include_caster=False)
tap_results["caster_shadow"]["compare_sign_mutant"] = four_taps(query["caster_shadow"], 1, comparator="less-equal")

report = {
    "fixture_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "sun_source_hex": [float(v).hex() for v in raw_s],
    "sun_product_hex": [v.hex() for v in s],
    "basis_hex": {"r": [v.hex() for v in r], "u": [v.hex() for v in u]},
    "origins_m": origins,
    "sample_count": len(origins) * (len(vertices) + len(receiver_points)),
    "worst": worst,
    "tap_cases": tap_results,
    "correct_ray_receiver_plane_x_m": [float(correct_hits[i][0]) for i in (0, 1)],
    "full_negated_sun_ray_forward_hits": sum(p is not None for p in full_negated_hits),
    "horizontal_only_sign_flip_receiver_plane_x_m":
        [float(horizontal_flip_hits[i][0]) for i in (0, 1)],
    "selected_point_two_sided_depth_error_m": 2 * worst["depth"]["error"] * lz,
}
(ROOT / "results.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print("samples", report["sample_count"])
for name, entry in worst.items():
    print(name, entry["error"], "origin", entry["origin_index"], "point", entry["point_index"])
for name, cases in tap_results.items():
    print(name, {key: value["lit_fraction"] for key, value in cases.items()})
