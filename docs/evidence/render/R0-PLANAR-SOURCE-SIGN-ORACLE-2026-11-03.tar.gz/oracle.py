#!/usr/bin/env python3
"""Exact, bounded planar source signs. Python standard library only; no GPU emulation."""
import argparse
import copy
import ctypes
from dataclasses import dataclass
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2) + "\n").encode()


@dataclass(frozen=True)
class Dyadic:
    n: int
    e: int = 0

    def __post_init__(self):
        n, e = self.n, self.e
        if n == 0:
            e = 0
        else:
            while n % 2 == 0:
                n //= 2
                e += 1
        object.__setattr__(self, "n", n)
        object.__setattr__(self, "e", e)

    @classmethod
    def decode(cls, value):
        # Route A: raw IEEE binary64 fields, including subnormal and signed zero.
        bits = struct.unpack(">Q", struct.pack(">d", value))[0]
        sign = -1 if bits >> 63 else 1
        exp = (bits >> 52) & 0x7ff
        mantissa = bits & ((1 << 52) - 1)
        if exp == 0x7ff:
            raise ValueError("nonfinite binary64 source")
        return cls(sign * (mantissa if exp == 0 else mantissa + (1 << 52)),
                   -1074 if exp == 0 else exp - 1075)

    def __add__(self, other):
        e = min(self.e, other.e)
        return Dyadic((self.n << (self.e-e)) + (other.n << (other.e-e)), e)

    def __neg__(self):
        return Dyadic(-self.n, self.e)

    def __sub__(self, other):
        return self + -other

    def __mul__(self, other):
        return Dyadic(self.n * other.n, self.e + other.e)

    def fraction(self):
        return Fraction(self.n << self.e) if self.e >= 0 else Fraction(self.n, 1 << -self.e)

    def record(self):
        return {"sign": (self.n > 0) - (self.n < 0), "integer": str(self.n), "power_of_two": self.e}


ZERO = Dyadic(0)

# CPython math.hypot uses a different rounding algorithm. Call the same native
# host operation as Rust f64::hypot, and independently compare its bits to Rust.
NATIVE_HYPOT = ctypes.CDLL(None).hypot
NATIVE_HYPOT.argtypes = (ctypes.c_double, ctypes.c_double)
NATIVE_HYPOT.restype = ctypes.c_double


def f3_direction_gate(sun):
    import math
    length = NATIVE_HYPOT(NATIVE_HYPOT(sun[0],sun[1]),sun[2])
    accepted = all(math.isfinite(x) for x in sun) and math.isfinite(length) and length != 0 and abs(length-1) <= 1e-9
    return length, accepted


def dot(a, b):
    return sum((x*y for x,y in zip(a,b)), ZERO)


def sub(a, b):
    return tuple(x-y for x,y in zip(a,b))


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def sign(x):
    return (x > 0) - (x < 0)


def floats(values):
    return [float.fromhex(v) for v in values]


def source_values(case):
    return [floats(p) for p in case["positions"]], floats(case["sun"]), floats(case["camera"])


def route_a(case):
    p, sun, camera = source_values(case)
    p = [tuple(map(Dyadic.decode, v)) for v in p]
    sun, camera = tuple(map(Dyadic.decode, sun)), tuple(map(Dyadic.decode, camera))
    normal = cross(sub(p[1],p[0]), sub(p[2],p[0]))
    d = dot(normal,p[0])
    return normal, d, dot(normal,sun), dot(normal,camera)-d


def determinant(matrix):
    # Route B: generic Leibniz determinant, not cross/dot or Dyadic arithmetic.
    n = len(matrix)
    total = Fraction(0)
    for perm in itertools.permutations(range(n)):
        inversions = sum(perm[i] > perm[j] for i in range(n) for j in range(i+1,n))
        term = Fraction((-1)**inversions)
        for i,j in enumerate(perm):
            term *= matrix[i][j]
        total += term
    return total


def route_b(case):
    p, sun, camera = source_values(case)
    # float.as_integer_ratio independently provides exact represented values.
    p = [[Fraction(*x.as_integer_ratio()) for x in v] for v in p]
    sun, camera = [[Fraction(*x.as_integer_ratio()) for x in v] for v in (sun,camera)]
    def plane(point):
        return -determinant([v+[Fraction(1)] for v in p+[point]])
    intercept = plane([Fraction(0)]*3)
    normal = []
    for i in range(3):
        axis = [Fraction(int(i == j)) for j in range(3)]
        normal.append(plane(axis)-intercept)
    translated = [p[0][j]+sun[j] for j in range(3)]
    return normal, -intercept, plane(translated), plane(camera)


IDENTITY = [[float(i == j).hex() for j in range(4)] for i in range(4)]
REQUIRED_BINDINGS = ("source_revision", "build_revision", "mesh_product_revision", "light_product_revision",
                     "geometry_id", "environment_id", "light_id", "world_epoch", "view_id", "camera_id",
                     "camera_pose_revision", "origin_revision", "presentation_generation")


def binding(case):
    return {"identities": case["identities"], "positions": case["positions"], "sun": case["sun"],
            "camera": case["camera"], "origin": case["origin"], "transform": case["transform"],
            "material": case["material"], "semantics": case["semantics"], "light_handoff": case["light_handoff"]}


def certificate(case):
    if set(case["identities"]) != set(REQUIRED_BINDINGS):
        raise ValueError("incomplete identity closure")
    if case["semantics"] != "decoded-binary64-exact-v1":
        raise ValueError("unsupported source semantics")
    if case["transform"] != IDENTITY:
        raise ValueError("non-identity transform unsupported (including reflections)")
    if case["material"] != {"one_sided": True, "normal_map": False, "flat_geometric_normal": True, "static": True}:
        raise ValueError("outside flat/static/one-sided specialization")
    if len(case["positions"]) != 3 or any(len(p) != 3 for p in case["positions"]):
        raise ValueError("not one triangle")
    if any(len(case[k]) != 3 for k in ("sun", "camera", "origin")):
        raise ValueError("not three component vectors")
    if not all(isinstance(v,str) and v for v in case["identities"].values()):
        raise ValueError("invalid identity")
    # Origin is representation metadata only; source positions remain physical world coordinates.
    for value in floats(case["origin"]):
        Dyadic.decode(value)
    a = route_a(case)
    b = route_b(case)
    assert [v.fraction() for v in a[0]] == b[0]
    assert all(x.fraction() == y for x,y in zip(a[1:],b[1:])), "independent determinant disagreement"
    if all(v.n == 0 for v in a[0]):
        raise ValueError("degenerate triangle has no geometric normal")
    _, sun, _ = source_values(case)
    # Match F3 environment_json.rs's ordered chained native hypot, independently
    # verified against Rust. This direction-only gate is not full F3 admission.
    if not f3_direction_gate(sun)[1]:
        raise ValueError("fixture fails F3 schema-1 chained-hypot direction check")
    return {"binding_sha256": digest(canonical(binding(case))), "normal": [v.record() for v in a[0]],
            "d": a[1].record(), "sun_predicate": a[2].record(), "camera_predicate": a[3].record(),
            "source_positive_hemisphere_pair": a[2].n > 0 and a[3].n > 0,
            "independent_fraction_determinant_agrees": True}


def reusable(cert, requested):
    # Re-evaluate the binding only; certification itself is never silently retargeted.
    return cert["binding_sha256"] == digest(canonical(binding(requested)))


def light_error_handoff(case):
    # Diagnostic-only implementation of ENVIRONMENT's ordered-f64 direction recipe.
    # Actual F4 admission/product decoding is absent. Hold the SOURCE normal exact.
    import math
    normal, _, source_dot, _ = route_a(case)
    _, source, _ = source_values(case)
    length = math.sqrt(((source[0]*source[0])+(source[1]*source[1]))+(source[2]*source[2]))
    product = [x/length for x in source]
    product = [0.0 if x == 0 else x for x in product]
    packed = [f32(x) for x in product]
    def diagnostic(values):
        source_q = [Fraction(*x.as_integer_ratio()) for x in source]
        target_q = [Fraction(*x.as_integer_ratio()) for x in values]
        normal_q = [n.fraction() for n in normal]
        delta = [y-x for x,y in zip(source_q,target_q)]
        bound = sum(abs(n)*abs(e) for n,e in zip(normal_q,delta))
        actual = sum(n*y for n,y in zip(normal_q,target_q))
        source_exact = source_dot.fraction()
        assert abs(actual-source_exact) <= bound
        proved = abs(source_exact) > bound or (source_exact == 0 and bound == 0)
        if proved:
            assert sign(actual) == sign(source_exact)
        def rational(x):
            return {"numerator":str(x.numerator),"denominator":str(x.denominator)}
        return {"direction_binary64_hex":[x.hex() for x in values], "exact_dot_with_source_normal":rational(actual),
                "sign":sign(actual), "absolute_dot_error_bound":rational(bound),
                "source_sign_preserved_by_strict_margin_bound":proved}
    return {"direction_convention":"world-space geometric receiver-to-source; raw perpendicular Sun; no attenuation",
            "normalization":"proof-local Python ordered-binary64 sqrt/divide; not real F4 product/admission",
            "packing":"proof-local IEEE f32 nearest-even; not WGSL operand/FTZ guarantee",
            "fixed_normal":"source exact unnormalized normal; no rounded/interpolated shader normal certificate",
            "normalized_f64":diagnostic(product),"normalized_then_f32":diagnostic(packed)}


def f32_bits(x):
    return struct.pack(">f", x).hex()


def f32(x):
    return struct.unpack(">f",struct.pack(">f",x))[0]


def assert_on_plane(case):
    # Camera sign must be constant for every exact barycentric point on the face.
    normal,d,_,view = route_a(case)
    points = [[Dyadic.decode(x) for x in p] for p in source_values(case)[0]]
    checks = 0
    for denominator in (1,2,4,16):
        for a in range(denominator+1):
            for b in range(denominator-a+1):
                c=denominator-a-b
                weights = [Dyadic(a,-(denominator.bit_length()-1)),Dyadic(b,-(denominator.bit_length()-1)),Dyadic(c,-(denominator.bit_length()-1))]
                point = [sum((weights[i]*points[i][j] for i in range(3)),ZERO) for j in range(3)]
                assert dot(normal,point) == d
                camera = tuple(map(Dyadic.decode,source_values(case)[2]))
                assert dot(normal,sub(camera,point)) == view
                checks += 1
    return checks


def run():
    fixture_bytes=(ROOT/"fixtures.json").read_bytes()
    fixture=json.loads(fixture_bytes)
    cases=fixture["valid"]
    reference_bytes=(ROOT/"hypot-reference.json").read_bytes()
    reference=json.loads(reference_bytes)
    all_cases=cases+fixture["refused"]
    for case,record in zip(all_cases,reference["records"],strict=True):
        length,accepted=f3_direction_gate(floats(case["sun"]))
        assert record == {"name":case["name"],"length_binary64_bits":struct.pack(">d",length).hex(),
                          "accepted_direction_gate":accepted}, "native hypot disagrees with Rust reference"
    rows=[]
    plane_checks=0
    for case in cases:
        cert=certificate(case)
        expected=case["expected_signs"]
        actual=[cert["sun_predicate"]["sign"],cert["camera_predicate"]["sign"]]
        assert expected == actual, (case["name"],actual,expected)
        plane_checks+=assert_on_plane(case)
        rows.append({"name":case["name"],**cert,"separate_light_direction_error_handoff":light_error_handoff(case)})
    refusals=[]
    for case in fixture["refused"]:
        try:
            certificate(case)
        except ValueError as error:
            assert str(error) == case["expected_refusal"], (case["name"],str(error))
            refusals.append({"name":case["name"],"reason":str(error)})
        else:
            raise AssertionError("invalid fixture admitted: "+case["name"])
    base=cases[0]
    cert=certificate(base)
    stale=[]
    for field in REQUIRED_BINDINGS:
        changed=copy.deepcopy(base)
        changed["identities"][field]+="-changed"
        assert not reusable(cert,changed)
        stale.append("identity:"+field)
    for field in ("camera","origin","sun","positions","material","transform","semantics","light_handoff"):
        changed=copy.deepcopy(base)
        if field == "light_handoff": changed[field]["packing_revision"]+="-changed"
        elif field == "material": changed[field]["normal_map"]=True
        elif field == "transform": changed[field][0][0]=(-1.0).hex()
        elif field == "semantics": changed[field]+="-changed"
        elif field == "positions": changed[field][0][0]=(0.5).hex()
        else: changed[field][0]=(0.5).hex()
        assert not reusable(cert,changed)
        stale.append("payload:"+field)
    pos=next(c for c in cases if c["name"]=="same-f32-source-positive")
    neg=next(c for c in cases if c["name"]=="same-f32-source-negative")
    witness={k:[f32_bits(v) for v in floats(pos[k])] for k in ("sun","camera")}
    for field in ("sun","camera"):
        assert witness[field] == [f32_bits(v) for v in floats(neg[field])]
    assert [[f32_bits(v) for v in p] for p in source_values(pos)[0]] == [[f32_bits(v) for v in p] for p in source_values(neg)[0]]
    assert route_a(pos)[2].n > 0 and route_a(neg)[2].n < 0
    # Meaningful wrong algorithms; each must be falsified by an actual fixture.
    mutants=[]
    def killed(name, case, observed, correct):
        assert observed != correct, name
        mutants.append({"mutant":name,"killed_by":case,"observed":observed,"correct":correct})
    ps=source_values(pos)[1]
    ns=[v.fraction() for v in route_a(pos)[0]]
    narrowed=sign(sum(Fraction(*f32(v).as_integer_ratio())*n for v,n in zip(ps,ns)))
    killed("narrow-source-to-f32-before-sign",pos["name"],narrowed,1)
    offset=next(c for c in cases if c["name"]=="offset-plane-camera-behind")
    n,d,s,v=route_a(offset)
    bad=dot(n,tuple(map(Dyadic.decode,source_values(offset)[2])))
    killed("omit-plane-offset-d",offset["name"],sign(bad.n),sign(v.n))
    tangent=next(c for c in cases if c["name"]=="exact-zero-both")
    tn,td,ts,tv=route_a(tangent)
    killed("use-nonstrict-hemisphere-greater-equal",tangent["name"],ts.n >= 0 and tv.n >= 0,certificate(tangent)["source_positive_hemisphere_pair"])
    reverse=next(c for c in cases if c["name"]=="reverse-winding")
    rn,rd,rs,rv=route_a(reverse)
    killed("absolute-value-hemisphere-predicates",reverse["name"],abs(rs.n) > 0 and abs(rv.n) > 0,certificate(reverse)["source_positive_hemisphere_pair"])
    tiny=next(c for c in cases if c["name"]=="near-degenerate-min-subnormal-edges")
    p,sun,cam=source_values(tiny)
    a,b=[[x-y for x,y in zip(p[i],p[0])] for i in (1,2)]
    naive=[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
    killed("binary64-cross-underflow-is-degenerate",tiny["name"],all(x==0 for x in naive),False)
    def omit_binding_key_reusable(original, requested, field, identity=False):
        # Actual mutant key construction: drop the dependency on both sides.
        a,b=copy.deepcopy(binding(original)),copy.deepcopy(binding(requested))
        if identity:
            del a["identities"][field]
            del b["identities"][field]
        else:
            del a[field]
            del b[field]
        return digest(canonical(a)) == digest(canonical(b))
    changed=copy.deepcopy(base)
    changed["identities"]["camera_pose_revision"]+="-changed"
    killed("cache-key-ignores-camera-pose", "stale-camera-pose",omit_binding_key_reusable(base,changed,"camera_pose_revision",True),reusable(cert,changed))
    changed=copy.deepcopy(base)
    changed["identities"]["light_product_revision"]+="-changed"
    killed("cache-key-ignores-light-product", "stale-light-product",omit_binding_key_reusable(base,changed,"light_product_revision",True),reusable(cert,changed))
    changed=copy.deepcopy(base)
    changed["origin"][0]=(0.5).hex()
    killed("cache-key-ignores-view-origin", "stale-origin-payload",omit_binding_key_reusable(base,changed,"origin"),reusable(cert,changed))
    boundary=next(c for c in fixture["refused"] if c["name"]=="sqrt-admits-but-F3-hypot-refuses")
    import math
    boundary_sun=floats(boundary["sun"])
    sqrt_length=math.sqrt(((boundary_sun[0]*boundary_sun[0])+(boundary_sun[1]*boundary_sun[1]))+(boundary_sun[2]*boundary_sun[2]))
    killed("sqrt-norm-substituted-for-host-F3-hypot",boundary["name"],abs(sqrt_length-1) <= 1e-9,f3_direction_gate(boundary_sun)[1])
    # Deterministic supplementary finite-bit cases stress cancellation/exponent spans.
    # A private LCG avoids Python random implementation/version dependence.
    state=0x13579bdf
    random_count=192
    random_hash=hashlib.sha256()
    for index in range(random_count):
        def value():
            nonlocal state
            state=(1664525*state+1013904223)&0xffffffff
            mant=(state & ((1<<20)-1)) + 1
            state=(1664525*state+1013904223)&0xffffffff
            e=(state % 1001)-500
            return float.fromhex(f"{('-' if state&0x80000000 else '')}0x{mant:x}p{e}")
        case=copy.deepcopy(base)
        case["positions"]=[[value().hex() for _ in range(3)] for _ in range(3)]
        case["camera"]=[value().hex() for _ in range(3)]
        case["name"]=f"lcg-{index}"
        a,b=route_a(case),route_b(case)
        assert [v.fraction() for v in a[0]]==b[0]
        assert all(x.fraction()==y for x,y in zip(a[1:],b[1:]))
        random_hash.update(canonical({"case":case,"sun":a[2].record(),"view":a[3].record()}))
    return {"format":"r0-planar-source-oracle-results-v1", "fixtures_sha256":digest(fixture_bytes),
            "provenance_sha256":digest((ROOT/"provenance.json").read_bytes()),
            "oracle_sha256":digest(Path(__file__).read_bytes()),"rust_hypot_reference_sha256":digest(reference_bytes),
            "native_hypot_rust_bit_agreements":len(all_cases),
            "direction_admission_scope":"host-specific native chained hypot; no cross-platform F3 admission claim; exact source-sign routes do not depend on libc",
            "named_certificates":rows,
            "refusals":refusals,"stale_binding_changes_refused":stale,"mutants_killed":mutants,
            "identical_f32_opposite_source_sign_witness":witness,
            "supplementary_exact_route_agreements":random_count,"supplementary_sha256":random_hash.hexdigest(),
            "exact_barycentric_plane_identity_checks":plane_checks,
            "claims":"source sign only; no shader magnitude, mapped/interpolated normal, coverage, WGSL/device or general C08 claim"}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--check",action="store_true",help="verify saved result bytes without modifying files")
    args=parser.parse_args()
    result=canonical(run())
    path=ROOT/"results.json"
    if args.check:
        assert path.read_bytes()==result, "saved deterministic results differ"
    else:
        path.write_bytes(result)
    decoded=json.loads(result)
    print(json.dumps({"named_certificates":len(decoded["named_certificates"]),"refusals":len(decoded["refusals"]),
                      "stale_changes":len(decoded["stale_binding_changes_refused"]),"mutants_killed":len(decoded["mutants_killed"]),
                      "supplementary_route_agreements":decoded["supplementary_exact_route_agreements"],
                      "result_sha256":digest(result)},sort_keys=True))


if __name__=="__main__":
    main()
