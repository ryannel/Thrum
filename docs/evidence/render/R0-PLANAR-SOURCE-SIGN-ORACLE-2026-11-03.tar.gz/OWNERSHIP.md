# Scratch ownership

- Owner: bounded `r0_planar_source_oracle` commission under the R0 robust-GGX research task.
- Purpose: independent offline exact source-sign proof for one static planar triangle; reviewer-ready scratch only.
- Allowed writes: `tmp/r0-planar-source-oracle/` only. No repository implementation, contract, maturity or build-plan changes; no commits.
- Inputs: named fixture JSON, pinned provenance JSON, and the referenced source specifications. No Broadsides input.
- Expected peak disk: below 1 MiB. Actual selected scratch is below 256 KiB before any coordinator packaging.
- Selected output: editable Python source/generator, fixture/provenance JSON, Rust hypot reference source/checker/bit-pattern record, deterministic results, this record and the report, all listed in SHA256SUMS.
- Closeout: retain for coordinator review/promotion; remove only after the coordinator preserves the selected evidence or explicitly rejects it. No deletion outside this owned directory.
