# Bounded R0 planar source-sign oracle — 3 November 2026

This scratch proves exact **source signs** for a deliberately restricted fixture. It does not select a general content restriction, change C08, or qualify a shader. Every source number means the exact real value represented by the decoded finite IEEE binary64 bits. Hex strings name those bits unambiguously. This is a declared first fixture semantics, not a claim that all future geometry source formats or decimal authoring have those semantics. The current F3 constant-light schema decodes a finite f64 Sun direction; geometry/camera source schema admission is not implemented here.

The fixture has one static planar triangle, flat geometric normal, identity object transform, no normal map, a one-sided material, one pinned physical world-space camera position and one pinned directional Sun. C01's right-handed world convention is retained. C08/E1's Sun direction is geometric **receiver-to-source**, in world space, before attenuation. The product remains raw perpendicular Sun illuminance; this oracle does not use illuminance, colour, ambient, background, visibility or attenuation to infer a sign.

The defining exact expressions are:

```
N = (P1-P0) × (P2-P0)
d = N · P0
S = N · Sun
V = N · Camera - d
```

A degenerate triangle (`N=0`) refuses. For every point `P` on its plane, `N·P=d`, so `N·(Camera-P)=V`. Dividing a nonzero normal or a nonzero view displacement by its positive real norm preserves a sign. Thus `S>0 && V>0` is the source positive-hemisphere pair for this flat fixture, with exact zero excluded as specified by RENDER-SPEC §2. Camera normalization at a coincident surface point would be undefined; the exact-zero camera fixtures place the camera outside the triangle. No camera projection, triangle coverage or visibility follows from these predicates.

## Routes and evidence

`oracle.py` Route A decodes raw binary64 sign/exponent/significand fields into canonical integer dyadics `n*2^e`. Integer additions, shifts and multiplications compute the cross, plane offset and dot products without rounding or underflow. Route B independently uses `float.as_integer_ratio`, `Fraction`, and a generic Leibniz 4×4 determinant. It obtains the complete plane equation by evaluating the oriented determinant at the origin and coordinate axes; it never calls Route A's cross/dot routines. Both routes must agree exactly on `N`, `d`, `S`, and `V`. Finite fixture agreement checks transcription; exactness follows from the integer/rational operations, not sampling.

| Checked result | Count |
| --- | ---: |
| Named exact certificates, all expected signs matched | 18 |
| Invalid/out-of-specialization inputs refused | 15 |
| Binding changes refused for certificate reuse | 21 |
| Deliberate wrong algorithms killed by concrete witnesses | 9 |
| Deterministic supplementary binary64 exponent-stress cases, routes agree | 192 |
| Exact barycentric plane/view identity checks | 3,186 |
| Native chained-hypot direction gates match independent Rust result bits | 33 |

The named cases include positive and negative Sun/view hemispheres; both exact zeros and separate zero predicates; all four near-tangent sign combinations at `±2^-60`; reverse winding; a translated plane whose camera is behind despite `N·Camera>0`; large-coordinate plane-offset cancellation; adjacent-binary64 near degeneracy; minimum-subnormal edges; signed zero; and the information-loss witness below. The minimum-subnormal edges produce exact `N.z=2^-2148`, whereas a direct binary64 cross product rounds the entire normal to zero. This fixture is an arithmetic stress case, not a production geometry-admission proposal.

Refusals cover reflected and translated transforms, collinear/coincident triangles, normal maps, two-sided and smooth-normal materials, moving geometry, nonfinite source positions/camera, zero/nonunit Sun, unsupported numeric semantics and missing source identity. Reflections require an explicit normal/winding/transform policy; this identity-transform proof refuses them instead of guessing one.

## Information lost by f32 narrowing

Use `P0=(0,0,0)`, `P1=(0,0,1)`, `P2=(-1,-1,0)`, giving `N=(1,-1,0)` and `d=0`. Let `q=0x1.6a09e667f3bcdp-1`. The two accepted source Suns are `(nextafter(q,+∞),q,0)` and `(nextafter(q,-∞),q,0)`. Their exact source predicates are `+2^-53` and `-2^-53`. Both pass the host schema-1 ordered chained-native-`hypot` source direction length check within `1e-9`.

Both direction triples narrow to f32 words `[3f3504f3,3f3504f3,00000000]`. Positions and camera are identical, hence all f32 numeric inputs in this pair are identical. The exact dot of the narrowed direction with the exact normal is zero. No algorithm seeing those identical narrowed inputs alone can recover both original signs. This is a proof about **represented decoded binary64** source signs, without the stronger claim of arbitrary authored-real geometry.

## Host-specific F3 direction admission correction

The proof-local direction-only admission gate follows the current Rust parser's operation order `direction[0].hypot(direction[1]).hypot(direction[2])`, rather than the distinct F4 `sqrt(sum of squares)` normalization recipe. It calls host native `hypot` twice through `ctypes`, then checks finite/nonzero length and `abs(length-1)<=1e-9`. This is a **host-specific direction gate**, not complete F3 source admission or cross-platform admission conformance. The exact dyadic and determinant source-sign computations themselves do not depend on libc.

An adversarial review supplied the boundary direction `[0x1.279a745df8cb4p-1, 0x1.279a745df8cedp-1, 0x1.279a745df8cd2p-1]`. The previous scratch incorrectly used F4's square-root expression to label source admission. On this host, that expression returns `0x1.000000044b82fp+0`, whose residual `9.99999860695766e-10` admits, but Rust/native chained `hypot` returns `0x1.000000044b830p+0`, whose residual `1.000000082740371e-9` refuses. This is now an explicit refusal and kills the old square-root admission mutant. All 18 selected certificates and their exact signs are unchanged.

Simply substituting CPython `math.hypot(math.hypot(x,y),z)` would still admit this witness on the tested Python builds, because Python uses a different rounding algorithm. `hypot_reference.rs` independently runs actual Rust `f64::hypot` with the selected operation order. `check_hypot_reference.py` compiles it with pinned Rust 1.99.1 and checks exact output bits and decisions for all 33 fixture directions against `hypot-reference.json`; the main oracle also compares native results against this pinned record. The Rust reference pins its own source hash/toolchain. No cross-platform libc agreement is inferred; a portable admission decision at a tolerance boundary would require its own conservative boundary policy or target-specific validation.

## F4 normalization and direction-packing handoff

The actual ENVIRONMENT F4 product normalizes accepted f64 directions with the ordered expression `sqrt(((dx*dx)+(dy*dy))+(dz*dz))`, divides each component, canonicalizes zero, and pins cooker/normalizer/toolchain/target class. Source normalization tolerance is not a GPU shading-error budget. Exact real common positive scaling would preserve a dot sign, but independently rounded component division does not justify silently transferring the certificate.

For every named certificate, `results.json` separately records a **proof-local** execution of that f64 direction recipe and IEEE f32 nearest-even direction packing. For each target direction `T`, with exact source normal held fixed, it computes the exact rational bound

```
|N·T - N·Sun| <= Σ |N_i| |T_i - Sun_i| = B.
```

A source sign transfers by this bound only when `|S|>B`, or when both `S` and `B` are exactly zero. The output records the exact target dot, bound, sign and whether that strict margin test succeeds. It never labels an inconclusive margin as successful. In the information-loss pair, proof-local normalized-f64 direction dots remain opposite; normalized-then-f32 direction dots both become zero, and the margin bound does not certify source-sign preservation. This is a concrete separate error handoff.

This scratch does not decode or authenticate an actual F4 160-byte product. Its product revisions and normalizer/packing revisions are proof-local invalidation labels. Actual F3 lease/build identity, source↔product binding, normalization residual checks, immutable product bytes/hash, packing/origin conversion, rounded shader normal, WGSL operation orders and FTZ behavior still require their own production handoff and error proof. The direction-only bound must not be mistaken for a complete shader dot bound.

## Identity, invalidation and mutants

Certificate keys bind the exact source numeric payload and semantics, material/transform restrictions, Sun direction convention, proof-local normalizer and packing revisions, and source/build/mesh-product/light-product/geometry/environment/light/world/view/camera/camera-pose/origin/presentation identities. Physical source coordinates remain world-space; view origin is representation metadata, not a second authority for position. A changed origin invalidates this certificate even if the physical source plane predicate would happen to be unchanged. The stale checks independently mutate all 13 identities and eight payload groups, including camera position, origin values and packing revision.

The actual wrong implementations evaluated in `oracle.py` are: narrowing the source Sun before computing sign; omitting plane offset `d`; accepting `>=0` instead of `>0`; taking absolute hemisphere values; declaring a triangle degenerate after an underflowed binary64 cross; three cache-key algorithms that omit camera pose, light product revision or origin payload; and substituting the square-root norm for the host F3 chained-hypot admission gate. Each produces a recorded wrong result on a named case. These are concrete algorithm mutations, not changes to the expected answer.

## Reproduction and limits

From the repository root:

```sh
(cd tmp/r0-planar-source-oracle && shasum -a 256 -c SHA256SUMS)
python3.11 tmp/r0-planar-source-oracle/check_hypot_reference.py
python3.11 tmp/r0-planar-source-oracle/oracle.py --check
python3.11 tmp/r0-planar-source-oracle/make_fixtures.py
python3.11 tmp/r0-planar-source-oracle/oracle.py --check
```

To regenerate the selected result deliberately, run `python3.11 tmp/r0-planar-source-oracle/oracle.py` without `--check`. `provenance.json` records the execution HEAD, Python version, host-specific admission-check correction and exact input-document/parser hashes; it remains pinned for reproducibility if working documents later change. Fixture generation does not read repository state. `SHA256SUMS` covers all retained files except itself.

The final deterministic result was generated with Python 3.11 and independently reproduced byte-for-byte with Python 3.15.2 in the same workspace. There are no third-party packages or network calls. Python uses the current host native `hypot`; the independent optional reference check requires pinned Rust 1.99.1 and removes its owned temporary executable on completion. No engine code, shader, docs, build-plan or maturity state was changed. Repository implementation checks are not source-sign or renderer qualification; the coordinator owns combined repository verification.

This offline reference deliberately pays arbitrary-precision allocation and determinant overhead. A potential CPU certificate would scale with changed faces × lights/views, plus dependencies and cache invalidations; its worthwhile runtime layout/frequency is unmeasured. No device/performance result follows. No shader magnitude, mapped-normal cone, interpolated normal, deformation, transformed/reflected geometry, raster coverage, shadow, general C08 conformance or moving-image acceptance is claimed.
