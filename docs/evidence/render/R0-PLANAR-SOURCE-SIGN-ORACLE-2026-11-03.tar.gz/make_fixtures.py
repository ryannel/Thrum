#!/usr/bin/env python3
"""Regenerate the named proof inputs. Not used by oracle.py at verification time."""
import copy
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def vector(v):
    return [float(x).hex() for x in v]

identity=[[float(i==j).hex() for j in range(4)] for i in range(4)]
base={"name":"front-positive","positions":[vector(p) for p in ((0,0,0),(1,0,0),(0,1,0))],
      "sun":vector((0,0,1)),"camera":vector((0.25,0.25,1)),"origin":vector((0,0,0)),
      "transform":identity,"material":{"one_sided":True,"normal_map":False,"flat_geometric_normal":True,"static":True},
      "semantics":"decoded-binary64-exact-v1",
      "light_handoff":{"direction_convention":"world-geometric-receiver-to-source",
                       "normalizer_revision":"proof-local-ordered-f64-v1","packing_revision":"proof-local-ieee-f32-nearest-even-v1",
                       "actual_F4_product_verified":False},
      "identities":{k:k+"-A" for k in ("source_revision","build_revision","mesh_product_revision","light_product_revision",
             "geometry_id","environment_id","light_id","world_epoch","view_id","camera_id","camera_pose_revision",
             "origin_revision","presentation_generation")},"expected_signs":[1,1]}
valid=[copy.deepcopy(base)]

def case(name,**kwargs):
    c=copy.deepcopy(base)
    c.update(name=name,**kwargs)
    valid.append(c)
    return c

case("back-light",sun=vector((0,0,-1)),expected_signs=[-1,1])
case("back-camera",camera=vector((.25,.25,-1)),expected_signs=[1,-1])
case("exact-zero-both",sun=vector((1,0,0)),camera=vector((2,2,0)),expected_signs=[0,0])
case("exact-zero-sun",sun=vector((1,0,0)),expected_signs=[0,1])
case("exact-zero-camera",camera=vector((2,2,0)),expected_signs=[1,0])
for sl in (-1,1):
    for sv in (-1,1):
        case(f"near-tangent-sun-{sl:+d}-camera-{sv:+d}",sun=vector((1,0,sl*2.0**-60)),
             camera=vector((.25,.25,sv*2.0**-60)),expected_signs=[sl,sv])
case("reverse-winding",positions=list(reversed(base["positions"])),expected_signs=[-1,-1])
case("offset-plane-camera-behind",positions=[vector(p) for p in ((0,0,2),(1,0,2),(0,1,2))],
     camera=vector((.25,.25,1)),expected_signs=[1,-1])
case("large-world-offset-cancellation",positions=[vector(p) for p in ((2**52,2**52,2**52),(2**52+1,2**52,2**52),(2**52,2**52+1,2**52))],
     camera=vector((2**52,2**52,2**52-1)),origin=vector((2**52,2**52,2**52)),expected_signs=[1,-1])
case("near-degenerate-adjacent-binary64",positions=[vector(p) for p in ((0,0,0),(1,1,0),(1,math.nextafter(1,2),0))])
u=float.fromhex('0x0.0000000000001p-1022')
case("near-degenerate-min-subnormal-edges",positions=[vector(p) for p in ((0,0,0),(u,0,0),(0,u,0))])
case("signed-zero-source-components",sun=vector((-0.0,0,1)),camera=vector((-0.0,-0.0,1)))
q=float.fromhex('0x1.6a09e667f3bcdp-1')
for direction, suffix in ((math.inf,"positive"),(-math.inf,"negative")):
    case("same-f32-source-"+suffix,positions=[vector(p) for p in ((0,0,0),(0,0,1),(-1,-1,0))],
         sun=vector((math.nextafter(q,direction),q,0)),camera=vector((1,0,0)),expected_signs=[1 if suffix=="positive" else -1,1])
refused=[]
def refusal(name,reason,**kwargs):
    c=copy.deepcopy(base)
    c.update(name=name,expected_refusal=reason,**kwargs)
    refused.append(c)

reflected=copy.deepcopy(identity)
reflected[0][0]=(-1.0).hex()
refusal("reflected-transform","non-identity transform unsupported (including reflections)",transform=reflected)
translated=copy.deepcopy(identity)
translated[0][3]=(1.0).hex()
refusal("translated-transform","non-identity transform unsupported (including reflections)",transform=translated)
refusal("collinear-degenerate","degenerate triangle has no geometric normal",positions=[vector(p) for p in ((0,0,0),(1,1,1),(2,2,2))])
refusal("all-coincident","degenerate triangle has no geometric normal",positions=[vector((0,0,0))]*3)
refusal("normal-map","outside flat/static/one-sided specialization",material={**base["material"],"normal_map":True})
refusal("two-sided-material","outside flat/static/one-sided specialization",material={**base["material"],"one_sided":False})
refusal("smooth-normal","outside flat/static/one-sided specialization",material={**base["material"],"flat_geometric_normal":False})
refusal("moving-geometry","outside flat/static/one-sided specialization",material={**base["material"],"static":False})
refusal("nonfinite-source-position","nonfinite binary64 source",positions=[vector(p) for p in ((math.inf,0,0),(1,0,0),(0,1,0))])
refusal("nonfinite-source-camera","nonfinite binary64 source",camera=vector((0,0,math.nan)))
refusal("zero-sun","fixture fails F3 schema-1 chained-hypot direction check",sun=vector((0,0,0)))
refusal("nonunit-sun","fixture fails F3 schema-1 chained-hypot direction check",sun=vector((0,0,2)))
refusal("sqrt-admits-but-F3-hypot-refuses","fixture fails F3 schema-1 chained-hypot direction check",
        sun=['0x1.279a745df8cb4p-1','0x1.279a745df8cedp-1','0x1.279a745df8cd2p-1'])
refusal("unsupported-source-semantics","unsupported source semantics",semantics="authored-decimal-real-v1")
missing=copy.deepcopy(base["identities"])
del missing["source_revision"]
refusal("missing-source-identity","incomplete identity closure",identities=missing)
(ROOT/'fixtures.json').write_text(json.dumps({"format":"r0-planar-source-fixtures-v1","valid":valid,"refused":refused},sort_keys=True,indent=2)+'\n')
