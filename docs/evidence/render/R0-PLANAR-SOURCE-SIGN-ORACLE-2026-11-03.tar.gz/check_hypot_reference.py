#!/usr/bin/env python3
"""Compile actual Rust f64::hypot route and compare the pinned proof-local gate record."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--write',action='store_true')
args=parser.parse_args()
fixtures=json.loads((ROOT/'fixtures.json').read_bytes())
cases=fixtures['valid']+fixtures['refused']
inputs=''.join(' '.join(struct.pack('>d',float.fromhex(v)).hex() for v in c['sun'])+'\n' for c in cases)
binary=ROOT/'.hypot-reference'
try:
    subprocess.run(['rustup','run','1.99.1','rustc','--edition','2024',str(ROOT/'hypot_reference.rs'),'-o',str(binary)],check=True)
    output=subprocess.check_output([str(binary)],input=inputs,text=True)
finally:
    binary.unlink(missing_ok=True)
records=[]
for case,line in zip(cases,output.splitlines(),strict=True):
    length,accepted=line.split()
    records.append({'name':case['name'],'length_binary64_bits':length,'accepted_direction_gate':accepted=='true'})
result=(json.dumps({'rustc':subprocess.check_output(['rustup','run','1.99.1','rustc','--version'],text=True).strip(),
                    'reference_source_sha256':hashlib.sha256((ROOT/'hypot_reference.rs').read_bytes()).hexdigest(),
                    'records':records},sort_keys=True,indent=2)+'\n').encode()
path=ROOT/'hypot-reference.json'
if args.write:
    path.write_bytes(result)
else:
    assert path.read_bytes()==result,'Rust reference changed'
print(f'{len(records)} Rust chained-hypot direction gates verified')
