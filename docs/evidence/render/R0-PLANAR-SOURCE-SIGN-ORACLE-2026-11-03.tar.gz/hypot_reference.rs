//! Independent host Rust reference for F3's chained-hypot direction gate.
use std::io::{self, BufRead};

fn main() {
    for line in io::stdin().lock().lines() {
        let line = line.expect("read fixture");
        let words: Vec<_> = line.split_whitespace().collect();
        assert_eq!(words.len(), 3);
        let direction: Vec<_> = words
            .iter()
            .map(|word| f64::from_bits(u64::from_str_radix(word, 16).expect("binary64 word")))
            .collect();
        // Keep the operation order identical to environment_json.rs, not sqrt(sum squares).
        let length = direction[0].hypot(direction[1]).hypot(direction[2]);
        let accepted = direction.iter().all(|x| x.is_finite())
            && length.is_finite()
            && length != 0.0
            && (length - 1.0).abs() <= 1e-9;
        println!("{:016x} {}", length.to_bits(), accepted);
    }
}
