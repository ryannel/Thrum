// Synthetic resource-dependency fixture; no authored R0 geometry or lighting.
// Per-packet immutable 16-byte uniform: Sun depth, view depth, blue tag, pad.
@group(0) @binding(2) var<uniform> packet: vec4<f32>;
fn corner(i: u32, z: f32) -> vec4<f32> {
    let xy = array<vec2<f32>, 3>(vec2(-1., -1.), vec2(3., -1.), vec2(-1., 3.));
    return vec4(xy[i], z, 1.);
}
@vertex fn vs_sun(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> { return corner(i, packet.x); }
@vertex fn vs_depth(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> { return corner(i, packet.y); }
@vertex fn vs_first(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> { return corner(i, .875); }
@vertex fn vs_second(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> { return corner(i, .5); }
@fragment fn fs_depth() {}
@group(0) @binding(0) var sun: texture_depth_2d;
@group(0) @binding(1) var sun_sampler: sampler_comparison;
fn shade(draw_bit: f32) -> vec4<f32> {
    let d = 1. / 2048.;
    let s = .25 * (textureSampleCompareLevel(sun, sun_sampler, vec2(.5-d, .5-d), .5)
        + textureSampleCompareLevel(sun, sun_sampler, vec2(.5+d, .5-d), .5)
        + textureSampleCompareLevel(sun, sun_sampler, vec2(.5-d, .5+d), .5)
        + textureSampleCompareLevel(sun, sun_sampler, vec2(.5+d, .5+d), .5));
    return vec4(vec3(1.+s, 1.+draw_bit, packet.z) / 8192., 1.);
}
@fragment fn fs_first() -> @location(0) vec4<f32> { return shade(0.); }
@fragment fn fs_second() -> @location(0) vec4<f32> { return shade(1.); }
