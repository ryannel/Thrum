//! Instrumented synthetic two-credit four-role resize/lifetime proof.
//! No authored R0, surface, physical residency or performance claim.
use objc2::{rc::Retained, runtime::ProtocolObject};
use objc2_metal::{MTLDevice, MTLSharedEvent};
use std::{
    error::Error,
    sync::{Arc, mpsc},
    time::Duration,
};
use wgpu::*;
const HD: (u32, u32) = (1280, 720);
const FHD: (u32, u32) = (1920, 1080);
const DEVICE_GENERATION: u64 = 1;
const SCRATCH_BUDGET: u64 = 80 * 1024 * 1024;
const OUTPUT_BUDGET: u64 = 16 * 1024 * 1024;
const READBACK_BUDGET: u64 = 20 * 1024 * 1024;
type AnyResult<T> = Result<T, Box<dyn Error>>;

fn pipeline(
    d: &Device,
    m: &ShaderModule,
    vs: &str,
    fs: &str,
    format: Option<TextureFormat>,
    depth: Option<bool>,
) -> RenderPipeline {
    let targets = format.map(|format| {
        [Some(ColorTargetState {
            format,
            blend: None,
            write_mask: ColorWrites::ALL,
        })]
    });
    d.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(fs),
        layout: None,
        vertex: VertexState {
            module: m,
            entry_point: Some(vs),
            buffers: &[],
            compilation_options: Default::default(),
        },
        primitive: Default::default(),
        depth_stencil: depth.map(|write| DepthStencilState {
            format: TextureFormat::Depth32Float,
            depth_write_enabled: Some(write),
            depth_compare: Some(CompareFunction::Greater),
            stencil: Default::default(),
            bias: Default::default(),
        }),
        multisample: Default::default(),
        fragment: Some(FragmentState {
            module: m,
            entry_point: Some(fs),
            targets: targets.as_ref().map_or(&[], |x| x.as_slice()),
            compilation_options: Default::default(),
        }),
        multiview_mask: None,
        cache: None,
    })
}
fn color_attachment(view: &TextureView) -> RenderPassColorAttachment<'_> {
    RenderPassColorAttachment {
        view,
        depth_slice: None,
        resolve_target: None,
        ops: Operations {
            load: LoadOp::Clear(Color {
                r: 1.,
                g: 0.,
                b: 1.,
                a: 1.,
            }),
            store: StoreOp::Store,
        },
    }
}
fn write_depth(
    e: &mut CommandEncoder,
    name: &str,
    view: &TextureView,
    pipe: &RenderPipeline,
    group: &BindGroup,
) {
    let mut p = e.begin_render_pass(&RenderPassDescriptor {
        label: Some(name),
        color_attachments: &[],
        depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
            view,
            depth_ops: Some(Operations {
                load: LoadOp::Clear(0.),
                store: StoreOp::Store,
            }),
            stencil_ops: None,
        }),
        ..Default::default()
    });
    p.set_pipeline(pipe);
    p.set_bind_group(0, group, &[]);
    p.draw(0..3, 0..1);
}
fn draw_color(
    e: &mut CommandEncoder,
    name: &str,
    view: &TextureView,
    pipe: &RenderPipeline,
    group: &BindGroup,
) {
    let mut p = e.begin_render_pass(&RenderPassDescriptor {
        label: Some(name),
        color_attachments: &[Some(color_attachment(view))],
        ..Default::default()
    });
    p.set_pipeline(pipe);
    p.set_bind_group(0, group, &[]);
    p.draw(0..3, 0..1);
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
struct AllocationStats {
    textures: u64,
    packet_extractions: u64,
    uniforms: u64,
    readbacks: u64,
    init_staging_payload: u64,
    submissions: u64,
}
fn payload(extent: (u32, u32), bytes_per_texel: u64) -> AnyResult<u64> {
    u64::from(extent.0)
        .checked_mul(u64::from(extent.1))
        .and_then(|n| n.checked_mul(bytes_per_texel))
        .ok_or_else(|| "payload overflow".into())
}
fn sum(values: &[u64]) -> AnyResult<u64> {
    values.iter().try_fold(0u64, |n, x| {
        n.checked_add(*x).ok_or_else(|| "charge overflow".into())
    })
}
fn view_bytes(extent: (u32, u32)) -> AnyResult<u64> {
    payload(extent, 20)
}
struct OwnedTexture {
    id: u64,
    raw: Texture,
    view: TextureView,
}
fn texture(
    d: &Device,
    label: &str,
    extent: (u32, u32),
    format: TextureFormat,
    usage: TextureUsages,
    stats: &mut AllocationStats,
) -> OwnedTexture {
    stats.textures += 1;
    let id = stats.textures;
    println!(
        "allocation={id} label={label} extent={extent:?} format={format:?} usage={usage:?} mips=1 samples=1 layers=1"
    );
    let raw = d.create_texture(&TextureDescriptor {
        label: Some(label),
        size: Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format,
        usage,
        view_formats: &[],
    });
    let view = raw.create_view(&Default::default());
    OwnedTexture { id, raw, view }
}
struct ViewRoles {
    depth: OwnedTexture,
    scene: OwnedTexture,
    encoded: OwnedTexture,
}
struct Graph {
    generation: u64,
    extent: (u32, u32),
    sun: Arc<OwnedTexture>,
    views: Arc<ViewRoles>,
    output: Arc<OwnedTexture>,
    tone_group: BindGroup,
    fxaa_group: BindGroup,
}
impl Graph {
    fn ids(&self) -> [u64; 5] {
        [
            self.sun.id,
            self.views.depth.id,
            self.views.scene.id,
            self.views.encoded.id,
            self.output.id,
        ]
    }
}
struct Pipelines {
    sun_depth: RenderPipeline,
    view_depth: RenderPipeline,
    first: RenderPipeline,
    second: RenderPipeline,
    tone: RenderPipeline,
    fxaa: RenderPipeline,
    comparison: Sampler,
    filtering: Sampler,
}
fn pipelines(d: &Device) -> Pipelines {
    let module = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("synthetic depth/forward"),
        source: ShaderSource::Wgsl(include_str!("chain.wgsl").into()),
    });
    let tone = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("selected tone/encode"),
        source: ShaderSource::Wgsl(include_str!("tone.wgsl").into()),
    });
    let pinned = include_str!("fxaa.wgsl");
    let signature =
        "@fragment fn fs_fxaa(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32>";
    assert_eq!(pinned.matches(signature).count(), 1);
    let mut source = pinned.replace(
        signature,
        "fn fxaa_encoded(position: vec4<f32>) -> vec4<f32>",
    );
    source.push_str(include_str!("output.wgsl"));
    let fxaa = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("pinned FXAA plus output wrapper"),
        source: ShaderSource::Wgsl(source.into()),
    });
    Pipelines {
        sun_depth: pipeline(d, &module, "vs_sun", "fs_depth", None, Some(true)),
        view_depth: pipeline(d, &module, "vs_depth", "fs_depth", None, Some(true)),
        first: pipeline(
            d,
            &module,
            "vs_first",
            "fs_first",
            Some(TextureFormat::Rgba16Float),
            Some(false),
        ),
        second: pipeline(
            d,
            &module,
            "vs_second",
            "fs_second",
            Some(TextureFormat::Rgba16Float),
            Some(false),
        ),
        tone: pipeline(
            d,
            &tone,
            "vs_full",
            "fs_tone",
            Some(TextureFormat::Rgba16Float),
            None,
        ),
        fxaa: pipeline(
            d,
            &fxaa,
            "vs_fxaa",
            "fs_output",
            Some(TextureFormat::Rgba8Unorm),
            None,
        ),
        comparison: d.create_sampler(&SamplerDescriptor {
            label: Some("Sun greater"),
            compare: Some(CompareFunction::Greater),
            ..Default::default()
        }),
        filtering: d.create_sampler(&SamplerDescriptor {
            label: Some("FXAA linear clamp"),
            min_filter: FilterMode::Linear,
            mag_filter: FilterMode::Linear,
            ..Default::default()
        }),
    }
}
fn prepare_graph(
    d: &Device,
    p: &Pipelines,
    generation: u64,
    extent: (u32, u32),
    sun: Arc<OwnedTexture>,
    stats: &mut AllocationStats,
) -> Arc<Graph> {
    let rt = TextureUsages::RENDER_ATTACHMENT;
    let sampled = rt | TextureUsages::TEXTURE_BINDING;
    let views = Arc::new(ViewRoles {
        depth: texture(
            d,
            "View D32",
            extent,
            TextureFormat::Depth32Float,
            rt,
            stats,
        ),
        scene: texture(
            d,
            "Scene linear",
            extent,
            TextureFormat::Rgba16Float,
            sampled,
            stats,
        ),
        encoded: texture(
            d,
            "Encoded scene",
            extent,
            TextureFormat::Rgba16Float,
            sampled,
            stats,
        ),
    });
    let output = Arc::new(texture(
        d,
        "Independent output",
        extent,
        TextureFormat::Rgba8Unorm,
        rt | TextureUsages::COPY_SRC,
        stats,
    ));
    let tone_group = d.create_bind_group(&BindGroupDescriptor {
        label: Some("scene last read"),
        layout: &p.tone.get_bind_group_layout(0),
        entries: &[BindGroupEntry {
            binding: 0,
            resource: BindingResource::TextureView(&views.scene.view),
        }],
    });
    let fxaa_group = d.create_bind_group(&BindGroupDescriptor {
        label: Some("encoded last read"),
        layout: &p.fxaa.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&views.encoded.view),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&p.filtering),
            },
        ],
    });
    Arc::new(Graph {
        generation,
        extent,
        sun,
        views,
        output,
        tone_group,
        fxaa_group,
    })
}

#[derive(Debug)]
struct Reservation {
    slot: usize,
    nonce: u64,
    device: u64,
}
#[derive(Debug, Clone, Copy)]
enum CreditState {
    Reserved(u64),
    Submitted { nonce: u64, serial: u64 },
}
struct Credits {
    slots: [Option<CreditState>; 2],
    next_nonce: u64,
    next_serial: u64,
}
impl Credits {
    fn new() -> Self {
        Self {
            slots: [None, None],
            next_nonce: 1,
            next_serial: 1,
        }
    }
    fn held(&self) -> usize {
        self.slots.iter().flatten().count()
    }
    fn reserve(&mut self) -> Option<Reservation> {
        let slot = self.slots.iter().position(Option::is_none)?;
        let nonce = self.next_nonce;
        self.next_nonce = self
            .next_nonce
            .checked_add(1)
            .expect("reservation overflow");
        self.slots[slot] = Some(CreditState::Reserved(nonce));
        Some(Reservation {
            slot,
            nonce,
            device: DEVICE_GENERATION,
        })
    }
    fn submitted(&mut self, r: &Reservation) -> u64 {
        assert_eq!(r.device, DEVICE_GENERATION);
        assert!(matches!(self.slots[r.slot],Some(CreditState::Reserved(n)) if n==r.nonce));
        let serial = self.next_serial;
        self.next_serial = self.next_serial.checked_add(1).expect("serial overflow");
        self.slots[r.slot] = Some(CreditState::Submitted {
            nonce: r.nonce,
            serial,
        });
        serial
    }
    fn complete(&mut self, r: Reservation, serial: u64) {
        assert_eq!(r.device, DEVICE_GENERATION);
        assert!(
            matches!(self.slots[r.slot],Some(CreditState::Submitted {nonce,serial:s}) if nonce==r.nonce && s==serial)
        );
        self.slots[r.slot] = None;
    }
}

// Keep each unretained native wait/tail event through completion and verification.
// On failure, signal every gate, drain submitted tails and leak event references
// only if the short-lived diagnostic cannot drain. This is not loss recovery.
struct EventPair {
    gate: Retained<ProtocolObject<dyn MTLSharedEvent>>,
    tail: Retained<ProtocolObject<dyn MTLSharedEvent>>,
    submitted: bool,
}
struct Events {
    pairs: Vec<EventPair>,
}
impl Events {
    fn new(d: &Device) -> AnyResult<Self> {
        let make = || -> AnyResult<_> {
            // SAFETY: device is Metal and native handles are used only for
            // diagnostic synchronization on its owning queue.
            let h =
                unsafe { d.as_hal::<wgpu::hal::api::Metal>() }.ok_or("Metal device unavailable")?;
            Ok(h.raw_device()
                .newSharedEvent()
                .ok_or("shared event unavailable")?)
        };
        let mut pairs = Vec::new();
        for _ in 0..3 {
            pairs.push(EventPair {
                gate: make()?,
                tail: make()?,
                submitted: false,
            });
        }
        Ok(Self { pairs })
    }
    fn stage(&mut self, q: &Queue, index: usize) -> AnyResult<()> {
        let event = &mut self.pairs[index];
        assert!(!event.submitted);
        assert_eq!(
            (event.gate.signaledValue(), event.tail.signaledValue()),
            (0, 0)
        );
        // SAFETY: one CPU submitter; waits staged immediately before the
        // corresponding nonempty ordinary-wgpu submit; all refs stay owned.
        let h = unsafe { q.as_hal::<wgpu::hal::api::Metal>() }.ok_or("Metal queue unavailable")?;
        h.add_wait_event(event.gate.clone(), 1);
        h.add_signal_event(event.tail.clone(), 1);
        event.submitted = true;
        Ok(())
    }
    fn tail_values(&self) -> Vec<u64> {
        self.pairs.iter().map(|p| p.tail.signaledValue()).collect()
    }
}
impl Drop for Events {
    fn drop(&mut self) {
        for pair in &self.pairs {
            pair.gate.setSignaledValue(1);
        }
        let mut drained = true;
        for pair in self.pairs.iter().filter(|p| p.submitted) {
            drained &= pair.tail.waitUntilSignaledValue_timeoutMS(1, 10_000);
        }
        if !drained {
            for pair in &self.pairs {
                std::mem::forget(pair.gate.clone());
                std::mem::forget(pair.tail.clone());
            }
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Params {
    sun: f32,
    depth: f32,
    blue: f32,
}
struct Packet {
    name: &'static str,
    extent: (u32, u32),
    params: Params,
    uniform: Buffer,
    readback: Buffer,
    graph_pin: Option<Arc<Graph>>,
    reservation: Option<Reservation>,
    gpu_index: SubmissionIndex,
    serial: u64,
}
fn depth_binding(d: &Device, pipe: &RenderPipeline, u: &Buffer) -> BindGroup {
    d.create_bind_group(&BindGroupDescriptor {
        label: Some("immutable depth packet"),
        layout: &pipe.get_bind_group_layout(0),
        entries: &[BindGroupEntry {
            binding: 2,
            resource: u.as_entire_binding(),
        }],
    })
}
fn forward_binding(
    d: &Device,
    pipe: &RenderPipeline,
    u: &Buffer,
    g: &Graph,
    p: &Pipelines,
) -> BindGroup {
    d.create_bind_group(&BindGroupDescriptor {
        label: Some("immutable forward packet"),
        layout: &pipe.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&g.sun.view),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&p.comparison),
            },
            BindGroupEntry {
                binding: 2,
                resource: u.as_entire_binding(),
            },
        ],
    })
}
fn encode_packet(
    d: &Device,
    p: &Pipelines,
    g: &Graph,
    uniform: &Buffer,
    readback: &Buffer,
) -> CommandBuffer {
    let sun_binding = depth_binding(d, &p.sun_depth, uniform);
    let depth_binding = depth_binding(d, &p.view_depth, uniform);
    let first = forward_binding(d, &p.first, uniform, g, p);
    let second = forward_binding(d, &p.second, uniform, g, p);
    let mut e = d.create_command_encoder(&CommandEncoderDescriptor::default());
    write_depth(
        &mut e,
        "Sun first write",
        &g.sun.view,
        &p.sun_depth,
        &sun_binding,
    );
    write_depth(
        &mut e,
        "View depth first write",
        &g.views.depth.view,
        &p.view_depth,
        &depth_binding,
    );
    {
        let mut pass = e.begin_render_pass(&RenderPassDescriptor {
            label: Some("forward Sun/depth last read; scene first write"),
            color_attachments: &[Some(color_attachment(&g.views.scene.view))],
            depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
                view: &g.views.depth.view,
                depth_ops: None,
                stencil_ops: None,
            }),
            ..Default::default()
        });
        pass.set_pipeline(&p.first);
        pass.set_bind_group(0, &first, &[]);
        pass.draw(0..3, 0..1);
        pass.set_pipeline(&p.second);
        pass.set_bind_group(0, &second, &[]);
        pass.draw(0..3, 0..1);
    }
    draw_color(
        &mut e,
        "tone scene last read; encoded first write",
        &g.views.encoded.view,
        &p.tone,
        &g.tone_group,
    );
    draw_color(
        &mut e,
        "FXAA uniform path and independent output",
        &g.output.view,
        &p.fxaa,
        &g.fxaa_group,
    );
    e.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: &g.output.raw,
            mip_level: 0,
            origin: Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: readback,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(g.extent.0 * 4),
                rows_per_image: Some(g.extent.1),
            },
        },
        Extent3d {
            width: g.extent.0,
            height: g.extent.1,
            depth_or_array_layers: 1,
        },
    );
    e.finish()
}
fn submit_packet(
    d: &Device,
    q: &Queue,
    p: &Pipelines,
    g: &Arc<Graph>,
    r: Reservation,
    params: Params,
    name: &'static str,
    event_index: usize,
    events: &mut Events,
    credits: &mut Credits,
    stats: &mut AllocationStats,
) -> AnyResult<Packet> {
    // Entry requires an already reserved credit. No packet allocation occurs on
    // the caller's failed reserve branch. UNIFORM map-at-creation has 16 bytes
    // of initialization staging in pinned wgpu-core; charge it separately.
    assert!(matches!(credits.slots[r.slot],Some(CreditState::Reserved(n)) if n==r.nonce));
    stats.packet_extractions += 1;
    let uniform = d.create_buffer(&BufferDescriptor {
        label: Some(name),
        size: 16,
        usage: BufferUsages::UNIFORM,
        mapped_at_creation: true,
    });
    stats.uniforms += 1;
    stats.init_staging_payload += 16;
    {
        let mut mapped = uniform.slice(..).get_mapped_range_mut()?;
        let mut bytes = [0u8; 16];
        for (dest, v) in
            bytes
                .as_chunks_mut::<4>()
                .0
                .iter_mut()
                .zip([params.sun, params.depth, params.blue, 0.])
        {
            dest.copy_from_slice(&v.to_le_bytes());
        }
        mapped.copy_from_slice(&bytes);
    }
    uniform.unmap(); // Immutable until packet retirement; never mapped/written again.
    let readback = d.create_buffer(&BufferDescriptor {
        label: Some(name),
        size: payload(g.extent, 4)?,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    stats.readbacks += 1;
    let encoded = encode_packet(d, p, g, &uniform, &readback);
    // Strict relay assumptions require encode -> stage -> submit sequentially.
    events.stage(q, event_index)?;
    let gpu_index = q.submit([encoded]); // Exactly one nonempty ordinary user CB.
    let serial = credits.submitted(&r);
    stats.submissions += 1;
    println!(
        "submitted {name}: device={DEVICE_GENERATION} serial={serial} graph={} allocation_ids={:?} params={params:?} held_credits={}",
        g.generation,
        g.ids(),
        credits.held()
    );
    Ok(Packet {
        name,
        extent: g.extent,
        params,
        uniform,
        readback,
        graph_pin: Some(g.clone()),
        reservation: Some(r),
        gpu_index,
        serial,
    })
}
fn require_incomplete(d: &Device, packet: &Packet, event: &EventPair) -> AnyResult<()> {
    let result = d.poll(PollType::Wait {
        submission_index: Some(packet.gpu_index.clone()),
        timeout: Some(Duration::from_millis(10)),
    });
    if !matches!(result, Err(PollError::Timeout)) {
        return Err(format!(
            "{} unexpectedly completed while gated: {result:?}",
            packet.name
        )
        .into());
    }
    assert_eq!(
        (event.gate.signaledValue(), event.tail.signaledValue()),
        (0, 0)
    );
    println!("{} blocked: API Timeout, native gate=0 tail=0", packet.name);
    Ok(())
}
fn certify(
    d: &Device,
    packet: &mut Packet,
    event: &EventPair,
    credits: &mut Credits,
) -> AnyResult<()> {
    d.poll(PollType::Wait {
        submission_index: Some(packet.gpu_index.clone()),
        timeout: Some(Duration::from_secs(10)),
    })?;
    if !event.tail.waitUntilSignaledValue_timeoutMS(1, 10_000) {
        return Err(format!("{} native tail failed despite wgpu poll", packet.name).into());
    }
    assert_eq!(event.tail.signaledValue(), 1);
    credits.complete(
        packet
            .reservation
            .take()
            .ok_or("credit already completed")?,
        packet.serial,
    );
    packet.graph_pin = None;
    println!(
        "{} certified API completion + native tail=1; credit reclaimed; held={}",
        packet.name,
        credits.held()
    );
    Ok(())
}
fn half_round(v: f64) -> f64 {
    assert!(v.is_finite() && (2f64.powi(-14)..=65504.).contains(&v));
    let step = 2f64.powi(v.log2().floor() as i32 - 10);
    (v / step).round_ties_even() * step
}
fn srgb(v: f64) -> f64 {
    if v <= 0.0031308 {
        12.92 * v
    } else {
        1.055 * v.powf(1. / 2.4) - 0.055
    }
}
fn oracle(p: Params) -> [u8; 4] {
    // Independent CPU depth decisions and f64 tone/half/output calculation.
    // All depths and immutable tags are exactly representable binary values.
    let sun_bit = u8::from(0.5 > p.sun) as f64;
    let draw_bit = u8::from(0.5 > p.depth) as f64;
    let l = [
        (1. + sun_bit) / 8.,
        (1. + draw_bit) / 8.,
        f64::from(p.blue) / 8.,
    ]
    .map(|x| half_round(x / 1024.) * 1024.);
    let y = 0.2126 * l[0] + 0.7152 * l[1] + 0.0722 * l[2];
    let t = l.map(|x| x / (1. + y));
    assert!(
        t.into_iter().fold(0f64, f64::max) < 1.,
        "fixture must preserve observable tone denominator"
    );
    let e = t.map(|x| half_round(srgb(x)));
    [
        (e[0] * 255.).round() as u8,
        (e[1] * 255.).round() as u8,
        (e[2] * 255.).round() as u8,
        255,
    ]
}
fn verify(d: &Device, packet: &Packet) -> AnyResult<()> {
    let (tx, rx) = mpsc::channel();
    packet
        .readback
        .slice(..)
        .map_async(MapMode::Read, move |r| {
            let _ = tx.send(r);
        });
    d.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(10)),
    })?;
    rx.recv_timeout(Duration::from_secs(2))??;
    let mapped = packet.readback.slice(..).get_mapped_range()?;
    let data = mapped.as_ref();
    assert_eq!(u64::try_from(data.len())?, payload(packet.extent, 4)?);
    let expected = oracle(packet.params);
    let (pixels, rest) = data.as_chunks::<4>();
    assert!(rest.is_empty());
    let mut worst = 0;
    for (index, pixel) in pixels.iter().enumerate() {
        for c in 0..4 {
            let delta = pixel[c].abs_diff(expected[c]);
            worst = worst.max(delta);
            assert!(
                delta <= if c == 3 { 0 } else { 1 },
                "{} pixel={index} channel={c} actual={} expected={}",
                packet.name,
                pixel[c],
                expected[c]
            );
        }
    }
    assert_eq!(packet.uniform.size(), 16);
    println!(
        "{} every-pixel CPU oracle passed: extent={:?} expected={expected:?} first={:?} pixels={} max_code_error={worst}",
        packet.name,
        packet.extent,
        &data[..4],
        pixels.len()
    );
    drop(mapped);
    packet.readback.unmap();
    Ok(())
}
fn try_retire(old: &mut Option<Arc<Graph>>) -> bool {
    let g = old.as_ref().expect("already retired");
    if Arc::strong_count(g) != 1
        || Arc::strong_count(&g.views) != 1
        || Arc::strong_count(&g.output) != 1
    {
        return false;
    }
    old.take();
    true
}
fn main() -> AnyResult<()> {
    let mut descriptor = InstanceDescriptor::new_without_display_handle();
    descriptor.backends = Backends::METAL;
    let instance = Instance::new(descriptor);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let rt = TextureUsages::RENDER_ATTACHMENT;
    let sampled = rt | TextureUsages::TEXTURE_BINDING;
    for (format, usage, filter) in [
        (TextureFormat::Depth32Float, sampled, false),
        (TextureFormat::Rgba16Float, sampled, true),
        (
            TextureFormat::Rgba8Unorm,
            rt | TextureUsages::COPY_SRC,
            false,
        ),
    ] {
        let supported = adapter.get_texture_format_features(format);
        assert!(supported.allowed_usages.contains(usage));
        assert!(
            !filter
                || supported
                    .flags
                    .contains(TextureFormatFeatureFlags::FILTERABLE)
        );
    }
    assert!(adapter.limits().max_texture_dimension_2d >= 2048);
    let (d, q) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    assert!(d.limits().max_texture_dimension_2d >= 2048);
    let info = adapter.get_info();
    println!(
        "adapter={} backend={:?} max2d={}",
        info.name,
        info.backend,
        d.limits().max_texture_dimension_2d
    );
    // SAFETY: one CPU submitter, native handles used solely for diagnostic
    // synchronization. No queue callbacks or other submitting thread exist.
    unsafe { q.as_hal::<wgpu::hal::api::Metal>() }
        .ok_or("Metal queue unavailable")?
        .enable_strict_event_sync()?;
    let mut events = Events::new(&d)?;
    let scope = d.push_error_scope(ErrorFilter::Validation);
    let sun_bytes = payload((2048, 2048), 4)?;
    let old_scratch = sum(&[sun_bytes, view_bytes(HD)?])?;
    let new_scratch = sum(&[sun_bytes, view_bytes(FHD)?])?;
    let overlap = sum(&[sun_bytes, view_bytes(HD)?, view_bytes(FHD)?])?;
    let output_overlap = sum(&[payload(HD, 4)?, payload(FHD, 4)?])?;
    let readback_total = sum(&[payload(HD, 4)?, payload(HD, 4)?, payload(FHD, 4)?])?;
    // All persistent preparation budgets are preflighted before any texture.
    assert!(overlap <= SCRATCH_BUDGET);
    assert!(output_overlap <= OUTPUT_BUDGET);
    assert!(readback_total <= READBACK_BUDGET);
    assert_eq!(
        (old_scratch, new_scratch, overlap),
        (35_209_216, 58_249_216, 76_681_216)
    );
    println!(
        "preflight scratch budget={SCRATCH_BUDGET} old={old_scratch} new={new_scratch} overlap={overlap}; independent output budget={OUTPUT_BUDGET} overlap={output_overlap}; readback budget={READBACK_BUDGET} selected={readback_total}"
    );
    let p = pipelines(&d);
    let mut stats = AllocationStats::default();
    let sun = Arc::new(texture(
        &d,
        "shared Sun",
        (2048, 2048),
        TextureFormat::Depth32Float,
        sampled,
        &mut stats,
    ));
    let mut old = Some(prepare_graph(&d, &p, 1, HD, sun.clone(), &mut stats));
    let weak_views = Arc::downgrade(&old.as_ref().unwrap().views);
    let weak_output = Arc::downgrade(&old.as_ref().unwrap().output);
    let mut cpu_view_lease = Some(old.as_ref().unwrap().views.clone());
    let mut cpu_output_lease = Some(old.as_ref().unwrap().output.clone());
    let mut credits = Credits::new();
    let ra = credits.reserve().ok_or("A reservation failed")?;
    let mut a = submit_packet(
        &d,
        &q,
        &p,
        old.as_ref().unwrap(),
        ra,
        Params {
            sun: 0.75,
            depth: 0.75,
            blue: 4.,
        },
        "A",
        0,
        &mut events,
        &mut credits,
        &mut stats,
    )?;
    let rb = credits.reserve().ok_or("B reservation failed")?;
    let mut b = submit_packet(
        &d,
        &q,
        &p,
        old.as_ref().unwrap(),
        rb,
        Params {
            sun: 0.25,
            depth: 0.25,
            blue: 6.,
        },
        "B",
        1,
        &mut events,
        &mut credits,
        &mut stats,
    )?;
    assert_eq!(credits.held(), 2);
    assert!(Arc::ptr_eq(
        a.graph_pin.as_ref().unwrap(),
        b.graph_pin.as_ref().unwrap()
    ));
    require_incomplete(&d, &a, &events.pairs[0])?;
    require_incomplete(&d, &b, &events.pairs[1])?;
    let before = stats;
    assert!(credits.reserve().is_none());
    assert_eq!(stats, before);
    assert_eq!(stats.uniforms, 2);
    assert_eq!(stats.readbacks, 2);
    assert_eq!(stats.init_staging_payload, 32);
    assert_eq!(stats.submissions, 2);
    println!(
        "C refused before extraction/uniform/readback/staging/submit: unchanged stats={stats:?}"
    );
    assert!(!try_retire(&mut old));
    // This configuration transaction prepares persistent slots/output only;
    // no third packet or packet buffer is admitted while both credits are held.
    let newer = prepare_graph(&d, &p, 2, FHD, sun.clone(), &mut stats);
    assert!(Arc::ptr_eq(&old.as_ref().unwrap().sun, &newer.sun));
    assert!(!Arc::ptr_eq(&old.as_ref().unwrap().views, &newer.views));
    assert!(!Arc::ptr_eq(&old.as_ref().unwrap().output, &newer.output));
    assert_eq!(
        (
            stats.packet_extractions,
            stats.uniforms,
            stats.readbacks,
            stats.submissions
        ),
        (2, 2, 2, 2)
    );
    require_incomplete(&d, &a, &events.pairs[0])?;
    require_incomplete(&d, &b, &events.pairs[1])?;
    println!(
        "new persistent graph prepared while A/B GPU-incomplete: scratch logical overlap={overlap}; output logical overlap={output_overlap}; tails={:?}",
        events.tail_values()
    );
    events.pairs[0].gate.setSignaledValue(1);
    certify(&d, &mut a, &events.pairs[0], &mut credits)?;
    require_incomplete(&d, &b, &events.pairs[1])?;
    assert_eq!(events.tail_values(), vec![1, 0, 0]);
    assert_eq!(credits.held(), 1);
    assert!(!try_retire(&mut old));
    let rc = credits.reserve().ok_or("C reservation after A failed")?;
    let mut c = submit_packet(
        &d,
        &q,
        &p,
        &newer,
        rc,
        Params {
            sun: 0.75,
            depth: 0.25,
            blue: 2.,
        },
        "C",
        2,
        &mut events,
        &mut credits,
        &mut stats,
    )?;
    assert_eq!(credits.held(), 2);
    require_incomplete(&d, &b, &events.pairs[1])?;
    require_incomplete(&d, &c, &events.pairs[2])?;
    events.pairs[1].gate.setSignaledValue(1);
    events.pairs[2].gate.setSignaledValue(1);
    certify(&d, &mut b, &events.pairs[1], &mut credits)?;
    certify(&d, &mut c, &events.pairs[2], &mut credits)?;
    assert_eq!(events.tail_values(), vec![1, 1, 1]);
    assert_eq!(credits.held(), 0);
    if let Some(error) = pollster::block_on(scope.pop()) {
        return Err(format!("wgpu validation: {error}").into());
    }
    // GPU completion alone cannot retire prepared ownership or CPU leases.
    assert!(!try_retire(&mut old));
    verify(&d, &a)?;
    verify(&d, &b)?;
    verify(&d, &c)?;
    cpu_output_lease.take();
    assert!(!try_retire(&mut old));
    assert!(weak_views.upgrade().is_some());
    assert!(weak_output.upgrade().is_some());
    cpu_view_lease.take();
    assert!(try_retire(&mut old));
    assert!(weak_views.upgrade().is_none());
    assert!(weak_output.upgrade().is_none());
    assert!(old.is_none());
    assert_eq!(newer.sun.id, sun.id);
    println!(
        "old view/output owners retired only after B native/API completion + CPU output and view lease release; new prepared scratch={new_scratch} output={}",
        payload(FHD, 4)?
    );
    let uniform_payload = stats
        .uniforms
        .checked_mul(16)
        .ok_or("uniform sum overflow")?;
    let conservative = sum(&[
        overlap,
        output_overlap,
        readback_total,
        uniform_payload,
        stats.init_staging_payload,
    ])?;
    println!(
        "logical selected payload: scratch overlap={overlap}; output overlap={output_overlap}; readbacks={readback_total}; immutable uniforms={uniform_payload}; initialization staging charge={} cumulative, conservatively retained for whole diagnostic; total charged={conservative}; stats={stats:?}",
        stats.init_staging_payload
    );
    println!(
        "instrumented two-credit four-role 720p-to-1080p synthetic proof passed; no authored R0, physical residency or performance claim"
    );
    drop(events);
    Ok(())
}
