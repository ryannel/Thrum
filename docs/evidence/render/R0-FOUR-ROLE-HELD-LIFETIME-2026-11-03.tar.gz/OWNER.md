Owner: /root/r0_gpu_narrow_review, bounded R0 synthetic GPU commission, 3 November 2026.
Scope: ONLY this tmp/r0-four-role scratch directory; parent integrates sequentially.
Purpose: instrumented two-credit four-role 720p-to-1080p lifetime proof with
native strict gates/tails, immutable packet inputs and CPU view/output leases.
Expected peak disk: under 2 GiB including isolated Cargo target.
Selected inputs: committed R0 schedule candidate, selected FXAA package and exact
wgpu 30.0.1 / objc2 0.6.5 / objc2-metal 0.3.2 / pollster 1.0.1 dependencies.
Historical single-frame baseline: docs/evidence/render/R0-FOUR-ROLE-SYNTHETIC-2026-11-03.tar.gz.
Current result: RESULT.md and lifetime-run-final.log; no tracked changes.
Retained output: small source archive/hash and compact evidence if parent accepts.
Closeout: retain selected source/evidence, then inspect owned build output for cleanup.
No authored R0, physical residency, performance, real surface or production promise.
