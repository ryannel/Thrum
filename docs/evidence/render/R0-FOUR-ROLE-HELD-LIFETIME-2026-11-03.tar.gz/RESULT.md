# Instrumented synthetic two-credit four-role lifetime proof — 3 November 2026

Implemented only in this owned scratch directory. The previously selected
single-frame source is archived at
`docs/evidence/render/R0-FOUR-ROLE-SYNTHETIC-2026-11-03.tar.gz`.
The current source extends that chain, not production V1/F4. It uses Rust 1.99.1,
wgpu 30.0.1, objc2 0.6.5, objc2-metal 0.3.2 and pollster 1.0.1, with exact
versions and an offline lockfile. Final native run selected Apple M3 Max / Metal,
reported maximum 2D dimension 8192 and exited zero. No tracked file was edited.

## Actual resources and data flow

Every texture is D2, one mip/layer/sample, empty view_formats. Adapter format
usages/filterability and adapter/device dimensions are checked before allocation.

| Role | Format / extent | Usage |
| --- | --- | --- |
| Shared Sun | Depth32Float, 2048x2048 | RENDER_ATTACHMENT + TEXTURE_BINDING |
| View depth | Depth32Float, 1280x720 or 1920x1080 | RENDER_ATTACHMENT |
| Scene linear | Rgba16Float, view extent | RENDER_ATTACHMENT + TEXTURE_BINDING |
| Encoded scene | Rgba16Float, view extent | RENDER_ATTACHMENT + TEXTURE_BINDING |
| Independent output | Rgba8Unorm, view extent | RENDER_ATTACHMENT + COPY_SRC |
| Immutable packet input | 16 B buffer | UNIFORM, mapped at creation only |
| Per-packet output copy | width*height*4 B buffer | COPY_DST + MAP_READ |

The three packet inputs differ: A=(Sun .75, view depth .75, blue tag 4),
B=(.25,.25,6), C=(.75,.25,2). Each buffer is initialized once and unmapped;
no in-flight input is mapped or written again. Pinned wgpu-core implements this
non-MAP_WRITE mapped-at-creation initialization using staging, so its 16 B logical
payload per packet is separately charged. Input extraction, uniform creation,
readback creation, staging payload and submission have allocation-site counters.

Each nonempty ordinary-wgpu command buffer executes Sun write, view-depth write,
forward, tone/encode, FXAA/output, then output-to-buffer copy. Both depth passes
clear to reverse-Z zero and draw the packet-selected depth. Forward loads view
depth read-only (depth_ops None; pipeline depth writes false) and uses Greater:
a draw at .875 passes, followed by a draw at .5 that passes only for view depth
.25. Both fragment variants use four equal-weight Sun comparison taps at .5.
Sun comparison and surviving forward draw control separate RGB channels;
blue carries the immutable packet tag. Scene storage is
`[(1+SunBit),(1+DrawBit),blueTag]/8192`.

Tone undoes storage scale p=1/1024 and applies the selected exposure-1
Rec.709 luminance/Reinhard/gamut/sRGB formula. These low radiances keep gamut
normalization inactive so the tone denominator remains observable. Encoded alpha
carries the selected luma. The unchanged pinned FXAA file takes its uniform early
exit; shader assembly only converts its entry signature into an ordinary function
and appends the small display-linear-decode/explicit-UNORM-encode output wrapper.
FXAA notices and the copied Intel Apache notice/license remain present.

## Exercised ownership sequence

1. Reserve A, allocate/encode/stage its native gate and tail, then submit. Repeat
   sequentially for B. A/B use exactly the same prepared graph object and texture
   IDs [1,2,3,4,5]; each copies output before any next packet overwrite.
2. With two submitted credits held, A and B each return API Timeout at a 10 ms
   wait; their distinct native gates and tails remain zero.
3. Attempt C reservation. It refuses before packet extraction or any C
   uniform/readback/staging/submission. All allocation counters remain unchanged:
   two extracted packets, two uniforms, two readbacks, 32 B staging payload and
   two submissions. C's diagnostic events were finite fixture instrumentation
   created at startup, not packet storage.
4. In a separately budgeted configuration transaction, prepare the three new
   1080p view roles and independent new output. Compatible Sun is shared by Arc
   identity; new IDs are [1,6,7,8,9]. No C packet input/readback is created here.
   A/B still time out with zero native tails after all allocations exist.
5. Signal only A's gate. Require its API completion and native tail 1, release
   its graph pin and reclaim its matching generation/serial credit. B still times
   out with gate/tail zero; observed tails are [1,0,0].
6. Reserve C using the reclaimed slot, then allocate/encode/submit its immutable
   input and readback. B/C now occupy exactly two credits. Both still time out
   with their gates/tails zero before release.
7. Release B/C, require each packet's API completion and independent native tail,
   and reclaim the matching credits. Final tails are [1,1,1], credits held zero.
8. GPU completion alone still refuses old ownership retirement because explicit
   CPU view and output leases remain. Check all readbacks, release the CPU output
   lease and verify retirement still refuses, then release the CPU view lease.
   Retirement now succeeds. Weak ownership checks confirm all old application
   view/output owners have gone; the shared Sun remains owned by the new graph.

Allocation IDs are assigned by this harness at actual create_texture call sites;
they are not native allocator addresses. Ownership retirement means application
handles/references were released, not observed physical driver deallocation.

## Native instrumentation constraints

Strict-event synchronization is enabled before command encoding. One CPU thread
encodes, stages waits/signals and submits each packet in order. Every gated submit
contains a nonempty ordinary-wgpu command buffer; there are no completion-callback
submits or other submitters. A/B/C have separate retained native gate/tail events.
No later gate is released while the proof requires an earlier packet to remain
blocked, avoiding a later strict-relay signal bypassing an earlier wait.

Native event references remain owned through all tail and pixel checks. Error
cleanup signals every gate and waits for submitted tails; if it cannot drain,
it leaks event references for this short-lived process rather than freeing native
inputs still in use. This is fixture lifetime protection, not device-loss recovery.
Queue completion alone is not an execution-success oracle: native tails and pixels
are required, following the prior strict-event diagnostic's observed failure.

## Result and cost classification

Both the initial complete run and final Clippy-clean rebuilt run passed.
Final output is retained in `lifetime-run-final.log`. All 3,916,800 RGBA pixels
were checked by a separate f64 CPU depth/tone/sRGB calculation with arithmetic
binary16 rounding. The tolerance is at most one RGB code, exact alpha:

| Packet | Extent | Expected and observed first RGBA | Worst error over every pixel |
| --- | --- | --- | --- |
| A | 1280x720 | [93,93,176,255] | 0 |
| B | 1280x720 | [122,122,201,255] | 0 |
| C | 1920x1080 | [90,125,125,255] | 0 |

The wgpu validation scope was empty. Pinned rustfmt check, offline locked release
build and isolated Clippy `-D warnings` passed. The scratch manifest follows
CONTRIBUTING's disabled argument-count lint; no helper split was made for it.

Checked descriptor arithmetic is preflighted before texture creation:

- Scratch owner policy: 80 MiB; old 35,209,216 B, new 58,249,216 B,
  shared-Sun overlap 76,681,216 B.
- Independent output policy: 16 MiB; old/new overlap 11,980,800 B.
- Readback policy: 20 MiB; A/B/C retained payloads total 15,667,200 B.
- Three retained immutable uniform payloads: 48 B.
- Three initialization-staging payloads: 48 B cumulatively, charged conservatively
  through this entire diagnostic. Their actual internal retirement/capacity is
  not measured; this is not a claim all three transfers remain GPU-incomplete.
- Combined selected conservative logical charge: 104,329,312 B.

These are descriptor and policy charges, not physical allocation sizes, residency
or measured high-water. Pipelines, bind groups, samplers, native events/relay,
internal alignment, retained staging capacity and driver overhead are outside
these selected texture/buffer payloads.

Build/run from repository root (the run needs native Metal access):

```sh
RUSTC_WRAPPER= rustup run 1.99.1 cargo build --offline --locked --release --manifest-path tmp/r0-four-role/Cargo.toml
tmp/r0-four-role/target/release/r0-four-role-synthetic
```

Still unproved: authored R0 game/geometry/mask/light correctness, nonuniform FXAA
filtering, F4 product/upload leases, real graph validation, a real surface,
60 MiB refusal/loading, preparation failure, device loss/stale-generation behavior,
other backends/devices, physical high-water and ordinary frame cost/visual quality.
The native gate blocks before execution, not midway through a partially run frame.
