use std::{borrow::Cow, fs, sync::mpsc, time::Duration};
use wgpu::*;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn main() -> Result<()> {
    let spv = include_bytes!("../reference.spv");
    let module = naga::front::spv::parse_u8_slice(spv, &Default::default())?;
    naga::valid::Validator::new(
        naga::valid::ValidationFlags::all(),
        naga::valid::Capabilities::empty(),
    )
    .validate(&module)?;
    println!("naga30 SPIR-V validated with empty optional capabilities");
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let instance = Instance::new(desc);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    println!("adapter={:?}", adapter.get_info());
    let (device, queue) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    let wgsl = device.create_shader_module(ShaderModuleDescriptor {
        label: Some("unchanged WGSL"),
        source: ShaderSource::Wgsl(
            std::fs::read_to_string(std::env::var("FXAA_SHADER_PATH")?)?.into(),
        ),
    });
    let reference = device.create_shader_module(ShaderModuleDescriptor {
        label: Some("independent HLSL SPIR-V"),
        source: ShaderSource::SpirV(Cow::Owned(
            spv.as_chunks::<4>()
                .0
                .iter()
                .map(|x| u32::from_le_bytes(*x))
                .collect(),
        )),
    });
    let motion = device.create_shader_module(ShaderModuleDescriptor {
        label: Some("prior motion input"),
        source: ShaderSource::Wgsl(include_str!("motion.wgsl").into()),
    });
    let port = pipeline(&device, &wgsl, "vs_fxaa", &wgsl, "fs_fxaa");
    let refpipe = pipeline(&device, &wgsl, "vs_fxaa", &reference, "main");
    let motionpipe = pipeline(&device, &motion, "vs_full", &motion, "fs_motion");
    let sampler = device.create_sampler(&SamplerDescriptor {
        label: Some("same clamp linear mip0"),
        address_mode_u: AddressMode::ClampToEdge,
        address_mode_v: AddressMode::ClampToEdge,
        mag_filter: FilterMode::Linear,
        min_filter: FilterMode::Linear,
        mipmap_filter: MipmapFilterMode::Nearest,
        lod_min_clamp: 0.,
        lod_max_clamp: 0.,
        ..Default::default()
    });
    for (name, w, h) in [
        ("orientation", 64, 64),
        ("masked", 256, 256),
        ("thin", 256, 256),
        ("motion-a", 1280, 720),
        ("motion-b", 1280, 720),
    ] {
        let input = texture(
            &device,
            w,
            h,
            TextureUsages::RENDER_ATTACHMENT
                | TextureUsages::TEXTURE_BINDING
                | TextureUsages::COPY_SRC
                | TextureUsages::COPY_DST,
        );
        let view = input.create_view(&Default::default());
        if name == "masked" || name == "thin" {
            let bytes = fs::read(if name == "masked" {
                "encoded.rgba16f"
            } else {
                "fixture.rgba16f"
            })?;
            assert_eq!(bytes.len(), (w * h * 8) as usize);
            upload(&queue, &input, &bytes, w, h);
        } else if name == "orientation" {
            // Asymmetric RGB quadrants, constant alpha luma: exact early-exit orientation control.
            let colors = [
                [0x3c00u16, 0, 0],
                [0, 0x3c00, 0],
                [0, 0, 0x3c00],
                [0x3800, 0x3400, 0x3a00],
            ];
            let bytes = (0..h)
                .flat_map(|y| {
                    (0..w).flat_map(move |x| {
                        let c = colors[((y >= h / 2) as usize) * 2 + (x >= w / 2) as usize];
                        [c[0], c[1], c[2], 0x3800]
                            .into_iter()
                            .flat_map(u16::to_le_bytes)
                    })
                })
                .collect::<Vec<_>>();
            upload(&queue, &input, &bytes, w, h);
        } else {
            let params = uniform(
                &device,
                &[
                    w as f32,
                    h as f32,
                    if name == "motion-a" { 0. } else { 0.37 },
                    0.,
                ],
            );
            let bg = device.create_bind_group(&BindGroupDescriptor {
                label: None,
                layout: &motionpipe.get_bind_group_layout(0),
                entries: &[BindGroupEntry {
                    binding: 0,
                    resource: params.as_entire_binding(),
                }],
            });
            let mut enc = device.create_command_encoder(&Default::default());
            draw(&mut enc, &view, &motionpipe, &bg);
            queue.submit([enc.finish()]);
        }
        let params = uniform(&device, &[1. / w as f32, 1. / h as f32, 0., 0.]);
        let mut enc = device.create_command_encoder(&Default::default());
        let mut buffers = vec![("input", copy(&device, &mut enc, &input, w, h))];
        for (label, pipe) in [("reference", &refpipe), ("wgsl", &port)] {
            let output = device.create_texture(&TextureDescriptor {
                label: None,
                size: Extent3d {
                    width: w,
                    height: h,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: TextureDimension::D2,
                format: output_format(),
                usage: TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC,
                view_formats: &[],
            });
            let outview = output.create_view(&Default::default());
            let mut entries = vec![
                BindGroupEntry {
                    binding: 0,
                    resource: BindingResource::TextureView(&view),
                },
                BindGroupEntry {
                    binding: 1,
                    resource: BindingResource::Sampler(&sampler),
                },
            ];
            if label == "reference" {
                entries.push(BindGroupEntry {
                    binding: 2,
                    resource: params.as_entire_binding(),
                });
            }
            let bg = device.create_bind_group(&BindGroupDescriptor {
                label: Some(label),
                layout: &pipe.get_bind_group_layout(0),
                entries: &entries,
            });
            draw(&mut enc, &outview, pipe, &bg);
            buffers.push((label, copy(&device, &mut enc, &output, w, h)));
        }
        let submission = queue.submit([enc.finish()]);
        let channels = buffers
            .iter()
            .map(|(_, b)| {
                let (tx, rx) = mpsc::channel();
                b.slice(..).map_async(MapMode::Read, move |r| {
                    let _ = tx.send(r);
                });
                rx
            })
            .collect::<Vec<_>>();
        device.poll(PollType::Wait {
            submission_index: Some(submission),
            timeout: Some(Duration::from_secs(30)),
        })?;
        for rx in channels {
            rx.recv_timeout(Duration::from_secs(1))??;
        }
        for (label, b) in buffers {
            let data = b.slice(..).get_mapped_range()?;
            let suffix = if label != "input" && output_format() == TextureFormat::Rgba8Unorm {
                "rgba8"
            } else {
                "rgba16f"
            };
            fs::write(format!("{name}-{w}x{h}-{label}.{suffix}"), data.as_ref())?;
            drop(data);
            b.unmap();
        }
        println!("captured {name} {w}x{h}");
    }
    Ok(())
}
fn uniform(d: &Device, v: &[f32]) -> Buffer {
    let b = d.create_buffer(&BufferDescriptor {
        label: None,
        size: (v.len() * 4) as u64,
        usage: BufferUsages::UNIFORM,
        mapped_at_creation: true,
    });
    {
        let mut m = b.slice(..).get_mapped_range_mut().unwrap();
        for (i, x) in v.iter().enumerate() {
            m.slice(i * 4..i * 4 + 4).copy_from_slice(&x.to_le_bytes());
        }
    }
    b.unmap();
    b
}
fn texture(d: &Device, w: u32, h: u32, usage: TextureUsages) -> Texture {
    d.create_texture(&TextureDescriptor {
        label: None,
        size: Extent3d {
            width: w,
            height: h,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format: TextureFormat::Rgba16Float,
        usage,
        view_formats: &[],
    })
}
fn upload(q: &Queue, t: &Texture, b: &[u8], w: u32, h: u32) {
    q.write_texture(
        TexelCopyTextureInfo {
            texture: t,
            mip_level: 0,
            origin: Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        b,
        TexelCopyBufferLayout {
            offset: 0,
            bytes_per_row: Some(w * 8),
            rows_per_image: Some(h),
        },
        Extent3d {
            width: w,
            height: h,
            depth_or_array_layers: 1,
        },
    );
}
fn draw(e: &mut CommandEncoder, v: &TextureView, p: &RenderPipeline, b: &BindGroup) {
    let mut pass = e.begin_render_pass(&RenderPassDescriptor {
        label: None,
        color_attachments: &[Some(RenderPassColorAttachment {
            view: v,
            depth_slice: None,
            resolve_target: None,
            ops: Operations {
                load: LoadOp::Clear(Color::BLACK),
                store: StoreOp::Store,
            },
        })],
        ..Default::default()
    });
    pass.set_pipeline(p);
    pass.set_bind_group(0, b, &[]);
    pass.draw(0..3, 0..1);
}
fn copy(d: &Device, e: &mut CommandEncoder, t: &Texture, w: u32, h: u32) -> Buffer {
    let bpp = if t.format() == TextureFormat::Rgba8Unorm {
        4
    } else {
        8
    };
    assert_eq!((w * bpp) % 256, 0);
    let b = d.create_buffer(&BufferDescriptor {
        label: None,
        size: (w * h * bpp) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    e.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: t,
            mip_level: 0,
            origin: Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: &b,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(w * bpp),
                rows_per_image: Some(h),
            },
        },
        Extent3d {
            width: w,
            height: h,
            depth_or_array_layers: 1,
        },
    );
    b
}
fn pipeline(
    d: &Device,
    vs: &ShaderModule,
    ve: &str,
    fs: &ShaderModule,
    fe: &str,
) -> RenderPipeline {
    d.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(fe),
        layout: None,
        vertex: VertexState {
            module: vs,
            entry_point: Some(ve),
            buffers: &[],
            compilation_options: Default::default(),
        },
        primitive: Default::default(),
        depth_stencil: None,
        multisample: Default::default(),
        fragment: Some(FragmentState {
            module: fs,
            entry_point: Some(fe),
            targets: &[Some(ColorTargetState {
                format: if fe == "fs_motion" {
                    TextureFormat::Rgba16Float
                } else {
                    output_format()
                },
                blend: None,
                write_mask: ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        multiview_mask: None,
        cache: None,
    })
}

fn output_format() -> TextureFormat {
    if std::env::var_os("OUT8").is_some() {
        TextureFormat::Rgba8Unorm
    } else {
        TextureFormat::Rgba16Float
    }
}
