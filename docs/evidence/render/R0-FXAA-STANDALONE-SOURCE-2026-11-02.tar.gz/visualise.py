from pathlib import Path
import struct,zlib
r=Path(__file__).resolve().parent;o=r/'out'
def png(path,w,h,data):
 def chunk(t,d):return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
 path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(b'\0'+data[y*w*3:(y+1)*w*3] for y in range(h)),9))+chunk(b'IEND',b''))
def rgb(pixels):return bytes(max(0,min(255,round(v*255)))for p in pixels for v in p[:3])
frames=[]
for label in ['a','b']:
 data=list(struct.iter_unpack('<4e',(o/f'motion-{label}-1280x720-wgsl.rgba16f').read_bytes()));frames.append(data)
 png(o/f'standalone-motion-{label}.png',1280,720,rgb(data))
crops=[rgb([frame[y*1280+x] for y in range(180,436) for x in range(900,1156)])for frame in frames]
png(o/'standalone-motion-crop.png',512,256,b''.join(data[y*256*3:(y+1)*256*3]for y in range(256)for data in crops))
