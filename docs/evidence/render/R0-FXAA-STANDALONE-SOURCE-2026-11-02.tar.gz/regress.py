"""Exact RGB comparator anchored to independently compiled HLSL, not WGSL-derived goldens."""
from pathlib import Path
import json,struct,sys,hashlib,os
r=Path(__file__).resolve().parent;o=r/'out'
pkg=Path(os.environ.get('FXAA_PACKAGE_PATH',r/'package' if (r/'package').exists() else r.parents[1]/'docs/evidence/render/fxaa-quality12-v1'))
p=json.loads((pkg/'product.json').read_text())
for name,expected in p['hashes'].items():assert hashlib.sha256((pkg/name).read_bytes()).hexdigest()==expected
actual_shader=Path(os.environ.get('FXAA_SHADER_PATH',pkg/'fxaa.wgsl'))
actual_hash=hashlib.sha256(actual_shader.read_bytes()).hexdigest()
goldens=json.loads((r/'reference-goldens.json').read_text())
results={}
for stem,n in [('orientation-64x64',4096),('masked-256x256',65536),('thin-256x256',65536),('motion-a-1280x720',921600),('motion-b-1280x720',921600)]:
 a=(o/f'{stem}-reference.rgba16f').read_bytes();b=(o/f'{stem}-wgsl.rgba16f').read_bytes();i=(o/f'{stem}-input.rgba16f').read_bytes()
 assert len(a)==len(b)==len(i)==n*8
 assert hashlib.sha256(a).hexdigest()==goldens[stem]['reference_sha256'],'reference changed against retained independent capture'
 assert hashlib.sha256(i).hexdigest()==goldens[stem]['input_sha256'],'fixture changed against retained capture'
 ref=list(struct.iter_unpack('<4e',a));port=list(struct.iter_unpack('<4e',b));inp=list(struct.iter_unpack('<4e',i))
 differing=sum(x[:3]!=y[:3] for x,y in zip(ref,port));changed=sum(x[:3]!=y[:3] for x,y in zip(ref,inp))
 results[stem]={'pixels':n,'rgb_differing_pixels':differing,'reference_filtered_pixels':changed,'reference_sha256':hashlib.sha256(a).hexdigest(),'shader_sha256':actual_hash}
 if stem=='orientation-64x64':assert all(x[:3]==y[:3] for x,y in zip(ref,inp))
 else:assert changed>1000,'identity reference would make regression vacuous'
 assert all(x[3]==y[3] for x,y in zip(ref,inp)),'reference alpha must retain centre luma'
 assert all(x[3]==1 for x in port),'selected output alpha must be1'
print(json.dumps(results,indent=2))
(o/'regression.json').write_text(json.dumps(results,indent=2)+'\n')
if any(x['rgb_differing_pixels'] for x in results.values()):sys.exit(1)
