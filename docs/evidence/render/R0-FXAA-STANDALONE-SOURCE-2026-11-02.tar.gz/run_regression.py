"""Run fresh independent-reference comparisons and explicit comparator sensitivity checks."""
from pathlib import Path
import os,subprocess,json,hashlib
r=Path(__file__).resolve().parent;o=r/'out';pkg=Path(os.environ.get('FXAA_PACKAGE_PATH',r/'package' if (r/'package').exists() else r.parents[1]/'docs/evidence/render/fxaa-quality12-v1'))
meta=json.loads((pkg/'product.json').read_text())
for name,expected in meta['hashes'].items():assert hashlib.sha256((pkg/name).read_bytes()).hexdigest()==expected
shader=pkg/'fxaa.wgsl';base=shader.read_text()
faults={'green':base.replace('sample_at(uv).a','sample_at(uv).g').replace('let m = center.a','let m = center.g'),'flip':base.replace('let uv = position.xy * texel;','let base_uv = position.xy * texel;\n    let uv = vec2<f32>(base_uv.x, 1.0-base_uv.y);')}
for name,text in faults.items():(r/f'fault-{name}.wgsl').write_text(text)
binary=o/'target/debug/r0-fxaa-standalone';env=os.environ.copy();env['FXAA_SHADER_PATH']=str(shader)
with (o/'prior.log').open('w') as log:subprocess.run([str(o/'target/debug/prior')],cwd=o,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
summary={}
for name,path in [('green',r/'fault-green.wgsl'),('flip',r/'fault-flip.wgsl'),('normal',shader)]:
 env['FXAA_SHADER_PATH']=str(path)
 with(o/f'{name}-run.log').open('w')as log:subprocess.run([str(binary)],cwd=o,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 with(o/f'{name}-comparison.log').open('w')as log:result=subprocess.run(['python3',str(r/'regress.py')],cwd=o,env=env,stdout=log,stderr=subprocess.STDOUT)
 data=json.loads((o/'regression.json').read_text());(r/f'{name}-regression.json').write_text(json.dumps(data,indent=2)+'\n')
 expected=0 if name=='normal' else 1
 assert result.returncode==expected,(name,result.returncode,expected)
 summary[name]={'comparator_exit':result.returncode,'shader_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'differing_rgb_pixels':{k:v['rgb_differing_pixels']for k,v in data.items()}}
(r/'regression-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
