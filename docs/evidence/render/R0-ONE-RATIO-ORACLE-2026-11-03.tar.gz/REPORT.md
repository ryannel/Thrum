# Independent one-ratio Smith and represented-dot oracle

Scratch candidate, 3 November 2026. Only `tmp/r0-one-ratio-oracle/` was
written by this commission. Actual selected execution revision is
`81b1269dd89d44790d624e1709927937d5064da1`; exact input hashes are in
`results.json`. The prior oracle's report was read for its scope and
discriminators; no prior oracle code was imported or executed.

Run from the repository root with Python 3.11 or later:

```sh
python3.11 tmp/r0-one-ratio-oracle/oracle.py > tmp/r0-one-ratio-oracle/run-summary.json
```

This run used Python 3.11.15, stdlib only, and took 0.471878 seconds for the
whole CPU workflow. This is workflow duration, with no shader-cost claim.
The final oracle was explicitly executed with `python3.11`. Results contain
no runtime or timestamp and are deterministic for the same Python version,
revision and input files. A second Python 3.11.15 execution reproduced the
same `results.json` SHA-256.
`run-summary.json` includes wall time and will vary on repetition.

## Formula separation and checked domain

The original reference computes a Gauss-Legendre Pi at 340 decimal digits,
normalizes the unscaled half vector, and evaluates the original GGX D,
height-correlated Smith through the Lambda formulation,
`G2=1/(1+Lambda_i+Lambda_o)`, Schlick F, `D*G2*F/(4ci*co)`, and finally
incident cosine `ci` (E is one). It never uses a combined Smith ratio.

The separately transcribed candidate max-scales the half vector, uses the
alternative D polynomial, and evaluates the two one-ratio branches in the
research note. Both evaluators apply the existing `.045` roughness floor
and return zero before half normalization for nonpositive hemispheres.
Fixtures have unit normal `(0,0,1)`, independently constructed unit
directions, roughness in `[0,1]`, and F0 in `[0,1]`. No angle floor or source
sign certificate is assumed. This CPU experiment supplies neither one.

All 1,265 fixtures pass `abs(candidate-reference)/max(1,abs(reference)) <
1e-260`: 554 `ci>=co` branches, 707 `ci<co` branches, four hemisphere-zero
results. Maximum discrepancy is `7.75400826159092378026030037027e-334`.
The fixture set includes 1,200 fixed-seed mixed cosine/log-grazing cases,
normal incidence, aligned/right-angle/opposing azimuths, the sharp family
and its reversed numerator, exact branch equality and neighbours, former
angle-floor/minnormal/minsubnormal neighbours, roughness floor and f32
`.32` neighbours, exact opposed tangency and negative hemispheres.

At `ci=2^-12,co=2^-24,r=.32,F0=.04`, both expressions give
`148.101166996892454673178792546` radiance per unit illuminance. At
`ci=2^-200,co=2^-400` the result is
`148.224591363123930775452184838`; reversed cosines yield
`9.22403896607444853307101236931e-59`. The asymmetry is expected because
radiance includes the incident cosine. Three sharp-family checks reconstruct
directions and Pi afresh at 420 digits. The largest reference change is
`3.93103942585666469813374071909e-280` at power 200, below the declared
`1e-260` comparison tolerance. The 420-digit one-ratio/original discrepancy
is below `7.36e-418` on those checks. Precision stability and sampled
agreement support transcription; finite samples do not prove the identity.

## Exact represented-input dot signs

Two independent stdlib routes agree for five fixed cases and 4,000 seeded
normal-component cases: (1) integer decoding on the common `2^-149` f32
operand lattice followed by integer three-product accumulation, and (2)
separate binary32-to-Fraction conversion and rational products/sum. All
inputs are normal-or-zero components in `[-1,1]`; they are not required to
form unit geometric vectors. The exact integer result has scale `2^-298`.

For `u=2^-149,M=2^23`, use
`v=((M+1)u,Mu,0)`, `w=((M+1)u,-(M+2)u,0)`. These nonzero components are
normal f32 values with bits `00800001,00800000` and
`00800001,80800002`. Their exact dot is **positive `2^-298`**, since
`(M+1)^2-M(M+2)=1`. Negating w gives `-2^-298`; a separate equal-product
cancellation gives exact zero. No floating product is needed for the sign.

At this lattice scale, three bounded products need at most 301 signed bits:
`abs(sum)<=3*2^298`, whose magnitude needs 300 bits. Selected samples reach
301 signed bits. This verifies a conservative arithmetic budget for these
operands; it does not implement or prove multiword-u32 product/carry logic.

For source loss, choose exact authored unit n `(3/5,0,4/5)` and tangent
`(4/5,0,-3/5)`, then normalize `tangent +/- 2^-140*n`. True dot signs are
opposite because the shared norm is positive. Exact rational intervals
bound the true norm by `[1,1+2^-280/2]`; each normalized coordinate lies
between its unnormalized value x and `x/(1+2^-280/2)`. Both rational
endpoints narrow to the same bits, proving the true normalized values
also narrow identically by monotonicity. Fresh 420-digit normalized
reconstructions provide a separate numerical cross-check. Narrowing uses
an exact rational ties-to-even search. The represented n/direction exact
dot is zero. A represented-input exact predicate cannot recover the two
authored signs.

The selected FTZ ambiguity is `2^-126 * .5`: both operands are normal f32,
the exact dot is positive `2^-127`, and flushing that subnormal product
gives zero. This is one explicit FTZ model, not a WGSL error interval or
an exhaustive emulator. Exact sign by itself does not make a usable f32
positive magnitude available to the ratio evaluator.

## Deliberate discriminators

Omitting q from the `ci<co` branch numerator gives a 50-times result at
`ci=.01,co=.5`: mutated `0.662454167101697880230577068659` versus original
`0.0132490833420339576046115413732`, relative error 49. The assertion catches
this transcription defect. Separately, retaining only 256 bits of the
fixed `2^-298` dot lattice wraps the exact positive unit-dot numerator
`2^298` to zero; its sign assertion fails. Neither mutant is included in
passing-case error statistics.

## Limits

This is a Decimal real-number experiment and integer/Fraction represented
operand predicate, with no f32 one-ratio evaluator, WGSL, source certificate,
sound WGSL interval filter, multiword shader implementation, magnitude-carry
fallback, GPU/backend execution, visual quality or performance claim.
No half packing, tone/display output, energy integration or ordinary moving
content was tested. Source quantization, transform/interpolation/filtering
and authored-to-represented error contracts remain unresolved. The selected
dot tests do not justify subnormal-input bit recovery under WGSL.

SHA-256 values for source, results, report and owner record are in
`SHA256SUMS`; input hashes and actual execution revision are in `results.json`.
Total retained tree size stays far below 1 MiB.
