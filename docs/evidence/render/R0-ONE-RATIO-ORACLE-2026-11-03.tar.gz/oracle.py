#!/usr/bin/env python3
"""Python >=3.11 stdlib only. Deterministic numerical research, not a shader."""
from collections import Counter
from decimal import Decimal as D, localcontext
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path
import platform
import random
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
PRECISION = 340
TOL = D('1e-260')
INPUTS = [
    'docs/design/research/R0-ARITHMETIC-ENVELOPE-2026-11-03.md',
    'docs/design/research/R0-ROBUST-GGX-EVALUATION-OPTIONS-2026-11-03.md',
    'docs/evidence/render/R0-GGX-NUMERIC-ORACLE-2026-11-03.md',
    'docs/evidence/render/R0-GGX-NUMERIC-ORACLE-2026-11-03.tar.gz',
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def show(x):
    return format(x, '.30g')


def pow2(k):
    return D(2) ** k


def pi():
    # Independent Gauss-Legendre construction; no binary64 pi constant.
    a, b, t, p = D(1), D(1) / D(2).sqrt(), D(1) / 4, D(1)
    for _ in range(12):
        an = (a + b) / 2
        b = (a * b).sqrt()
        t -= p * (a - an) ** 2
        a, p = an, 2 * p
    return (a + b) ** 2 / (4 * t)


def dot(v, w):
    return sum((x * y for x, y in zip(v, w)), D(0))


def normalize(v):
    length = dot(v, v).sqrt()
    assert length > 0
    return tuple(x / length for x in v)


def directions(ci, co, azimuth):
    # Unit n=(0,0,1), incident horizontal axis x; azimuth is +/-1 or 0.
    si, so = (1 - ci * ci).sqrt(), (1 - co * co).sqrt()
    wi = (si, D(0), ci)
    wo = (D(azimuth) * so, D(0) if azimuth else so, co)
    return wi, wo


def original(wi, wo, roughness, f0, pival):
    """Separate D, original correlated G2, original BRDF, then cosine."""
    ci, co = wi[2], wo[2]
    if ci <= 0 or co <= 0:
        return D(0)
    h = normalize(tuple(x + y for x, y in zip(wi, wo)))
    alpha = max(D('.045'), roughness) ** 2
    a = alpha ** 2
    ch, vh = h[2], dot(wo, h)
    distribution = a / (pival * (ch * ch * (a - 1) + 1) ** 2)
    # Lambda formulation deliberately differs from ratio candidate g(c).
    li = ((1 + a * (1 - ci * ci) / (ci * ci)).sqrt() - 1) / 2
    lo = ((1 + a * (1 - co * co) / (co * co)).sqrt() - 1) / 2
    geometry = 1 / (1 + li + lo)
    fresnel = f0 + (1 - f0) * (1 - vh) ** 5
    brdf = distribution * geometry * fresnel / (4 * ci * co)
    return brdf * ci


def one_ratio(wi, wo, roughness, f0, pival, mutant=False):
    ci, co = wi[2], wo[2]
    if ci <= 0 or co <= 0:
        return D(0), 'zero'
    v = tuple(x + y for x, y in zip(wi, wo))
    hm = max(abs(x) for x in v)
    assert hm > 0
    h = normalize(tuple(x / hm for x in v))
    alpha = max(D('.045'), roughness) ** 2
    a = alpha * alpha
    ch, vh = h[2], dot(wo, h)
    d = max(a, (1 - ch * ch) + a * ch * ch)
    distribution = a / (pival * d * d)
    gi = (a + (1 - a) * ci * ci).sqrt()
    go = (a + (1 - a) * co * co).sqrt()
    if ci >= co:
        q = co / ci
        denominator = go + q * gi
        k = D('.5') / max(alpha, denominator)
        branch = 'ci>=co'
    else:
        q = ci / co
        denominator = q * go + gi
        # Deliberate mutation: omitting q incorrectly brightens this branch.
        k = (D('.5') if mutant else D('.5') * q) / max(alpha, denominator)
        branch = 'ci<co'
    assert 0 < q <= 1 and denominator >= alpha * (1 - D('1e-250'))
    fresnel = f0 + (1 - f0) * (1 - vh) ** 5
    return distribution * fresnel * k, branch


def fixtures():
    rows = []
    def add(name, ci, co, az=-1, r='.32', f='.04'):
        rows.append((name, D(ci), D(co), az, D(r), D(f)))
    add('normal', 1, 1)
    for r in ('.045', '.32', '.5', '1'):
        add('normal-r' + r, 1, 1, 1, r)
    for r, name in ((D('.02'), 'below-material-floor'),
                    (D('.045') - pow2(-24), 'below-material-floor-neighbour'),
                    (D('.045') + pow2(-24), 'above-material-floor-neighbour'),
                    (D('0.319999992847442626953125'), 'f32-below-.32'),
                    (D('0.3200000226497650146484375'), 'f32-above-.32')):
        add('roughness-' + name, 1, 1, 1, r)
    for k in (1, 4, 8, 12, 16, 32, 64, 126, 149, 200):
        t = pow2(-k)
        add('sharp-' + str(k), t, t * t)
        add('sharp-reversed-' + str(k), t * t, t)
        add('grazing-equal-' + str(k), t, t)
    for center, name in ((pow2(-16), 'former-s'), (pow2(-126), 'f32-minnormal'),
                         (pow2(-149), 'f32-minsubnormal')):
        for delta in (-1, 0, 1):
            x = center * (1 + D(delta) * pow2(-24))
            add(name + '-' + str(delta), x, x * x)
            add(name + '-reversed-' + str(delta), x * x, x)
    # Exact equality and immediate decimal neighbours exercise branch choice.
    for delta in (-1, 0, 1):
        add('branch-boundary-' + str(delta), '.5', D('.5') + D(delta) * pow2(-80))
    for co, name in ((0, 'zero'), (-pow2(-140), 'negative')):
        add('hemisphere-' + name, '.5', co)
    add('exact-opposed-tangent-zero', 0, 0)
    add('negative-incident', -pow2(-140), '.5')
    rng = random.Random(0x52304F4E45524154)
    for i in range(1200):
        ci = D(rng.randint(1, 2 ** 20)) / (2 ** 20)
        co = D(rng.randint(1, 2 ** 20)) / (2 ** 20)
        if i % 3 == 0:
            ci *= pow2(-rng.randint(1, 200))
        if i % 5 == 0:
            co *= pow2(-rng.randint(1, 200))
        add('seeded-' + str(i), ci, co, (-1, 0, 1)[i % 3],
            ('.045', '.32', '.5', '1')[i % 4], ('0', '.04', '.5', '1')[i % 4])
    return rows


def f32_fraction(bits):
    sign = -1 if bits >> 31 else 1
    exponent = (bits >> 23) & 255
    mantissa = bits & 0x7fffff
    assert exponent != 255
    if exponent == 0:
        return sign * Q(mantissa, 2 ** 149)
    mantissa += 2 ** 23
    shift = exponent - 150
    return sign * (Q(mantissa << shift) if shift >= 0 else Q(mantissa, 2 ** -shift))


def lattice_integer(bits):
    # For every finite f32, x = this integer * 2^-149; no float operation.
    sign = -1 if bits >> 31 else 1
    exponent, mantissa = (bits >> 23) & 255, bits & 0x7fffff
    assert exponent != 255
    return sign * (mantissa if exponent == 0 else (mantissa + 2 ** 23) << (exponent - 1))


def exact_dot_bits(v, w):
    numerator = sum(lattice_integer(x) * lattice_integer(y) for x, y in zip(v, w))
    independent = sum((f32_fraction(x) * f32_fraction(y) for x, y in zip(v, w)), Q(0))
    assert Q(numerator, 2 ** 298) == independent
    return numerator


def sign(x):
    return (x > 0) - (x < 0)


def nearest_f32_bits(x):
    """Exact nearest-ties-even Fraction narrowing, bounded here by |x| <= 1."""
    if x < 0:
        return nearest_f32_bits(-x) | 0x80000000
    assert x <= 1
    lo, hi = 0, 0x3f800000
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if f32_fraction(mid) <= x:
            lo = mid
        else:
            hi = mid - 1
    if f32_fraction(lo) == x:
        return lo
    upper = lo + 1
    dl, du = x - f32_fraction(lo), f32_fraction(upper) - x
    return lo if dl < du or (dl == du and lo % 2 == 0) else upper


def dot_diagnostics():
    # Input operands are all normal-or-zero binary32 in [-1,1].
    m = 1 << 23
    cancellation_v, cancellation_w = [m + 1, m, 0], [m + 1, 0x80000000 | (m + 2), 0]
    cases = [
        ('cancellation-2^-298', cancellation_v, cancellation_w, 1),
        ('cancellation-negative-2^-298', cancellation_v, [x ^ 0x80000000 for x in cancellation_w], -1),
        ('exact-zero', [0x3f000000, 0x3f000000, 0], [0x3f000000, 0xbf000000, 0], 0),
        ('three-positive-units', [0x3f800000] * 3, [0x3f800000] * 3, 1),
        ('normal-product-subnormal', [0x00800000, 0, 0], [0x3f000000, 0, 0], 1),
    ]
    output = []
    for name, v, w, expected in cases:
        numerator = exact_dot_bits(v, w)
        assert sign(numerator) == expected
        assert all((b & 0x7fffffff) == 0 or 1 <= ((b >> 23) & 255) <= 127 for b in v + w)
        output.append({'name': name, 'v_bits': [f'{b:08x}' for b in v],
                       'w_bits': [f'{b:08x}' for b in w], 'dot_lattice_numerator': str(numerator),
                       'dot_lattice_exponent': -298, 'sign': sign(numerator)})
    assert exact_dot_bits(cancellation_v, cancellation_w) == 1
    # Independent exhaustive exponent boundary list + deterministic raw-bit samples.
    rng = random.Random(0xD07D1AD1C)
    max_signed_bits = 0
    samples = []
    for i in range(4000):
        def component():
            exponent = (1, 2, 63, 126, 127)[i % 5] if i < 100 else rng.randint(1, 127)
            fraction = 0 if exponent == 127 else rng.randrange(2 ** 23)
            return (rng.randrange(2) << 31) | (exponent << 23) | fraction
        v, w = [component() for _ in range(3)], [component() for _ in range(3)]
        num = exact_dot_bits(v, w)
        max_signed_bits = max(max_signed_bits, abs(num).bit_length() + 1)
        samples.append(sign(num))
    # Authored rational vectors have opposite real dot signs and identical f32 bits.
    n, tangent, eps = [Q(3, 5), Q(0), Q(4, 5)], [Q(4, 5), Q(0), -Q(3, 5)], Q(1, 2 ** 140)
    authored = [[t + direction * eps * a for t, a in zip(tangent, n)] for direction in (-1, 1)]
    authored_signs = [sign(sum((a * b for a, b in zip(n, v)), Q(0))) for v in authored]
    narrowed = [[nearest_f32_bits(x) for x in v] for v in authored]
    assert authored_signs == [-1, 1] and narrowed[0] == narrowed[1]
    # Exact normalized-real narrowing certificate: 1 <= sqrt(1+eps^2)
    # <= 1+eps^2/2. Each coordinate lies between x and x/(1+eps^2/2).
    # Monotonic rounding maps both rational endpoints to the same bits.
    norm_upper = 1 + eps * eps / 2
    for v, bits in zip(authored, narrowed):
        assert sum((x * x for x in v), Q(0)) == 1 + eps * eps
        for x, expected_bits in zip(v, bits):
            endpoints = sorted((x, x / norm_upper))
            assert [nearest_f32_bits(y) for y in endpoints] == [expected_bits] * 2
    # Fresh high precision normalization of the authored pair: true norm is
    # sqrt(1+eps^2), positive and identical for both. Re-narrow exactly from
    # the saved Decimal value, avoiding Decimal->binary64 double rounding.
    with localcontext() as c:
        c.prec = 420
        normalized = []
        for v in authored:
            decimal_v = [D(x.numerator) / D(x.denominator) for x in v]
            normalized.append(normalize(decimal_v))
        normalized_bits = [[nearest_f32_bits(Q(x)) for x in v] for v in normalized]
        assert normalized_bits == narrowed
    represented_n = [nearest_f32_bits(x) for x in n]
    represented_sign = sign(exact_dot_bits(represented_n, narrowed[0]))
    # Sampled FTZ ambiguity model: flush each product below f32 minnormal.
    exact = Q(1, 2 ** 127)
    ftz = Q(0) if abs(exact) < Q(1, 2 ** 126) else exact
    assert exact > 0 and ftz == 0
    # 256 signed bits cannot hold the shared 2^-298 lattice over this domain.
    unit_num = exact_dot_bits([0x3f800000, 0, 0], [0x3f800000, 0, 0])
    wrapped = unit_num % (2 ** 256)
    assert unit_num > 0 and wrapped == 0
    assert (3 * 2 ** 298).bit_length() + 1 == 301
    return {'fixed_cases': output, 'random_normal_or_zero_cases': len(samples),
            'random_sign_counts': dict(Counter(map(str, samples))),
            'sample_max_signed_bits': max_signed_bits,
            'domain_sufficient_signed_bits': 301,
            'source_real_information_loss': {'authored_signs': authored_signs,
                'normal_bits': [f'{b:08x}' for b in represented_n],
                'same_direction_bits': [f'{b:08x}' for b in narrowed[0]],
                'normalized_real_narrowing_exact_rational_interval_certified': True,
                'positive_norm_normalization_420_digit_same_bits': True,
                'represented_exact_dot_sign': represented_sign,
                'construction': 'n=(3/5,0,4/5); tangent=(4/5,0,-3/5); wi=normalize(tangent +/- 2^-140*n). Authored true dot signs are +/- because common normalization sqrt(1+2^-280) is positive; 420-digit normalized reconstructions narrow to the same bits.'},
            'selected_ftz_ambiguity': {'operands': '2^-126 * 0.5, other terms zero',
                'exact_dot': '2^-127', 'product_ftz_dot': '0',
                'scope': 'Explicit selected product-FTZ model only; no universal WGSL filter or emulator.'},
            'allocated_precision_mutant': {'signed_bits': 256, 'input': 'dot((1,0,0),(1,0,0))',
                'true_sign': 1, 'wrapped_lattice_sign': 0, 'caught': True}}


def run():
    start = time.perf_counter()
    with localcontext() as ctx:
        ctx.prec = PRECISION
        pival, counts, worst, selected = pi(), Counter(), D(0), []
        rows = fixtures()
        for name, ci, co, az, r, f0 in rows:
            wi, wo = directions(ci, co, az)
            reference = original(wi, wo, r, f0, pival)
            candidate, branch = one_ratio(wi, wo, r, f0, pival)
            error = abs(candidate - reference) / max(D(1), abs(reference))
            assert error < TOL, (name, error)
            worst = max(worst, error)
            counts[branch] += 1
            if not name.startswith('seeded-'):
                selected.append({'name': name, 'ci': show(ci), 'co': show(co), 'azimuth': az,
                    'roughness': str(r), 'F0': str(f0), 'branch': branch,
                    'original_L_per_E': show(reference), 'candidate_L_per_E': show(candidate),
                    'unit_scaled_error': show(error)})
        # Original and candidate reconstructed at higher precision, including directions/pi.
        crosscheck = []
        for k in (12, 126, 200):
            low_t = pow2(-k)
            low_wi, low_wo = directions(low_t, low_t ** 2, -1)
            low = original(low_wi, low_wo, D('.32'), D('.04'), pival)
            with localcontext() as high:
                high.prec = 420
                t = pow2(-k)
                wi, wo = directions(t, t * t, -1)
                ref = original(wi, wo, D('.32'), D('.04'), pi())
                candidate, _ = one_ratio(wi, wo, D('.32'), D('.04'), pi())
                error = abs(candidate - ref) / max(D(1), abs(ref))
                delta = abs(ref - low) / max(D(1), abs(ref))
                assert error < D('1e-300') and delta < TOL
                crosscheck.append({'sharp_power': k, 'higher_precision': 420,
                    'reconstructed_geometry_and_pi': True, 'higher_precision_unit_scaled_error': show(error),
                    'reference_change': show(delta)})
        wi, wo = directions(D('.01'), D('.5'), -1)
        reference = original(wi, wo, D('.32'), D('.04'), pival)
        mutated, _ = one_ratio(wi, wo, D('.32'), D('.04'), pival, mutant=True)
        assert abs(mutated - reference) / reference > 40
        result = {'schema': 1, 'python_version': platform.python_version(),
            'source_revision_at_execution': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'source_sha256': digest(Path(__file__)),
            'input_sha256': {p: digest(ROOT / p) for p in INPUTS},
            'decimal_precision': PRECISION, 'unit_scaled_tolerance': str(TOL),
            'fixtures_total': len(rows), 'branch_counts': dict(counts),
            'max_unit_scaled_error': show(worst), 'selected_fixtures': selected,
            'reconstruction_crosscheck': crosscheck,
            'wrong_one_ratio_mutant': {'fault': 'omit q from ci<co branch numerator',
                'ci': '.01', 'co': '.5', 'reference': show(reference), 'mutated': show(mutated),
                'relative_error': show(abs(mutated - reference) / reference), 'caught': True},
            'represented_dot': dot_diagnostics(),
            'limits': ['Finite deterministic numerical samples do not prove all-input equivalence; the algebraic derivation remains separate.',
                'Decimal implements a CPU real-number approximation; no f32 one-ratio evaluator, WGSL, source certificate, shader, visual or performance qualification.',
                'Exact integer/Fraction dot signs refer to represented operand bits only, not authored values before narrowing.',
                'All predicate random inputs are normal-or-zero f32 components in [-1,1], not assumed unit geometric vectors.',
                'Authored rational tangent perturbations and their 420-digit normalized reconstructions demonstrate sign information loss; no source-error contract is supplied.',
                'No sound WGSL interval filter, multiword u32 carry implementation, or magnitude-carry shader path is supplied.',
                'Selected product FTZ is a diagnostic example; it does not enumerate WGSL reassociation/fusion/FTZ behavior.',
                'No half packing, tone/display, energy integration, visual review, backend or actual device execution.']}
        (HERE / 'results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    summary = {'assertions': 'passed', 'fixtures': len(rows), 'results_sha256': digest(HERE / 'results.json'),
               'source_sha256': digest(Path(__file__)), 'wall_seconds': round(time.perf_counter() - start, 6),
               'runtime_scope': 'whole CPU numerical workflow only; no shader-cost claim'}
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == '__main__':
    run()
