# Ownership

Owner: `/root/r0_one_ratio_oracle`, commissioned by `/root`, 2026-11-03.
Purpose: independent stdlib high-precision one-ratio Smith and exact represented-f32
dot-sign numerical experiment. Only this directory is owned/written.
Expected peak and retained size: below 1 MiB (no dependency/build cache).
Inputs: the two R0 arithmetic/robust-evaluation research notes and prior selected
GGX numeric oracle evidence/archive; hashes are recorded by `oracle.py`.
Retained candidates: source, deterministic JSON, report and hash manifest.
Expiry: parent review and evidence selection; parent owns promotion/closeout.
No network, dependency installation, WGSL, GPU, visual or performance work.
