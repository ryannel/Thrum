//! Metal strict-event diagnostic: ordered writes/copies of one tracked texture
//! while old and resized submissions are genuinely GPU-incomplete.

use objc2::{rc::Retained, runtime::ProtocolObject};
use objc2_metal::{MTLDevice, MTLSharedEvent};
use std::{error::Error, sync::mpsc, time::Duration};

use wgpu::{
    Backends, Buffer, BufferDescriptor, BufferUsages, CommandEncoderDescriptor, Device,
    DeviceDescriptor, Extent3d, Instance, InstanceDescriptor, LoadOp, MapMode, Operations,
    PollType, PowerPreference, RenderPassColorAttachment, RenderPassDescriptor,
    RequestAdapterOptions, StoreOp, TexelCopyBufferInfo, TexelCopyBufferLayout,
    TexelCopyTextureInfo, Texture, TextureAspect, TextureDescriptor, TextureDimension,
    TextureFormat, TextureUsages,
};

const HD: (u32, u32) = (1280, 720);
const FHD: (u32, u32) = (1920, 1080);

// The native command buffers use unretained event references. This owner
// signals on failure, then keeps every submitted event alive until its tail
// marker has fired. A stalled/lost submission retains leaked references for
// this short-lived diagnostic process rather than freeing live GPU inputs.
struct GateGuard {
    gate: Retained<ProtocolObject<dyn MTLSharedEvent>>,
    tails: Vec<Retained<ProtocolObject<dyn MTLSharedEvent>>>,
    submitted: usize,
}

impl Drop for GateGuard {
    fn drop(&mut self) {
        self.gate.setSignaledValue(1);
        let complete = self
            .tails
            .iter()
            .take(self.submitted)
            .all(|event| event.waitUntilSignaledValue_timeoutMS(1, 10_000));
        if !complete {
            std::mem::forget(self.gate.clone());
            for event in &self.tails {
                std::mem::forget(event.clone());
            }
        }
    }
}

fn texture(device: &Device, label: &'static str, extent: (u32, u32)) -> Texture {
    device.create_texture(&TextureDescriptor {
        label: Some(label),
        size: Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format: TextureFormat::Rgba8Unorm,
        usage: TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC,
        view_formats: &[],
    })
}

fn readback(device: &Device, label: &'static str, extent: (u32, u32)) -> Buffer {
    device.create_buffer(&BufferDescriptor {
        label: Some(label),
        size: u64::from(extent.0) * u64::from(extent.1) * 4,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    })
}

fn encode(
    device: &Device,
    scratch: &Texture,
    output: &Buffer,
    extent: (u32, u32),
    color: wgpu::Color,
) -> wgpu::CommandBuffer {
    let mut encoder = device.create_command_encoder(&CommandEncoderDescriptor::default());
    let view = scratch.create_view(&wgpu::TextureViewDescriptor::default());
    {
        let _pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("tagged scratch clear"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &view,
                depth_slice: None,
                resolve_target: None,
                ops: Operations {
                    load: LoadOp::Clear(color),
                    store: StoreOp::Store,
                },
            })],
            depth_stencil_attachment: None,
            ..Default::default()
        });
    }
    encoder.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: scratch,
            mip_level: 0,
            origin: wgpu::Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: output,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(extent.0 * 4),
                rows_per_image: Some(extent.1),
            },
        },
        Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
    );
    encoder.finish()
}

fn verify(
    device: &Device,
    buffer: &Buffer,
    extent: (u32, u32),
    expected: [u8; 4],
) -> Result<(), Box<dyn Error>> {
    let (tx, rx) = mpsc::channel();
    buffer.slice(..).map_async(MapMode::Read, move |result| {
        let _ = tx.send(result);
    });
    device.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(10)),
    })?;
    rx.recv_timeout(Duration::from_secs(2))??;
    let mapped = buffer.slice(..).get_mapped_range()?;
    let data = mapped.as_ref();
    let expected_len = usize::try_from(extent.0)? * usize::try_from(extent.1)? * 4;
    assert_eq!(data.len(), expected_len);
    for (index, pixel) in data.chunks_exact(4).enumerate() {
        assert_eq!(pixel, expected, "pixel {index}");
    }
    drop(mapped);
    buffer.unmap();
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut descriptor = InstanceDescriptor::new_without_display_handle();
    descriptor.backends = Backends::METAL;
    let instance = Instance::new(descriptor);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let info = adapter.get_info();
    let (device, queue) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    println!(
        "adapter={} backend={:?} driver={} device_max_2d={}",
        info.name,
        info.backend,
        info.driver,
        device.limits().max_texture_dimension_2d
    );

    // Native handles are only used to stage diagnostic synchronization on
    // wgpu's owning Metal queue. All render/copy commands remain wgpu encoded.
    unsafe { queue.as_hal::<wgpu::hal::api::Metal>() }
        .ok_or("Metal queue unavailable")?
        .enable_strict_event_sync()?;
    let make_event = || -> Result<_, Box<dyn Error>> {
        let hal_device = unsafe { device.as_hal::<wgpu::hal::api::Metal>() }
            .ok_or("Metal device unavailable")?;
        Ok(hal_device
            .raw_device()
            .newSharedEvent()
            .ok_or("shared event unavailable")?)
    };
    let mut gate = GateGuard {
        gate: make_event()?,
        tails: Vec::new(),
        submitted: 0,
    };
    let done_a = make_event()?;
    let done_b = make_event()?;
    let done_c = make_event()?;
    gate.tails = vec![done_a.clone(), done_b.clone(), done_c.clone()];
    assert_eq!(gate.gate.signaledValue(), 0);

    let old = texture(&device, "one 720p scratch allocation", HD);
    let out_a = readback(&device, "A copy before overwrite", HD);
    let out_b = readback(&device, "B copy after overwrite", HD);
    let encoded_a = encode(&device, &old, &out_a, HD, wgpu::Color::RED);
    {
        let hal_queue =
            unsafe { queue.as_hal::<wgpu::hal::api::Metal>() }.ok_or("Metal queue unavailable")?;
        hal_queue.add_wait_event(gate.gate.clone(), 1);
        hal_queue.add_signal_event(done_a.clone(), 1);
    }
    gate.submitted = 1;
    let a = queue.submit([encoded_a]);
    let encoded_b = encode(&device, &old, &out_b, HD, wgpu::Color::BLUE);
    {
        let hal_queue =
            unsafe { queue.as_hal::<wgpu::hal::api::Metal>() }.ok_or("Metal queue unavailable")?;
        hal_queue.add_wait_event(gate.gate.clone(), 1);
        hal_queue.add_signal_event(done_b.clone(), 1);
    }
    gate.submitted = 2;
    let b = queue.submit([encoded_b]);

    // Resize uses a different allocation. Keep the old handle and both old
    // outputs alive until a queue completion API reports through B.
    let newer = texture(&device, "new 1080p scratch allocation", FHD);
    let out_c = readback(&device, "C resized copy", FHD);
    let encoded_c = encode(&device, &newer, &out_c, FHD, wgpu::Color::GREEN);
    {
        let hal_queue =
            unsafe { queue.as_hal::<wgpu::hal::api::Metal>() }.ok_or("Metal queue unavailable")?;
        hal_queue.add_wait_event(gate.gate.clone(), 1);
        hal_queue.add_signal_event(done_c.clone(), 1);
    }
    gate.submitted = 3;
    let c = queue.submit([encoded_c]);
    let blocked_a = device.poll(PollType::Wait {
        submission_index: Some(a.clone()),
        timeout: Some(Duration::from_millis(10)),
    });
    let blocked_b = device.poll(PollType::Wait {
        submission_index: Some(b.clone()),
        timeout: Some(Duration::from_millis(10)),
    });
    let blocked_c = device.poll(PollType::Wait {
        submission_index: Some(c.clone()),
        timeout: Some(Duration::from_millis(10)),
    });
    let held_gate = gate.gate.signaledValue();
    let held_done = (
        done_a.signaledValue(),
        done_b.signaledValue(),
        done_c.signaledValue(),
    );
    // Metal's command buffer uses unretained references to staged events;
    // keep the CPU's gate owner alive until every native tail completes.
    gate.gate.setSignaledValue(1);
    assert!(
        matches!(blocked_a, Err(wgpu::PollError::Timeout)),
        "A was {blocked_a:?}"
    );
    assert!(
        matches!(blocked_b, Err(wgpu::PollError::Timeout)),
        "B was {blocked_b:?}"
    );
    assert!(
        matches!(blocked_c, Err(wgpu::PollError::Timeout)),
        "C was {blocked_c:?}"
    );
    assert_eq!(held_gate, 0);
    assert_eq!(held_done, (0, 0, 0));
    let completed = device.poll(PollType::Wait {
        submission_index: Some(c),
        timeout: Some(Duration::from_secs(10)),
    })?;
    println!(
        "wgpu completion={completed:?}; native tail markers immediately after poll={:?}",
        (
            done_a.signaledValue(),
            done_b.signaledValue(),
            done_c.signaledValue()
        )
    );
    assert!(done_a.waitUntilSignaledValue_timeoutMS(1, 10_000));
    assert!(done_b.waitUntilSignaledValue_timeoutMS(1, 10_000));
    assert!(done_c.waitUntilSignaledValue_timeoutMS(1, 10_000));
    assert_eq!(
        (
            done_a.signaledValue(),
            done_b.signaledValue(),
            done_c.signaledValue()
        ),
        (1, 1, 1)
    );
    verify(&device, &out_a, HD, [255, 0, 0, 255])?;
    verify(&device, &out_b, HD, [0, 0, 255, 255])?;
    verify(&device, &out_c, FHD, [0, 255, 0, 255])?;
    drop(gate);
    println!(
        "submissions A={a:?} B={b:?}; A/B same texture, C new texture; native gate held all three incomplete, every RGBA pixel passed"
    );
    println!(
        "logical scratch bytes: old={} new={} overlap={}; readbacks separately={}",
        u64::from(HD.0) * u64::from(HD.1) * 4,
        u64::from(FHD.0) * u64::from(FHD.1) * 4,
        (u64::from(HD.0) * u64::from(HD.1) + u64::from(FHD.0) * u64::from(FHD.1)) * 4,
        (2 * u64::from(HD.0) * u64::from(HD.1) + u64::from(FHD.0) * u64::from(FHD.1)) * 4
    );
    drop(old);
    Ok(())
}
