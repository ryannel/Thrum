#!/usr/bin/env python3
"""Regenerate the four negative controls for the R0 embedded-ID probe."""

import json
import pathlib
import subprocess
import sys


def run(*argv: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(argv, capture_output=True, text=True, check=False)


def compact(path: pathlib.Path, record: dict) -> None:
    path.write_text(json.dumps(record, separators=(",", ":")), encoding="utf-8")


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 mutate.py PATH_TO_RELEASE_PROBE")
    probe = pathlib.Path(sys.argv[1]).resolve()
    base = pathlib.Path(__file__).resolve().parent
    input_one = base / "mutation_input_one"
    input_two = base / "mutation_input_two"
    for roots, folder in ((1, input_one), (2, input_two)):
        result = run(str(probe), "generate", str(folder), str(roots), "1000")
        if result.returncode:
            raise RuntimeError(result.stderr)

    outcomes = []
    for name, roots, source in (
        ("duplicate_within_root", 1, input_one),
        ("duplicate_across_roots", 2, input_two),
        ("wrong_camera_kind", 1, input_one),
        ("cross_root_camera", 2, input_two),
    ):
        records = [
            json.loads((source / f"render-{i}.json").read_text(encoding="utf-8"))
            for i in range(roots)
        ]
        first = records[0]["fields"]
        if name == "duplicate_within_root":
            first["local_lights"][0]["id"] = first["cameras"][0]["id"]
            expected = "ids.windows(2).all"
        elif name == "duplicate_across_roots":
            records[1]["fields"]["local_lights"][0]["id"] = first["local_lights"][0]["id"]
            expected = "ids.windows(2).all"
        elif name == "wrong_camera_kind":
            first["active_camera"] = first["meshes"][0]["id"]
            expected = "left: 2\n right: 1"
        else:
            first["active_camera"] = records[1]["fields"]["cameras"][0]["id"]
            expected = "left: 1\n right: 0"

        destination = base / f"mutation_{name}"
        destination.mkdir(exist_ok=True)
        for i, record in enumerate(records):
            compact(destination / f"render-{i}.json", record)
        result = run(str(probe), "measure", str(destination), str(roots), "no")
        matched = result.returncode == 101 and expected in result.stderr
        outcomes.append(
            {
                "name": name,
                "exit_code": result.returncode,
                "expected_stderr": expected,
                "matched": matched,
            }
        )
        if not matched:
            raise RuntimeError(f"{name} failed expectation:\n{result.stderr}")

    (base / "mutants.json").write_text(
        json.dumps(outcomes, indent=2) + "\n", encoding="utf-8"
    )
    print("four deterministic mutation controls matched expected failures")


if __name__ == "__main__":
    main()
