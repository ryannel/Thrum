# R0 embedded index microprobe reproduction

Use the repository's Rust 1.99.1 toolchain on macOS. The isolated Cargo
manifest pins the local serde_json and libc versions. Build offline:

```sh
CARGO_TARGET_DIR=tmp/r0-embedded-index/target RUSTC_WRAPPER= cargo build --offline --release --manifest-path tmp/r0-embedded-index/Cargo.toml
```

Generate a mixed root with 20% instances (two edges each) and 80% lights:

```sh
tmp/r0-embedded-index/target/release/r0-embedded-index-probe generate tmp/r0-embedded-index/fixtures_75k 2 75000
```

Generate four light-heavy roots (one active-camera edge per root):

```sh
tmp/r0-embedded-index/target/release/r0-embedded-index-probe generate-lights tmp/r0-embedded-index/fixtures_light_83k 4 83000
```

Measure in a fresh process for each repetition:

```sh
tmp/r0-embedded-index/target/release/r0-embedded-index-probe measure tmp/r0-embedded-index/fixtures_75k 2 no
tmp/r0-embedded-index/target/release/r0-embedded-index-probe measure tmp/r0-embedded-index/fixtures_light_83k 4 overlap
```

Recreate the four mutation inputs and their expected-failure report from the
same compiled probe. The script generates its own one- and two-root,
1,000-entry base records, makes exactly one JSON field edit per mutant, and
requires the expected nonzero assertion for duplicate IDs, wrong camera kind
or cross-root camera ownership:

```sh
python3 tmp/r0-embedded-index/mutate.py tmp/r0-embedded-index/target/release/r0-embedded-index-probe
cat tmp/r0-embedded-index/mutants.json
```

The archive includes `mutate.py` and its deterministic `mutants.json`. The
mutated JSON files are regenerated in scratch, so no process-specific panic
thread IDs or large duplicate source files are needed in the archive.

`overlap` retains an old sorted identity index while re-reading, parsing and
resolving the same fixture for the new index. It does not retain source-store
bytes or a decoded old JSON tree. `maxrss_bytes` is Darwin `getrusage`
`ru_maxrss`. JSON parsing uses `serde_json::Value`, then extracts IDs and
edges into 24-byte compact structs. This is a generic parse cost comparator,
not a production strict typed decoder or complete F3 admission.

Every mixed root has `13×N+66` JSON value nodes; every light-only root has
`12×N+66`. Python's independent JSON traversal checked 975,066 nodes and
11,985,709 bytes for `N=75,000` mixed, and 996,066 nodes and 12,201,710
bytes for `N=83,000` light-only. Both are below the current 1,000,000-node
and 16-MiB per-record bounds. The two-root mixed case has 60,002 typed
edges, below the existing 65,536 edge allowance. Four light-only roots have
four edges. The fixture is only a set of render records, not a complete
project, and its many lights exceed the first R0 recipe's four-light limit.
