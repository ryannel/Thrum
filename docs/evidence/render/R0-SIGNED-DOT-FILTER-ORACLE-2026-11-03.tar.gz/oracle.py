#!/usr/bin/env python3
"""Independent exact-rational finite-operation filter oracle. Python 3.11 stdlib."""
from __future__ import annotations

import hashlib
import itertools
import json
from collections import Counter
from fractions import Fraction as Q
from functools import lru_cache
from pathlib import Path
import platform
import random
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
N = Q(1, 2**126)
T = Q(1, 2**20)
E = 9 * Q(1, 2**24) + 5 * N
SEED = 0x523046494C544552


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rational(q):
    return f"{q.numerator}/{q.denominator}"


@lru_cache(maxsize=None)
def decode(bits):
    """Exact binary32 decoding, independent of host float arithmetic."""
    exp = (bits >> 23) & 255
    mant = bits & 0x7fffff
    assert exp != 255
    if exp:
        mant += 1 << 23
        power = exp - 150
    else:
        power = -149
    value = Q(mant * 2**power) if power >= 0 else Q(mant, 2**(-power))
    return -value if bits >> 31 else value


def adjacent(q):
    """Exact lower/upper binary32 neighbors (same value when representable)."""
    if q < 0:
        lo, hi = adjacent(-q)
        return -hi, -lo
    if not q:
        return Q(0), Q(0)
    assert q <= 3
    if q < N:
        scaled = q * 2**149
        floor_bits = scaled.numerator // scaled.denominator
    else:
        exponent = q.numerator.bit_length() - q.denominator.bit_length()
        p2 = Q(2**exponent) if exponent >= 0 else Q(1, 2**(-exponent))
        if q < p2:
            exponent -= 1
        scaled = q * (Q(2**(23-exponent)) if exponent <= 23 else Q(1, 2**(exponent-23)))
        sig = scaled.numerator // scaled.denominator
        floor_bits = ((exponent + 127) << 23) + sig - 2**23
    lo = decode(floor_bits)
    hi = lo if lo == q else decode(floor_bits + 1)
    assert lo <= q <= hi
    return lo, hi


def choices(q, bound, error):
    """Four labeled choices: down/up, each with and without output FTZ."""
    assert abs(q) <= bound
    lo, hi = adjacent(q)
    out = Counter()
    for value in (lo, hi):
        for flush in (False, True):
            result = Q(0) if flush and 0 < abs(value) < N else value
            assert abs(result) <= bound
            assert abs(result - q) <= error + N
            out[result] += 1
    assert sum(out.values()) == 4
    return out


def node_sum(a, b, bound, error):
    out = Counter()
    for av, ac in a.items():
        for bv, bc in b.items():
            for value, count in choices(av + bv, bound, error).items():
                out[value] += ac * bc * count
    return out


def normal(bits):
    return (bits & 0x7fffffff) == 0 or 1 <= ((bits >> 23) & 255) <= 127


def integer_dot(case):
    """Second exact-D route: signed integer operands on the 2^-149 lattice."""
    def lattice(bits):
        exp = (bits >> 23) & 255
        sig = bits & 0x7fffff
        value = sig if exp == 0 else (sig + 2**23) << (exp-1)
        return -value if bits & 0x80000000 else value
    total = sum(lattice(u)*lattice(v) for u, v in zip(case["x"], case["y"]))
    return Q(total, 2**298)


def fixture(name, x, y):
    assert all(normal(b) and abs(decode(b)) <= 1 for b in (*x, *y))
    return {"name": name, "x": list(x), "y": list(y)}


def fixtures():
    one, half, zero, tiny = 0x3f800000, 0x3f000000, 0, 0x00800000
    a, b = 0x3f7ffffe, 0x3f7ffffc  # 1-2^-23, 1-2^-22
    p47 = (127 - 47) << 23
    focused = [
        fixture("tiny_positive_opposite_sign", (a, one | 0x80000000, one | 0x80000000), (a, b, p47)),
        fixture("cancellation_positive_2^-298", (tiny+1, tiny, zero), (tiny+1, (tiny+2)|0x80000000, zero)),
        fixture("cancellation_negative_2^-298", (tiny+1, tiny, zero), ((tiny+1)|0x80000000, tiny+2, zero)),
        fixture("exact_zero_large", (one, one, zero), (one, one|0x80000000, zero)),
        fixture("exact_zero_rounding", (a, one|0x80000000, one|0x80000000), (a, b, (127-46)<<23)),
        fixture("all_zero", (zero, zero, zero), (one, half, tiny)),
        fixture("underflow_product_2^-127", (tiny, zero, zero), (half, zero, zero)),
        fixture("underflow_product_2^-252", (tiny, zero, zero), (tiny, zero, zero)),
        fixture("minsubnormal_product", (tiny, zero, zero), ((127-23)<<23, zero, zero)),
        fixture("minnormal_product", (tiny, zero, zero), (one, zero, zero)),
        fixture("endpoint_positive_three", (one, one, one), (one, one, one)),
        fixture("endpoint_negative_three", (one, one, one), (one|0x80000000, one|0x80000000, one|0x80000000)),
        fixture("sum_rounding_positive", (one, one, one), (one, (127-24)<<23, (127-24)<<23)),
        fixture("sum_rounding_negative", (one, one, one), (one|0x80000000, ((127-24)<<23)|0x80000000, ((127-24)<<23)|0x80000000)),
    ]
    threshold_bits = (127 - 20) << 23
    for delta in (-1, 0, 1):
        for sign in (0, 0x80000000):
            focused.append(fixture(f"threshold_{delta}_{sign>>31}", (one, zero, zero), ((threshold_bits+delta)|sign, zero, zero)))
    rng = random.Random(SEED)

    def bits():
        if rng.randrange(12) == 0:
            return 0
        exponent = rng.randrange(1, 127)
        return (rng.randrange(2)<<31) | (exponent<<23) | rng.getrandbits(23)

    sampled = []
    for i in range(256):
        if i % 4 == 0:
            x = (bits(), bits(), bits())
            y = (bits(), bits(), bits())
        elif i % 4 == 1:
            p = (126<<23) | rng.getrandbits(23)
            x = (one, one, one)
            y = (p, p|0x80000000, bits())
        elif i % 4 == 2:
            p = (126<<23) | rng.getrandbits(23)
            q = (126<<23) | rng.getrandbits(23)
            x = (p, p, one)
            y = (q, q|0x80000000, (threshold_bits+rng.randrange(-8, 9)) | (rng.randrange(2)<<31))
        else:
            x = tuple((126<<23) | rng.getrandbits(23) | (rng.randrange(2)<<31) for _ in range(3))
            y = tuple((126<<23) | rng.getrandbits(23) | (rng.randrange(2)<<31) for _ in range(3))
        sampled.append(fixture(f"seeded_{i:03d}", x, y))
    return focused, sampled


def evaluate(case):
    x, y = [tuple(map(decode, case[k])) for k in ("x", "y")]
    # Reference D is computed once directly from exact represented operands;
    # evaluated outputs below arise from explicit rounded expression trees.
    exact = sum((u*v for u, v in zip(x, y)), Q(0))
    assert exact == integer_dot(case)
    products = [choices(x[i]*y[i], 1, Q(1, 2**24)) for i in range(3)]
    out = Counter()
    for i, j, k in itertools.permutations(range(3)):
        left = node_sum(node_sum(products[i], products[j], 2, Q(1, 2**23)), products[k], 3, Q(1, 2**22))
        right = node_sum(products[i], node_sum(products[j], products[k], 2, Q(1, 2**23)), 3, Q(1, 2**22))
        out.update(left)
        out.update(right)
    assert sum(out.values()) == 12 * 4**5
    return exact, out


def fused(case):
    """Focused contractions: first-sum FMA, final-sum FMA, fully fused dot."""
    x, y = [tuple(map(decode, case[k])) for k in ("x", "y")]
    p = [x[i]*y[i] for i in range(3)]
    rounded = [choices(v, 1, Q(1, 2**24)) for v in p]
    out = Counter()
    for i, j, k in itertools.permutations(range(3)):
        # x[i]*y[i] + rounded(x[j]*y[j]) is one FMA node.
        inner = Counter()
        for value, count in rounded[j].items():
            for v, c in choices(p[i]+value, 2, Q(1, 2**23)).items():
                inner[v] += count*c
        out.update(node_sum(inner, rounded[k], 3, Q(1, 2**22)))
        # rounded(product i + product j) + x[k]*y[k] is final FMA.
        inner = node_sum(rounded[i], rounded[j], 2, Q(1, 2**23))
        for value, count in inner.items():
            for v, c in choices(value+p[k], 3, Q(1, 2**22)).items():
                out[v] += count*c
    out.update(choices(sum(p, Q(0)), 3, Q(1, 2**22)))
    assert sum(out.values()) == 12 * 4**4 + 4
    return out


def sign(q):
    return (q > 0) - (q < 0)


def main():
    started = time.monotonic()
    assert E < T
    assert decode(0x00800000) == N
    assert decode(1) == Q(1, 2**149)
    assert adjacent(Q(1, 2**150)) == (Q(0), Q(1, 2**149))
    assert adjacent(Q(1)+Q(1, 2**25)) == (Q(1), Q(1)+Q(1, 2**23))
    focus, sample = fixtures()
    all_cases = focus + sample
    totals = Counter()
    rows = []
    worst = (Q(0), None, None, None)
    mutants = []
    for case in all_cases:
        assert time.monotonic()-started < 110, "bounded runtime exceeded"
        exact, outputs = evaluate(case)
        totals["five_node_schedules"] += sum(outputs.values())
        totals["five_node_distinct_outputs_sum"] += len(outputs)
        for computed, multiplicity in outputs.items():
            error = abs(computed-exact)
            assert error <= E, (case["name"], exact, computed)
            if error > worst[0]:
                worst = (error, case["name"], exact, computed)
            admitted = abs(computed) > T
            if admitted:
                assert sign(computed) == sign(exact)
                totals["admitted_schedules"] += multiplicity
            else:
                totals["uncertain_schedules"] += multiplicity
            if abs(computed) == T:
                assert not admitted
                totals["strict_boundary_uncertain_schedules"] += multiplicity
            if sign(computed) != sign(exact):
                totals["nonmatching_sign_schedules_including_zero"] += multiplicity
            if abs(computed) > Q(1, 2**48) and sign(computed) != sign(exact):
                mutants.append({"fixture": case["name"], "exact": rational(exact), "computed": rational(computed)})
        payload = [[rational(k), v] for k, v in sorted(outputs.items())]
        rows.append({**case, "x": [f"{b:08x}" for b in case["x"]], "y": [f"{b:08x}" for b in case["y"]], "exact": rational(exact), "output_min": rational(min(outputs)), "output_max": rational(max(outputs)), "distinct_outputs": len(outputs), "output_distribution_sha256": hashlib.sha256(json.dumps(payload, separators=(",", ":")).encode()).hexdigest()})
    assert mutants, "wrong threshold mutant escaped"
    # Required adversarial witness and exact-reference anchors.
    d, vals = evaluate(focus[0])
    assert d == Q(1, 2**47) and -Q(1, 2**47) in vals
    assert evaluate(focus[1])[0] == Q(1, 2**298)
    assert evaluate(focus[2])[0] == -Q(1, 2**298)
    assert evaluate(focus[3])[0] == 0
    assert evaluate(focus[4])[0] == 0 and any(evaluate(focus[4])[1])
    assert evaluate(focus[6])[0] == Q(1, 2**127) and Q(0) in evaluate(focus[6])[1]
    fused_rows = []
    for case in focus[:14]:
        exact = sum((decode(u)*decode(v) for u, v in zip(case["x"], case["y"])), Q(0))
        outputs = fused(case)
        for computed, count in outputs.items():
            assert abs(computed-exact) <= E
            if abs(computed) > T:
                assert sign(computed) == sign(exact)
                totals["fused_admitted_schedules"] += count
        totals["focused_fused_schedules"] += sum(outputs.values())
        fused_rows.append({"fixture": case["name"], "distinct_outputs": len(outputs)})
    inputs = ["AGENTS.md", "docs/ASSET-LIFECYCLE.md", "docs/design/research/R0-ROBUST-GGX-EVALUATION-OPTIONS-2026-11-03.md", "docs/evidence/render/R0-ONE-RATIO-ORACLE-2026-11-03.md", "docs/evidence/render/R0-ONE-RATIO-ORACLE-2026-11-03.tar.gz"]
    result = {
        "schema": 1, "python": platform.python_version(),
        "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "input_sha256": {p: sha(ROOT/p) for p in inputs}, "source_sha256": sha(Path(__file__)),
        "seed": SEED, "focused_fixtures": len(focus), "seeded_fixtures": len(sample),
        "bounds": {"E": rational(E), "threshold": rational(T), "strictly_less": E < T},
        "model": "all 6 permutations times both associations; 3 products + 2 sums; each node directed down/up then optional output FTZ; equal numeric states merged with schedule multiplicity; signed zero merged",
        "schedule_cap_per_fixture": 12*4**5,
        "counts": dict(sorted(totals.items())),
        "worst_observed_error": {"value": rational(worst[0]), "fixture": worst[1], "exact": rational(worst[2]), "computed": rational(worst[3])},
        "mutant": {"wrong_threshold": rational(Q(1, 2**48)), "rejected": True, "witness": mutants[0]},
        "focused_fusion": {"model": "6 orders each with first-sum FMA or final-sum FMA, plus one exact-dot rounding; directed adjacent rounding and optional FTZ at every effective node", "fixtures": fused_rows},
        "fixtures": rows,
        "limitations": ["Finite CPU operation model, not exhaustive operands or a proof over all f32 inputs", "No WGSL conformance/emulation, backend or shader expression qualification", "No source transform, interpolation, normal-map or input-quantization error included", "No subnormal input-bit recovery, fallback implementation, radiance ratio or magnitude guarantee", "No GPU, visual or device performance claim"],
    }
    (HERE/"results.json").write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    print(json.dumps({"elapsed_seconds": round(time.monotonic()-started, 6), "results_sha256": sha(HERE/"results.json"), "counts": result["counts"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
