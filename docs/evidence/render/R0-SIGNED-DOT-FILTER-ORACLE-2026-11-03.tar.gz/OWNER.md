# Owned scratch experiment

- Owner: delegated `r0_filter_oracle` agent for the current R0 research task.
- Purpose: independent exact-rational rejection oracle for the conditional represented-dot filter.
- Writable scope: only `tmp/r0-filter-oracle/`; no tracked edits.
- Inputs: robust-GGX research note, retained one-ratio evidence note/archive; no imported oracle code.
- Expected peak: below 1 MiB; Python 3.11 standard library only.
- Retained output: editable oracle, deterministic JSON, report, SHA-256 manifest, timing summary.
- Expiry: parent review and explicit promotion or ownership-scoped closeout.
- Claims: finite modeled CPU arithmetic only; no WGSL/backend, upstream source, GPU, visual or device claim.
