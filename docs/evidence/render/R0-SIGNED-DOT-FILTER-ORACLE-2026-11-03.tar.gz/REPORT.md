# Conditional represented-dot filter: independent bounded rejection oracle

3 November 2026. Scratch-only Python 3.11 standard-library experiment.
Execution revision: `b6b23d77661b17494ba0422a66be7f634e376e60`.
Only `tmp/r0-filter-oracle/` is owned and written by this commission.
Input-document and retained-archive hashes, source hash and exact fixture bits
are recorded in `results.json`. The retained one-ratio report was read for its
scope and witnesses; no previous oracle source was imported or executed.

Reproduce from the repository root:

```sh
python3.11 tmp/r0-filter-oracle/oracle.py > tmp/r0-filter-oracle/run-summary.json
```

Python version: 3.11.15. The selected run took approximately 0.55 seconds;
this is CPU workflow duration, with no shader-cost claim. A second execution
reproduced `results.json` byte-for-byte. Results have no timestamp or elapsed
time and are deterministic for the same source, Python version, revision and
input files. `run-summary.json` contains timing and varies on rerun. Direct
script execution creates no `__pycache__`; no bytecode files are retained.
The complete scratch tree remains below 1 MiB. `SHA256SUMS` covers source,
deterministic results, report and ownership record; timing is intentionally
excluded from that stable manifest.

## Exact reference and finite operation model

All six operands are finite represented binary32 normal-or-zero values in
`[-1,1]`; fixtures do not require unit geometric vectors. Input bits are
decoded directly into `Fraction` values without host-float arithmetic.
The exact reference `D` is the rational sum of three exact products of those
operands. It is independent of the rounded expression-tree evaluation.
A separately implemented signed integer decode on the `2^-149` operand
lattice independently checks that exact reference on every fixture; its
three-product result has scale `2^-298`.

Exact integer/rational calculations find the lower and upper adjacent f32
values for each node result. Exact representable results have identical
lower and upper values. For each node the model independently chooses
directed down or up rounding, then either preserves the rounded result or
flushes a subnormal output to zero. This is four labeled choices per node,
including duplicate numeric results. Signed zero is merged, because this
experiment tests sign and absolute error, not division or signed-zero
semantics. Subnormal intermediate outputs are supported; subnormal operand
inputs are outside the selected domain.

The main check exhausts all six product permutations and both binary-tree
associations of the two additions. There are five effective nodes, hence
`12*4^5 = 12,288` labeled schedules per fixture. Counter-based dynamic
evaluation merges equal intermediate numerical values **while preserving
their exact schedule multiplicities**; equal states are interchangeable at
their one parent. The operation choices are applied afresh at each parent.
This avoids a Cartesian enumeration of duplicate states without omitting
any schedule in this finite model. A child output FTZ represents an effective
flush on that single-use edge. Input flushing of already rounded subnormal
edge values is the same modeled numerical choice; there are no subnormal
original inputs here.

The script checks exact local endpoint and error bounds at every evaluated
node: products are bounded by one with error at most `2^-24+N`; first sums
are bounded by two with error at most `2^-23+N`; final sums are bounded by
three with error at most `2^-22+N`, where `N=2^-126`.
It then independently asserts `abs(d-D) <= E = 9*2^-24+5*N` on every final
state, exactly asserts `E < 2^-20`, and admits only `abs(d)>2^-20`.
Every admitted state must match the exact represented sign. Equality at the
threshold is explicitly uncertain. These finite checks challenge the
derivation; they do not constitute a proof over all binary32 operands.

## Results and rejection witnesses

| Check | Selected result |
| --- | ---: |
| Focused / deterministic seeded fixtures | 20 / 256 |
| Main five-node labeled schedules | 3,391,488 |
| Sum of distinct final numerical states per fixture | 1,266 |
| Main admitted schedules, all sign-correct | 1,272,832 |
| Main uncertain schedules | 2,118,656 |
| Schedules exactly on the strict threshold, all uncertain | 227,328 |
| Focused fused schedules over 14 fixtures | 43,064 |
| Fused admitted schedules, all sign-correct | 12,304 |

The seeded cases mix full exponent-range normal-or-zero values, exact
two-term cancellation with a third term, values near the filter threshold,
and ordinary large signed values. The seed and exact bits are retained.
The schedule counts are **not** millions of distinct operand fixtures or
millions of distinct numerical cases.

The largest main observed error is exactly
`70225741/281474976710656` (about `2.495e-7`), below E (about `5.364e-7`),
on `seeded_219`. All reference and computed values for that observation are
recorded in the JSON. Across main schedules, 403,664 have a computed sign
different from the exact sign when zero is counted as a distinct sign.
All of these remain uncertain under the proposed filter; this count is
not a count of nonzero sign reversals.

Selected exact anchors include:

- With `a=1-2^-23`, `b=1-2^-22`, `x=(a,-1,-1)` and
  `y=(a,b,2^-47)`, exact `D=+2^-47`. Rounding `a*a` down to b, then
  subtracting b and `2^-47`, produces `d=-2^-47`. Both results exist in
  the modeled set. A deliberate threshold mutant `2^-48` wrongly admits
  that result and is rejected by the sign assertion.
- The minimum-normal cancellation construction using operand bits
  `00800001`, `00800000`, `00800001`, `80800002` gives `D=2^-298`;
  negating the second vector gives `-2^-298`.
- Exact large cancellation and the nontrivial `a*a-b-2^-46=0` check exact
  zero; the latter also produces nonzero computed outcomes.
- Positive `2^-126 * 0.5 = 2^-127` can flush to zero. Cases also cover
  `2^-252`, minimum-subnormal and minimum-normal product outputs.
- Positive and negative threshold predecessor, equality and successor
  fixtures exercise strict admission, and `+/-3` checks endpoint sums.

The focused fusion supplement checks six permutations of a first-pair FMA,
six permutations of a final FMA, and one exact three-product sum with only
final rounding. Per fixture this is `12*4^4+4 = 3,076` schedules. Rounded
products and effective fused-node outputs use the same adjacent/FTZ choices.
These 43,064 schedules also satisfy E and the admitted-sign condition.
They supplement the main five-node model; this is not an exhaustive model
of all shader compiler contraction or expression transformation behavior.

## Scope limits

This experiment models exact adjacent f32 rounding and optional effective
node-output FTZ for the explicitly stated scalar expression trees, plus the
focused contraction cases. It does not implement the complete WGSL numeric
specification or establish a WGSL builtin/backend accuracy interpretation.
No shader expression, compiler, device or backend was exercised. There is
no GPU, visual or device-performance claim.

The reference D concerns already represented operand bits. No authored-real
sign or source-error guarantee follows. Transform, interpolation, normal-map
and input-quantization error are excluded; a separately proved upstream
error allowance would have to be added. The filter's uncertain outcomes
remain uncertain. No exact shader fallback, subnormal input-bit recovery,
positive magnitude preservation, radiance-ratio bound or one-ratio f32
evaluator is implemented or qualified by this experiment.
