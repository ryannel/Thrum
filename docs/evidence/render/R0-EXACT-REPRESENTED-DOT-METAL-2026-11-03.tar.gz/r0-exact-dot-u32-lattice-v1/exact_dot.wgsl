// Raw-u32 inputs only: x[3], y[3]. No floating operations or float bitcasts.
// Output: status, sign (0/1/2), floor exponent, trunc normalized f32 bits,
// discarded-nonzero, nearest-even exponent, nearest-even normalized f32 bits,
// ten little-endian magnitude limbs on the 2^-298 lattice.
@group(0) @binding(0) var<storage, read> inputs: array<u32>;
@group(0) @binding(1) var<storage, read_write> outputs: array<u32>;

fn valid(b: u32) -> bool {
    let a = b & 0x7fffffffu;
    return a == 0u || (a >= 0x00800000u && a <= 0x3f800000u);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let n = arrayLength(&inputs) / 6u;
    if id.x >= n { return; }
    let src = id.x * 6u;
    let dst = id.x * 17u;
    for (var j = 0u; j < 17u; j++) { outputs[dst+j] = 0u; }
    for (var j = 0u; j < 6u; j++) {
        if !valid(inputs[src+j]) { outputs[dst] = 1u; return; }
    }
    var positive: array<u32, 10>;
    var negative: array<u32, 10>;
    for (var k = 0u; k < 3u; k++) {
        let x = inputs[src+k];
        let y = inputs[src+k+3u];
        if (x & 0x7fffffffu) == 0u || (y & 0x7fffffffu) == 0u { continue; }
        let a = (x & 0x007fffffu) | 0x00800000u;
        let b = (y & 0x007fffffu) | 0x00800000u;
        // Exact 24x24 -> 48 multiplication using bounded 16/8-bit chunks.
        let q0 = (a & 65535u) * (b & 65535u);
        let q1 = (a >> 16u) * (b & 65535u) + (a & 65535u) * (b >> 16u);
        let lo = q0 + (q1 << 16u);
        let hi = (a >> 16u) * (b >> 16u) + (q1 >> 16u) + select(0u, 1u, lo < q0);
        let shift = ((x >> 23u) & 255u) + ((y >> 23u) & 255u) - 2u;
        let word = shift / 32u;
        let offset = shift % 32u;
        var term: array<u32, 10>;
        term[word] = lo << offset;
        if offset == 0u {
            term[word+1u] = hi;
        } else {
            term[word+1u] = (lo >> (32u-offset)) | (hi << offset);
            term[word+2u] = hi >> (32u-offset);
        }
        let neg = ((x ^ y) >> 31u) != 0u;
        var carry = 0u;
        for (var j = 0u; j < 10u; j++) {
            let old = select(positive[j], negative[j], neg);
            let s = old + term[j];
            let t = s + carry;
            carry = select(0u, 1u, s < old || t < s);
            if neg { negative[j] = t; } else { positive[j] = t; }
        }
    }
    var comparison = 0i;
    for (var j = 9i; j >= 0i; j--) {
        if positive[u32(j)] > negative[u32(j)] { comparison = 1i; break; }
        if positive[u32(j)] < negative[u32(j)] { comparison = -1i; break; }
    }
    if comparison == 0i { return; }
    outputs[dst+1u] = select(2u, 1u, comparison > 0i);
    var magnitude: array<u32, 10>;
    var borrow = 0u;
    for (var j = 0u; j < 10u; j++) {
        let a = select(negative[j], positive[j], comparison > 0i);
        let b = select(positive[j], negative[j], comparison > 0i);
        let s = a - b;
        let t = s - borrow;
        borrow = select(0u, 1u, a < b || s < borrow);
        magnitude[j] = t;
        outputs[dst+7u+j] = t;
    }
    var top = 0u;
    for (var j = 9i; j >= 0i; j--) {
        if magnitude[u32(j)] != 0u {
            top = u32(j)*32u + 31u - countLeadingZeros(magnitude[u32(j)]);
            break;
        }
    }
    var mantissa = 0u;
    var sticky = false;
    var round_bit = false;
    var below_round = false;
    // Extract top 24 bits, padding exactly on the right when top < 23.
    for (var j = 0u; j <= top; j++) {
        let bit = (magnitude[j/32u] >> (j%32u)) & 1u;
        if top-j < 24u {
            mantissa = mantissa | (bit << (23u-(top-j)));
        } else {
            sticky = sticky || bit != 0u;
            if top-j == 24u { round_bit = bit != 0u; }
            else { below_round = below_round || bit != 0u; }
        }
    }
    let exponent = i32(top)-298i;
    outputs[dst+2u] = bitcast<u32>(exponent);
    outputs[dst+3u] = 0x3f800000u | (mantissa & 0x007fffffu);
    outputs[dst+4u] = select(0u, 1u, sticky);
    var rounded = mantissa;
    var rounded_exponent = exponent;
    if round_bit && (below_round || (mantissa & 1u) != 0u) { rounded++; }
    if rounded == 0x01000000u { rounded >>= 1u; rounded_exponent++; }
    outputs[dst+5u] = bitcast<u32>(rounded_exponent);
    outputs[dst+6u] = 0x3f800000u | (rounded & 0x007fffffu);
}
