Owner: R0 exact-dot GPU commissioned worker.
Purpose: scratch-only integer WGSL represented-dot diagnostic; no engine integration.
Expected peak: 1.5 GiB with owned Cargo target; inputs/results under 80 MiB.
Inputs: raw binary32 bit patterns; exact normal-or-zero components in [-1,1].
Retained output: source, locked dependencies, deterministic fixtures/results, report and hashes.
Closeout: coordinator review and explicit retention/promotion decision. No other worker outputs are owned.
