# Raw-u32 exact represented-dot GPU diagnostic

3 November 2026. Review candidate `r0-exact-dot-u32-lattice-v1`; scratch only.
No engine, design, contract, maturity or build-plan files were changed by this worker.

The public wgpu Metal compute diagnostic matches an independent Python Fraction
oracle for **189,803 records, 189,792 distinct operand tuples**, including 66
invalid records. Each selected output contains 17 words: status, exact sign,
normalized exponent, truncated normalized mantissa bits, discarded-bit flag,
nearest-even exponent/mantissa bits, and all ten magnitude limbs. Three processes
matched **9,679,953 selected-readback words**, with ten byte-identical dispatch
outputs in each process. There were no mismatches. This is a bounded executable
diagnostic, not an engine fallback or portable shader qualification.

## Exact arithmetic and interface

Each input is six little-endian u32 words, `x[0..3], y[0..3]`. Their binary32
encodings must be signed zero or normal values in [-1,1]. The shader checks
absolute bits equal zero or in `[0x00800000,0x3f800000]` before decoding.
Subnormal, NaN, infinity and magnitude greater than one are rejected with status
1 and sixteen zero words. Accepted records have status 0. Both signs of zero
are accepted; an exact zero dot has sixteen zero result words.

For a nonzero admitted component with biased exponent E and 24-bit significand
S, its exact value is `(-1)^sign S 2^(E-150)`, with `1 <= E <= 127`.
Consequently, a product's unsigned integer on the `2^-298` lattice is
`Sx Sy << (Ex+Ey-2)`. The shift is 0..252. Products have magnitude at most one;
three positive or negative terms sum to at most three, requiring at most 300
magnitude bits. Ten u32 limbs provide 320 bits. The shader separately accumulates
positive and negative terms, compares them and subtracts the smaller from the
larger. The exact dot is `sign * A * 2^-298`, where A is the ten-limb result.

The 24x24 multiplication splits each operand into low 16 and high 8 bits.
`q0=alo*blo < 2^32`; `q1=ahi*blo+alo*bhi <= 33,422,850 < 2^25`.
The low-word sum wraps deliberately, and its overflow bit contributes to
`hi=ahi*bhi+(q1>>16)+carry < 2^16`. This yields the full 48-bit product.
The shifted product uses at most three adjacent limbs; their ORed pieces occupy
disjoint bit positions. The maximum limb index is nine. Offset-zero branches
avoid a shift by 32. Carry/borrow comparisons preserve exact modular limb
addition/subtraction; the domain bound prevents final accumulator overflow.
The final subtraction cannot underflow because the larger magnitude was selected.

For nonzero A, let B be its highest set-bit index and e=B-298. The truncated
mantissa is `floor((A/2^B)*2^23)/2^23` in [1,2), and sticky reports whether any
discarded bit is nonzero. The second mantissa uses the next bit, all lower bits
and the retained low bit to implement nearest-even rounding; an overflow to two
renormalizes to one and increments e. Small A is padded exactly to 24 bits.
The two mantissas are returned as ordinary normalized binary32 **bit patterns**,
with separate signed exponents encoded as u32 two's-complement bits.
The exact magnitude remains available in all ten limbs. The mantissa pairs alone
are rounded representations. No operation materializes `2^-298` as a GPU float.
The WGSL has no floating-point operations, no float inputs and no float bitcasts;
its two bitcasts reinterpret signed integer exponents only.

## Independent oracle and corpus

`oracle.py` decodes bits directly into Python Fraction values, multiplies and sums
fractions, and only then serializes the exact integer lattice magnitude. It does
not reproduce WGSL split multiplication, limb shifts, carry or borrow algorithms.
Normalization and nearest-even rounding use Fraction division and integer divmod.
`summarize.py` independently reads every selected output and raw timestamp record,
checks complete byte equality and checks exact named witness values.

The corpus includes:

- ±2^-298 cancellation from normal inputs `(M+1)^2-M(M+2)=1`, M=2^23;
- ±2^-127 products, all signed-zero pairs, exact cancellation, ±3 dot extremes,
  and the exact +2^-47 witness whose floating evaluation can have the wrong sign;
- both signed 2^-20 thresholds, their ±2^-298 exact neighbors, and adjacent f32 thresholds;
- all 127x127 admitted exponent pairs with four boundary significands, both
  three-term accumulation and exact cancellation plus a small product (129,032 entries);
- 16,129 long-borrow cases and 32,258 leading-power ± one-lattice-unit cases;
- nearest-even ties, values just above/below ties and rounded-exponent carry;
- 12,288 seeded independent/cancelling tuples;
- 66 invalid records: six operand positions crossed with 11 subnormal,
  out-of-range, infinity, quiet/signaling-NaN or maximum-finite encodings.

189,737 records are valid; 187,520 exact dots lie in the inclusive `|D|<=2^-20`
uncertainty band. Every valid record runs the exact path unconditionally.
This does not measure real fallback frequency or fast-path interaction.
Python 3.11.15 and Python 3.15.2 generated identical input and expected bytes.
The final corpus was extended after successful preliminary 157,545-record runs;
those preliminary runs are not counted in the final results. The initial
sandbox execution could not enumerate Metal; the authorized device-access retry
and all subsequent device runs succeeded.

## Execution, identities and isolated cost

Device: Apple M3 Max integrated GPU, Metal, macOS 26.6.2 build 25G83,
Darwin 25.6.0, aarch64. Public wgpu 30.0.1, Naga 30.0.1, pollster 1.0.1;
all direct requirements are exact and Cargo.lock pins the 84-package closure.
Direct dependencies use MIT OR Apache-2.0 licensing; dependency metadata is retained.
Rust 1.99.1 (`58cf8f9c35b355199727627d07ae34a4e2846d67`), LLVM 23.1.1,
Cargo 1.99.1 (`5f94df478`). The **execution revision** is
`8bf10ef4fe1c770e7cc2d7c0042639a6c8a9fe4e`: this names the repository HEAD
observed by the original execution-time shell capture before the final GPU runs.
The GPU logs do not themselves embed a Git revision. `EXECUTION-RECORD.json`
preserves that capture's revision and pins the executed host source, shader,
binary, inputs, lockfile and three raw logs by hash; it was added during provenance
review, rather than being represented as a contemporaneous GPU log.
The **packaging revision**, recorded explicitly as `packaging_revision` in
`PROVENANCE.json` and `PACKAGE.json`, names repository HEAD when that specific
archive was constructed. `package.py` reads that HEAD separately and preserves
the pinned execution revision. Both JSON records carry both explicit fields;
a packaging HEAD never relabels the GPU execution. A later packaging run after a
repository commit may change the packaging revision and archive hash without
changing the executed shader, binary, inputs, logs or numerical results.
Unrelated tracked changes at execution were `.github/workflows/ci.yml` and
`CONTRIBUTING.md`; they were preserved. The scratch crate is outside the engine
workspace, with no new engine dependency or crate registration.

Pinned Naga parsing/full validation, release build, rustfmt check and release
Clippy with `-D warnings` passed. Three sequential final GPU processes each ran
two warmups and eight measured dispatches. There were 2,966 workgroups of 64;
the final tail is guarded. Every dispatch's output was read and compared with
the process's first output; the CPU oracle checked each selected process output.

| Final process | GPU pass median | GPU measured range | CPU encode/submit/wait median |
| --- | ---: | ---: | ---: |
| 1 | 1.045021 ms | 0.873333–1.076750 ms | 1.430 ms |
| 2 | 0.885063 ms | 0.873625–1.064458 ms | 2.2245 ms |
| 3 | 1.024313 ms | 0.873167–1.096958 ms | 6.1515 ms |

All 30 raw timestamp pairs were positive and strictly ordered, at period 1 ns.
Compute completed before a separate query resolve submission, following the
existing Metal delayed-resolve diagnostic method. GPU values bracket the complete
compute pass, including its result writes, and exclude uploads, resolve, result
copy, map and CPU work. CPU values include encoder creation/encoding, submission
and completion wait, but exclude resolve/copy/readback/map. Large CPU variation
is retained; this is diagnostic timing, without controlled thermals/power,
hardware counters, register/spill measurements, sustained execution or A/A controls.
Module/pipeline creation CPU times in logs are process-local; driver caches were
not cleared, so these are not cold compilation measurements.

ABI payloads: 4,555,272 input bytes and 12,906,604 output bytes. Explicit retained
GPU buffers comprise input, output, a matching readback and two 16-byte query
buffers: 30,368,512 bytes total, excluding wgpu/driver staging and physical
residency. Source declares four ten-u32 private arrays (positive, negative,
shifted term, magnitude); compiler liveness, physical registers and spills are
unmeasured. Three ten-limb accumulation loops and up to 300 normalization-bit
iterations expose why ordinary-fragment cost needs a separate measurement.

## Reproduction

From this directory (cached registry packages are required for offline builds):

```sh
python3.11 oracle.py generate > generation-python311.json
RUSTC_WRAPPER= CARGO_TARGET_DIR=target rustup run 1.99.1 cargo build --release --locked --offline
rustup run 1.99.1 cargo fmt --check
RUSTC_WRAPPER= CARGO_TARGET_DIR=target rustup run 1.99.1 cargo clippy --release --locked --offline -- -D warnings
./target/release/r0-exact-dot-gpu inputs.bin gpu-1.bin > gpu-1.log 2>&1
./target/release/r0-exact-dot-gpu inputs.bin gpu-2.bin > gpu-2.log 2>&1
./target/release/r0-exact-dot-gpu inputs.bin gpu-3.bin > gpu-3.log 2>&1
python3.11 oracle.py compare gpu-1.bin
python3.11 oracle.py compare gpu-2.bin
python3.11 oracle.py compare gpu-3.bin
RUSTC_WRAPPER= rustup run 1.99.1 cargo metadata --offline --locked --format-version 1 > cargo-metadata.json
python3.11 summarize.py
```

The default sccache wrapper could not run inside the sandbox; `RUSTC_WRAPPER=`
selects the pinned compiler directly. Device execution requires local Metal access.
No network fetch was needed. The candidate archive retains source, lock, exact
input bytes, deterministic fixture metadata, complete compact results, logs,
dependency provenance and hash manifest. The three large raw outputs and
expected.bin remain in scratch; regenerate expected.bin with the oracle.

Input SHA-256:
`7879abe50693029e2b8c5fcd71a13b2be4fd6f779582a14a8b8545ca1107c596`.
Expected and all selected GPU output SHA-256:
`03a401f4be096a4d42ba1f662b5cf59891579e4cba9c83a3a6c7cbf0df22402b`.
WGSL SHA-256:
`139e0e8b58e5221fd3d1dc78d1230e9d57a22adef05ce3f4787425851cf8a231`.
The complete manifest pins the remaining source, binary and evidence bytes.
The provenance correction changed packaging/report files only. Oracle regeneration,
three full saved-output comparisons, summary regeneration and archive/manifest
verification were repeated without a new GPU dispatch; their deterministic
numerical outputs and original GPU logs remained byte-identical.

## Explicit limits

This establishes bounded exact represented-input compute agreement on one
device/backend and an explained integer construction. It does not prove every
possible tuple by exhaustive testing, independent formal verification or other
backend/compiler conformance. The raw-u32 input encoding is essential: there is
no float-to-u32 recovery test, no subnormal input support and no claim about
WGSL float bitcast FTZ safety. Supplying raw bits from a real fragment is an
unresolved integration boundary. No source-real sign/error certificate, scalar
filter implementation, shader fast path, positive ratio arithmetic, half-vector
normalization, Smith/GGX evaluation, half storage, moving-image quality, source
admission, ordinary fragment cost, fallback occupancy, five-light workload or
complete frame diagnostic/renderer is established. Normalization returns mantissa
bits and an exponent; it does not itself consume that magnitude in lighting.

The scratch result is ready for independent review and a separate promotion
decision. Owned build products and redundant readbacks are still present; no
cleanup, commit, push, publication or deployment was performed.
