#!/usr/bin/env python3
"""Independent Fraction reference; no WGSL limb multiplication/carry algorithm."""
import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import random
import struct

ROOT = Path(__file__).resolve().parent
MASK = (1 << 32) - 1

def decode(bits):
    sign = -1 if bits >> 31 else 1
    a = bits & 0x7fffffff
    if a == 0:
        return Fraction(0)
    if not 0x00800000 <= a <= 0x3f800000:
        raise ValueError("not normal-or-zero in [-1,1]")
    exponent = (a >> 23) - 150
    significand = (a & 0x7fffff) + (1 << 23)
    return sign * Fraction(significand) * Fraction(2) ** exponent

def reference(bits):
    try:
        v = list(map(decode, bits))
    except ValueError:
        return [1] + [0]*16
    value = sum((a*b for a,b in zip(v[:3], v[3:])), Fraction())
    if value == 0:
        return [0]*17
    magnitude = abs(value)
    # Fraction arithmetic defines exact value independently. Serialize only at
    # the end; no aligned significand products or limb arithmetic in this oracle.
    lattice = magnitude * (1 << 298)
    assert lattice.denominator == 1
    integer = lattice.numerator
    assert integer.bit_length() <= 300
    exponent = magnitude.numerator.bit_length() - magnitude.denominator.bit_length()
    if magnitude < Fraction(2) ** exponent:
        exponent -= 1
    normalized = magnitude / (Fraction(2) ** exponent)
    assert 1 <= normalized < 2
    exact_mantissa = normalized * (1 << 23)
    truncated, remainder = divmod(exact_mantissa.numerator, exact_mantissa.denominator)
    rounded = truncated + (2*remainder > exact_mantissa.denominator or
        (2*remainder == exact_mantissa.denominator and truncated % 2 == 1))
    round_exp = exponent
    if rounded == 1 << 24:
        rounded >>= 1
        round_exp += 1
    limbs = [(integer >> (32*j)) & MASK for j in range(10)]
    return [0, 1 if value > 0 else 2, exponent & MASK,
        0x3f800000 | (truncated & 0x7fffff), int(remainder != 0),
        round_exp & MASK, 0x3f800000 | (rounded & 0x7fffff)] + limbs

def fbits(value):
    return struct.unpack('<I', struct.pack('<f', value))[0]

def fixtures():
    cases = []
    def add(label, x, y):
        cases.append((label, tuple(x+y)))
    zero = [0,0,0]
    one = 0x3f800000
    minimum = 0x00800000
    def neg(b):
        return b ^ 0x80000000
    for sx in (0,0x80000000):
        for sy in (0,0x80000000):
            add('signed_zero', [sx]*3, [sy]*3)
    for reverse in (False,True):
        x = [minimum+1,minimum,0]
        y = [minimum+1,neg(minimum+2),0]
        if reverse: y = [neg(b) for b in y]
        add('plus_minus_2^-298',x,y)
        add('plus_minus_2^-127',[minimum,0,0],[fbits(-0.5 if reverse else 0.5),0,0])
    add('all_ones_sum3',[one]*3,[one]*3)
    add('all_negative_sum3',[one]*3,[neg(one)]*3)
    add('exact_cancellation',[one,one,0],[one,neg(one),0])
    a,b = fbits(1-2**-23),fbits(1-2**-22)
    add('wrong_fast_sign_2^-47',[a,neg(one),neg(one)],[a,b,fbits(2**-47)])
    for sign in (1,-1):
        for offset in (-1,0,1):
            x = [fbits(2**-20),minimum+1,minimum]
            y = [fbits(sign),minimum+1,neg(minimum+2)]
            if offset == -1: y[1:] = [neg(y[1]),neg(y[2])]
            if offset == 0: x[1:] = [0,0]
            add(f'threshold_{sign}_{offset}_lattice_neighbor',x,y)
        for b in (fbits(2**-20)-1,fbits(2**-20),fbits(2**-20)+1):
            add('threshold_f32_neighbors',[b,0,0],[fbits(sign),0,0])
    # All exponent pairs with high/low/alternating significands exercise 48-bit
    # multiply, shift residues, addition carries, subtraction borrows and tails.
    significands = (0,1,0x7ffffe,0x7fffff)
    for e in range(1,128):
        for f in range(1,128):
            for index, frac in enumerate(significands):
                a = (e<<23) | (frac if e<127 else 0)
                b = (f<<23) | (significands[-index-1] if f<127 else 0)
                add('all_exponent_pairs',[a,a,a],[b,b,b])
                add('all_exponent_pair_cancellation',[a,a,minimum+1],[b,neg(b),minimum+1])
    # Long carry/borrow ranges: a leading power minus the minimum lattice term.
    for e in range(1,128):
        for f in range(1,128):
            a,b=e<<23,f<<23
            add('long_borrow',[a,minimum,0],[b,neg(minimum),0])
            for direction in (-1,1):
                add('full_width_lattice_neighbor',[a,minimum+1,minimum],
                    [b,minimum+1 if direction>0 else neg(minimum+1),
                        neg(minimum+2) if direction>0 else minimum+2])
    # Exact halfway and round-up-to-next-exponent boundaries.
    for delta in (-1,0,1):
        add('nearest_even_boundary',[one,fbits(2**-24),minimum+1],
            [one,one,0 if delta==0 else (minimum+1 if delta>0 else neg(minimum+1))])
        add('rounded_exponent_carry',[one,fbits(2**-25),0],[one,neg(one),0])
    rng = random.Random(0x52304558414354)
    def normal():
        exponent = rng.randrange(1,128)
        return (rng.getrandbits(1)<<31) | (exponent<<23) | (rng.getrandbits(23) if exponent<127 else 0)
    for _ in range(8192):
        add('seeded_independent',[normal() for _ in range(3)],[normal() for _ in range(3)])
    for _ in range(4096):
        a,b,c = normal(),normal(),normal()
        add('seeded_cancellation',[a,a,c],[b,neg(b),normal()])
    for pos in range(6):
        for bad in (1,0x007fffff,0x80000001,0x807fffff,0x3f800001,0xbf800001,
                    0x7f800000,0xff800000,0x7fc00000,0x7f800001,0x7f7fffff):
            x = [one]*6
            x[pos] = bad
            cases.append(('invalid',tuple(x)))
    return cases

def write():
    cases = fixtures()
    raw = b''.join(struct.pack('<6I',*bits) for _,bits in cases)
    expected = b''.join(struct.pack('<17I',*reference(bits)) for _,bits in cases)
    (ROOT/'inputs.bin').write_bytes(raw)
    (ROOT/'expected.bin').write_bytes(expected)
    labels = [{'index':i,'label':label,'bits':[f'{x:08x}' for x in bits]}
        for i,(label,bits) in enumerate(cases) if not label.startswith(('all_exponent','long_borrow','full_width','seeded'))]
    metadata = {'cases':len(cases),'distinct_operand_tuples':len({bits for _,bits in cases}),
        'categories':dict(Counter(label for label,_ in cases)),
        'focused_cases':labels,'oracle':'Python Fraction exact real sum, independently normalized',
        'input_sha256':hashlib.sha256(raw).hexdigest(),'expected_sha256':hashlib.sha256(expected).hexdigest()}
    (ROOT/'fixtures.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in metadata.items() if k!='focused_cases'},indent=2))

def compare(path):
    expected = (ROOT/'expected.bin').read_bytes()
    actual = Path(path).read_bytes()
    assert len(actual) == len(expected), (len(actual),len(expected))
    count = len(actual)//68
    failures=[]
    for i in range(count):
        e=struct.unpack_from('<17I',expected,i*68)
        a=struct.unpack_from('<17I',actual,i*68)
        if a!=e: failures.append({'case':i,'expected':e,'actual':a})
    result={'file':str(path),'cases':count,'word_comparisons':count*17,'failures':len(failures),
        'sha256':hashlib.sha256(actual).hexdigest(),'first_failures':failures[:8]}
    print(json.dumps(result,indent=2))
    if failures: raise SystemExit(1)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['generate','compare'])
    parser.add_argument('file',nargs='?')
    args=parser.parse_args()
    write() if args.action=='generate' else compare(args.file)
