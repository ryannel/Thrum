#!/usr/bin/env python3
"""Recheck complete saved outputs and summarize raw, independently read timings."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import statistics
import struct
import sys
import oracle

ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
expected=(ROOT/'expected.bin').read_bytes()
inputs=(ROOT/'inputs.bin').read_bytes()
fixtures=json.loads((ROOT/'fixtures.json').read_text())
assert len(expected)==fixtures['cases']*68
assert sha(expected)==fixtures['expected_sha256']
assert sha(inputs)==fixtures['input_sha256']
rows=list(struct.iter_unpack('<17I',expected))
values=[]
for row in rows:
    integer=sum(x<<(32*j) for j,x in enumerate(row[7:]))
    values.append(Fraction(integer,1<<298)*(1 if row[1]==1 else -1))
assert values[4]==Fraction(1,1<<298)
assert values[5]==Fraction(1,1<<127)
assert values[6]==-Fraction(1,1<<298)
assert values[7]==-Fraction(1,1<<127)
assert values[8]==3 and values[9]==-3 and values[10]==0
assert values[11]==Fraction(1,1<<47)
assert sum(row[0]==1 for row in rows)==66
assert all(row==tuple([1]+[0]*16) for row in rows[-66:])
comparisons=[]
timings=[]
for rep in (1,2,3):
    raw=(ROOT/f'gpu-{rep}.bin').read_bytes()
    assert raw==expected, f'full comparison failed for process {rep}'
    comparisons.append({'process':rep,'cases':len(rows),'words':len(rows)*17,
        'mismatches':0,'output_sha256':sha(raw)})
    log=(ROOT/f'gpu-{rep}.log').read_text()
    records=[]
    for line in log.splitlines():
        if not line.startswith('run='):continue
        record=dict(x.split('=',1) for x in line.split())
        for k in ('run','encode_submit_completion_us','gpu_begin','gpu_end','gpu_ns'):
            record[k]=int(record[k])
        assert record['gpu_begin']>0 and record['gpu_end']>record['gpu_begin']
        assert record['gpu_ns']==record['gpu_end']-record['gpu_begin']
        records.append(record)
    assert len(records)==10
    measured=[r for r in records if r['phase']=='measured']
    assert len(measured)==8
    gpu=[r['gpu_ns'] for r in measured]
    cpu=[r['encode_submit_completion_us'] for r in measured]
    timings.append({'process':rep,'query_pairs_valid':len(records),
        'gpu_ns_min':min(gpu),'gpu_ns_median':statistics.median(gpu),'gpu_ns_max':max(gpu),
        'cpu_encode_submit_completion_us_min':min(cpu),
        'cpu_encode_submit_completion_us_median':statistics.median(cpu),
        'cpu_encode_submit_completion_us_max':max(cpu),
        'records':records})
packages=json.loads((ROOT/'cargo-metadata.json').read_text())['packages']
dependencies=[{k:p.get(k) for k in ('name','version','license','source','repository')}
    for p in packages if p['name']!='r0-exact-dot-gpu']
results={'scope':'raw-u32 normal-or-zero represented-input exact-dot compute diagnostic',
    'cases':len(rows),'distinct_operand_tuples':fixtures['distinct_operand_tuples'],
    'valid_cases':len(rows)-66,'invalid_cases':66,
    'full_word_comparisons_per_process':len(rows)*17,
    'full_word_comparisons_across_selected_readbacks':len(rows)*17*3,
    'ten_stable_dispatch_outputs_per_process':True,'comparisons':comparisons,
    'exact_witness_assertions':'pass',
    'input_sha256':sha(inputs),'expected_sha256':sha(expected),
    'timings':timings,
    'represented_dot_within_2^-20_count':sum(r[0]==0 and abs(v)<=Fraction(1,1<<20) for r,v in zip(rows,values)),
    'gpu_timing_scope':'isolated serialized whole-corpus compute pass; excludes input upload, readback, delayed query resolve, map and engine work',
    'cpu_timing_scope':'encode+submit+wait completion; excludes result-copy/resolve/readback/map',
    'python_summary':sys.version}
(ROOT/'results.json').write_text(json.dumps(results,indent=2,sort_keys=True)+'\n')
(ROOT/'dependencies.json').write_text(json.dumps(dependencies,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in results.items() if k not in ('timings','comparisons')},indent=2))
for t in timings:
    print({k:v for k,v in t.items() if k!='records'})
