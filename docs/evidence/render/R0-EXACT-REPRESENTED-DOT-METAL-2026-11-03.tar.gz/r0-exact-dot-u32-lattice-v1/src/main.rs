use std::{
    error::Error,
    fs,
    sync::mpsc,
    time::{Duration, Instant},
};
use wgpu::*;
type Result<T> = std::result::Result<T, Box<dyn Error>>;

fn wait(d: &Device, index: SubmissionIndex) -> Result<()> {
    d.poll(PollType::Wait {
        submission_index: Some(index),
        timeout: Some(Duration::from_secs(30)),
    })?;
    Ok(())
}
fn read(d: &Device, b: &Buffer) -> Result<Vec<u8>> {
    let (tx, rx) = mpsc::channel();
    b.slice(..).map_async(MapMode::Read, move |r| {
        tx.send(r).unwrap();
    });
    d.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(30)),
    })?;
    rx.recv_timeout(Duration::from_secs(30))??;
    let bytes = b.slice(..).get_mapped_range()?.to_vec();
    b.unmap();
    Ok(bytes)
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 3 {
        return Err("usage: r0-exact-dot-gpu INPUT.bin OUTPUT.bin".into());
    }
    let bytes = fs::read(&args[1])?;
    if bytes.is_empty() || bytes.len() % 24 != 0 {
        return Err("input length must be a nonzero multiple of 24".into());
    }
    let n = u32::try_from(bytes.len() / 24)?;
    let shader_source = fs::read_to_string("exact_dot.wgsl")?;
    let parsed = naga::front::wgsl::parse_str(&shader_source)
        .map_err(|e| e.emit_to_string(&shader_source))?;
    naga::valid::Validator::new(
        naga::valid::ValidationFlags::all(),
        naga::valid::Capabilities::empty(),
    )
    .validate(&parsed)?;
    println!("naga_validation=pass cases={n} shader_float_operations=0");
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let instance = Instance::new(desc);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions::default()))?;
    println!("adapter={:?}", adapter.get_info());
    println!("adapter_limits={:?}", adapter.limits());
    let timestamp = adapter.features().contains(Features::TIMESTAMP_QUERY);
    let (d, q) = pollster::block_on(adapter.request_device(&DeviceDescriptor {
        required_features: if timestamp {
            Features::TIMESTAMP_QUERY
        } else {
            Features::empty()
        },
        ..Default::default()
    }))?;
    let start = Instant::now();
    let shader = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("integer exact represented dot"),
        source: ShaderSource::Wgsl(shader_source.into()),
    });
    let pipeline = d.create_compute_pipeline(&ComputePipelineDescriptor {
        label: Some("integer exact represented dot"),
        layout: None,
        module: &shader,
        entry_point: Some("main"),
        compilation_options: Default::default(),
        cache: None,
    });
    println!(
        "module_pipeline_creation_cpu_us={}",
        start.elapsed().as_micros()
    );
    let input = d.create_buffer(&BufferDescriptor {
        label: Some("raw-u32 operands"),
        size: bytes.len() as u64,
        usage: BufferUsages::STORAGE,
        mapped_at_creation: true,
    });
    input
        .slice(..)
        .get_mapped_range_mut()?
        .copy_from_slice(&bytes);
    input.unmap();
    let output_bytes = u64::from(n) * 17 * 4;
    let output = d.create_buffer(&BufferDescriptor {
        label: Some("exact magnitude and normalized output"),
        size: output_bytes,
        usage: BufferUsages::STORAGE | BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let readback = d.create_buffer(&BufferDescriptor {
        label: Some("output readback"),
        size: output_bytes,
        usage: BufferUsages::MAP_READ | BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });
    let group = d.create_bind_group(&BindGroupDescriptor {
        label: None,
        layout: &pipeline.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: input.as_entire_binding(),
            },
            BindGroupEntry {
                binding: 1,
                resource: output.as_entire_binding(),
            },
        ],
    });
    let queries = timestamp.then(|| {
        d.create_query_set(&QuerySetDescriptor {
            label: None,
            ty: QueryType::Timestamp,
            count: 2,
        })
    });
    let resolve = d.create_buffer(&BufferDescriptor {
        label: None,
        size: 16,
        usage: BufferUsages::QUERY_RESOLVE | BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let query_readback = d.create_buffer(&BufferDescriptor {
        label: None,
        size: 16,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    println!(
        "timestamp_available={timestamp} timestamp_period_ns={} workgroups={} input_bytes={} output_bytes={output_bytes} warmup=2 measured=8",
        q.get_timestamp_period(),
        n.div_ceil(64),
        bytes.len()
    );
    let mut selected = Vec::new();
    for run in 0..10 {
        let start = Instant::now();
        let mut encoder = d.create_command_encoder(&CommandEncoderDescriptor::default());
        {
            let mut pass = encoder.begin_compute_pass(&ComputePassDescriptor {
                label: None,
                timestamp_writes: queries.as_ref().map(|set| ComputePassTimestampWrites {
                    query_set: set,
                    beginning_of_pass_write_index: Some(0),
                    end_of_pass_write_index: Some(1),
                }),
            });
            pass.set_pipeline(&pipeline);
            pass.set_bind_group(0, &group, &[]);
            pass.dispatch_workgroups(n.div_ceil(64), 1, 1);
        }
        // Complete compute before resolve: prior Metal diagnostics observed stale
        // query ends for same-submission resolve. This is isolated serialized work.
        wait(&d, q.submit([encoder.finish()]))?;
        let submit_completion_us = start.elapsed().as_micros();
        let mut copy = d.create_command_encoder(&CommandEncoderDescriptor::default());
        copy.copy_buffer_to_buffer(&output, 0, &readback, 0, output_bytes);
        if let Some(set) = &queries {
            copy.resolve_query_set(set, 0..2, &resolve, 0);
            copy.copy_buffer_to_buffer(&resolve, 0, &query_readback, 0, 16);
        }
        wait(&d, q.submit([copy.finish()]))?;
        let result = read(&d, &readback)?;
        if run == 0 {
            selected = result;
        } else if result != selected {
            return Err(format!("nondeterministic output run {run}").into());
        }
        let gpu = if timestamp {
            let raw = read(&d, &query_readback)?;
            let begin = u64::from_le_bytes(raw[0..8].try_into()?);
            let end = u64::from_le_bytes(raw[8..16].try_into()?);
            if begin == 0 || end <= begin {
                return Err(format!("invalid query pair {begin},{end}").into());
            }
            format!(
                "gpu_begin={begin} gpu_end={end} gpu_ns={:.0}",
                (end - begin) as f64 * f64::from(q.get_timestamp_period())
            )
        } else {
            "gpu_ns=unavailable".to_owned()
        };
        println!(
            "run={run} phase={} encode_submit_completion_us={submit_completion_us} {gpu}",
            if run < 2 { "warmup" } else { "measured" }
        );
    }
    fs::write(&args[2], &selected)?;
    println!(
        "stable_outputs=10 output_file={} output_bytes={}",
        args[2],
        selected.len()
    );
    Ok(())
}
