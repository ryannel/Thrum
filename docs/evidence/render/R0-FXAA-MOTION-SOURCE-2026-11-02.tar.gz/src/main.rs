//! Isolated Metal timing and moving-input inspection of the pinned FXAA WGSL port.
//! The workload is synthetic and cannot stand in for whole-R0 frame cost.

use std::{fs::File, io::Write, sync::mpsc, time::Duration};
use wgpu::{
    Backends, BufferDescriptor, BufferUsages, Color, ColorTargetState, ColorWrites,
    CommandEncoderDescriptor, DeviceDescriptor, Extent3d, Features, FragmentState,
    Instance, InstanceDescriptor, LoadOp, MapMode, Operations, PipelineCompilationOptions,
    PowerPreference, PrimitiveState, QuerySetDescriptor, QueryType,
    RenderPassColorAttachment, RenderPassDescriptor, RenderPassTimestampWrites,
    RenderPipelineDescriptor, RequestAdapterOptions, StoreOp, TextureDescriptor,
    TextureDimension, TextureFormat, TextureUsages, TextureViewDescriptor, VertexState,
};

const SAMPLES: u32 = 64;
const WARMUP: u32 = 32;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    for (name, source) in [
        ("fxaa.wgsl", include_str!("fxaa.wgsl")),
        ("motion.wgsl", include_str!("motion.wgsl")),
    ] {
        let module = naga::front::wgsl::parse_str(source)?;
        naga::valid::Validator::new(naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::empty()).validate(&module)?;
        println!("naga 30.0.1 valid={name}");
    }
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let instance = Instance::new(desc);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let info = adapter.get_info();
    if !adapter.features().contains(Features::TIMESTAMP_QUERY) {
        return Err("adapter lacks TIMESTAMP_QUERY".into());
    }
    let (device, queue) = pollster::block_on(adapter.request_device(&DeviceDescriptor {
        required_features: Features::TIMESTAMP_QUERY,
        ..Default::default()
    }))?;
    println!("adapter={} backend={:?} timestamp_period_ns={}",
        info.name, info.backend, queue.get_timestamp_period());
    let motion_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("encoded moving fixture"),
        source: wgpu::ShaderSource::Wgsl(include_str!("motion.wgsl").into()),
    });
    let fxaa_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("pinned quality-12 WGSL port"),
        source: wgpu::ShaderSource::Wgsl(include_str!("fxaa.wgsl").into()),
    });
    let motion_pipeline = pipeline(&device, &motion_shader, "vs_full", "fs_motion",
        TextureFormat::Rgba16Float);
    let fxaa_pipeline = pipeline(&device, &fxaa_shader, "vs_fxaa", "fs_fxaa",
        TextureFormat::Rgba8Unorm);
    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        ..Default::default()
    });
    for (width, height) in [(1920, 1080), (1280, 720)] {
        run_size(&device, &queue, &motion_pipeline, &fxaa_pipeline, &sampler, width, height)?;
    }
    Ok(())
}

fn run_size(device: &wgpu::Device, queue: &wgpu::Queue,
            motion: &wgpu::RenderPipeline, fxaa: &wgpu::RenderPipeline,
            sampler: &wgpu::Sampler, width: u32, height: u32)
    -> Result<(), Box<dyn std::error::Error>> {
    let size = Extent3d { width, height, depth_or_array_layers: 1 };
    let encoded = (0..2).map(|_| texture(device, size, TextureFormat::Rgba16Float,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING))
        .collect::<Vec<_>>();
    let encoded_views = encoded.iter().map(|t| t.create_view(&TextureViewDescriptor::default()))
        .collect::<Vec<_>>();
    let outputs = (0..2).map(|_| texture(device, size, TextureFormat::Rgba8Unorm,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC))
        .collect::<Vec<_>>();
    let output_views = outputs.iter().map(|t| t.create_view(&TextureViewDescriptor::default()))
        .collect::<Vec<_>>();
    let uniforms = [0.0_f32, 0.37_f32].map(|shift| {
        let buffer = device.create_buffer(&BufferDescriptor {
            label: Some("motion params"), size: 16, usage: BufferUsages::UNIFORM,
            mapped_at_creation: true,
        });
        {
            let mut mapped = buffer.slice(..).get_mapped_range_mut()?;
            for (i, v) in [width as f32, height as f32, shift, 0.0].iter().enumerate() {
                mapped.slice(i * 4..i * 4 + 4).copy_from_slice(&v.to_le_bytes());
            }
        }
        buffer.unmap();
        Ok::<_, Box<dyn std::error::Error>>(buffer)
    });
    let uniforms = [uniforms[0].as_ref().unwrap(), uniforms[1].as_ref().unwrap()];
    let motion_groups = uniforms.map(|buffer| device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("motion frame"), layout: &motion.get_bind_group_layout(0),
        entries: &[wgpu::BindGroupEntry { binding: 0,
            resource: buffer.as_entire_binding() }],
    }));
    let fxaa_groups = encoded_views.iter().map(|view| device.create_bind_group(
        &wgpu::BindGroupDescriptor {
            label: Some("FXAA encoded frame"), layout: &fxaa.get_bind_group_layout(0),
            entries: &[
                wgpu::BindGroupEntry { binding: 0,
                    resource: wgpu::BindingResource::TextureView(view) },
                wgpu::BindGroupEntry { binding: 1,
                    resource: wgpu::BindingResource::Sampler(sampler) },
            ],
        })).collect::<Vec<_>>();
    let queries = device.create_query_set(&QuerySetDescriptor {
        label: Some("FXAA pass timings"), ty: QueryType::Timestamp, count: SAMPLES * 2,
    });
    let resolve = device.create_buffer(&BufferDescriptor {
        label: Some("timestamp resolve"), size: (SAMPLES * 16) as u64,
        usage: BufferUsages::QUERY_RESOLVE | BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let timing_readback = device.create_buffer(&BufferDescriptor {
        label: Some("timestamp readback"), size: (SAMPLES * 16) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let rgb_stride = width * 4;
    assert_eq!(rgb_stride % 256, 0);
    let rgb_readbacks = (0..2).map(|_| device.create_buffer(&BufferDescriptor {
        label: Some("RGB frame readback"), size: (rgb_stride * height) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    })).collect::<Vec<_>>();
    let mut encoder = device.create_command_encoder(&CommandEncoderDescriptor::default());
    for frame in 0..2 {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("moving encoded source"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &encoded_views[frame], depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(motion);
        pass.set_bind_group(0, &motion_groups[frame], &[]);
        pass.draw(0..3, 0..1);
    }
    for frame in 0..2 {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("FXAA moving capture"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &output_views[frame], depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(fxaa);
        pass.set_bind_group(0, &fxaa_groups[frame], &[]);
        pass.draw(0..3, 0..1);
    }
    for frame in 0..2 {
        encoder.copy_texture_to_buffer(
            wgpu::TexelCopyTextureInfo { texture: &outputs[frame], mip_level: 0,
                origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
            wgpu::TexelCopyBufferInfo { buffer: &rgb_readbacks[frame],
                layout: wgpu::TexelCopyBufferLayout { offset: 0,
                    bytes_per_row: Some(rgb_stride), rows_per_image: Some(height) } },
            size);
    }
    // Untimed passes warm the exact pipeline and attachments. Timing then
    // records 64 passes on one input/output pair to force write-after-write
    // ordering and avoid interpreting independently scheduled views as a frame.
    for pass_index in 0..(SAMPLES + WARMUP) {
        let frame = 0usize;
        let measured = pass_index.checked_sub(WARMUP);
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("FXAA timed pass"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &output_views[frame], depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            timestamp_writes: measured.map(|i| RenderPassTimestampWrites {
                query_set: &queries,
                beginning_of_pass_write_index: Some(i * 2),
                end_of_pass_write_index: Some(i * 2 + 1),
            }),
            ..Default::default()
        });
        pass.set_pipeline(fxaa);
        pass.set_bind_group(0, &fxaa_groups[frame], &[]);
        pass.draw(0..3, 0..1);
    }
    encoder.resolve_query_set(&queries, 0..SAMPLES * 2, &resolve, 0);
    encoder.copy_buffer_to_buffer(&resolve, 0, &timing_readback, 0, (SAMPLES * 16) as u64);
    let submission = queue.submit([encoder.finish()]);
    let (tx, rx) = mpsc::channel();
    timing_readback.slice(..).map_async(MapMode::Read, move |r| { let _ = tx.send(r); });
    let receivers = rgb_readbacks.iter().map(|b| {
        let (tx, rx) = mpsc::channel();
        b.slice(..).map_async(MapMode::Read, move |r| { let _ = tx.send(r); });
        rx
    }).collect::<Vec<_>>();
    device.poll(wgpu::PollType::Wait { submission_index: Some(submission),
        timeout: Some(Duration::from_secs(20)) })?;
    rx.recv_timeout(Duration::from_secs(1))??;
    for receiver in &receivers { receiver.recv_timeout(Duration::from_secs(1))??; }
    let mapped = timing_readback.slice(..).get_mapped_range()?;
    let mut times_us = Vec::with_capacity(SAMPLES as usize);
    let mut first_start = 0u64;
    let mut previous_end = 0u64;
    let mut last_end = 0u64;
    let mut overlaps = 0u32;
    for bytes in mapped.chunks_exact(16) {
        let begin = u64::from_le_bytes(bytes[..8].try_into()?);
        let end = u64::from_le_bytes(bytes[8..16].try_into()?);
        if times_us.is_empty() { first_start = begin; }
        if !times_us.is_empty() && begin < previous_end { overlaps += 1; }
        previous_end = end;
        last_end = end;
        times_us.push((end - begin) as f64 * f64::from(queue.get_timestamp_period()) / 1000.0);
    }
    let sum_us: f64 = times_us.iter().sum();
    let slow = times_us.iter().enumerate().filter(|(_, t)| **t > 1000.0)
        .map(|(i, t)| format!("{i}:{t:.0}"))
        .collect::<Vec<_>>();
    times_us.sort_by(f64::total_cmp);
    println!("size={}x{} samples={} fxaa_pass_gpu_us min={:.1} median={:.1} p95={:.1} max={:.1} mean={:.1}",
        width, height, SAMPLES, times_us[0], times_us[32], times_us[60], times_us[63], sum_us / SAMPLES as f64);
    println!("size={}x{} batch_gpu_us={:.1} overlaps={}", width, height,
        (last_end - first_start) as f64 * f64::from(queue.get_timestamp_period()) / 1000.0, overlaps);
    println!("size={}x{} slow_gt_1ms={:?}", width, height, slow);
    drop(mapped);
    timing_readback.unmap();
    for (frame, buffer) in rgb_readbacks.iter().enumerate() {
        let mapped = buffer.slice(..).get_mapped_range()?;
        let mut file = File::create(format!("motion-{width}x{height}-{frame}.ppm"))?;
        write!(file, "P6\n{width} {height}\n255\n")?;
        for pixel in mapped.chunks_exact(4) { file.write_all(&pixel[..3])?; }
        drop(mapped);
        buffer.unmap();
    }
    Ok(())
}

fn texture(device: &wgpu::Device, size: Extent3d, format: TextureFormat,
           usage: TextureUsages) -> wgpu::Texture {
    device.create_texture(&TextureDescriptor {
        label: Some("FXAA motion target"), size, mip_level_count: 1,
        sample_count: 1, dimension: TextureDimension::D2, format, usage,
        view_formats: &[],
    })
}

fn pipeline(device: &wgpu::Device, shader: &wgpu::ShaderModule,
            vertex: &str, fragment: &str, format: TextureFormat) -> wgpu::RenderPipeline {
    device.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(fragment), layout: None,
        vertex: VertexState { module: shader, entry_point: Some(vertex), buffers: &[],
            compilation_options: PipelineCompilationOptions::default() },
        primitive: PrimitiveState::default(), depth_stencil: None,
        multisample: Default::default(),
        fragment: Some(FragmentState { module: shader, entry_point: Some(fragment),
            targets: &[Some(ColorTargetState { format, blend: None,
                write_mask: ColorWrites::ALL })],
            compilation_options: PipelineCompilationOptions::default() }),
        multiview_mask: None, cache: None,
    })
}
