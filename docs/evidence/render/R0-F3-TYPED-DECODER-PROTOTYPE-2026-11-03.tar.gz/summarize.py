"""Summarize raw key=value benchmark rows without claiming integrated admission."""

from pathlib import Path
from statistics import median
import sys


def read(path: Path) -> list[dict[str, float]]:
    rows = []
    for line in path.read_text().splitlines():
        row = {}
        for part in line.split():
            key, value = part.split("=", 1)
            if key in {"read_ms", "decode_ms", "parse_ms", "extract_ms", "sort_ms", "resolve_ms", "maxrss_bytes"}:
                row[key] = float(value)
        rows.append(row)
    return rows


for name in sys.argv[1:]:
    path = Path(name)
    rows = read(path)
    keys = sorted(set().union(*(row.keys() for row in rows)))
    print(path.name, "n", len(rows))
    for key in keys:
        values = [row[key] for row in rows]
        factor = 1 / (1024 * 1024) if key == "maxrss_bytes" else 1
        print(key, f"median={median(values)*factor:.3f}", f"min={min(values)*factor:.3f}", f"max={max(values)*factor:.3f}")
    if "parse_ms" in rows[0]:
        values = [row["parse_ms"] + row["extract_ms"] for row in rows]
        print("parse_plus_extract_ms", f"median={median(values):.3f}")
