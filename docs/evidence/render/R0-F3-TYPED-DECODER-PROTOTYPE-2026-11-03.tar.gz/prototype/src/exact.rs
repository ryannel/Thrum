const LIMBS: usize = 36;

#[derive(Clone, Copy)]
struct Big {
    sign: i8,
    n: usize,
    limb: [u64; LIMBS],
}
impl Default for Big {
    fn default() -> Self {
        Self {
            sign: 0,
            n: 0,
            limb: [0; LIMBS],
        }
    }
}

impl Big {
    fn from_f64(x: f64, common_exp: i32) -> Self {
        assert!(x.is_finite());
        let bits = x.to_bits();
        let frac = bits & ((1u64 << 52) - 1);
        let raw_exp = ((bits >> 52) & 0x7ff) as i32;
        let (mant, exp) = if raw_exp == 0 {
            (frac, -1074)
        } else {
            ((1u64 << 52) | frac, raw_exp - 1023 - 52)
        };
        if mant == 0 {
            return Self::default();
        }
        let shift = (exp - common_exp) as usize;
        let word = shift / 64;
        let offset = shift % 64;
        assert!(word + 1 < LIMBS);
        let mut result = Self::default();
        result.limb[word] = mant << offset;
        if offset != 0 {
            result.limb[word + 1] = mant >> (64 - offset);
        }
        result.n = if result.limb[word + 1] == 0 {
            word + 1
        } else {
            word + 2
        };
        result.sign = if bits >> 63 == 0 { 1 } else { -1 };
        result
    }

    fn trim(&mut self) {
        while self.n > 0 && self.limb[self.n - 1] == 0 {
            self.n -= 1;
        }
        if self.n == 0 {
            self.sign = 0;
        }
    }

    fn abs_cmp(&self, rhs: &Self) -> std::cmp::Ordering {
        match self.n.cmp(&rhs.n) {
            std::cmp::Ordering::Equal => {
                for i in (0..self.n).rev() {
                    let c = self.limb[i].cmp(&rhs.limb[i]);
                    if c != std::cmp::Ordering::Equal {
                        return c;
                    }
                }
                std::cmp::Ordering::Equal
            }
            c => c,
        }
    }

    fn abs_add(a: &Self, b: &Self) -> Self {
        let mut out = Self::default();
        let mut carry: u128 = 0;
        let n = a.n.max(b.n);
        assert!(n < LIMBS);
        for i in 0..n {
            let sum = a.limb[i] as u128 + b.limb[i] as u128 + carry;
            out.limb[i] = sum as u64;
            carry = sum >> 64;
        }
        out.n = n;
        if carry != 0 {
            out.limb[n] = carry as u64;
            out.n += 1;
        }
        out.trim();
        out
    }

    fn abs_sub(a: &Self, b: &Self) -> Self {
        assert!(a.abs_cmp(b) != std::cmp::Ordering::Less);
        let mut out = Self::default();
        let mut borrow: u128 = 0;
        for i in 0..a.n {
            let ai = a.limb[i] as u128;
            let bi = b.limb[i] as u128 + borrow;
            out.limb[i] = ai.wrapping_sub(bi) as u64;
            borrow = u128::from(ai < bi);
        }
        assert_eq!(borrow, 0);
        out.n = a.n;
        out.trim();
        out
    }

    fn add(a: &Self, b: &Self) -> Self {
        if a.sign == 0 {
            return *b;
        }
        if b.sign == 0 {
            return *a;
        }
        if a.sign == b.sign {
            let mut out = Self::abs_add(a, b);
            out.sign = a.sign;
            out
        } else {
            match a.abs_cmp(b) {
                std::cmp::Ordering::Greater => {
                    let mut out = Self::abs_sub(a, b);
                    if out.n > 0 {
                        out.sign = a.sign;
                    }
                    out
                }
                std::cmp::Ordering::Less => {
                    let mut out = Self::abs_sub(b, a);
                    if out.n > 0 {
                        out.sign = b.sign;
                    }
                    out
                }
                std::cmp::Ordering::Equal => Self::default(),
            }
        }
    }

    fn sub(a: &Self, b: &Self) -> Self {
        let mut neg = *b;
        neg.sign = -neg.sign;
        Self::add(a, &neg)
    }

    fn mul(a: &Self, b: &Self) -> Self {
        if a.sign == 0 || b.sign == 0 {
            return Self::default();
        }
        assert!(a.n + b.n <= LIMBS);
        let mut out = Self::default();
        out.sign = a.sign * b.sign;
        for i in 0..a.n {
            let mut carry: u128 = 0;
            for j in 0..b.n {
                let k = i + j;
                let sum = (a.limb[i] as u128) * (b.limb[j] as u128) + out.limb[k] as u128 + carry;
                out.limb[k] = sum as u64;
                carry = sum >> 64;
            }
            let mut k = i + b.n;
            while carry != 0 {
                assert!(k < LIMBS);
                let sum = out.limb[k] as u128 + carry;
                out.limb[k] = sum as u64;
                carry = sum >> 64;
                k += 1;
            }
        }
        out.n = a.n + b.n;
        out.trim();
        out
    }
}

fn exponent(x: f64) -> Option<i32> {
    if x == 0.0 {
        return None;
    }
    let bits = x.to_bits();
    let raw = ((bits >> 52) & 0x7ff) as i32;
    Some(if raw == 0 { -1074 } else { raw - 1023 - 52 })
}

fn exact_cross(p: [[f64; 3]; 3]) -> [i8; 3] {
    let common_exp = p
        .iter()
        .flat_map(|v| v.iter())
        .filter_map(|&x| exponent(x))
        .min()
        .unwrap_or(0);
    let mut d = [[Big::default(); 3]; 2];
    for i in 0..2 {
        for j in 0..3 {
            d[i][j] = Big::sub(
                &Big::from_f64(p[i + 1][j], common_exp),
                &Big::from_f64(p[0][j], common_exp),
            );
        }
    }
    let mut signs = [0; 3];
    for k in 0..3 {
        let a = (k + 1) % 3;
        let b = (k + 2) % 3;
        let v = Big::sub(&Big::mul(&d[0][a], &d[1][b]), &Big::mul(&d[0][b], &d[1][a]));
        signs[k] = v.sign;
    }
    signs
}

pub(crate) fn valid_triangle(p: [[f64; 3]; 3]) -> bool {
    exact_cross(p).iter().any(|&component| component != 0)
}

/// Exact fallback for decoded dyadic squared radius against 1000² metres².
/// The component precheck bounds the fixed 36-limb arithmetic below.
fn radius_le_1000_exact(p: [f64; 3]) -> bool {
    if p.iter().any(|&x| !x.is_finite() || x.abs() > 1000.0) {
        return false;
    }
    let Some(common_exp) = p.iter().filter_map(|&x| exponent(x)).min() else {
        return true;
    };
    let mut squared = Big::default();
    for x in p {
        let scaled = Big::from_f64(x, common_exp);
        squared = Big::add(&squared, &Big::mul(&scaled, &scaled));
    }
    let bound = Big::from_f64(1_000_000.0, 2 * common_exp);
    squared.abs_cmp(&bound) != std::cmp::Ordering::Greater
}

fn up(x: f64) -> f64 {
    if x == f64::INFINITY {
        return x;
    }
    if x == 0.0 {
        return f64::from_bits(1);
    }
    f64::from_bits(if x > 0.0 {
        x.to_bits() + 1
    } else {
        x.to_bits() - 1
    })
}

fn down(x: f64) -> f64 {
    if x == f64::NEG_INFINITY {
        return x;
    }
    if x == 0.0 {
        return -f64::from_bits(1);
    }
    f64::from_bits(if x > 0.0 {
        x.to_bits() - 1
    } else {
        x.to_bits() + 1
    })
}

/// Outward binary64 intervals accept/reject clear radii. Ambiguous boundary
/// values use the exact decoded-dyadic comparison. The interval argument
/// assumes IEEE round-to-nearest and gradual underflow, as in the prior
/// triangle probe; target/compiler qualification remains necessary.
pub(crate) fn radius_le_1000(p: [f64; 3]) -> (bool, bool) {
    if p.iter().any(|&x| !x.is_finite() || x.abs() > 1000.0) {
        return (false, false);
    }
    let mut lo = 0.0;
    let mut hi = 0.0;
    for x in p {
        let square = x * x;
        lo = down(lo + down(square));
        hi = up(hi + up(square));
    }
    if hi <= 1_000_000.0 {
        return (true, false);
    }
    if lo > 1_000_000.0 {
        return (false, false);
    }
    (radius_le_1000_exact(p), true)
}

#[cfg(test)]
pub(crate) fn radius_le_1000_reference(p: [f64; 3]) -> bool {
    radius_le_1000_exact(p)
}
