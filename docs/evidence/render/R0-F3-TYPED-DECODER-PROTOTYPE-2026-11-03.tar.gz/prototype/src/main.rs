mod exact;

use std::borrow::Cow;
use std::cell::Cell;
use std::env;
use std::fs;
use std::hint::black_box;
use std::mem::size_of;
use std::path::Path;
use std::time::Instant;

use serde::Deserialize;
use serde::de::{DeserializeSeed, Error as _, IgnoredAny, MapAccess, SeqAccess, Visitor};
use serde_json::value::RawValue;

const MAX_BYTES: usize = 16 * 1024 * 1024;
const MAX_NODES: usize = 1_000_000;
const MAX_DEPTH: usize = 64;

fn fail(message: &str) -> String {
    message.to_owned()
}

struct Count<'a> {
    nodes: &'a Cell<usize>,
    depth: usize,
}
struct CountVisitor<'a> {
    nodes: &'a Cell<usize>,
    depth: usize,
}
impl<'de> DeserializeSeed<'de> for Count<'_> {
    type Value = ();
    fn deserialize<D: serde::Deserializer<'de>>(self, d: D) -> Result<(), D::Error> {
        if self.nodes.get() >= MAX_NODES {
            return Err(D::Error::custom("node limit"));
        }
        self.nodes.set(self.nodes.get() + 1);
        d.deserialize_any(CountVisitor {
            nodes: self.nodes,
            depth: self.depth,
        })
    }
}
impl<'de> Visitor<'de> for CountVisitor<'_> {
    type Value = ();
    fn expecting(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        f.write_str("JSON value")
    }
    fn visit_bool<E: serde::de::Error>(self, _: bool) -> Result<(), E> {
        Ok(())
    }
    fn visit_i64<E: serde::de::Error>(self, _: i64) -> Result<(), E> {
        Ok(())
    }
    fn visit_u64<E: serde::de::Error>(self, _: u64) -> Result<(), E> {
        Ok(())
    }
    fn visit_f64<E: serde::de::Error>(self, v: f64) -> Result<(), E> {
        if v.is_finite() {
            Ok(())
        } else {
            Err(E::custom("nonfinite number"))
        }
    }
    fn visit_str<E: serde::de::Error>(self, _: &str) -> Result<(), E> {
        Ok(())
    }
    fn visit_string<E: serde::de::Error>(self, _: String) -> Result<(), E> {
        Ok(())
    }
    fn visit_none<E: serde::de::Error>(self) -> Result<(), E> {
        Ok(())
    }
    fn visit_unit<E: serde::de::Error>(self) -> Result<(), E> {
        Ok(())
    }
    fn visit_map<A: MapAccess<'de>>(self, mut map: A) -> Result<(), A::Error> {
        if self.depth >= MAX_DEPTH {
            return Err(A::Error::custom("depth limit"));
        }
        while map.next_key::<IgnoredAny>()?.is_some() {
            map.next_value_seed(Count {
                nodes: self.nodes,
                depth: self.depth + 1,
            })?;
        }
        Ok(())
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut seq: A) -> Result<(), A::Error> {
        if self.depth >= MAX_DEPTH {
            return Err(A::Error::custom("depth limit"));
        }
        while seq
            .next_element_seed(Count {
                nodes: self.nodes,
                depth: self.depth + 1,
            })?
            .is_some()
        {}
        Ok(())
    }
}
fn prewalk(bytes: &[u8]) -> Result<usize, String> {
    if bytes.len() > MAX_BYTES {
        return Err(fail("record byte limit"));
    }
    let nodes = Cell::new(0);
    let mut d = serde_json::Deserializer::from_slice(bytes);
    Count {
        nodes: &nodes,
        depth: 0,
    }
    .deserialize(&mut d)
    .map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())?;
    Ok(nodes.get())
}

fn present<'de, D, T>(d: D) -> Result<Option<T>, D::Error>
where
    D: serde::Deserializer<'de>,
    T: Deserialize<'de>,
{
    T::deserialize(d).map(Some)
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Root<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    #[serde(borrow, rename = "type")]
    record_type: Cow<'a, str>,
    schema: u64,
    #[serde(borrow)]
    fields: Fields<'a>,
    #[serde(borrow, default, deserialize_with = "present")]
    documentation: Option<Cow<'a, str>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Fields<'a> {
    #[serde(borrow)]
    active_camera: Cow<'a, str>,
    #[serde(borrow)]
    cameras: Vec<&'a RawValue>,
    #[serde(borrow)]
    meshes: Vec<&'a RawValue>,
    #[serde(borrow)]
    instances: Vec<&'a RawValue>,
    #[serde(borrow)]
    materials: Vec<&'a RawValue>,
    #[serde(borrow)]
    textures: Vec<&'a RawValue>,
    #[serde(borrow)]
    local_lights: Vec<&'a RawValue>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Camera<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    position_m: [f64; 3],
    orientation_xyzw: [f64; 4],
    vertical_fov_rad: f64,
    near_m: f64,
    far_m: f64,
    exposure: f64,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Mesh<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    positions_m: Vec<[f64; 3]>,
    uv0: Vec<[f64; 2]>,
    triangles: Vec<[u32; 3]>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Instance<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    #[serde(borrow)]
    mesh: Cow<'a, str>,
    #[serde(borrow)]
    material: Cow<'a, str>,
    translation_m: [f64; 3],
    orientation_xyzw: [f64; 4],
    scale: [f64; 3],
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Sampler<'a> {
    #[serde(borrow)]
    min_filter: Cow<'a, str>,
    #[serde(borrow)]
    mag_filter: Cow<'a, str>,
    #[serde(borrow)]
    address_u: Cow<'a, str>,
    #[serde(borrow)]
    address_v: Cow<'a, str>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Material<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    #[serde(borrow)]
    alpha_mode: Cow<'a, str>,
    two_sided: bool,
    sampler: Sampler<'a>,
    #[serde(default, deserialize_with = "present")]
    alpha_cutoff: Option<f64>,
    #[serde(default, deserialize_with = "present")]
    base_factor_rgba: Option<[f64; 4]>,
    #[serde(default, deserialize_with = "present")]
    emissive_radiance_factor_cd_m2: Option<[f64; 3]>,
    #[serde(default, deserialize_with = "present")]
    metallic_factor: Option<f64>,
    #[serde(default, deserialize_with = "present")]
    roughness_factor: Option<f64>,
    #[serde(default, deserialize_with = "present")]
    occlusion_strength: Option<f64>,
    #[serde(borrow, default, deserialize_with = "present")]
    base_texture: Option<Cow<'a, str>>,
    #[serde(borrow, default, deserialize_with = "present")]
    orm_texture: Option<Cow<'a, str>>,
    #[serde(borrow, default, deserialize_with = "present")]
    emissive_texture: Option<Cow<'a, str>>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Texture<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    width: u64,
    height: u64,
    #[serde(borrow)]
    format: Cow<'a, str>,
    #[serde(borrow)]
    rgba8: Cow<'a, str>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct LocalLight<'a> {
    #[serde(borrow)]
    id: Cow<'a, str>,
    position_m: [f64; 3],
    luminous_intensity_cd: f64,
    unit_luminance_linear_rec709: [f64; 3],
    radius_m: f64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Identity {
    id: [u8; 16],
    owner: u32,
    kind: u8,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Edge {
    target: [u8; 16],
    owner: u32,
    expected: u8,
}
const ROOT: u8 = 0;
const CAMERA: u8 = 1;
const MESH: u8 = 2;
const INSTANCE: u8 = 3;
const MATERIAL: u8 = 4;
const TEXTURE_SRGB: u8 = 5;
const LIGHT: u8 = 6;
const TEXTURE_LINEAR: u8 = 7;

fn uuid(s: &str) -> Result<[u8; 16], String> {
    let b = s.as_bytes();
    if b.len() != 36 || !matches!(b[14], b'1'..=b'8') || !matches!(b[19], b'8' | b'9' | b'a' | b'b')
    {
        return Err(fail("UUID shape/version"));
    }
    let mut out = [0u8; 16];
    let mut i = 0;
    let mut o = 0;
    while i < 36 {
        if matches!(i, 8 | 13 | 18 | 23) {
            if b[i] != b'-' {
                return Err(fail("UUID hyphen"));
            }
            i += 1;
            continue;
        }
        fn hex(b: u8) -> Option<u8> {
            match b {
                b'0'..=b'9' => Some(b - b'0'),
                b'a'..=b'f' => Some(b - b'a' + 10),
                _ => None,
            }
        }
        let a = hex(b[i]).ok_or_else(|| fail("UUID hex"))?;
        let c = hex(b[i + 1]).ok_or_else(|| fail("UUID hex"))?;
        out[o] = (a << 4) | c;
        i += 2;
        o += 1;
    }
    Ok(out)
}
fn finite(v: f64) -> Result<(), String> {
    if v.is_finite() {
        Ok(())
    } else {
        Err(fail("nonfinite"))
    }
}
fn finite_vec<const N: usize>(v: [f64; N]) -> Result<(), String> {
    for x in v {
        finite(x)?;
    }
    Ok(())
}
fn in_range(v: f64, lo: f64, hi: f64) -> Result<(), String> {
    finite(v)?;
    if (lo..=hi).contains(&v) {
        Ok(())
    } else {
        Err(fail("range"))
    }
}
fn position(p: [f64; 3]) -> Result<(), String> {
    for v in p {
        in_range(v, -1e6, 1e6)?;
    }
    Ok(())
}
fn unit_quat(q: [f64; 4]) -> Result<(), String> {
    finite_vec(q)?;
    let n = q[0].hypot(q[1]).hypot(q[2]).hypot(q[3]);
    if n > 0.0 && (n - 1.0).abs() <= 1e-9 {
        Ok(())
    } else {
        Err(fail("quaternion"))
    }
}
fn colour(c: [f64; 3]) -> Result<(), String> {
    for v in c {
        finite(v)?;
        if v < 0.0 {
            return Err(fail("colour"));
        }
    }
    let y = 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    if (y - 1.0).abs() <= 1e-9 {
        Ok(())
    } else {
        Err(fail("colour Y"))
    }
}
fn unit(v: f64) -> Result<(), String> {
    in_range(v, 0.0, 1.0)
}
fn nonnegative(v: f64) -> Result<(), String> {
    finite(v)?;
    if v >= 0.0 {
        Ok(())
    } else {
        Err(fail("negative"))
    }
}
fn sampler(s: &Sampler<'_>) -> Result<(), String> {
    if !matches!(s.min_filter.as_ref(), "nearest" | "linear")
        || !matches!(s.mag_filter.as_ref(), "nearest" | "linear")
        || !matches!(
            s.address_u.as_ref(),
            "repeat" | "clamp-to-edge" | "mirror-repeat"
        )
        || !matches!(
            s.address_v.as_ref(),
            "repeat" | "clamp-to-edge" | "mirror-repeat"
        )
    {
        Err(fail("sampler"))
    } else {
        Ok(())
    }
}

fn b64value(b: u8) -> Option<u8> {
    match b {
        b'A'..=b'Z' => Some(b - b'A'),
        b'a'..=b'z' => Some(b - b'a' + 26),
        b'0'..=b'9' => Some(b - b'0' + 52),
        b'+' => Some(62),
        b'/' => Some(63),
        _ => None,
    }
}
fn decode_base64(s: &str, expected: usize) -> Result<Vec<u8>, String> {
    let b = s.as_bytes();
    if b.len() % 4 != 0 {
        return Err(fail("base64 length"));
    }
    let pad = if b.ends_with(b"==") {
        2
    } else if b.ends_with(b"=") {
        1
    } else {
        0
    };
    let length = b
        .len()
        .checked_div(4)
        .and_then(|x| x.checked_mul(3))
        .and_then(|x| x.checked_sub(pad))
        .ok_or_else(|| fail("base64 size"))?;
    if length != expected {
        return Err(fail("texture length"));
    }
    let mut out = Vec::with_capacity(expected);
    for (chunk_index, c) in b.chunks_exact(4).enumerate() {
        let last = chunk_index + 1 == b.len() / 4;
        let a = b64value(c[0]).ok_or_else(|| fail("base64 char"))?;
        let bb = b64value(c[1]).ok_or_else(|| fail("base64 char"))?;
        let cc = if c[2] == b'=' && last && pad == 2 {
            0
        } else {
            b64value(c[2]).ok_or_else(|| fail("base64 char"))?
        };
        let dd = if c[3] == b'=' && last && pad > 0 {
            0
        } else {
            b64value(c[3]).ok_or_else(|| fail("base64 char"))?
        };
        if (pad == 2 && last && bb & 15 != 0) || (pad == 1 && last && cc & 3 != 0) {
            return Err(fail("base64 pad bits"));
        }
        out.push((a << 2) | (bb >> 4));
        if !(last && pad == 2) {
            out.push((bb << 4) | (cc >> 2));
        }
        if !(last && pad > 0) {
            out.push((cc << 6) | dd);
        }
    }
    Ok(out)
}

fn push_id(ids: &mut Vec<Identity>, owner: u32, kind: u8, s: &str) -> Result<[u8; 16], String> {
    let id = uuid(s)?;
    ids.push(Identity { id, owner, kind });
    Ok(id)
}
fn parse_item<'a, T: Deserialize<'a>>(r: &'a RawValue) -> Result<T, String> {
    serde_json::from_str(r.get()).map_err(|e| e.to_string())
}

fn decode_root(
    bytes: &[u8],
    owner: u32,
    ids: &mut Vec<Identity>,
    edges: &mut Vec<Edge>,
) -> Result<(usize, usize, usize, usize), String> {
    let nodes = prewalk(bytes)?;
    let root: Root = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
    if root.record_type != "thrum.render.scene" || root.schema != 1 {
        return Err(fail("root type/schema"));
    }
    if root.documentation.is_some_and(|d| d.len() > 4096) {
        return Err(fail("documentation"));
    }
    let mut owned_ids = usize::from(matches!(&root.id, Cow::Owned(_)));
    let root_id = push_id(ids, owner, ROOT, &root.id)?;
    edges.push(Edge {
        target: uuid(&root.fields.active_camera)?,
        owner,
        expected: CAMERA,
    });
    let mut triangles = 0;
    let mut radius_fallbacks = 0;
    for raw in root.fields.cameras {
        let c: Camera = parse_item(raw)?;
        owned_ids += usize::from(matches!(&c.id, Cow::Owned(_)));
        push_id(ids, owner, CAMERA, &c.id)?;
        position(c.position_m)?;
        unit_quat(c.orientation_xyzw)?;
        finite(c.vertical_fov_rad)?;
        if !(c.vertical_fov_rad > 0.0 && c.vertical_fov_rad < std::f64::consts::PI) {
            return Err(fail("fov"));
        }
        finite(c.near_m)?;
        finite(c.far_m)?;
        if !(c.near_m > 0.0 && c.near_m < c.far_m) {
            return Err(fail("projection"));
        }
        finite(c.exposure)?;
        if c.exposure <= 0.0 {
            return Err(fail("exposure"));
        }
    }
    for raw in root.fields.meshes {
        let m: Mesh = parse_item(raw)?;
        owned_ids += usize::from(matches!(&m.id, Cow::Owned(_)));
        push_id(ids, owner, MESH, &m.id)?;
        if m.positions_m.len() != m.uv0.len() {
            return Err(fail("UV count"));
        }
        for p in &m.positions_m {
            finite_vec(*p)?;
            let (inside, fallback) = exact::radius_le_1000(*p);
            radius_fallbacks += usize::from(fallback);
            if !inside {
                return Err(fail("mesh radius"));
            }
        }
        for uv in &m.uv0 {
            finite_vec(*uv)?;
        }
        for tri in &m.triangles {
            let [a, b, c] = *tri;
            if a == b || b == c || a == c {
                return Err(fail("triangle index distinct"));
            }
            let (a, b, c) = (a as usize, b as usize, c as usize);
            if a >= m.positions_m.len() || b >= m.positions_m.len() || c >= m.positions_m.len() {
                return Err(fail("triangle index"));
            }
            if !exact::valid_triangle([m.positions_m[a], m.positions_m[b], m.positions_m[c]]) {
                return Err(fail("triangle degenerate"));
            }
            triangles += 1;
        }
    }
    for raw in root.fields.materials {
        let m: Material = parse_item(raw)?;
        owned_ids += usize::from(matches!(&m.id, Cow::Owned(_)));
        push_id(ids, owner, MATERIAL, &m.id)?;
        if !matches!(m.alpha_mode.as_ref(), "opaque" | "mask") {
            return Err(fail("alpha mode"));
        }
        if (m.alpha_mode == "mask") != m.alpha_cutoff.is_some() {
            return Err(fail("cutoff presence"));
        }
        if let Some(v) = m.alpha_cutoff {
            unit(v)?;
        }
        if let Some(v) = m.base_factor_rgba {
            for x in v {
                unit(x)?;
            }
        }
        if let Some(v) = m.emissive_radiance_factor_cd_m2 {
            for x in v {
                nonnegative(x)?;
            }
        }
        for v in [m.metallic_factor, m.roughness_factor, m.occlusion_strength]
            .into_iter()
            .flatten()
        {
            unit(v)?;
        }
        sampler(&m.sampler)?;
        black_box(m.two_sided);
        for (s, expected) in [
            (m.base_texture, TEXTURE_SRGB),
            (m.orm_texture, TEXTURE_LINEAR),
            (m.emissive_texture, TEXTURE_SRGB),
        ] {
            if let Some(s) = s {
                edges.push(Edge {
                    target: uuid(&s)?,
                    owner,
                    expected,
                });
            }
        }
    }
    for raw in root.fields.textures {
        let t: Texture = parse_item(raw)?;
        owned_ids += usize::from(matches!(&t.id, Cow::Owned(_)));
        let kind = match t.format.as_ref() {
            "rgba8-srgb" => TEXTURE_SRGB,
            "rgba8-linear" => TEXTURE_LINEAR,
            _ => return Err(fail("texture format")),
        };
        push_id(ids, owner, kind, &t.id)?;
        let bytes = t
            .width
            .checked_mul(t.height)
            .and_then(|x| x.checked_mul(4))
            .and_then(|x| usize::try_from(x).ok())
            .ok_or_else(|| fail("texture dimensions"))?;
        if t.width == 0 || t.height == 0 {
            return Err(fail("texture dimensions"));
        }
        black_box(decode_base64(&t.rgba8, bytes)?);
    }
    for raw in root.fields.instances {
        let i: Instance = parse_item(raw)?;
        owned_ids += usize::from(matches!(&i.id, Cow::Owned(_)));
        push_id(ids, owner, INSTANCE, &i.id)?;
        position(i.translation_m)?;
        unit_quat(i.orientation_xyzw)?;
        finite_vec(i.scale)?;
        edges.push(Edge {
            target: uuid(&i.mesh)?,
            owner,
            expected: MESH,
        });
        edges.push(Edge {
            target: uuid(&i.material)?,
            owner,
            expected: MATERIAL,
        });
    }
    for raw in root.fields.local_lights {
        let l: LocalLight = parse_item(raw)?;
        owned_ids += usize::from(matches!(&l.id, Cow::Owned(_)));
        push_id(ids, owner, LIGHT, &l.id)?;
        position(l.position_m)?;
        nonnegative(l.luminous_intensity_cd)?;
        colour(l.unit_luminance_linear_rec709)?;
        nonnegative(l.radius_m)?;
    }
    black_box(root_id);
    Ok((nodes, triangles, owned_ids, radius_fallbacks))
}

fn measure(dir: &Path, roots: usize, overlap: bool) -> Result<(), String> {
    let mut ids = Vec::new();
    let mut edges = Vec::new();
    let mut node_total = 0;
    let mut triangles = 0;
    let mut owned_ids = 0;
    let mut radius_fallbacks = 0;
    let old = if overlap {
        for root in 0..roots {
            let bytes =
                fs::read(dir.join(format!("render-{root}.json"))).map_err(|e| e.to_string())?;
            decode_root(&bytes, root as u32, &mut ids, &mut edges)?;
        }
        ids.sort_unstable_by_key(|x| x.id);
        Some(std::mem::take(&mut ids))
    } else {
        None
    };
    edges.clear();
    let (mut read_ms, mut decode_ms) = (0.0, 0.0);
    let mut bytes_total = 0;
    for root in 0..roots {
        let t = Instant::now();
        let bytes = fs::read(dir.join(format!("render-{root}.json"))).map_err(|e| e.to_string())?;
        read_ms += t.elapsed().as_secs_f64() * 1000.0;
        bytes_total += bytes.len();
        let t = Instant::now();
        let (nodes, tris, owned, fallback) =
            decode_root(&bytes, root as u32, &mut ids, &mut edges)?;
        decode_ms += t.elapsed().as_secs_f64() * 1000.0;
        node_total += nodes;
        triangles += tris;
        owned_ids += owned;
        radius_fallbacks += fallback;
    }
    let t = Instant::now();
    ids.sort_unstable_by_key(|x| x.id);
    if ids.windows(2).any(|p| p[0].id == p[1].id) {
        return Err(fail("duplicate UUID"));
    }
    let sort_ms = t.elapsed().as_secs_f64() * 1000.0;
    let t = Instant::now();
    for e in &edges {
        let j = ids
            .binary_search_by_key(&e.target, |x| x.id)
            .map_err(|_| fail("unresolved edge"))?;
        let x = ids[j];
        if x.kind != e.expected {
            return Err(fail("wrong edge type"));
        }
        if x.owner != e.owner {
            return Err(fail("cross-root edge"));
        }
    }
    let resolve_ms = t.elapsed().as_secs_f64() * 1000.0;
    let mut usage: libc::rusage = unsafe { std::mem::zeroed() };
    if unsafe { libc::getrusage(libc::RUSAGE_SELF, &mut usage) } != 0 {
        return Err(fail("getrusage"));
    }
    let checksum = ids
        .iter()
        .fold(0u64, |a, x| a.wrapping_add(x.id[15] as u64));
    println!(
        "roots={roots} bytes={bytes_total} nodes={node_total} triangles={triangles} radius_fallbacks={radius_fallbacks} ids={} owned_id_strings={owned_ids} edges={} overlap={overlap} identity_size={} edge_size={} id_capacity={} edge_capacity={} read_ms={read_ms:.3} decode_ms={decode_ms:.3} sort_ms={sort_ms:.3} resolve_ms={resolve_ms:.3} maxrss_bytes={} checksum={checksum}",
        ids.len(),
        edges.len(),
        size_of::<Identity>(),
        size_of::<Edge>(),
        ids.capacity(),
        edges.capacity(),
        usage.ru_maxrss
    );
    black_box((ids, edges, old));
    Ok(())
}

fn main() {
    let a: Vec<_> = env::args().collect();
    if a.len() != 4 {
        eprintln!("usage: prototype FIXTURE_DIR ROOTS overlap|single");
        std::process::exit(2);
    }
    if let Err(e) = measure(Path::new(&a[1]), a[2].parse().unwrap(), a[3] == "overlap") {
        eprintln!("REJECT {e}");
        std::process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample() -> String {
        let root = "10000000-0000-4000-8000-000000000001";
        let camera = "10000000-0000-4000-8000-000000000002";
        let mesh = "10000000-0000-4000-8000-000000000003";
        let material = "10000000-0000-4000-8000-000000000004";
        let texture = "10000000-0000-4000-8000-000000000005";
        let instance = "10000000-0000-4000-8000-000000000006";
        let light = "10000000-0000-4000-8000-000000000007";
        format!(
            r#"{{"id":"{root}","type":"thrum.render.scene","schema":1,"fields":{{"active_camera":"{camera}","cameras":[{{"id":"{camera}","position_m":[0,0,5],"orientation_xyzw":[0,0,0,1],"vertical_fov_rad":1,"near_m":0.1,"far_m":20,"exposure":0.0001}}],"meshes":[{{"id":"{mesh}","positions_m":[[0,0,0],[1,0,0],[0,1,0]],"uv0":[[0,0],[1,0],[0,1]],"triangles":[[0,1,2]]}}],"materials":[{{"id":"{material}","alpha_mode":"mask","alpha_cutoff":0.5,"two_sided":false,"sampler":{{"min_filter":"linear","mag_filter":"linear","address_u":"repeat","address_v":"repeat"}},"base_texture":"{texture}"}}],"textures":[{{"id":"{texture}","width":1,"height":1,"format":"rgba8-srgb","rgba8":"/wAA/w=="}}],"instances":[{{"id":"{instance}","mesh":"{mesh}","material":"{material}","translation_m":[0,0,0],"orientation_xyzw":[0,0,0,1],"scale":[1,1,1]}}],"local_lights":[{{"id":"{light}","position_m":[0,0,3],"luminous_intensity_cd":1,"unit_luminance_linear_rec709":[1,1,1],"radius_m":0.1}}]}}}}"#
        )
    }

    fn decode(s: &str) -> Result<(usize, usize, usize, usize), String> {
        let mut ids = Vec::new();
        let mut edges = Vec::new();
        let (nodes, triangles, _, _) = decode_root(s.as_bytes(), 0, &mut ids, &mut edges)?;
        ids.sort_unstable_by_key(|x| x.id);
        if ids.windows(2).any(|p| p[0].id == p[1].id) {
            return Err(fail("duplicate UUID"));
        }
        for e in &edges {
            let i = ids
                .binary_search_by_key(&e.target, |x| x.id)
                .map_err(|_| fail("missing"))?;
            if ids[i].kind != e.expected {
                return Err(fail("wrong type"));
            }
        }
        Ok((nodes, triangles, ids.len(), edges.len()))
    }

    fn projection(s: &str) -> Result<(usize, usize, Vec<Identity>, Vec<Edge>), String> {
        let mut ids = Vec::new();
        let mut edges = Vec::new();
        let (_, triangles, owned, _) = decode_root(s.as_bytes(), 0, &mut ids, &mut edges)?;
        ids.sort_unstable_by_key(|x| x.id);
        edges.sort_unstable_by_key(|x| (x.target, x.owner, x.expected));
        Ok((triangles, owned, ids, edges))
    }

    #[test]
    fn complete_sample_and_mutants() {
        let good = sample();
        let (_, triangles, ids, edges) = decode(&good).unwrap();
        assert_eq!((triangles, ids, edges), (1, 7, 4));
        let on_radius = good.replace("[0,1,0]],\"uv0\"", "[600,800,0]],\"uv0\"");
        assert!(decode(&on_radius).is_ok());
        let cases = [
            (
                good.replace(
                    "\"position_m\":[0,0,5]",
                    "\"id\":\"10000000-0000-4000-8000-000000000002\",\"position_m\":[0,0,5]",
                ),
                "duplicate",
            ),
            (
                good.replace(
                    "\"alpha_mode\":\"mask\"",
                    "\"normal_texture\":null,\"alpha_mode\":\"mask\"",
                ),
                "unknown",
            ),
            (good.replace("\"alpha_cutoff\":0.5,", ""), "missing cutoff"),
            (
                good.replace(
                    "\"base_texture\":\"10000000-0000-4000-8000-000000000005\"",
                    "\"base_texture\":null",
                ),
                "null reference",
            ),
            (
                good.replace("[0,1,0]],\"uv0\"", "[2,0,0]],\"uv0\""),
                "degenerate",
            ),
            (
                good.replace("[0,1,0]],\"uv0\"", "[600,800,0.000001]],\"uv0\""),
                "exact radius boundary",
            ),
            (good.replace("/wAA/w==", "/wAA/x=="), "noncanonical base64"),
            (good.replace("rgba8-srgb", "rgba8-linear"), "wrong transfer"),
            (
                good.replace(
                    "10000000-0000-4000-8000-000000000007",
                    "10000000-0000-4000-8000-000000000002",
                ),
                "duplicate embedded UUID",
            ),
        ];
        for (bad, name) in cases {
            assert!(decode(&bad).is_err(), "{name}");
        }
    }

    #[test]
    fn escaped_spellings_keep_the_same_typed_projection() {
        let good = sample();
        let escaped = good
            .replacen(
                "\"id\":\"10000000-0000-4000-8000-000000000001\"",
                "\"\\u0069d\":\"\\u00310000000-0000-4000-8000-000000000001\"",
                1,
            )
            .replace(
                "\"type\":\"thrum.render.scene\"",
                "\"type\":\"\\u0074hrum.render.scene\"",
            )
            .replace(
                "\"active_camera\":\"10000000",
                "\"active_camera\":\"\\u00310000000",
            )
            .replace(
                "\"alpha_mode\":\"mask\"",
                "\"\\u0061lpha_mode\":\"\\u006dask\"",
            )
            .replace(
                "\"min_filter\":\"linear\"",
                "\"\\u006din_filter\":\"\\u006cinear\"",
            )
            .replace(
                "\"base_texture\":\"10000000",
                "\"\\u0062ase_texture\":\"\\u00310000000",
            )
            .replace(
                "\"format\":\"rgba8-srgb\"",
                "\"format\":\"\\u0072gba8-srgb\"",
            )
            .replace("/wAA/w==", r"\/wAA\/w==");
        assert_ne!(good.as_bytes(), escaped.as_bytes());
        let original = projection(&good).unwrap();
        let reencoded = projection(&escaped).unwrap();
        assert_eq!(original.0, reencoded.0);
        assert_eq!(original.2, reencoded.2);
        assert_eq!(original.3, reencoded.3);
        assert!(reencoded.1 > 0, "escaped IDs should use owned fallback");

        let duplicate_key = good.replace(
            "\"position_m\":[0,0,5]",
            "\"\\u0069d\":\"10000000-0000-4000-8000-000000000002\",\"position_m\":[0,0,5]",
        );
        assert!(decode(&duplicate_key).is_err());
        let unknown_key = good.replace(
            "\"alpha_mode\":\"mask\"",
            "\"\\u006eormal_texture\":null,\"alpha_mode\":\"mask\"",
        );
        assert!(decode(&unknown_key).is_err());
    }

    #[test]
    fn outward_radius_filter_agrees_with_exact_boundary() {
        let tiny = f64::from_bits(1);
        let cases = [
            [0.0, 0.0, 0.0],
            [1000.0, 0.0, 0.0],
            [600.0, 800.0, 0.0],
            [600.0, 800.0, tiny],
            [600.0, 800.0, -tiny],
            [600.0, 800.0, 0.000001],
            [600.0, 799.0, 0.0],
            [999.0, 0.0, 0.0],
            [1000.0, tiny, 0.0],
            [1000.0, 1000.0, 0.0],
        ];
        for p in cases {
            assert_eq!(
                exact::radius_le_1000(p).0,
                exact::radius_le_1000_reference(p)
            );
        }
        assert!(!exact::radius_le_1000([600.0, 800.0, tiny]).0);
        assert!(exact::radius_le_1000([600.0, 800.0, tiny]).1);
        assert!(exact::radius_le_1000([600.0, 800.0, 0.0]).0);
        let mut state = 0x9e37_79b9_7f4a_7c15_u64;
        for _ in 0..4096 {
            let mut p = [0.0; 3];
            for x in &mut p {
                state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
                *x = ((state >> 17) % 2_000_001) as f64 / 1000.0 - 1000.0;
            }
            assert_eq!(
                exact::radius_le_1000(p).0,
                exact::radius_le_1000_reference(p)
            );
        }
    }

    #[test]
    fn bounded_no_tree_prewalk() {
        let mut almost = String::with_capacity(2 * MAX_NODES);
        almost.push('[');
        almost.push_str(&"0,".repeat(MAX_NODES - 2));
        almost.push('0');
        almost.push(']');
        assert_eq!(prewalk(almost.as_bytes()).unwrap(), MAX_NODES);
        almost.insert(almost.len() - 1, ',');
        almost.insert(almost.len() - 1, '0');
        assert!(
            prewalk(almost.as_bytes())
                .unwrap_err()
                .contains("node limit")
        );
        let deep = format!(
            "{}0{}",
            "[".repeat(MAX_DEPTH + 1),
            "]".repeat(MAX_DEPTH + 1)
        );
        assert!(
            prewalk(deep.as_bytes())
                .unwrap_err()
                .contains("depth limit")
        );
        assert!(
            prewalk(&vec![b' '; MAX_BYTES + 1])
                .unwrap_err()
                .contains("byte limit")
        );
    }
}
