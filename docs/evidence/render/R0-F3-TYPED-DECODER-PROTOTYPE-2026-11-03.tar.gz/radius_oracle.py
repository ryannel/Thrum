"""Independent Python-rational checks for decoded binary64 radius cases."""

from fractions import Fraction
from math import nextafter, inf


def within(point: tuple[float, float, float]) -> bool:
    return sum((Fraction.from_float(x) ** 2 for x in point), Fraction()) <= 1_000_000


cases = {
    "on_boundary": ((600.0, 800.0, 0.0), True),
    "tiny_outside": ((600.0, 800.0, float.fromhex("0x0.0000000000001p-1022")), False),
    "epsilon_outside": ((600.0, 800.0, 1e-6), False),
    "one_ulp_outside": ((nextafter(600.0, inf), 800.0, 0.0), False),
    "one_ulp_inside": ((nextafter(600.0, -inf), 800.0, 0.0), True),
}
for name, (point, expected) in cases.items():
    actual = within(point)
    assert actual == expected, (name, actual, expected)
    print(f"{name}: {'inside' if actual else 'outside'}")
