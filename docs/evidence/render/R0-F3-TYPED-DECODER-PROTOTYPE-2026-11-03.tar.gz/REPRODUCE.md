# R0 typed-decoder prototype reproduction

This archive is an isolated experiment. Its `prototype` is not the production
`thrum-source` decoder. Generated JSON fixtures and Cargo target directories
are intentionally omitted.

From an extracted archive directory on a host with the locked crates cached:

```sh
RUSTC_WRAPPER= cargo test --offline --manifest-path prototype/Cargo.toml
RUSTC_WRAPPER= cargo build --offline --release --manifest-path prototype/Cargo.toml
RUSTC_WRAPPER= cargo build --offline --release --manifest-path baseline/Cargo.toml
baseline/target/release/r0-embedded-index-probe generate-lights fixture-lights 4 83000
baseline/target/release/r0-embedded-index-probe generate fixture-mixed 2 75000
python3 generate_geometry_texture.py fixture-geometry/render-0.json
python3 generate_geometry_texture.py fixture-boundary/render-0.json --boundary
python3 generate_escaped.py fixture-lights fixture-lights-escaped
python3 verify_escaped.py fixture-lights fixture-lights-escaped
python3 radius_oracle.py
python3 verify_fixture.py fixture-lights/render-0.json fixture-mixed/render-0.json fixture-geometry/render-0.json fixture-boundary/render-0.json fixture-lights-escaped/render-0.json
prototype/target/release/r0-typed-decoder-prototype fixture-lights 4 single
prototype/target/release/r0-typed-decoder-prototype fixture-lights 4 overlap
prototype/target/release/r0-typed-decoder-prototype fixture-lights-escaped 4 single
prototype/target/release/r0-typed-decoder-prototype fixture-lights-escaped 4 overlap
prototype/target/release/r0-typed-decoder-prototype fixture-mixed 2 single
prototype/target/release/r0-typed-decoder-prototype fixture-geometry 1 single
prototype/target/release/r0-typed-decoder-prototype fixture-geometry 1 overlap
prototype/target/release/r0-typed-decoder-prototype fixture-boundary 1 single
```

Repeat each measurement in five fresh serial processes for the retained raw
run distributions. The baseline executable's `measure` mode uses the same
generated fixture paths; its generic `Value` extraction omits material texture
edges and source semantic validation, so the CPU times are not equivalent
work. Regenerated fixture hashes are in the evidence note. The source of
`prototype/src/exact.rs` adapts the earlier
`R0-F3-EXACT-TRIANGLE-PROBE-2026-11-03.tar.gz` experiment: its triangle hook
uses exact dyadic arithmetic; the added local-radius check uses an outward
binary64 interval filter and exact fallback. Boundary-source vertices invoke
the fallback. The interval proof assumes IEEE round-to-nearest and gradual
underflow; production target/compiler qualification remains open.
