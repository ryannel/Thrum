"""Generate a bounded, complete render-root stress record for the prototype."""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
import sys


def uid(value: int) -> str:
    return f"00000000-0000-4000-8000-{value:012x}"


def write(path: Path, triangles: int = 25_000, lights: int = 28_000, boundary: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    base = 5_000_000
    root, camera, mesh, material, texture, instance = [uid(base + i) for i in range(6)]
    image_side = 1280
    pixels = bytes((i * 17 + 29) % 256 for i in range(image_side * image_side * 4))
    encoded = base64.b64encode(pixels).decode("ascii")
    with path.open("w", encoding="utf-8") as out:
        out.write(json.dumps({"id": root, "type": "thrum.render.scene", "schema": 1}, separators=(",", ":"))[:-1])
        out.write(',"fields":{"active_camera":')
        out.write(json.dumps(camera))
        out.write(',"cameras":[')
        out.write(json.dumps({"id": camera, "position_m": [0, 0, 5], "orientation_xyzw": [0, 0, 0, 1], "vertical_fov_rad": 1, "near_m": 0.1, "far_m": 20, "exposure": 0.0001}, separators=(",", ":")))
        out.write('],"meshes":[{"id":')
        out.write(json.dumps(mesh))
        out.write(',"positions_m":[')
        for i in range(triangles):
            if i:
                out.write(",")
            x, y = (i % 100) / 100, ((i // 100) % 100) / 100
            positions = [[600, 800, 0], [-600, 800, 0], [600, -800, 0]] if boundary else [[x, y, 0], [x + 0.001, y, 0], [x, y + 0.001, 0]]
            out.write(json.dumps(positions, separators=(",", ":"))[1:-1])
        out.write('],"uv0":[')
        for i in range(triangles):
            if i:
                out.write(",")
            out.write("[0,0],[1,0],[0,1]")
        out.write('],"triangles":[')
        for i in range(triangles):
            if i:
                out.write(",")
            out.write(f"[{3*i},{3*i+1},{3*i+2}]")
        out.write(']}],"materials":[')
        out.write(json.dumps({"id": material, "alpha_mode": "mask", "alpha_cutoff": 0.5, "two_sided": False,
                              "sampler": {"min_filter": "linear", "mag_filter": "linear", "address_u": "repeat", "address_v": "repeat"},
                              "base_texture": texture}, separators=(",", ":")))
        out.write('],"textures":[')
        out.write(json.dumps({"id": texture, "width": image_side, "height": image_side, "format": "rgba8-srgb", "rgba8": encoded}, separators=(",", ":")))
        out.write('],"instances":[')
        out.write(json.dumps({"id": instance, "mesh": mesh, "material": material, "translation_m": [0, 0, 0],
                              "orientation_xyzw": [0, 0, 0, 1], "scale": [1, 1, 1]}, separators=(",", ":")))
        out.write('],"local_lights":[')
        for i in range(lights):
            if i:
                out.write(",")
            out.write(json.dumps({"id": uid(base + 6 + i), "position_m": [0, 0, 3], "luminous_intensity_cd": 1,
                                  "unit_luminance_linear_rec709": [1, 1, 1], "radius_m": 0.1}, separators=(",", ":")))
        out.write("]}}")
    data = path.read_bytes()
    print(f"path={path} bytes={len(data)} sha256={hashlib.sha256(data).hexdigest()} triangles={triangles} lights={lights}")


if __name__ == "__main__":
    write(Path(sys.argv[1]), boundary=len(sys.argv) > 2 and sys.argv[2] == "--boundary")
