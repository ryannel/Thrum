"""Re-encode every light-heavy fixture ID key/value without changing meaning."""

from pathlib import Path
import hashlib
import re
import sys

source = Path(sys.argv[1])
target = Path(sys.argv[2])
target.mkdir(parents=True, exist_ok=True)
pattern = re.compile(rb'"id":"0')
for path in sorted(source.glob("render-*.json")):
    original = path.read_bytes()
    escaped, count = pattern.subn(lambda _: b'"\\u0069d":"\\u0030', original)
    if count == 0:
        raise RuntimeError(f"no ID keys in {path}")
    out = target / path.name
    out.write_bytes(escaped)
    print(f"{out} bytes={len(escaped)} escaped_ids={count} sha256={hashlib.sha256(escaped).hexdigest()}")
