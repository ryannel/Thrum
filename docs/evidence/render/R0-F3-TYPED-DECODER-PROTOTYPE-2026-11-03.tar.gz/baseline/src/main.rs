use std::env;
use std::fs::{self, File};
use std::io::{BufWriter, Write};
use std::mem::size_of;
use std::path::Path;
use std::time::Instant;

#[derive(Clone, Copy, Eq, PartialEq, Ord, PartialOrd)]
#[repr(C)]
struct Identity {
    id: [u8; 16],
    owner: u32,
    kind: u8,
}

#[derive(Clone, Copy)]
struct Edge {
    target: [u8; 16],
    owner: u32,
    expected: u8,
}

fn uuid(value: u64) -> String {
    format!("00000000-0000-4000-8000-{value:012x}")
}

fn permuted(i: usize, n: usize) -> u64 {
    // 32771 is coprime with all selected fixture counts. This defeats the
    // already-sorted input shortcut without changing the UUID population.
    ((i * 32771 + 7919) % n) as u64
}

fn parse_uuid(value: &str) -> [u8; 16] {
    assert_eq!(value.len(), 36);
    let b = value.as_bytes();
    let mut out = [0; 16];
    let mut o = 0;
    let mut i = 0;
    while i < 36 {
        if matches!(i, 8 | 13 | 18 | 23) {
            assert_eq!(b[i], b'-');
            i += 1;
            continue;
        }
        out[o] = (hex(b[i]) << 4) | hex(b[i + 1]);
        o += 1;
        i += 2;
    }
    out
}

fn hex(b: u8) -> u8 {
    match b {
        b'0'..=b'9' => b - b'0',
        b'a'..=b'f' => b - b'a' + 10,
        _ => panic!("noncanonical UUID hex"),
    }
}

fn generate(dir: &Path, roots: usize, per_root: usize, with_instances: bool) {
    fs::create_dir_all(dir).unwrap();
    for root in 0..roots {
        let base = (root as u64 + 1) * 1_000_000;
        let path = dir.join(format!("render-{root}.json"));
        let mut out = BufWriter::new(File::create(&path).unwrap());
        let root_id = uuid(base);
        let camera = uuid(base + 1);
        let mesh = uuid(base + 2);
        let material = uuid(base + 3);
        write!(out, "{{\"id\":\"{root_id}\",\"type\":\"thrum.render.scene\",\"schema\":1,\"fields\":{{\"active_camera\":\"{camera}\",\"cameras\":[{{\"id\":\"{camera}\",\"position_m\":[0,0,5],\"orientation_xyzw\":[0,0,0,1],\"vertical_fov_rad\":1,\"near_m\":0.1,\"far_m\":20,\"exposure\":0.0001}}],\"meshes\":[{{\"id\":\"{mesh}\",\"positions_m\":[[0,0,0],[1,0,0],[0,1,0]],\"uv0\":[[0,0],[1,0],[0,1]],\"triangles\":[[0,1,2]]}}],\"materials\":[{{\"id\":\"{material}\",\"alpha_mode\":\"opaque\",\"two_sided\":false,\"sampler\":{{\"min_filter\":\"linear\",\"mag_filter\":\"linear\",\"address_u\":\"repeat\",\"address_v\":\"repeat\"}}}}],\"textures\":[],\"instances\":[").unwrap();
        let instances = if with_instances { per_root / 5 } else { 0 };
        for i in 0..instances {
            if i > 0 { write!(out, ",").unwrap(); }
            let id = uuid(base + 4 + permuted(i, per_root));
            write!(out, "{{\"id\":\"{id}\",\"mesh\":\"{mesh}\",\"material\":\"{material}\",\"translation_m\":[0,0,0],\"orientation_xyzw\":[0,0,0,1],\"scale\":[1,1,1]}}").unwrap();
        }
        write!(out, "],\"local_lights\":[").unwrap();
        for i in instances..per_root {
            if i > instances { write!(out, ",").unwrap(); }
            let id = uuid(base + 4 + permuted(i, per_root));
            write!(out, "{{\"id\":\"{id}\",\"position_m\":[0,0,3],\"luminous_intensity_cd\":1,\"unit_luminance_linear_rec709\":[1,1,1],\"radius_m\":0.1}}").unwrap();
        }
        write!(out, "]}}}}").unwrap();
        out.flush().unwrap();
        let bytes = fs::metadata(&path).unwrap().len();
        assert!(bytes <= 16 * 1024 * 1024, "root {root} is {bytes} bytes");
        eprintln!("fixture root={root} ids={} bytes={bytes}", per_root + 3);
    }
}

fn extract(dir: &Path, roots: usize) -> (Vec<Identity>, Vec<Edge>, u64, f64, f64, f64) {
    let mut ids = Vec::new();
    let mut edges = Vec::new();
    let mut bytes_total = 0;
    let (mut read_ms, mut parse_ms, mut extract_ms) = (0.0, 0.0, 0.0);
    for root in 0..roots {
        let start = Instant::now();
        let bytes = fs::read(dir.join(format!("render-{root}.json"))).unwrap();
        read_ms += start.elapsed().as_secs_f64() * 1000.0;
        bytes_total += bytes.len() as u64;
        let start = Instant::now();
        let value: serde_json::Value = serde_json::from_slice(&bytes).unwrap();
        parse_ms += start.elapsed().as_secs_f64() * 1000.0;
        let start = Instant::now();
        let fields = value.get("fields").unwrap();
        let root_id = parse_uuid(value.get("id").unwrap().as_str().unwrap());
        ids.push(Identity { id: root_id, owner: root as u32, kind: 0 });
        for (field, kind) in [("cameras", 1), ("meshes", 2), ("instances", 3), ("materials", 4), ("textures", 5), ("local_lights", 6)] {
            for item in fields.get(field).unwrap().as_array().unwrap() {
                let id = parse_uuid(item.get("id").unwrap().as_str().unwrap());
                ids.push(Identity { id, owner: root as u32, kind });
                if kind == 3 {
                    edges.push(Edge { target: parse_uuid(item.get("mesh").unwrap().as_str().unwrap()), owner: root as u32, expected: 2 });
                    edges.push(Edge { target: parse_uuid(item.get("material").unwrap().as_str().unwrap()), owner: root as u32, expected: 4 });
                }
            }
        }
        edges.push(Edge { target: parse_uuid(fields.get("active_camera").unwrap().as_str().unwrap()), owner: root as u32, expected: 1 });
        extract_ms += start.elapsed().as_secs_f64() * 1000.0;
    }
    (ids, edges, bytes_total, read_ms, parse_ms, extract_ms)
}

fn measure(dir: &Path, roots: usize, overlap: bool) {
    let old = if overlap {
        let mut prior = extract(dir, roots).0;
        prior.sort_unstable_by_key(|item| item.id);
        Some(prior)
    } else {
        None
    };
    let (mut ids, edges, bytes, read_ms, parse_ms, extract_ms) = extract(dir, roots);
    let start = Instant::now();
    ids.sort_unstable_by_key(|item| item.id);
    assert!(ids.windows(2).all(|pair| pair[0].id != pair[1].id));
    let sort_ms = start.elapsed().as_secs_f64() * 1000.0;
    let start = Instant::now();
    for edge in &edges {
        let found = ids.binary_search_by_key(&edge.target, |item| item.id).unwrap();
        let target = ids[found];
        assert_eq!(target.kind, edge.expected);
        assert_eq!(target.owner, edge.owner);
    }
    let resolve_ms = start.elapsed().as_secs_f64() * 1000.0;
    let checksum = ids.iter().fold(0_u64, |v, item| v.wrapping_add(u64::from(item.id[15])));
    let mut usage: libc::rusage = unsafe { std::mem::zeroed() };
    assert_eq!(unsafe { libc::getrusage(libc::RUSAGE_SELF, &mut usage) }, 0);
    println!("roots={roots} bytes={bytes} ids={} edges={} overlap={} identity_size={} edge_size={} id_capacity={} edge_capacity={} read_ms={read_ms:.3} parse_ms={parse_ms:.3} extract_ms={extract_ms:.3} sort_ms={sort_ms:.3} resolve_ms={resolve_ms:.3} maxrss_bytes={} checksum={checksum}", ids.len(), edges.len(), overlap, size_of::<Identity>(), size_of::<Edge>(), ids.capacity(), edges.capacity(), usage.ru_maxrss);
    std::hint::black_box((ids, edges, old));
}

fn main() {
    let args: Vec<_> = env::args().collect();
    assert_eq!(args.len(), 5, "usage: probe generate|measure DIR ROOTS IDS_PER_ROOT|overlap");
    let dir = Path::new(&args[2]);
    let roots = args[3].parse::<usize>().unwrap();
    match args[1].as_str() {
        "generate" => generate(dir, roots, args[4].parse().unwrap(), true),
        "generate-lights" => generate(dir, roots, args[4].parse().unwrap(), false),
        "measure" => measure(dir, roots, args[4] == "overlap"),
        _ => panic!("mode"),
    }
}
