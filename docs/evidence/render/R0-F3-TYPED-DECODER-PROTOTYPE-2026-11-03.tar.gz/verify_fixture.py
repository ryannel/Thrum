"""Independent structural count for generated render-root JSON fixtures."""

import base64
import json
from pathlib import Path
import sys


def nodes(value):
    if isinstance(value, dict):
        return 1 + sum(nodes(child) for child in value.values())
    if isinstance(value, list):
        return 1 + sum(nodes(child) for child in value)
    return 1


for name in sys.argv[1:]:
    path = Path(name)
    root = json.loads(path.read_bytes())
    fields = root["fields"]
    identities = 1 + sum(len(fields[key]) for key in (
        "cameras", "meshes", "instances", "materials", "textures", "local_lights"
    ))
    edges = 1 + 2 * len(fields["instances"]) + sum(
        key in material for material in fields["materials"]
        for key in ("base_texture", "orm_texture", "emissive_texture")
    )
    triangles = sum(len(mesh["triangles"]) for mesh in fields["meshes"])
    texture_bytes = sum(len(base64.b64decode(texture["rgba8"], validate=True)) for texture in fields["textures"])
    print(f"{path} bytes={path.stat().st_size} nodes={nodes(root)} ids={identities} edges={edges} triangles={triangles} texture_bytes={texture_bytes}")
