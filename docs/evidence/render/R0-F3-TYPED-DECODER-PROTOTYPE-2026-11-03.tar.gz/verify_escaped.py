"""Independently compare escaped and ordinary generated JSON values."""

import json
from pathlib import Path
import sys

ordinary = Path(sys.argv[1])
escaped = Path(sys.argv[2])
for path in sorted(ordinary.glob("render-*.json")):
    a = path.read_bytes()
    b = (escaped / path.name).read_bytes()
    if a == b or json.loads(a) != json.loads(b):
        raise RuntimeError(f"not an exact semantic re-encoding: {path.name}")
    print(f"{path.name}: decoded JSON values equal; exact bytes differ")
