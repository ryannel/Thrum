#!/usr/bin/env python3
"""Verify portable package members and selected exact readbacks; no GPU needed."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for line in (ROOT/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert sha(ROOT/name)==digest,name
original=ROOT/'r0-exact-dot-u32-lattice-v1'
for line in (original/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    assert sha(original/name)==digest,'retained baseline '+name
provenance=json.loads((ROOT/'PROVENANCE.json').read_text())
for name,digest in provenance['source_sha256'].items(): assert sha(ROOT/name)==digest,name
assert sha(ROOT/'harness-v1')==provenance['binary_sha256']['v1']
assert sha(ROOT/'harness-v2')==provenance['binary_sha256']['v2']
package=json.loads((ROOT/'PACKAGE.json').read_text())
for output,expected in package['selected_readbacks'].items():
    a=(ROOT/output).read_bytes();e=(ROOT/expected).read_bytes()
    assert a==e,output
    print(output,'oracle_match=pass','records',len(a)//68,'sha256',hashlib.sha256(a).hexdigest())
print('All portable member hashes, original 26 member hashes and selected full-ABI comparisons pass.')
