#!/usr/bin/env python3
"""Serialized same-process A/B/A measurements. No concurrent GPU jobs."""
import datetime,hashlib,json,subprocess,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
binary=ROOT/'target/release/r0-exact-dot-gpu'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,inp,expected,stride,variants):
    args=[str(binary),inp,expected,name,str(stride),os.getenv('R0_ROUNDS','8'),*variants]
    metadata={'command':args,'cwd':str(ROOT),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'binary_sha256':sha(binary),'host_sha256':sha(ROOT/'src/main.rs'),
        'input_sha256':sha(ROOT/inp),'expected_sha256':sha(ROOT/expected),
        'shader_sha256':{v:sha(ROOT/v) for v in variants},'protocol_version':2,
        'dispatches_per_pass':int(os.getenv('R0_DISPATCHES','1')),
        'thermal_before':subprocess.run(['pmset','-g','therm'],capture_output=True,text=True).stdout,
        'measurement_lease':'Coordinator reserved M3 Max; serialized passes and copy/resolve; no other task GPU measurements.'}
    with (ROOT/(name+'.log')).open('w') as log:
        p=subprocess.run(args,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    metadata.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=p.returncode,log_sha256=sha(ROOT/(name+'.log')))
    (ROOT/(name+'.execution.json')).write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
    print(name,'exit',p.returncode,flush=True)
    if p.returncode:raise SystemExit(p.returncode)
mode=sys.argv[1]
full=['baseline.wgsl','limb_extract.wgsl','signed_sparse.wgsl']
compact=[s.replace('.wgsl','_compact.wgsl') for s in full]
if mode=='full':
    for i in [2,3]:run(f'corpus-full-{i}','r0-exact-dot-u32-lattice-v1/inputs.bin','r0-exact-dot-u32-lattice-v1/expected.bin',17,full)
elif mode=='compact':
    run('corpus-compact-1','r0-exact-dot-u32-lattice-v1/inputs.bin','corpus.expected7.bin',7,compact)
    for i in [1,2,3]:
        names=['normal','all_ambiguous'] if i%2 else ['all_ambiguous','normal']
        for name in names:run(f'{name}-compact-{i}',f'{name}.inputs.bin',f'{name}.expected7.bin',7,compact)
elif mode=='extra':
    run('corpus-full-4','r0-exact-dot-u32-lattice-v1/inputs.bin','r0-exact-dot-u32-lattice-v1/expected.bin',17,full)
    for name in ['normal','all_ambiguous']:
        run(name+'-base-full',name+'.base-inputs.bin',name+'.base-expected17.bin',17,full)
elif mode=='controls':
    for name in ['normal','all_ambiguous']:
        for candidate in ['baseline','signed_sparse']:
            run(name+'-'+candidate+'-aa',name+'.inputs.bin',name+'.expected7.bin',7,[candidate+'_compact.wgsl',candidate+'_compact_copy.wgsl'])
elif mode=='1080p':
    for name in ['normal','all_ambiguous']:
        run(name+'-1080p-five-dot-count',name+'.1080p-inputs.bin',name+'.1080p-expected7.bin',7,compact)
elif mode=='scale-control':
    dispatches=int(os.getenv('R0_DISPATCHES','1'))
    for name in ['normal','all_ambiguous']:
        if dispatches==1:
            run(name+'-1080p-one-dot-count',name+'.1080p-inputs.bin',name+'.1080p-expected7.bin',7,compact)
        elif dispatches==5:
            run(name+'-1m-five-dot-count',name+'.inputs.bin',name+'.expected7.bin',7,compact)
        else:raise SystemExit('control dispatches must be 1 or 5')
elif mode=='recheck':
    for name in ['normal','all_ambiguous']:
        run(name+'-1m-one-recheck',name+'.inputs.bin',name+'.expected7.bin',7,compact)
else:raise SystemExit('full, compact, extra, controls, 1080p, scale-control or recheck')
