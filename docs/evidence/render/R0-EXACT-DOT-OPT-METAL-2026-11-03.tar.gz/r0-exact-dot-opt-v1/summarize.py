#!/usr/bin/env python3
"""Parse raw timings and verify all retained selected outputs, without editing them."""
from pathlib import Path
import hashlib,json,re,statistics
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results={}
for path in sorted(ROOT.glob('*.execution.json')):
    record=json.loads(path.read_text()); name=path.name.removesuffix('.execution.json')
    log=ROOT/(name+'.log')
    assert sha(log)==record['log_sha256']
    for p,h in record['shader_sha256'].items():assert sha(ROOT/p)==h
    assert record['binary_sha256'] in {sha(ROOT/'target/release/r0-exact-dot-gpu'),sha(ROOT/'harness-v1')}
    assert record['host_sha256'] in {sha(ROOT/'src/main.rs'),sha(ROOT/'harness-v1.rs')}
    command=record['command']; assert sha(ROOT/command[1])==record['input_sha256'];assert sha(ROOT/command[2])==record['expected_sha256']
    samples=[]
    for line in log.read_text().splitlines():
        if line.startswith('sequence='):
            p=dict(re.findall(r'(\w+)=([^ ]+)',line))
            p={k:int(v) if k in ['sequence','round','gpu_begin','gpu_end','gpu_ns','encode_submit_completion_us'] else v for k,v in p.items()}
            assert p['gpu_end']>p['gpu_begin']>0 and p['oracle_match']=='pass'
            samples.append(p)
    assert 'all_dispatches_oracle_match=pass' in log.read_text()
    measured=[p for p in samples if p['phase']=='measured']; names=list(dict.fromkeys(p['candidate'] for p in measured)); baseline=names[0]
    summaries={}
    for candidate in names:
        v=[p['gpu_ns'] for p in measured if p['candidate']==candidate]
        pairs=[]
        for i,p in enumerate(measured):
            if p['candidate']!=candidate or candidate==baseline:continue
            before=measured[i-1]; after=measured[i+1];assert before['candidate']==after['candidate']==baseline
            paired_a=(before['gpu_ns']+after['gpu_ns'])/2
            pairs.append({'round':p['round'],'baseline_before_ns':before['gpu_ns'],'candidate_ns':p['gpu_ns'],'baseline_after_ns':after['gpu_ns'],'ratio_baseline_to_candidate':paired_a/p['gpu_ns'],'candidate_fraction_of_baseline':p['gpu_ns']/paired_a})
        summaries[candidate]={'measured_samples':len(v),'median_gpu_ns':statistics.median(v),'min_gpu_ns':min(v),'max_gpu_ns':max(v),'bracketed_pairs':pairs}
        if pairs:
            ratios=[x['ratio_baseline_to_candidate'] for x in pairs]
            summaries[candidate]['median_bracketed_ratio']=statistics.median(ratios)
            summaries[candidate]['range_bracketed_ratio']=[min(ratios),max(ratios)]
    output_checks={}
    expected=(ROOT/command[2]).read_bytes()
    for shader in record['shader_sha256']:
        p=ROOT/name/(Path(shader).stem+'.bin');actual=p.read_bytes();assert actual==expected
        output_checks[p.name]={'bytes':len(actual),'sha256':sha(p),'oracle_match':True}
    input_records=(ROOT/command[1]).stat().st_size//24;dispatches=record.get('dispatches_per_pass',1)
    results[name]={'cases_per_dispatch':input_records,'dispatches_per_pass':dispatches,'exact_dots_per_pass':input_records*dispatches,'stride_words':int(command[4]),'source_execution':path.name,'all_dispatches':len(samples),'summaries':summaries,'selected_outputs':output_checks}
# Explicitly check execution intervals, including all final blocks and controls.
intervals=sorted((json.loads(p.read_text())['start_utc'],json.loads(p.read_text())['end_utc'],p.name) for p in ROOT.glob('*.execution.json'))
for a,b in zip(intervals,intervals[1:]): assert a[1]<=b[0],('GPU measurement overlap',a,b)
(ROOT/'results.json').write_text(json.dumps({'version':1,'measurement_intervals_nonoverlapping':True,'runs':results},indent=2,sort_keys=True)+'\n')
for name,r in results.items():
 print(name, {Path(k).stem:round(v['median_gpu_ns']/1e6,6) for k,v in r['summaries'].items()})
print('All execution metadata/log hashes, current shader/input/oracle hashes, selected readbacks and serialized intervals verified.')
