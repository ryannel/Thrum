# R0 exact represented-dot optimization — bounded Metal result

3 November 2026. Package `r0-exact-dot-opt-v1`; scratch only. Source/output hashes,
all raw pass samples, bracketed comparisons and exact selected readback checks are
in `PROVENANCE.json`, `results.json`, `*.execution.json`, `*.log` and the retained
readback directories. No engine code, dependency, design, contract, build plan,
maturity, commit, publication or deployment changed in this commission.

## Recommendation

**Select `signed_sparse.wgsl` as the next exact represented-input compute candidate.**
It preserves the full raw-u32 normal-or-zero domain and every word of the original
17-word ABI on the retained 189,803-record oracle corpus. Its full-ABI medians
are 0.204–0.234 ms across three final processes, versus 1.039–1.057 ms for the
original. The seven-word output variant also wins the paired diagnostic blocks.
The simpler limb-extraction-only variant is a useful retained attribution control;
its measured medians are slower than the signed variant throughout this study.

**Do not select this as a viable common fragment fallback from these measurements.**
The direct 10,368,000-dot pass observed 20.508 ms on normal directions and 33.928 ms
on all-ambiguous inputs for the signed compact variant. These are compute
throughput-surrogate observations, not renderer frame costs. Scale/repetition
controls vary strongly; neither an extrapolated ~8/~13 ms from the 1M-record
samples nor a causal cache/register explanation is justified. Actual frequency,
mixed-wave divergence, register allocation/spills, integration and full lighting
cost remain open. A low fallback-frequency assumption has not been measured.

## Semantic changes and proof account

The admitted input remains six raw binary32 `u32` encodings, each signed zero or
normal in [-1,1]. Subnormals, nonfinite values and larger magnitudes refuse with
status 1 and sixteen zero words. All variants use integer WGSL only; they never
materialize a tiny float or recover bits from float operands. Exact zero, sign,
full ten-limb magnitude, truncated/sticky normalization and nearest-even rounded
normalization retain their original meanings. Input admission, 24×24-to-48
multiplication and the `2^-298` lattice are unchanged.

`limb_extract.wgsl` replaces the original up-to-300-bit loop with at most two
indexed limb loads for the 24 retained bits, one round-bit/partial-limb test,
and a scan of the lower limbs for sticky. The separate leading-limb search
still scans at most ten limbs. When the leading-bit index is at most 23, a
left shift pads the exact small integer. Otherwise discard count is `top-23`;
the round bit is at `discarded-1`, and all bits below it contribute to sticky.
All shifts are explicitly 0..31; the offset-zero branch prevents a shift by 32.
Rounding and exponent-carry code after extraction is unchanged.

`signed_sparse.wgsl` combines that extraction with one ten-u32 two's-complement
accumulator. It keeps a shifted 48-bit product in three scalar pieces and
adds/subtracts them directly, starting at the product's first occupied limb.
No lower limb can change because the term and incoming carry there are zero.
Unsigned wrap and carry/borrow propagation implement arithmetic modulo `2^320`.
Every intermediate sum of at most three admitted products has magnitude at most
three, hence its lattice integer needs at most 300 magnitude bits. It fits safely
within signed 320 bits, so bit 319 gives the true sign. A negative result is
negated in place, retaining the same array as its unsigned magnitude. Exact zero
is detected before normalization. The signed representation therefore does not
lose the signed one-lattice-unit cancellation or long carry/borrow cases.

Source array declarations fall from four ten-word arrays (positive, negative,
shifted term, magnitude) to one. The transformed loop also removes the final
positive/negative comparison/subtraction and skips provably unaffected low words.
The additional timing gain is attributable to this combined representation/work
change, not an isolated measured register-count reduction. Actual physical
registers, thread-memory spills and occupancy were unavailable through this
public-wgpu harness and remain unmeasured. Dynamic private-array indexing may
still lower to thread memory. No register or occupancy claim follows from source
array counts.

All full variants write the same required 17 output words. The signed variant
also writes ten redundant zero magnitude words for accepted exact-zero records;
this cannot explain a saving from omitted work. The compact variants remove only
the ten diagnostic magnitude stores, preserving all first seven words: status,
sign, truncated exponent/mantissa/sticky and nearest-even exponent/mantissa.
They still compute the full exact magnitude. Seven storage words remain a larger
and different consumer than returning values in a real fragment's registers.

## Correctness evidence

The unchanged retained Python Fraction oracle is authoritative for this bounded
comparison. It decodes and sums rational products independently of WGSL limb
multiplication, signed accumulation and rounding. All six shader variants pass
Naga 30.0.1 parse/full validation and execute on wgpu 30.0.1 Metal.

- Three final full-ABI processes (`corpus-full-2`, `-3`, `-4`) each run baseline,
  limb extraction and signed accumulation with the original 189,803 records,
  including all 66 invalid records and the original non-workgroup-aligned tail.
  Every one of 138 dispatches matches expected bytes: **445,277,838 word
  comparisons**, including warmups. Nine selected full readbacks contain
  **29,039,859 words**, all exact. The initial development run is retained but
  excluded from those counts because it predates the execution-record wrapper.
- Coverage is the retained corpus: all admitted exponent pairs, carry and long
  borrow boundaries, exact cancellation, ±2^-298, positive 2^-127, threshold
  neighbors, wrong floating-sign witness, sticky/tie/nearest-even and exponent
  carry boundaries, seeded independent/cancelling records and invalid encodings.
- Each new workload has 8,192 independently-oracled base records. Full 17-word
  baseline/intermediate/signed outputs are separately checked on both base sets,
  in addition to the repeated compact workload checks. Normal records are pairs
  of normalized independent uniform-cube samples. Each direction starts from
  coordinates uniform on [-1,1], is normalized in binary64 and then narrowed
  to f32; its angular distribution is nonuniform. None is in the inclusive
  `|D|≤2^-20` band. All ambiguous records are in that band and 25% are
  exact zero; they include planar perpendicular terms with tiny residual
  products and varying-sign ±2^-298 cancellation.
- The 1,048,576-record workloads repeat each base set 128 times; they contain
  8,192 authored tuples, not one million independent cases. Exact-dot work is
  unconditional for every record. There is no implemented fast sign filter,
  magnitude filter, fallback dispatch policy or measured fallback frequency.
- `summarize.py` verifies execution/log/source/input hashes, exact saved outputs,
  ordered positive timestamps and non-overlapping measurement intervals. All
  matched. The original retained archive's 26 member hashes were also verified;
  regenerating its oracle reference preserved the original input/reference bytes.

Canonical input SHA-256: `7879abe50693029e2b8c5fcd71a13b2be4fd6f779582a14a8b8545ca1107c596`.
Canonical expected and all selected full-corpus outputs SHA-256:
`03a401f4be096a4d42ba1f662b5cf59891579e4cba9c83a3a6c7cbf0df22402b`.
Baseline WGSL: `139e0e8b58e5221fd3d1dc78d1230e9d57a22adef05ce3f4787425851cf8a231`.
Signed full WGSL: `def132e252749c06ac16443581bd68dd07cf8ef34ff68f523584c7e708294654`.
Signed compact WGSL: `09fbff97a419ec280809e00369534a7c34c24e81a3bbd01c65497ffa47239089`.

## Paired timing protocol and device

Apple M3 Max integrated GPU / Metal, macOS 26.6.2 (25G83), Darwin 25.6.0,
aarch64; Rust 1.99.1 / LLVM 23.1.1. Cargo.lock pins the original wgpu/Naga
30.0.1 / pollster 1.0.1 dependency closure. No network was used.
`PROVENANCE.json` records compiler and OS output, both executed host/binary
versions and the closeout Git HEAD. That HEAD is explicitly a closeout capture,
not an execution-time Git claim; each launch pins actual binary, host, shader,
input, expected-output and log hashes separately.

The coordinator reserved the GPU measurement lease; all recorded process
intervals are sequential. Each process creates all variants up front, runs two
warmups per variant, then eight measured rounds of A/B/A/C/A, reversing B/C
order on alternate rounds. Thus each measured candidate sample has a preceding
and following baseline sample. All pipelines use 64-thread workgroups, identical
inputs/buffers/output ABI within a block, and consume/check every readback.
`results.json` retains each raw sample and the ratio against the mean of its
surrounding A measurements; process/round samples are correlated and are not
advertised as hundreds of independent trials or confidence intervals.

Timestamps bracket the entire compute pass, including storage writes, at 1 ns
period. Compute completion precedes a separate query-resolve/readback submission,
matching the retained baseline's delayed-resolve protocol. Upload, result copy,
query resolution, map, oracle comparison and CPU work are excluded. All recorded
timestamp pairs are positive/ordered. CPU encode/submit/wait durations are in
the raw logs. Module/pipeline times are warm-cache observations; caches were not
cleared and no cold compilation claim is made. This is serialized diagnostic
execution, not a sustained thermal qualification.

The closeout power snapshot shows AC attached, battery 80%. `pmset -g therm`
reported no recorded thermal/performance warnings in later run records; this
is not a GPU frequency, temperature or power measurement. Background compositor
work, hardware scheduling and other system activity were not controlled. Initial
blocks did not capture a power snapshot. Same-shader controls expose material
noise/outliers, so absolute costs and small percentage differences remain
unqualified.

### Original corpus: full and compact ABI

Values are process medians over measured pass samples.

| Run | Records × dispatches | Baseline ms | Limb extraction ms | Signed accumulator ms |
| --- | ---: | ---: | ---: | ---: |
| `corpus-full-2` | 189,803 × 1 | 1.050 | 0.387 | 0.204 |
| `corpus-full-3` | 189,803 × 1 | 1.039 | 0.378 | 0.234 |
| `corpus-full-4` | 189,803 × 1 | 1.057 | 0.440 | 0.222 |
| `corpus-compact-1` | 189,803 × 1 | 0.876 | 0.412 | 0.192 |

### Normal and all-ambiguous compact workloads

| Run | Records × dispatches | Baseline ms | Limb extraction ms | Signed accumulator ms |
| --- | ---: | ---: | ---: | ---: |
| `normal-compact-1` | 1,048,576 × 1 | 14.655 | 1.919 | 0.811 |
| `all_ambiguous-compact-1` | 1,048,576 × 1 | 12.100 | 2.158 | 1.193 |
| `normal-compact-2` | 1,048,576 × 1 | 15.428 | 1.747 | 0.731 |
| `all_ambiguous-compact-2` | 1,048,576 × 1 | 12.240 | 2.092 | 1.277 |
| `normal-compact-3` | 1,048,576 × 1 | 16.029 | 1.944 | 0.813 |
| `all_ambiguous-compact-3` | 1,048,576 × 1 | 11.842 | 2.205 | 1.276 |
| `normal-1m-one-recheck` | 1,048,576 × 1 | 13.299 | 1.820 | 0.820 |
| `all_ambiguous-1m-one-recheck` | 1,048,576 × 1 | 13.112 | 2.056 | 1.358 |

The final original-size recheck returns to approximately the earlier signed
rate after the scale controls. It does not validate a particular cause for
scale/repetition variation. All medians still favor signed accumulation, but
these blocks cannot support a universal constant dot cost.

### Direct dot-count and scale/repetition controls

| Run | Records × dispatches | Baseline ms | Limb extraction ms | Signed accumulator ms |
| --- | ---: | ---: | ---: | ---: |
| `normal-1080p-one-dot-count` | 2,073,600 × 1 | 52.743 | 12.994 | 1.610 |
| `all_ambiguous-1080p-one-dot-count` | 2,073,600 × 1 | 44.082 | 15.944 | 10.230 |
| `normal-1m-five-dot-count` | 1,048,576 × 5 | 153.678 | 49.050 | 21.551 |
| `all_ambiguous-1m-five-dot-count` | 1,048,576 × 5 | 120.630 | 64.404 | 39.823 |
| `normal-1080p-five-dot-count` | 2,073,600 × 5 | 177.499 | 52.944 | 20.508 |
| `all_ambiguous-1080p-five-dot-count` | 2,073,600 × 5 | 143.821 | 64.121 | 33.928 |

The exact 1080p×five count is 2,073,600 ×5 = **10,368,000 dot evaluations**,
with repeated dispatches over the same input/output buffers inside one pass.
It equates only the number of exact dots to one dot per pixel/light. There are
no five distinct real lights, fragment rasterization, textures, depth, BRDF,
ratio division, half vector, shadows, tone conversion or frame. A real R0
consumer may need multiple dot predicates per pair and has different storage,
register lifetime and scheduling. The direct normal/ambiguous signed medians
correspond to approximately **506/306 million dots/s** for these observed passes.

The 1M×five control is slower than simple multiplication and sometimes slower
than the larger five-dispatch control. The one-dispatch larger ambiguous run
also has large variation. The matrix therefore does **not** isolate a clean
cache threshold, memory bandwidth, register-spill effect or universal frame
budget. Do not replace it with extrapolation from the favorable 1M samples.
The direct values are retained diagnostic observations with one paired block
per matrix cell, not a selected common-fragment budget or stable scaling law.

### Same-shader A/A controls

| Workload / identical shader | A median ms | Copy median ms | Median bracketed A/copy ratio |
| --- | ---: | ---: | ---: |
| `normal-baseline-aa` | 15.175 | 13.672 | 1.144 |
| `normal-signed_sparse-aa` | 0.783 | 0.776 | 1.037 |
| `all_ambiguous-baseline-aa` | 12.116 | 11.633 | 1.027 |
| `all_ambiguous-signed_sparse-aa` | 1.347 | 1.269 | 1.038 |

The normal baseline A/A median bracket ratio is 1.144, already a 14% order/noise
signal. The ambiguous signed A/A block has one severe slow-copy outlier (minimum
bracket ratio ~0.144). These controls disallow precise percentage claims and
expose why the scaled matrix must remain qualified. The full-corpus signed
candidate's per-process median bracket ratios are 4.602, 4.266 and 4.812; all
its full-corpus bracket pairs favor it. This is useful narrow evidence for the
representation, while the complete raw distribution remains the authority.

## Reproduction and remaining gates

Run from this scratch crate with the pinned cached dependencies and local Metal
access. Retained package oracle and original source remain unchanged.

```sh
python3.11 r0-exact-dot-u32-lattice-v1/oracle.py generate
python3.11 generate_variants.py
python3.11 make_workloads.py
RUSTC_WRAPPER= CARGO_TARGET_DIR=target rustup run 1.99.1 cargo build --release --locked --offline
rustup run 1.99.1 cargo fmt --check
RUSTC_WRAPPER= CARGO_TARGET_DIR=target rustup run 1.99.1 cargo clippy --release --locked --offline -- -D warnings
python3.11 run_measurements.py full
python3.11 run_measurements.py compact
python3.11 run_measurements.py extra
python3.11 run_measurements.py controls
R0_DISPATCHES=5 python3.11 run_measurements.py 1080p
R0_DISPATCHES=1 python3.11 run_measurements.py scale-control
R0_DISPATCHES=5 python3.11 run_measurements.py scale-control
python3.11 run_measurements.py recheck
python3.11 summarize.py
```

All actual builds were offline. Release build, rustfmt check, release Clippy
`-D warnings` and Python compilation passed. No production repository code
changed, so this scratch experiment did not rerun unrelated engine gates.
The portable `r0-exact-dot-opt-v1.tar.gz` package omits expanded repeated fixtures,
redundant large readbacks and Cargo target. `PACKAGE.json` records its exact
inclusion set, omitted bulk hashes, selected readback/reference mapping and
recovery limits; `SHA256SUMS` verifies included members and
`PACKAGE-SHA256.txt` pins the archive outside it. Nine selected full readbacks
are included: all three variants on the original corpus and both new base sets.
All other raw readbacks remain in live scratch for coordinator review.
Run `python3.11 verify_retained.py` in the extracted portable package. Recompute references from the unchanged oracle before
running. Original host v1 and current v2 are both retained: v2 adds only a
checked dispatch-count setting; its default one-dispatch GPU work is unchanged.

Stop here because the requested representation changes and differential proof
are complete, all practical paired comparisons favor the signed candidate, and
scaled timing uncertainty requires a different measurement/integration step
rather than further tuning for a favorable microbenchmark. Reopen with a real
consumer ABI, a certified magnitude-accuracy filter/fallback policy, mixed wave
frequency and physical register/spill/occupancy counters on the intended target.
Integer source agreement cannot recover source-real information lost upstream,
certify float-bit recovery or subnormal float inputs, prove all possible tuples
exhaustively, or qualify another backend. It does not close ratio, half-vector,
GGX/Fresnel, image quality or complete-current-frame diagnostic obligations.
