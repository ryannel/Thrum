# R0 exact-dot optimization scratch

Owner: /root/r0_exact_dot_opt, commissioned by the coordinating chat on 3 November 2026.
Scope: this directory only; no engine source, contracts, design, build plan, maturity,
repository dependency or tracked-file edits. Purpose: preserve raw-u32 exact-dot semantics
while reducing normalization work and live array declarations, then compare paired Metal cost.

Original input: retained `docs/evidence/render/R0-EXACT-REPRESENTED-DOT-METAL-2026-11-03.tar.gz`.
Selected sources: `signed_sparse.wgsl`, `signed_sparse_compact.wgsl`, the versioned generators,
unchanged retained Fraction oracle, pinned lockfile, host v1/v2, raw logs and execution records.
Baseline and limb-extraction intermediate are retained for attribution and reproduction.
GPU lease: exclusively granted by coordinator; execution JSON intervals are checked for overlap.

Expected peak reservation during final controls: 3 GiB, all under this owned directory.
Capacity snapshot at closeout preparation: 61 GiB available, 1.8 GiB current scratch.
The initial capacity check was not captured before extraction/build; this record does not
represent an earlier reservation. No shared or unrelated cache was modified.
Retain through coordinator review and promotion decision. Raw repeated readbacks, expanded
repeated fixtures and the owned Cargo target are reconstructible; verify selected evidence
and hashes before an explicit ownership-scoped cleanup. No expiration/deletion is scheduled.
