#!/usr/bin/env python3
"""Package selected immutable source/evidence; omit reconstructible bulk explicitly."""
from pathlib import Path
import datetime,hashlib,json,tarfile
ROOT=Path(__file__).resolve().parent
PACKAGE='r0-exact-dot-opt-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
allowed={'.py','.md','.json','.log','.wgsl','.toml','.lock','.txt','.rs'}
files={p for p in ROOT.iterdir() if p.is_file() and p.suffix in allowed and p.name not in {'PACKAGE.json','PACKAGE-SHA256.txt','archive-verification.log','package.log','portable-verification.log'}}
files.update(ROOT/name for name in ['harness-v1','harness-v2'])
original=ROOT/'r0-exact-dot-u32-lattice-v1'
files.update(original/line.split('  ',1)[1] for line in (original/'SHA256SUMS').read_text().splitlines())
files.update([original/'SHA256SUMS',original/'expected.bin',ROOT/'src/main.rs'])
files.update(ROOT/(name+suffix) for name in ['normal','all_ambiguous'] for suffix in ['.base-inputs.bin','.base-expected17.bin'])
selected={}
for run,expected in [('corpus-full-4','r0-exact-dot-u32-lattice-v1/expected.bin'),('normal-base-full','normal.base-expected17.bin'),('all_ambiguous-base-full','all_ambiguous.base-expected17.bin')]:
    for name in ['baseline','limb_extract','signed_sparse']:
        p=ROOT/run/(name+'.bin');files.add(p);selected[str(p.relative_to(ROOT))]=expected
omitted=[]
for p in sorted(ROOT.glob('*.bin')):
    if p not in files:omitted.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in sorted(ROOT.glob('*/*.bin')):
    if p not in files:omitted.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)})
metadata={'package_id':PACKAGE,'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'selected_readbacks':selected,'included_files':sorted(str(p.relative_to(ROOT))for p in files)+['PACKAGE.json','SHA256SUMS'],
    'omitted_bulk':omitted,'omitted_build':'target/ is excluded; sources and pinned lockfile rebuild offline when the pinned toolchain/dependencies are cached.',
    'omitted_recovery':'make_workloads.py recreates expanded repeated fixtures and 1080p controls. Rerun the pinned GPU host for omitted historical readbacks; hashes alone do not retain their original bytes.',
    'live_scratch':'All omitted historical readbacks remain in live scratch for coordinator review. No live readback/build cleanup occurred.',
    'portable_verify':'python3.11 verify_retained.py; regenerate the independent oracle references separately for a fresh mathematical check.'}
(ROOT/'PACKAGE.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n');files.add(ROOT/'PACKAGE.json')
(ROOT/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(ROOT)}\n'for p in sorted(files)))
files.add(ROOT/'SHA256SUMS')
archive=ROOT/(PACKAGE+'.tar.gz')
with tarfile.open(archive,'w:gz',compresslevel=6)as tar:
    for p in sorted(files):tar.add(p,arcname=PACKAGE+'/'+str(p.relative_to(ROOT)),recursive=False)
(ROOT/'PACKAGE-SHA256.txt').write_text(f'{sha(archive)}  {archive.name}\n')
print('archive',archive.name,'bytes',archive.stat().st_size,'sha256',sha(archive),'members',len(files))
