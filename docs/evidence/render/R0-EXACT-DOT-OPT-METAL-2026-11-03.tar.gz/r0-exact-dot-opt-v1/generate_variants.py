#!/usr/bin/env python3
from pathlib import Path
ROOT=Path(__file__).resolve().parent
base=(ROOT/'r0-exact-dot-u32-lattice-v1/exact_dot.wgsl').read_text()
(ROOT/'baseline.wgsl').write_text(base)
start=base.index('    // Extract top 24 bits')
end=base.index('    let exponent =',start)
extract='''    // Select at most two limbs for the retained top 24 bits, then at most
    // ten limbs for round/sticky. All shifts are in 0..31.
    if top <= 23u {
        mantissa = magnitude[0] << (23u-top);
    } else {
        let discarded = top-23u;
        let word = discarded / 32u;
        let offset = discarded % 32u;
        mantissa = magnitude[word] >> offset;
        if offset != 0u && word+1u < 10u {
            mantissa |= magnitude[word+1u] << (32u-offset);
        }
        let round_index = discarded-1u;
        let round_word = round_index / 32u;
        let round_offset = round_index % 32u;
        round_bit = ((magnitude[round_word] >> round_offset) & 1u) != 0u;
        below_round = (magnitude[round_word] & ((1u << round_offset)-1u)) != 0u;
        for (var j = 0u; j < round_word; j++) {
            below_round = below_round || magnitude[j] != 0u;
        }
        sticky = round_bit || below_round;
    }
'''
limb=base[:start]+extract+base[end:]
(ROOT/'limb_extract.wgsl').write_text(limb)
a=limb.index('    var positive:')
b=limb.index('    var top =',a)
# Preserve original decoding/multiplication; replace only shifted accumulation.
body=limb[limb.index('    for (var k',a):limb.index('        var term:',a)]
signed='''    // The admitted sum has at most 300 magnitude bits, so signed 320-bit
    // two's-complement addition cannot overflow. Negative terms subtract the
    // unsigned shifted product directly; no term/positive/negative arrays.
    var magnitude: array<u32, 10>;
'''+body+'''        let part0 = lo << offset;
        var part1 = hi;
        var part2 = 0u;
        if offset != 0u {
            part1 = (lo >> (32u-offset)) | (hi << offset);
            part2 = hi >> (32u-offset);
        }
        let neg = ((x ^ y) >> 31u) != 0u;
        var carry = 0u;
        for (var j = word; j < 10u; j++) {
            var term = 0u;
            if j == word { term = part0; }
            if j == word+1u { term = part1; }
            if j == word+2u { term = part2; }
            let old = magnitude[j];
            if neg {
                let s = old-term;
                let t = s-carry;
                carry = select(0u, 1u, old < term || s < carry);
                magnitude[j] = t;
            } else {
                let s = old+term;
                let t = s+carry;
                carry = select(0u, 1u, s < old || t < s);
                magnitude[j] = t;
            }
        }
    }
    let negative = (magnitude[9] & 0x80000000u) != 0u;
    if negative {
        var carry = 1u;
        for (var j = 0u; j < 10u; j++) {
            let old = ~magnitude[j];
            let t = old+carry;
            carry = select(0u, 1u, t < old);
            magnitude[j] = t;
        }
    }
    var nonzero = 0u;
    for (var j = 0u; j < 10u; j++) {
        nonzero |= magnitude[j];
        outputs[dst+7u+j] = magnitude[j];
    }
    if nonzero == 0u { return; }
    outputs[dst+1u] = select(1u, 2u, negative);
'''
signed=limb[:a]+signed+limb[b:]
(ROOT/'signed_sparse.wgsl').write_text(signed)
# Deliberately separate ABI variants: all seven normalized result words retained,
# only the ten diagnostic magnitude-limb writes omitted. Exact work is still done.
for name,source in [('baseline',base),('limb_extract',limb),('signed_sparse',signed)]:
    compact=source.replace('id.x * 17u','id.x * 7u').replace('j < 17u','j < 7u')
    compact=compact.replace('        outputs[dst+7u+j] = t;\n','').replace('        outputs[dst+7u+j] = magnitude[j];\n','')
    (ROOT/(name+'_compact.wgsl')).write_text(compact)
