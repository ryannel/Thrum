#!/usr/bin/env python3
"""Versioned deterministic additional workloads; oracle imported unchanged."""
from pathlib import Path
import importlib.util, json, hashlib, math, random, struct
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('retained_oracle', ROOT/'r0-exact-dot-u32-lattice-v1/oracle.py')
oracle=importlib.util.module_from_spec(spec); spec.loader.exec_module(oracle)
def sha(b): return hashlib.sha256(b).hexdigest()
def normal_bits(rng):
    """Normalize uniform-cube samples; the angular distribution is nonuniform."""
    v=[rng.uniform(-1,1) for _ in range(3)]; length=math.sqrt(sum(c*c for c in v))
    return [oracle.fbits(c/length) for c in v]
rng=random.Random(0x52304f50544e4f52)
normal=[tuple(normal_bits(rng)+normal_bits(rng)) for _ in range(8192)]
rng=random.Random(0x52304f5054414d42)
ambiguous=[]
for i in range(8192):
    angle=rng.uniform(-math.pi,math.pi)
    a,b=oracle.fbits(math.cos(angle)),oracle.fbits(math.sin(angle))
    def tiny(): return (rng.getrandbits(1)<<31)|(rng.randrange(1,91)<<23)|rng.getrandbits(23)
    c,d=(0,0) if i%4==0 else (tiny(),tiny())
    bits=(a,b,c,b,a^0x80000000,d)
    if i%4==3:
        # Exact signed one-lattice-unit residual for variable significands.
        m=0x00800000+rng.randrange(1<<20)
        bits=(m+1,m,0,m+1,(m+2)^0x80000000,0)
        if rng.getrandbits(1): bits=bits[:3]+tuple(x^0x80000000 for x in bits[3:])
    ambiguous.append(bits)
manifest={'version':1,'base_records':8192,'repeat':128,'records':1048576,
          'semantics':'Every record unconditionally executes exact dot; no sign filter, frequency or GGX claim.'}
for name,cases in [('normal',normal),('all_ambiguous',ambiguous)]:
    base_input=b''.join(struct.pack('<6I',*x) for x in cases)
    full=b''.join(struct.pack('<17I',*oracle.reference(x)) for x in cases)
    compact=b''.join(full[i:i+28] for i in range(0,len(full),68))
    dots=[]
    for x in cases:
        v=list(map(oracle.decode,x)); dots.append(sum((a*b for a,b in zip(v[:3],v[3:])),oracle.Fraction()))
    amb=sum(abs(x)<=oracle.Fraction(1,1<<20) for x in dots)
    if name=='all_ambiguous': assert amb==8192
    (ROOT/f'{name}.base-inputs.bin').write_bytes(base_input)
    (ROOT/f'{name}.base-expected17.bin').write_bytes(full)
    (ROOT/f'{name}.inputs.bin').write_bytes(base_input*128)
    (ROOT/f'{name}.expected7.bin').write_bytes(compact*128)
    manifest[name]={'base_input_sha256':sha(base_input),'base_expected17_sha256':sha(full),
        'input_sha256':sha(base_input*128),'expected7_sha256':sha(compact*128),
        'base_in_inclusive_2^-20_band':amb,'base_exact_zero':sum(x==0 for x in dots),
        'distribution':'Independent uniform-cube samples with coordinates uniform on [-1,1], normalized in binary64 then narrowed to f32; nonuniform angular distribution' if name=='normal' else 'Planar perpendicular pairs with tiny third-component product; every fourth record replaced by signed 2^-298 cancellation; includes exact zeros'}
# Direct count-control inputs use the same base records, truncated to exactly 1080p.
for name in ['normal','all_ambiguous']:
    a=(ROOT/f'{name}.base-inputs.bin').read_bytes()
    e=(ROOT/f'{name}.base-expected17.bin').read_bytes()
    q=b''.join(e[i:i+28] for i in range(0,len(e),68)); n=2073600
    (ROOT/f'{name}.1080p-inputs.bin').write_bytes((a*((n+8191)//8192))[:n*24])
    (ROOT/f'{name}.1080p-expected7.bin').write_bytes((q*((n+8191)//8192))[:n*28])
corpus=(ROOT/'r0-exact-dot-u32-lattice-v1/expected.bin').read_bytes()
(ROOT/'corpus.expected7.bin').write_bytes(b''.join(corpus[i:i+28] for i in range(0,len(corpus),68)))
(ROOT/'workloads.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(manifest,indent=2))
