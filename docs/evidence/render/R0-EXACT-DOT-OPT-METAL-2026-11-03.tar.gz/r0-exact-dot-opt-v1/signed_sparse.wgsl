// Raw-u32 inputs only: x[3], y[3]. No floating operations or float bitcasts.
// Output: status, sign (0/1/2), floor exponent, trunc normalized f32 bits,
// discarded-nonzero, nearest-even exponent, nearest-even normalized f32 bits,
// ten little-endian magnitude limbs on the 2^-298 lattice.
@group(0) @binding(0) var<storage, read> inputs: array<u32>;
@group(0) @binding(1) var<storage, read_write> outputs: array<u32>;

fn valid(b: u32) -> bool {
    let a = b & 0x7fffffffu;
    return a == 0u || (a >= 0x00800000u && a <= 0x3f800000u);
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let n = arrayLength(&inputs) / 6u;
    if id.x >= n { return; }
    let src = id.x * 6u;
    let dst = id.x * 17u;
    for (var j = 0u; j < 17u; j++) { outputs[dst+j] = 0u; }
    for (var j = 0u; j < 6u; j++) {
        if !valid(inputs[src+j]) { outputs[dst] = 1u; return; }
    }
    // The admitted sum has at most 300 magnitude bits, so signed 320-bit
    // two's-complement addition cannot overflow. Negative terms subtract the
    // unsigned shifted product directly; no term/positive/negative arrays.
    var magnitude: array<u32, 10>;
    for (var k = 0u; k < 3u; k++) {
        let x = inputs[src+k];
        let y = inputs[src+k+3u];
        if (x & 0x7fffffffu) == 0u || (y & 0x7fffffffu) == 0u { continue; }
        let a = (x & 0x007fffffu) | 0x00800000u;
        let b = (y & 0x007fffffu) | 0x00800000u;
        // Exact 24x24 -> 48 multiplication using bounded 16/8-bit chunks.
        let q0 = (a & 65535u) * (b & 65535u);
        let q1 = (a >> 16u) * (b & 65535u) + (a & 65535u) * (b >> 16u);
        let lo = q0 + (q1 << 16u);
        let hi = (a >> 16u) * (b >> 16u) + (q1 >> 16u) + select(0u, 1u, lo < q0);
        let shift = ((x >> 23u) & 255u) + ((y >> 23u) & 255u) - 2u;
        let word = shift / 32u;
        let offset = shift % 32u;
        let part0 = lo << offset;
        var part1 = hi;
        var part2 = 0u;
        if offset != 0u {
            part1 = (lo >> (32u-offset)) | (hi << offset);
            part2 = hi >> (32u-offset);
        }
        let neg = ((x ^ y) >> 31u) != 0u;
        var carry = 0u;
        for (var j = word; j < 10u; j++) {
            var term = 0u;
            if j == word { term = part0; }
            if j == word+1u { term = part1; }
            if j == word+2u { term = part2; }
            let old = magnitude[j];
            if neg {
                let s = old-term;
                let t = s-carry;
                carry = select(0u, 1u, old < term || s < carry);
                magnitude[j] = t;
            } else {
                let s = old+term;
                let t = s+carry;
                carry = select(0u, 1u, s < old || t < s);
                magnitude[j] = t;
            }
        }
    }
    let negative = (magnitude[9] & 0x80000000u) != 0u;
    if negative {
        var carry = 1u;
        for (var j = 0u; j < 10u; j++) {
            let old = ~magnitude[j];
            let t = old+carry;
            carry = select(0u, 1u, t < old);
            magnitude[j] = t;
        }
    }
    var nonzero = 0u;
    for (var j = 0u; j < 10u; j++) {
        nonzero |= magnitude[j];
        outputs[dst+7u+j] = magnitude[j];
    }
    if nonzero == 0u { return; }
    outputs[dst+1u] = select(1u, 2u, negative);
    var top = 0u;
    for (var j = 9i; j >= 0i; j--) {
        if magnitude[u32(j)] != 0u {
            top = u32(j)*32u + 31u - countLeadingZeros(magnitude[u32(j)]);
            break;
        }
    }
    var mantissa = 0u;
    var sticky = false;
    var round_bit = false;
    var below_round = false;
    // Select at most two limbs for the retained top 24 bits, then at most
    // ten limbs for round/sticky. All shifts are in 0..31.
    if top <= 23u {
        mantissa = magnitude[0] << (23u-top);
    } else {
        let discarded = top-23u;
        let word = discarded / 32u;
        let offset = discarded % 32u;
        mantissa = magnitude[word] >> offset;
        if offset != 0u && word+1u < 10u {
            mantissa |= magnitude[word+1u] << (32u-offset);
        }
        let round_index = discarded-1u;
        let round_word = round_index / 32u;
        let round_offset = round_index % 32u;
        round_bit = ((magnitude[round_word] >> round_offset) & 1u) != 0u;
        below_round = (magnitude[round_word] & ((1u << round_offset)-1u)) != 0u;
        for (var j = 0u; j < round_word; j++) {
            below_round = below_round || magnitude[j] != 0u;
        }
        sticky = round_bit || below_round;
    }
    let exponent = i32(top)-298i;
    outputs[dst+2u] = bitcast<u32>(exponent);
    outputs[dst+3u] = 0x3f800000u | (mantissa & 0x007fffffu);
    outputs[dst+4u] = select(0u, 1u, sticky);
    var rounded = mantissa;
    var rounded_exponent = exponent;
    if round_bit && (below_round || (mantissa & 1u) != 0u) { rounded++; }
    if rounded == 0x01000000u { rounded >>= 1u; rounded_exponent++; }
    outputs[dst+5u] = bitcast<u32>(rounded_exponent);
    outputs[dst+6u] = 0x3f800000u | (rounded & 0x007fffffu);
}
