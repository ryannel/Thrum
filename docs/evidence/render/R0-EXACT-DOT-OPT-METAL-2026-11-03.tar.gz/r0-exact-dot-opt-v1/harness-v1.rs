use std::{
    error::Error,
    fs,
    path::Path,
    sync::mpsc,
    time::{Duration, Instant},
};
use wgpu::*;
type Result<T> = std::result::Result<T, Box<dyn Error>>;
fn wait(d: &Device, index: SubmissionIndex) -> Result<()> {
    d.poll(PollType::Wait {
        submission_index: Some(index),
        timeout: Some(Duration::from_secs(30)),
    })?;
    Ok(())
}
fn read(d: &Device, b: &Buffer) -> Result<Vec<u8>> {
    let (tx, rx) = mpsc::channel();
    b.slice(..).map_async(MapMode::Read, move |r| {
        tx.send(r).unwrap();
    });
    d.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(30)),
    })?;
    rx.recv_timeout(Duration::from_secs(30))??;
    let bytes = b.slice(..).get_mapped_range()?.to_vec();
    b.unmap();
    Ok(bytes)
}
struct Candidate {
    name: String,
    pipeline: ComputePipeline,
    group: BindGroup,
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() < 8 {
        return Err("usage: r0-exact-dot-gpu INPUT EXPECTED OUTDIR STRIDE ROUNDS baseline.wgsl candidate.wgsl [candidate.wgsl]".into());
    }
    let bytes = fs::read(&args[1])?;
    let expected = fs::read(&args[2])?;
    let outdir = Path::new(&args[3]);
    fs::create_dir_all(outdir)?;
    let stride: u64 = args[4].parse()?;
    let rounds: usize = args[5].parse()?;
    if bytes.is_empty() || bytes.len() % 24 != 0 || ![7, 17].contains(&stride) {
        return Err("invalid input/stride".into());
    }
    let n = u32::try_from(bytes.len() / 24)?;
    let output_bytes = u64::from(n) * stride * 4;
    if expected.len() as u64 != output_bytes {
        return Err("expected size differs".into());
    }
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let instance = Instance::new(desc);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions::default()))?;
    println!("adapter={:?}", adapter.get_info());
    println!("adapter_limits={:?}", adapter.limits());
    if !adapter.features().contains(Features::TIMESTAMP_QUERY) {
        return Err("timestamp queries required".into());
    }
    let (d, q) = pollster::block_on(adapter.request_device(&DeviceDescriptor {
        required_features: Features::TIMESTAMP_QUERY,
        ..Default::default()
    }))?;
    let input = d.create_buffer(&BufferDescriptor {
        label: Some("raw-u32 operands"),
        size: bytes.len() as u64,
        usage: BufferUsages::STORAGE,
        mapped_at_creation: true,
    });
    input
        .slice(..)
        .get_mapped_range_mut()?
        .copy_from_slice(&bytes);
    input.unmap();
    let output = d.create_buffer(&BufferDescriptor {
        label: Some("shared identical output writes"),
        size: output_bytes,
        usage: BufferUsages::STORAGE | BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let readback = d.create_buffer(&BufferDescriptor {
        label: None,
        size: output_bytes,
        usage: BufferUsages::MAP_READ | BufferUsages::COPY_DST,
        mapped_at_creation: false,
    });
    let mut candidates = Vec::new();
    for name in &args[6..] {
        let source = fs::read_to_string(name)?;
        let parsed =
            naga::front::wgsl::parse_str(&source).map_err(|e| e.emit_to_string(&source))?;
        naga::valid::Validator::new(
            naga::valid::ValidationFlags::all(),
            naga::valid::Capabilities::empty(),
        )
        .validate(&parsed)?;
        let start = Instant::now();
        let shader = d.create_shader_module(ShaderModuleDescriptor {
            label: Some(name),
            source: ShaderSource::Wgsl(source.into()),
        });
        let pipeline = d.create_compute_pipeline(&ComputePipelineDescriptor {
            label: Some(name),
            layout: None,
            module: &shader,
            entry_point: Some("main"),
            compilation_options: Default::default(),
            cache: None,
        });
        println!(
            "candidate={name} naga_validation=pass module_pipeline_creation_cpu_us={}",
            start.elapsed().as_micros()
        );
        let group = d.create_bind_group(&BindGroupDescriptor {
            label: None,
            layout: &pipeline.get_bind_group_layout(0),
            entries: &[
                BindGroupEntry {
                    binding: 0,
                    resource: input.as_entire_binding(),
                },
                BindGroupEntry {
                    binding: 1,
                    resource: output.as_entire_binding(),
                },
            ],
        });
        candidates.push(Candidate {
            name: name.clone(),
            pipeline,
            group,
        });
    }
    let queries = d.create_query_set(&QuerySetDescriptor {
        label: None,
        ty: QueryType::Timestamp,
        count: 2,
    });
    let resolve = d.create_buffer(&BufferDescriptor {
        label: None,
        size: 16,
        usage: BufferUsages::QUERY_RESOLVE | BufferUsages::COPY_SRC,
        mapped_at_creation: false,
    });
    let query_readback = d.create_buffer(&BufferDescriptor {
        label: None,
        size: 16,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    println!(
        "cases={n} stride={stride} input_bytes={} output_bytes={output_bytes} timestamp_period_ns={} rounds={rounds} protocol=warmup2_each_then_interleaved_A_B_A_C_A_reverse_candidate_order_alternate_rounds",
        bytes.len(),
        q.get_timestamp_period()
    );
    let mut schedule = Vec::new();
    for _ in 0..2 {
        for i in 0..candidates.len() {
            schedule.push((true, 0, i));
        }
    }
    for round in 0..rounds {
        schedule.push((false, round, 0));
        let order: Vec<_> = if round % 2 == 0 {
            (1..candidates.len()).collect()
        } else {
            (1..candidates.len()).rev().collect()
        };
        for i in order {
            schedule.push((false, round, i));
            schedule.push((false, round, 0));
        }
    }
    let mut saved = vec![false; candidates.len()];
    for (sequence, (warmup, round, i)) in schedule.into_iter().enumerate() {
        let c = &candidates[i];
        let start = Instant::now();
        let mut encoder = d.create_command_encoder(&CommandEncoderDescriptor::default());
        {
            let mut pass = encoder.begin_compute_pass(&ComputePassDescriptor {
                label: Some(&c.name),
                timestamp_writes: Some(ComputePassTimestampWrites {
                    query_set: &queries,
                    beginning_of_pass_write_index: Some(0),
                    end_of_pass_write_index: Some(1),
                }),
            });
            pass.set_pipeline(&c.pipeline);
            pass.set_bind_group(0, &c.group, &[]);
            pass.dispatch_workgroups(n.div_ceil(64), 1, 1);
        }
        wait(&d, q.submit([encoder.finish()]))?;
        let submit_us = start.elapsed().as_micros();
        let mut copy = d.create_command_encoder(&CommandEncoderDescriptor::default());
        copy.copy_buffer_to_buffer(&output, 0, &readback, 0, output_bytes);
        copy.resolve_query_set(&queries, 0..2, &resolve, 0);
        copy.copy_buffer_to_buffer(&resolve, 0, &query_readback, 0, 16);
        wait(&d, q.submit([copy.finish()]))?;
        let actual = read(&d, &readback)?;
        if actual != expected {
            let first = actual
                .iter()
                .zip(&expected)
                .position(|(a, b)| a != b)
                .unwrap();
            return Err(format!(
                "{} output differs at byte {first}, record {}",
                c.name,
                first / (stride as usize * 4)
            )
            .into());
        }
        if !saved[i] {
            fs::write(
                outdir.join(format!(
                    "{}.bin",
                    Path::new(&c.name).file_stem().unwrap().to_str().unwrap()
                )),
                &actual,
            )?;
            saved[i] = true;
        }
        let raw = read(&d, &query_readback)?;
        let begin = u64::from_le_bytes(raw[0..8].try_into()?);
        let end = u64::from_le_bytes(raw[8..16].try_into()?);
        if begin == 0 || end <= begin {
            return Err(format!("invalid timestamp {begin},{end}").into());
        }
        println!(
            "sequence={sequence} phase={} round={round} candidate={} encode_submit_completion_us={submit_us} gpu_begin={begin} gpu_end={end} gpu_ns={:.0} oracle_match=pass",
            if warmup { "warmup" } else { "measured" },
            c.name,
            (end - begin) as f64 * f64::from(q.get_timestamp_period())
        );
    }
    println!("all_dispatches_oracle_match=pass");
    Ok(())
}
