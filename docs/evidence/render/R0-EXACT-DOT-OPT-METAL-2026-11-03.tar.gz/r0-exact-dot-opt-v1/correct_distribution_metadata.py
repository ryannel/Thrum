#!/usr/bin/env python3
"""Metadata-only correction: normalized cube samples are not uniform on a sphere."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Preserve every live input/reference/readback and recorded GPU/timing identity.
protected=set(ROOT.glob('*.bin')) | set(ROOT.glob('*/*.bin')) | set(ROOT.glob('*.execution.json'))
protected.update(p for p in ROOT.glob('*.log') if p.name not in {'package.log','portable-verification.log','archive-verification.log','original-manifest-check.log'})
protected.add(ROOT/'results.json')
before={str(p.relative_to(ROOT)):sha(p)for p in sorted(protected)}
description='Independent uniform-cube samples with coordinates uniform on [-1,1], normalized in binary64 then narrowed to f32; nonuniform angular distribution'
p=ROOT/'make_workloads.py';s=p.read_text().replace('def normal_bits(rng):\n', 'def normal_bits(rng):\n    """Normalize uniform-cube samples; the angular distribution is nonuniform."""\n');s=s.replace('Independent uniform-sphere directions normalized in binary64 then narrowed to f32',description);p.write_text(s)
for name in ['workloads.json','workload-generation.json']:
    p=ROOT/name;j=json.loads(p.read_text());j['normal']['distribution']=description
    p.write_text(json.dumps(j,indent=2,sort_keys=name=='workloads.json')+'\n')
p=ROOT/'write_report.py';s=p.read_text().replace('  of independently sampled sphere directions narrowed to f32; none is in the\n  inclusive `|D|≤2^-20` band.', '  of normalized independent uniform-cube samples. Each direction starts from\n  coordinates uniform on [-1,1], is normalized in binary64 and then narrowed\n  to f32; its angular distribution is nonuniform. None is in the inclusive\n  `|D|≤2^-20` band.');p.write_text(s)
p=ROOT/'PROVENANCE.json';j=json.loads(p.read_text());j['normal_workload_distribution']=description
j['metadata_correction']={'reason':'Adversarial review corrected the distribution label: uniform-cube coordinates followed by normalization do not produce uniform-sphere directions.','scope':'Generator metadata, workload descriptions and report only; no input/reference/readback bytes, GPU logs, execution records or timings changed.'}
p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
assert all(sha(ROOT/name)==h for name,h in before.items())
(ROOT/'metadata-correction-verification.json').write_text(json.dumps({'correction':'normalized uniform-cube samples; nonuniform angular distribution','protected_files':before,'all_protected_bytes_unchanged':True},indent=2,sort_keys=True)+'\n')
