Owner: R0 GPU lifetime diagnostic, 3 November 2026.
Purpose: isolated wgpu 30.0.1 Metal same-allocation queue ordering check.
Expected peak disk: under 2 GiB including isolated Cargo target.
Selected inputs: committed R0 schedule candidate and pinned wgpu/pollster crates.
Retained output: small source archive/hash and compact evidence record if the run passes.
Closeout: retain selected source/evidence, then inspect owned build output for cleanup.
