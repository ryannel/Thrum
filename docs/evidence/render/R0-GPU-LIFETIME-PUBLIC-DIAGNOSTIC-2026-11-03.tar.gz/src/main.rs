//! Narrow Metal diagnostic: ordered writes/copies of one tracked texture.
//! No renderer, memory-residency or GPU-incomplete-work claim.

use std::{error::Error, sync::mpsc, time::Duration};

use wgpu::{
    Backends, Buffer, BufferDescriptor, BufferUsages, CommandEncoderDescriptor, Device,
    DeviceDescriptor, Extent3d, Instance, InstanceDescriptor, LoadOp, MapMode, Operations,
    PollType, PowerPreference, RenderPassColorAttachment, RenderPassDescriptor,
    RequestAdapterOptions, StoreOp, TexelCopyBufferInfo, TexelCopyBufferLayout,
    TexelCopyTextureInfo, Texture, TextureAspect, TextureDescriptor, TextureDimension,
    TextureFormat, TextureUsages,
};

const HD: (u32, u32) = (1280, 720);
const FHD: (u32, u32) = (1920, 1080);

fn texture(device: &Device, label: &'static str, extent: (u32, u32)) -> Texture {
    device.create_texture(&TextureDescriptor {
        label: Some(label),
        size: Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format: TextureFormat::Rgba8Unorm,
        usage: TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC,
        view_formats: &[],
    })
}

fn readback(device: &Device, label: &'static str, extent: (u32, u32)) -> Buffer {
    device.create_buffer(&BufferDescriptor {
        label: Some(label),
        size: u64::from(extent.0) * u64::from(extent.1) * 4,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    })
}

fn encode(
    device: &Device,
    scratch: &Texture,
    output: &Buffer,
    extent: (u32, u32),
    color: wgpu::Color,
) -> wgpu::CommandBuffer {
    let mut encoder = device.create_command_encoder(&CommandEncoderDescriptor::default());
    let view = scratch.create_view(&wgpu::TextureViewDescriptor::default());
    {
        let _pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("tagged scratch clear"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &view,
                depth_slice: None,
                resolve_target: None,
                ops: Operations {
                    load: LoadOp::Clear(color),
                    store: StoreOp::Store,
                },
            })],
            depth_stencil_attachment: None,
            ..Default::default()
        });
    }
    encoder.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: scratch,
            mip_level: 0,
            origin: wgpu::Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: output,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(extent.0 * 4),
                rows_per_image: Some(extent.1),
            },
        },
        Extent3d {
            width: extent.0,
            height: extent.1,
            depth_or_array_layers: 1,
        },
    );
    encoder.finish()
}

fn verify(
    device: &Device,
    buffer: &Buffer,
    extent: (u32, u32),
    expected: [u8; 4],
) -> Result<(), Box<dyn Error>> {
    let (tx, rx) = mpsc::channel();
    buffer.slice(..).map_async(MapMode::Read, move |result| {
        let _ = tx.send(result);
    });
    device.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(10)),
    })?;
    rx.recv_timeout(Duration::from_secs(2))??;
    let mapped = buffer.slice(..).get_mapped_range()?;
    let data = mapped.as_ref();
    let expected_len = usize::try_from(extent.0)? * usize::try_from(extent.1)? * 4;
    assert_eq!(data.len(), expected_len);
    for (index, pixel) in data.chunks_exact(4).enumerate() {
        assert_eq!(pixel, expected, "pixel {index}");
    }
    drop(mapped);
    buffer.unmap();
    Ok(())
}

fn main() -> Result<(), Box<dyn Error>> {
    let mut descriptor = InstanceDescriptor::new_without_display_handle();
    descriptor.backends = Backends::METAL;
    let instance = Instance::new(descriptor);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let info = adapter.get_info();
    let (device, queue) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    println!(
        "adapter={} backend={:?} driver={} device_max_2d={}",
        info.name,
        info.backend,
        info.driver,
        device.limits().max_texture_dimension_2d
    );

    let old = texture(&device, "one 720p scratch allocation", HD);
    let out_a = readback(&device, "A copy before overwrite", HD);
    let out_b = readback(&device, "B copy after overwrite", HD);
    let (done_tx, done_rx) = mpsc::channel();
    let a = queue.submit([encode(&device, &old, &out_a, HD, wgpu::Color::RED)]);
    let first_tx = done_tx.clone();
    queue.on_submitted_work_done(move || {
        let _ = first_tx.send("A");
    });
    let b = queue.submit([encode(&device, &old, &out_b, HD, wgpu::Color::BLUE)]);
    queue.on_submitted_work_done(move || {
        let _ = done_tx.send("B");
    });

    // Resize uses a different allocation. Keep the old handle and both old
    // outputs alive until a queue completion API reports through B.
    let newer = texture(&device, "new 1080p scratch allocation", FHD);
    let out_c = readback(&device, "C resized copy", FHD);
    let c = queue.submit([encode(&device, &newer, &out_c, FHD, wgpu::Color::GREEN)]);
    device.poll(PollType::Wait {
        submission_index: Some(c),
        timeout: Some(Duration::from_secs(10)),
    })?;
    let first = done_rx.recv_timeout(Duration::from_secs(2))?;
    let second = done_rx.recv_timeout(Duration::from_secs(2))?;
    assert!(matches!((first, second), ("A", "B") | ("B", "A")));
    verify(&device, &out_a, HD, [255, 0, 0, 255])?;
    verify(&device, &out_b, HD, [0, 0, 255, 255])?;
    verify(&device, &out_c, FHD, [0, 255, 0, 255])?;
    println!(
        "submissions A={a:?} B={b:?}; A/B same texture, C new texture; every RGBA pixel passed"
    );
    println!(
        "logical scratch bytes: old={} new={} overlap={}; readbacks separately={}",
        u64::from(HD.0) * u64::from(HD.1) * 4,
        u64::from(FHD.0) * u64::from(FHD.1) * 4,
        (u64::from(HD.0) * u64::from(HD.1) + u64::from(FHD.0) * u64::from(FHD.1)) * 4,
        (2 * u64::from(HD.0) * u64::from(HD.1) + u64::from(FHD.0) * u64::from(FHD.1)) * 4
    );
    drop(old);
    Ok(())
}
