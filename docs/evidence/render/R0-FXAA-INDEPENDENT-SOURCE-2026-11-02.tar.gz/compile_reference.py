from pathlib import Path
import subprocess, hashlib, json
root=Path(__file__).resolve().parent
header=(root/'Fxaa3_11.h').read_bytes()
assert hashlib.sha256(header).hexdigest()=='4834fada78774fc55726adeb717c53ca7324b66820df08ef773515cafb148aef'
source=(root/'reference-prefix.hlsl').read_bytes()+header+(root/'reference-wrapper.hlsl').read_bytes()
pre=subprocess.run(['/usr/bin/clang','-E','-P','-x','c','-'],input=source,capture_output=True,check=True).stdout
(root/'reference.pre.hlsl').write_bytes(pre)
base=root.parent/'android-sdk/ndk/28.2.13676358/shader-tools/darwin-x86_64'
spv=subprocess.run([str(base/'glslc'),'-x','hlsl','-fshader-stage=frag','--target-env=vulkan1.1','-O','-o','-','-'],input=pre,capture_output=True,check=True).stdout
(root/'reference.spv').write_bytes(spv)
for cmd in [[str(base/'spirv-val'),'--target-env','vulkan1.1','-'],[str(Path.home()/'.cargo/bin/naga'),'--input-kind','spv','--stdin-file-path','reference.spv']]:
 result=subprocess.run(cmd,input=spv,capture_output=True,check=True)
 print(' '.join(cmd),result.stdout.decode(),result.stderr.decode())
print('header_sha256',hashlib.sha256(header).hexdigest(),'spv_sha256',hashlib.sha256(spv).hexdigest(),'bytes',len(spv))
