import struct,json,hashlib,math,zlib
from pathlib import Path
r=Path(__file__).resolve().parent;o=r/'out'
def read(p):return list(struct.iter_unpack('<4e',p.read_bytes()))
def rgb8(p):return bytes(max(0,min(255,round(v*255))) for x in p for v in x[:3])
def png(path,w,h,data):
 def chunk(t,d):return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
 path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(b'\0'+data[y*w*3:(y+1)*w*3] for y in range(h)),9))+chunk(b'IEND',b''))
report={}; sheets=[]
for name,w,h in [('orientation',64,64),('masked',256,256),('thin',256,256),('motion-a',1280,720),('motion-b',1280,720)]:
 prefix=f'{name}-{w}x{h}'; ip=o/f'{prefix}-input.rgba16f';rp=o/f'{prefix}-reference.rgba16f';wp=o/f'{prefix}-wgsl.rgba16f'
 inp,ref,port=map(read,[ip,rp,wp]); errors=[max(abs(a[k]-b[k]) for k in range(3)) for a,b in zip(ref,port)];sort=sorted(errors)
 maxidx=max(range(len(errors)),key=errors.__getitem__); changed=[i for i,x in enumerate(errors) if x>1/255]
 # Scores are pixel maxima over RGB, not an aggregate that masks large differences.
 stats={'size':[w,h],'pixels':w*h,'nonfinite_values':sum(not math.isfinite(v) for p in ref+port for v in p),'rgb_exact_pixels':errors.count(0),'rgb_max_absolute':max(errors),'rgb_max_in_255_units':max(errors)*255,'rgb_mean_pixel_max_absolute':sum(errors)/len(errors),'rgb_p99_pixel_max_absolute':sort[int(len(sort)*.99)],'pixels_gt_1_over_255':len(changed),'pixels_gt_4_over_255':sum(x>4/255 for x in errors),'pixels_gt_16_over_255':sum(x>16/255 for x in errors),'max_at_xy':[maxidx%w,maxidx//w],'max_reference':ref[maxidx][:3],'max_wgsl':port[maxidx][:3],'reference_alpha_max_error_vs_input_luma':max(abs(a[3]-b[3]) for a,b in zip(ref,inp)),'wgsl_alpha_all_one':all(a[3]==1 for a in port),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ip,rp,wp]},'gt_1_over_255_bbox':([min(i%w for i in changed),min(i//w for i in changed),max(i%w for i in changed),max(i//w for i in changed)] if changed else None)}
 if name=='orientation':stats['orientation_exact_input_rgb']=all(a[:3]==b[:3]==c[:3] for a,b,c in zip(inp,ref,port))
 if name=='thin':
  stats['quadrants_gt_1_over_255']={str((qx,qy)):sum(errors[y*w+x]>1/255 for y in range(qy*128,(qy+1)*128) for x in range(qx*128,(qx+1)*128)) for qy in range(2) for qx in range(2)}
 a8=(o/f'{prefix}-reference.rgba8').read_bytes();b8=(o/f'{prefix}-wgsl.rgba8').read_bytes()
 stats['rgba8_rgb_nonzero_channels']=sum(a!=b for i,(a,b) in enumerate(zip(a8,b8)) if i%4!=3)
 stats['rgba8_rgb_max_byte_error']=max(abs(a-b) for i,(a,b) in enumerate(zip(a8,b8)) if i%4!=3)
 stats['reference_changed_rgb_pixels_vs_input']=sum(a[:3]!=b[:3] for a,b in zip(ref,inp))
 stats['hashes'].update({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [o/f'{prefix}-reference.rgba8',o/f'{prefix}-wgsl.rgba8']})
 report[name]=stats
 print(name,json.dumps({k:v for k,v in stats.items() if k!='hashes'}))
 if name in ['masked','thin']:
  # Columns: actual encoded input, independently compiled reference, unchanged port, RGB error x8.
  imgs=[rgb8(inp),rgb8(ref),rgb8(port),bytes(min(255,round(abs(a[k]-b[k])*255*8)) for a,b in zip(ref,port) for k in range(3))]
  sheets.append(b''.join(img[y*w*3:(y+1)*w*3] for y in range(h) for img in imgs))
 if name.startswith('motion'):
  png(o/f'{name}-reference.png',w,h,rgb8(ref))
  # Local max-error crop at native scale, four panels, bounded inside image.
  cx=max(0,min(w-128,maxidx%w-64));cy=max(0,min(h-128,maxidx//w-64)); crops=[]
  for kind in [inp,ref,port]:crops.append(rgb8([kind[y*w+x] for y in range(cy,cy+128) for x in range(cx,cx+128)]))
  crops.append(bytes(min(255,round(abs(ref[y*w+x][k]-port[y*w+x][k])*255*8)) for y in range(cy,cy+128) for x in range(cx,cx+128) for k in range(3)))
  png(o/f'{name}-max-crop.png',512,128,b''.join(c[y*128*3:(y+1)*128*3] for y in range(128) for c in crops))
  stats['crop_origin']=[cx,cy]
png(o/'masked-thin-comparison.png',1024,512,b''.join(sheets))
(o/'comparison.json').write_text(json.dumps(report,indent=2)+'\n')
