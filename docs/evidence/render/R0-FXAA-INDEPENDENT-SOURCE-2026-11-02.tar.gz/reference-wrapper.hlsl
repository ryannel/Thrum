
[[vk::binding(0,0)]] Texture2D im;
[[vk::binding(1,0)]] SamplerState sm;
[[vk::binding(2,0)]] cbuffer Params { float2 rcp; };
float4 main(float4 pos: SV_Position): SV_Target {
 FxaaTex t; t.tex=im; t.smpl=sm;
 return FxaaPixelShader(pos.xy*rcp,float4(0,0,0,0),t,t,t,t,rcp,float4(0,0,0,0),float4(0,0,0,0),float4(0,0,0,0),0.75,0.125,0.0625,0.,0.,0.,float4(0,0,0,0)); }
