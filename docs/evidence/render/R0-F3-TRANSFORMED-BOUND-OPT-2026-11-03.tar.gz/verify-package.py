#!/usr/bin/env python3
from pathlib import Path
import hashlib
R=Path(__file__).resolve().parent
for row in (R/'SHA256SUMS').read_text().splitlines():
    expected,name=row.split('  ',1)
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==expected,name
print('manifest verified')
