#[derive(Clone, Debug, PartialEq, Eq)]
struct B {
    neg: bool,
    a: [u64; L],
    used: usize,
    exp: i32,
}
impl B {
    fn zero() -> Self { Self { neg: false, a: [0; L], used: 0, exp: 0 } }
    fn small(x: u64) -> Self {
        let mut r = Self::zero();
        if x != 0 { r.a[0] = x; r.used = 1; }
        r.norm(); r
    }
    fn len(&self) -> usize { self.used }
    fn norm(&mut self) {
        while self.used > 0 && self.a[self.used-1] == 0 { self.used -= 1; }
        if self.used == 0 { self.neg = false; self.exp = 0; return; }
        let low = self.a[..self.used].iter().position(|x| *x != 0).unwrap();
        let shift = self.a[low].trailing_zeros();
        let old_used = self.used;
        for i in 0..old_used-low {
            let j = i+low;
            self.a[i] = self.a[j] >> shift;
            if shift != 0 && j+1 < old_used { self.a[i] |= self.a[j+1] << (64-shift); }
        }
        self.used -= low;
        self.exp += (low*64) as i32 + shift as i32;
        while self.used > 0 && self.a[self.used-1] == 0 { self.used -= 1; }
        self.a[self.used..old_used].fill(0);
    }
    fn aligned(&self, exp: i32) -> Self {
        if self.used == 0 { return Self::zero(); }
        let shift = usize::try_from(self.exp - exp).unwrap();
        let mut r = Self::zero(); r.exp = exp; r.neg = self.neg;
        for i in 0..self.used {
            let j = i + shift/64;
            assert!(j < L);
            r.a[j] |= self.a[i] << (shift%64);
            r.used = r.used.max(j+1);
            if shift%64 != 0 && self.a[i] >> (64-shift%64) != 0 {
                assert!(j+1 < L);
                r.a[j+1] |= self.a[i] >> (64-shift%64);
                r.used = r.used.max(j+2);
            }
        }
        r
    }
    fn cmpabs(&self, o: &Self) -> std::cmp::Ordering {
        if self.used == 0 || o.used == 0 { return self.used.cmp(&o.used); }
        let bit = self.exp + (self.used*64) as i32 - self.a[self.used-1].leading_zeros() as i32;
        let other = o.exp + (o.used*64) as i32 - o.a[o.used-1].leading_zeros() as i32;
        if bit != other { return bit.cmp(&other); }
        if self.exp == o.exp { return self.a[..self.used].iter().rev().cmp(o.a[..o.used].iter().rev()); }
        let exp = self.exp.min(o.exp);
        let a = self.aligned(exp); let b = o.aligned(exp);
        a.a[..a.used].iter().rev().cmp(b.a[..b.used].iter().rev())
    }
    fn cmp(&self, o: &Self) -> std::cmp::Ordering {
        if self.neg != o.neg { return if self.neg { std::cmp::Ordering::Less } else { std::cmp::Ordering::Greater }; }
        let c = self.cmpabs(o); if self.neg { c.reverse() } else { c }
    }
    fn minus(mut self) -> Self { if self.used != 0 { self.neg = !self.neg; } self }
    fn shl(&self, k: usize) -> Self {
        let mut r = self.clone(); if r.used != 0 { r.exp += i32::try_from(k).unwrap(); } r
    }
    fn add(&self, o: &Self) -> Self {
        if self.used == 0 { return o.clone(); }
        if o.used == 0 { return self.clone(); }
        let exp = self.exp.min(o.exp);
        let a = self.aligned(exp); let b = o.aligned(exp);
        let mut r = Self::zero(); r.exp = exp;
        let n = a.used.max(b.used);
        if a.neg == b.neg {
            r.neg = a.neg;
            let mut c = 0u128;
            for i in 0..n { let t = a.a[i] as u128+b.a[i] as u128+c; r.a[i] = t as u64; c=t>>64; }
            r.used=n;
            if c != 0 { assert!(n < L); r.a[n]=c as u64; r.used += 1; }
        } else {
            let (a,b) = if a.a[..n].iter().rev().cmp(b.a[..n].iter().rev()).is_lt() { (&b,&a) } else { (&a,&b) };
            r.neg=a.neg; r.used=n;
            let mut borrow=false;
            for i in 0..n { let (x,b1)=a.a[i].overflowing_sub(b.a[i]); let (y,b2)=x.overflowing_sub(borrow as u64); r.a[i]=y; borrow=b1||b2; }
            assert!(!borrow);
        }
        r.norm(); r
    }
    fn sub(&self, o: &Self) -> Self { self.add(&o.clone().minus()) }
    fn mul(&self, o: &Self) -> Self {
        if self.used == 0 || o.used == 0 { return Self::zero(); }
        let mut r = Self::zero(); r.exp=self.exp+o.exp;
        for i in 0..self.used {
            if self.a[i] == 0 { continue; }
            let mut c=0u128;
            for j in 0..o.used {
                let k=i+j; assert!(k < L);
                let t=self.a[i] as u128*o.a[j] as u128+r.a[k] as u128+c;
                r.a[k]=t as u64; c=t>>64;
            }
            let k=i+o.used;
            if c != 0 { assert!(k < L); assert_eq!(r.a[k],0); r.a[k]=c as u64; }
        }
        r.used=(self.used+o.used).min(L); r.neg=self.neg != o.neg; r.norm(); r
    }
    fn f64(x: f64) -> Self {
        assert!(x.is_finite()); let bits=x.to_bits(); let e=((bits>>52)&2047) as i32;
        let m=(bits&((1u64<<52)-1)) | if e==0 {0} else {1u64<<52};
        let mut r=Self::small(m);
        if r.used != 0 { r.exp += if e==0 {-1074} else {e-1075}; r.neg=x.is_sign_negative(); }
        r
    }
}
