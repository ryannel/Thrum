# Capacity and exactness preservation

The retained baseline `base/WIDTH.md` remains the original 84-limb (5,376-bit)
magnitude proof. Neither option reduces that storage capacity. All variants
use safe Rust, checked limb indices/carries, and the same interval evaluator.

## Sparse fixed-denominator option

The sparse multiplication stores exactly the same integer as the baseline.
For each nonzero input-limb pair it adds the full 128-bit product at its
limb offset and propagates carry until zero. Skipped products are exactly
zero. Partial unsigned product sums are nonnegative and cannot exceed the
complete product, so the baseline product bound also bounds this operation.
Add/subtract, decoded-f64 conversion, comparison and support selection are
otherwise unchanged. This changes work, not the denominator or width proof.

## Exponent-normalized option

A value stores signed `M * 2^exp`, with an odd nonzero magnitude M, its used
length, and the same 84-limb capacity. Zero has no sign, exp=0 and used=0.
Decoded normals use their exact integer significand times `2^(e-1075)`;
subnormals use their exact stored fraction times `2^-1074`. Normalization
removes only exact powers of two. Multiplication multiplies magnitudes and
adds exponents. Addition aligns to the smaller exponent and performs exact
signed magnitude arithmetic; normalization never rounds. Comparison first
checks sign and leading-bit position; equal leading-bit positions align
exponents before comparing all remaining bits. No floating-point arithmetic
is used inside this exact representation.

The norm-test graph now evaluates actual dyadics instead of integers scaled
by D=2^1074. The explicit baseline `D^2` shifts on rational norm endpoints,
extent threshold, and the `D` shift on translation disappear together.
This is algebraically identical: norm Q, numerator N, coefficients N*s,
and supports `t*Q + sum(N*s*p)` are actual dyadic quantities. Compare
`Q*10^18` to `(10^9 +/- 1)^2`, and supports to `10^6*Q`.

No normalized mantissa is wider than the corresponding baseline integer.
For inputs the denominator is D, quadratic operations D^2, coefficient
products D^3, and complete support operations D^4. Integer constants can be
lifted to the relevant denominator. Each normalized exponent is at least
minus its operation's denominator exponent. Aligning two values to the
smaller exponent therefore shifts no farther than the corresponding fixed
integer representation. Removing low zero bits only reduces the stored
mantissa. Product mantissas similarly remove powers of two from the original
product. Thus all nonzero-limb operations, alignments, temporary sums and
comparisons remain within the baseline positive-magnitude bound: <2^4258
for the unrestricted quaternion norm test and <2^5335 for valid-quaternion
supports under the original upstream local/translation preconditions. The
same 41-bit support headroom remains. No scale restriction is added.

The exponent field is i32; this bounded graph sums at most four decoded
exponents from [-1074,1023], plus small constant factors and normalization.
The conservative interval [-10000,10000] covers all exponent/leading-bit
bookkeeping here, well inside i32. This is not an arbitrary-precision public
API: adding operations would require checking both capacity and exponent
bounds again. Array slots outside used length remain zero; normalization
clears vacated slots before reuse.

## Residual-support option

The third candidate combines normalized dyadics with the exact equivalent
comparison

    sum(N*s*p_min) >= Q*(-10^6-t)
    sum(N*s*p_max) <= Q*( 10^6-t).

It builds scaled coefficients before the axis loop and moves translation
into the comparison threshold. In particular, a translation exactly on an
extent makes the corresponding threshold exactly zero. This avoids adding a
tiny displacement to a large world-coordinate center and then subtracting
that center through comparison. It has no epsilon/equality shortcut.
The displacement sum is bounded by the original three-local-term bound;
threshold magnitude is at most `2*10^6*Q`, a single extra threshold bit,
still far below the original full-support <2^5335 proof. Lifting both to
D^4 therefore preserves the original 84-limb argument. Full numerator and
coefficient intermediate bounds remain unchanged. No early classification
from rounded equality is introduced.
