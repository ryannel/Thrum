#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,io,tarfile
R=Path(__file__).resolve().parent
names=['OWNER.md','README.md','WIDTH.md','probe.rs','oracle.py','run.py','package.py','cases.tsv','results.json','oracle-results.json','hypot-mutant-witness.json','source-context.json']
(R/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256((R/n).read_bytes()).hexdigest()}  {n}\n' for n in names))
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    for name in sorted(names+['SHA256SUMS']):
        data=(R/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.uid=info.gid=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
archive=R/'selected.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as out:out.write(buf.getvalue())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
