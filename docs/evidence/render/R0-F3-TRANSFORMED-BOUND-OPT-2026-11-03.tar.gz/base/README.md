# Standalone exact transformed-box probe

This experiment has no workspace dependency and implements no production F3 path.
Run from an extracted archive directory with Python 3.11+ and Rust 1.99.1:

```sh
python3 oracle.py
rustup run 1.99.1 rustc --edition=2021 -C opt-level=3 -C target-cpu=native probe.rs -o probe
./probe cases.tsv
python3 run.py
```

`oracle.py` deterministically regenerates `cases.tsv`, `oracle-results.json`,
`hypot-mutant-witness.json` and the omitted 10.8 MB `many-instances.json`.
It uses exact Python Fraction arithmetic and Hamilton quaternion multiplication
for eight-corner bounds; six-support selection must agree exactly. Rust uses
explicit quadratic matrix numerators, fixed-width signed integers and an
outward binary64 interval filter. TSV fields are a name, sixteen binary64 bit
patterns (q XYZW, t, scale, local min, local max), Q-valid bit and bound-valid bit.
All inputs are finite; local component magnitudes <=1000 and translations
<=1e6 are upstream preconditions. The probe does not validate mesh radius,
JSON decoding, identity closure or F3 admission.

`run.py` runs five fresh Rust processes serially. Timed predicate loops exclude
TSV loading and all Python/JSON work. 50k-instance loops intentionally force all
fallbacks in equality, widest-span refusal and subnormal-cancellation families;
one clear family measures the ordinary filter. These are selected adversarial
families, not a proven universal runtime maximum. A separate cache experiment
uses unique translations and one repeated q/scale, retaining a 6,800-byte exact
prepared transform. Summary loops measure only producing/reusing mesh extrema,
not transformed predicates. RSS is the cumulative maximum among child probe
processes in each Python harness; it includes loaded TSV/cases and predicate
scratch but excludes the generated JSON and Python oracle.

Hashes in SHA256SUMS bind selected files; source-context.json records the
contemporaneous grammar digest. The coordinated parent may subsequently refine
that candidate. No production status, F4 support, device or end-to-end latency
claim follows from this archive.
