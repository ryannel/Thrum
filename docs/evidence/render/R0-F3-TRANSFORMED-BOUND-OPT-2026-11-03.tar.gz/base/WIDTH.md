# Fixed-width derivation

Let D=2^1074. Every finite decoded binary64 is X/D for a signed integer
|X|<2^2098. Conversion includes subnormals and canonicalizes signed zero.
An unrestricted finite quaternion therefore has QI=sum(qI_i^2)<2^4198.
The exact norm test compares QI*10^18 with (10^9 +/- 1)^2*D^2; both
sides and every nonnegative partial sum fit below 2^4258. Invalid Q returns
before constructing rotation coefficients.

For valid Q, every component has |q|<2, hence |qI|<2^1075, and a conservative
bound is QI<2^2150. Every completed quadratic rotation numerator NI satisfies
|NI|<=QI. For diagonal entries this follows by partitioning the four squares;
for off-diagonal entries it follows from 2|ab|<=a^2+b^2. Intermediate quadratic
sums/differences fit below 2^2152 independently, which also fits our width.
Scale is any finite binary64: |sI|<2^2098. Upstream local radius <=1000 implies
|pI|<2^1084; admitted translation <=1e6 implies |tI|<2^1094.

For a selected support, the exact world-coordinate numerator over the positive
denominator QI*D^2 is

    tI*QI*D + sum_j NI_ij*sI_j*pI_j.

Each scaled local product has magnitude below 2^(2150+2098+1084)=2^5332.
The three-term sum is below 2^5334. Translation is below 2^4318; the complete
numerator, including signed-sum intermediates, is below 2^5335. The extent
comparison threshold 1e6*QI*D^2 is below 2^4318. All multiplication and shift
intermediates are bounded by these positive magnitude bounds. Thus 84 u64
limbs = 5376 magnitude bits suffice; the separate sign bit does not consume
magnitude capacity. The Rust implementation checks every carry/shift boundary,
uses safe Rust only, and stores each signed integer in 680 bytes on this host.
This width is specific to this source regime and operation graph; it does not
apply automatically to arbitrary additional predicates or wider local bounds.

The code uses no integer division: six support signs select exact local min/max
and compare signed integer numerators against the scaled extent. The exact
rotation R=N/Q needs no square root. The quaternion tolerance endpoints retain
a denominator factor of five in reduced form, whereas Q is dyadic, so no finite
decoded quaternion can equal either tolerance endpoint. Exact rational endpoint
bracketing and neighboring f64 encodings are therefore the attainable tests;
world-box equality remains attainable and is tested on both sides.

The interval filter encloses every add/subtract/multiply with one outward
representable step; positive division encloses reciprocal then multiplication.
NaN-producing interval operations widen to [-infinity,+infinity]; uncertain
norm/extent tests use the exact path. This assumes normal IEEE binary64
round-to-nearest arithmetic with gradual underflow and no fast-math reassociation.
The Rust invocation enables optimization and target-cpu=native but no fast math.
This is an operation-level enclosure argument, not a compiler/target qualification
for future production evaluators.
