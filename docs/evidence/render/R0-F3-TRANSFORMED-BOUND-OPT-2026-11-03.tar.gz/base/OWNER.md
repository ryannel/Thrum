Owner: /root/f3_aabb_numeric_probe, commission from /root, 2026-11-03.
Purpose: independent exact decoded-f64 quaternion/transformed-box predicate and cost proof.
Expected peak disk: <30 MiB (available before work: 62 GiB).
Inputs: candidate R0-F3-RENDER-SOURCE-GRAMMAR-2026-11-03; no imported code/assets.
Retain: source/oracle/case TSV/results in selected docs/evidence/render archive and report.
Expiry: after selected archive regeneration/verification; binaries/source-shaped JSON reconstructible.
No production, specification, build-plan or Broadsides edits; no commit.
