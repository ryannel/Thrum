#!/usr/bin/env python3
"""Independent exact Fraction/Hamilton-corner reference and reproducible fixtures."""
from fractions import Fraction as F
import hashlib,json,math,platform,random,struct,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
EPS=F(1,10**9)
LIMIT=F(10**6)
def f(x):return F.from_float(float(x))
def ham(a,b):
    x,y,z,w=a; X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z)
def rotate(q,p):
    Q=sum(x*x for x in q)
    v=ham(ham(q,(*p,F(0))),(-q[0],-q[1],-q[2],q[3]))
    assert v[3]==0
    return tuple(x/Q for x in v[:3])
def ref(c):
    q,t,s,lo,hi=map(lambda v:tuple(map(f,v)),c)
    Q=sum(x*x for x in q)
    valid=(1-EPS)**2<=Q<=(1+EPS)**2
    if not valid:return False,False,None
    corners=[]
    for mask in range(8):
        p=tuple((hi[j] if mask>>j&1 else lo[j])*s[j] for j in range(3))
        r=rotate(q,p);corners.append(tuple(t[j]+r[j] for j in range(3)))
    lower=tuple(min(p[j] for p in corners) for j in range(3))
    upper=tuple(max(p[j] for p in corners) for j in range(3))
    # Six supports use independently obtained columns and sign selection.
    columns=[rotate(q,tuple(F(int(j==k)) for j in range(3))) for k in range(3)]
    support=[]
    for a in range(3):
        mn=mx=t[a]
        for j in range(3):
            coef=columns[j][a]*s[j]
            mn+=coef*(lo[j] if coef>=0 else hi[j]);mx+=coef*(hi[j] if coef>=0 else lo[j])
        support.append((mn,mx))
    assert all(support[j]==(lower[j],upper[j]) for j in range(3))
    return True,all(-LIMIT<=lower[j]<=upper[j]<=LIMIT for j in range(3)),(lower,upper)
def bits(x):return f'{struct.unpack(">Q",struct.pack(">d",x))[0]:016x}'
def case(q=(0.,0.,0.,1.),t=(0.,0.,0.),s=(1.,1.,1.),lo=(-1.,-1.,-1.),hi=(1.,1.,1.)):return tuple(map(tuple,(q,t,s,lo,hi)))
def bracket(r):
    x=float(r)
    if f(x)<r:return x,math.nextafter(x,math.inf)
    if f(x)>r:return math.nextafter(x,-math.inf),x
    return x,x

def generate():
    cases=[]
    def add(name,c):cases.append((name,c))
    add('identity',case());add('q_neg_identity',case(q=(0.,-0.,0.,-1.)))
    add('upper_equal',case(t=(999999.,0.,0.)))
    add('upper_next_in',case(t=(math.nextafter(999999.,-math.inf),0.,0.)))
    add('upper_next_out',case(t=(math.nextafter(999999.,math.inf),0.,0.)))
    add('lower_equal',case(t=(-999999.,0.,0.)))
    add('lower_next_in',case(t=(math.nextafter(-999999.,math.inf),0.,0.)))
    add('lower_next_out',case(t=(math.nextafter(-999999.,-math.inf),0.,0.)))
    for name,r in [('q_lower',1-EPS),('q_upper',1+EPS)]:
        for side,x in zip(('below','above'),bracket(r)):add(name+'_'+side,case(q=(0.,0.,0.,x)))
    add('q_zero',case(q=(0.,0.,0.,0.)))
    add('q_subnormal',case(q=(5e-324,0.,0.,0.)))
    add('q_max_finite',case(q=(sys.float_info.max,)*4))
    add('signed_scale',case(q=(0.,0.,0.6,0.8),s=(-2.,-0.,-1.),lo=(-3.,-7.,0.),hi=(4.,8.,0.)))
    add('zero_scale_at_extent',case(t=(1e6,-1e6,1e6),s=(0.,-0.,0.)))
    add('empty_mesh_origin',case(t=(1e6,-1e6,1e6),s=(sys.float_info.max,)*3,lo=(0.,)*3,hi=(0.,)*3))
    add('subnormal_support_inside',case(lo=(-5e-324,)*3,hi=(5e-324,)*3))
    add('subnormal_support_outside',case(t=(1e6,0.,0.),s=(5e-324,1.,1.),lo=(0.,0.,0.),hi=(5e-324,0.,0.)))
    add('huge_scale_subnormal_point',case(s=(sys.float_info.max,)*3,lo=(5e-324,)*3,hi=(5e-324,)*3))
    add('huge_scale_subnormal_rotation',case(q=(5e-324,0.,0.,1.),s=(sys.float_info.max,)*3,lo=(0.,5e-324,0.),hi=(0.,5e-324,0.)))
    add('huge_scale_refusal',case(s=(sys.float_info.max,)*3))
    add('rotated_empty_corner_refusal',case(q=(0.,0.,.6,.8),t=(0.,999000.,0.),lo=(-1000.,0.,0.),hi=(1000.,1000.,0.)))
    add('unreferenced_outlier',case(t=(999500.,0.,0.),lo=(0.,0.,0.),hi=(1000.,1.,0.)))
    add('wide_span_refusal',case(q=(5e-324,5e-324,5e-324,1.),s=(sys.float_info.max,)*3,lo=(-1000.,)*3,hi=(1000.,)*3))
    add('subnormal_cancellation',case(q=(5e-324,5e-324,5e-324,1.),t=(1e6,)*3,s=(sys.float_info.max,)*3,lo=(-5e-324,)*3,hi=(-5e-324,)*3))
    add('scaled_q_equivalent',case(q=(math.nextafter(.5,math.inf),)*4,t=(999999.,0.,0.)))
    add('base_q_equivalent',case(q=(.5,)*4,t=(999999.,0.,0.)))
    assert ref(cases[-1][1])==ref(cases[-2][1])
    add('negative_scale_boundary',case(s=(-1.,1.,1.),lo=(0.,0.,0.),hi=(1.,0.,0.),t=(1e6,0.,0.)))
    # All actual vertices stay in range in conservative-box witness.
    witness=dict(cases)['rotated_empty_corner_refusal'];q,t,s,_,_=witness
    actual=[(1000.,0.,0.),(0.,1000.,0.),(-1000.,0.,0.)]
    assert all(all(abs(f(t[j])+rotate(tuple(map(f,q)),tuple(map(f,p)))[j])<=LIMIT for j in range(3)) for p in actual)
    assert ref(witness)[1] is False
    assert ref(case(t=(999500.,0.,0.),lo=(0.,0.,0.),hi=(1.,1.,0.)))[1] # dropping unreferenced outlier wrongly admits
    rng=random.Random(0xF3AABB)
    vals=[0.,-0.,5e-324,-5e-324,math.ldexp(1.,-1022),math.ldexp(1.,-500),.5,-.5,1.,-1.,1000.,-1000.]
    scales=[0.,-0.,5e-324,-5e-324,math.ldexp(1.,-1000),math.ldexp(1.,500),sys.float_info.max,-sys.float_info.max,1.,-1.,.001,1000.]
    qs=[(0.,0.,0.,1.),(0.,0.,.6,.8),(.5,.5,.5,.5),(5e-324,0.,0.,1.),(0.,0.,0.,-1.)]
    for i in range(2400):
        q=rng.choice(qs);t=tuple(rng.choice([0.,999000.,-999999.,1e6,-1e6,math.nextafter(999999.,math.inf)]) for _ in range(3));s=tuple(rng.choice(scales) for _ in range(3));ends=[sorted(rng.choices(vals,k=2)) for _ in range(3)];lo=tuple(x[0] for x in ends);hi=tuple(x[1] for x in ends);add(f'mixed_{i}',case(q,t,s,lo,hi))
    for i in range(200):
        raw=[rng.uniform(-1.,1.) for _ in range(4)];n=math.sqrt(sum(x*x for x in raw));q=tuple(x/n for x in raw);t=tuple(rng.uniform(-1e6,1e6) for _ in range(3));s=tuple(rng.uniform(-2000.,2000.) for _ in range(3));lo=tuple(rng.uniform(-1000.,0.) for _ in range(3));hi=tuple(rng.uniform(0.,1000.) for _ in range(3));add(f'ordinary_{i}',case(q,t,s,lo,hi))
    antipodes=[(name+'_antipode',case(tuple(-x for x in c[0]),*c[1:])) for name,c in cases[:30] if ref(c)[0]]
    for name,c in antipodes:
        assert ref(c)==ref(dict(cases)[name.removesuffix('_antipode')])
    cases.extend(antipodes)
    rows=[]
    for name,c in cases:
        q,b,_=ref(c);rows.append(' '.join([name,*[bits(x) for v in c for x in v],str(int(q)),str(int(b))]))
    (ROOT/'cases.tsv').write_text('\n'.join(rows)+'\n')
    # Source-shaped repeated-instance payload, no identities/profile-admission claim.
    inst={'mesh':'10000000-0000-4000-8000-000000000001','material':'10000000-0000-4000-8000-000000000002','translation_m':[999999,0,0],'orientation_xyzw':[0,0,0,1],'scale':[1,1,1]}
    payload=json.dumps({'instances':[dict(inst,id=f'20000000-0000-4000-8000-{i:012x}') for i in range(50000)]},separators=(',',':')).encode()
    (ROOT/'many-instances.json').write_bytes(payload)
    # Mutants are independent changes to meaning, each must disagree with exact oracle.
    named=dict(cases);mutants={
      'strict_instead_of_closed_extent':not ref(named['upper_equal'])[1],
      'rounded_world_sum':not (1e6+5e-324*5e-324<=1e6)==ref(named['subnormal_support_outside'])[1],
      'vertices_instead_of_box':ref(witness)[1] is False,
      'ignore_unreferenced_vertex':ref(named['unreferenced_outlier'])[1] is False,
      'unscaled_local_bounds':ref(named['zero_scale_at_extent'])[1] != ref(case(t=(1e6,-1e6,1e6)))[1],
      'drop_scale_sign':ref(case(s=(-1.,1.,1.),lo=(0.,0.,0.),hi=(1.,0.,0.),t=(1e6,0.,0.)))[1] != ref(case(lo=(0.,0.,0.),hi=(1.,0.,0.),t=(1e6,0.,0.)))[1],
      'omit_Q_divisor':None,
      'wrong_rotation_transpose':None,
      'ordinary_hypot_Q_threshold':None,
    }
    mutants['strict_instead_of_closed_extent']=ref(named['upper_equal'])[1] is True
    # Find exact witnesses for wrong matrix normalization and transpose.
    c=case(q=(0.,0.,.6,.8),t=(1e6-1000.,0.,0.),lo=(1000.,0.,0.),hi=(1000.,0.,0.))
    # non-unit accepted scalar q produces a microscopic extent difference at exact equality.
    c=case(q=(0.,0.,0.,math.nextafter(1.,math.inf)),t=(999999.,0.,0.),lo=(1.,0.,0.),hi=(1.,0.,0.));Q=sum(f(x)**2 for x in c[0]);mutants['omit_Q_divisor']=ref(c)[1] and f(999999.)+Q>LIMIT
    c=case(q=(0.,0.,.6,.8),t=(0.,999500.,0.),lo=(1000.,0.,0.),hi=(1000.,0.,0.));ct=case(q=(0.,0.,-.6,.8),t=c[1],lo=c[3],hi=c[4]);mutants['wrong_rotation_transpose']=ref(c)[1]!=ref(ct)[1]
    mutants['ordinary_hypot_Q_threshold']=False
    for i in range(1000):
        raw=[rng.uniform(-1.,1.) for _ in range(4)];n=math.hypot(*raw);near=tuple(x/n*(1.+1e-9) for x in raw)
        valid=(1-EPS)**2<=sum(f(x)**2 for x in near)<=(1+EPS)**2
        if valid != (abs(math.hypot(*near)-1)<=1e-9):
            mutants['ordinary_hypot_Q_threshold']=True
            summary_witness={'q_bits':[bits(x) for x in near],'exact_Q_valid':valid,'rounded_hypot_valid':not valid}
            (ROOT/'hypot-mutant-witness.json').write_text(json.dumps(summary_witness,indent=2)+'\n')
            break
    assert all(mutants.values()),mutants
    def nodes(x):return 1+sum(map(nodes,x.values() if isinstance(x,dict) else x)) if isinstance(x,(dict,list)) else 1
    assert len(payload)<16*1024*1024 and nodes(json.loads(payload))<1000000
    summary={'cases':len(cases),'mutants':mutants,'fixture_sha256':hashlib.sha256((ROOT/'cases.tsv').read_bytes()).hexdigest(),'many_instance_bytes':len(payload),'many_instance_count':50000,'many_instance_nodes':nodes(json.loads(payload)),'many_instance_sha256':hashlib.sha256(payload).hexdigest(),'python':sys.version,'platform':platform.platform(),'Q_endpoint_note':'Exact tolerance endpoints are non-dyadic, so no finite decoded-f64 Q can equal them; tested neighboring f64 q encodings on each side.'}
    (ROOT/'oracle-results.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':generate()
