use std::{hint::black_box, time::Instant};
const L: usize = 84;
#[derive(Clone, Debug, PartialEq, Eq)]
struct B {
    neg: bool,
    a: [u64; L],
}
impl B {
    fn zero() -> Self {
        Self {
            neg: false,
            a: [0; L],
        }
    }
    fn small(x: u64) -> Self {
        let mut b = Self::zero();
        b.a[0] = x;
        b
    }
    fn len(&self) -> usize {
        self.a.iter().rposition(|x| *x != 0).map_or(0, |i| i + 1)
    }
    fn cmpabs(&self, o: &Self) -> std::cmp::Ordering {
        self.a.iter().rev().cmp(o.a.iter().rev())
    }
    fn cmp(&self, o: &Self) -> std::cmp::Ordering {
        if self.neg != o.neg {
            return if self.neg {
                std::cmp::Ordering::Less
            } else {
                std::cmp::Ordering::Greater
            };
        }
        let c = self.cmpabs(o);
        if self.neg {
            c.reverse()
        } else {
            c
        }
    }
    fn minus(mut self) -> Self {
        if self.len() != 0 {
            self.neg = !self.neg
        }
        self
    }
    fn shl(&self, k: usize) -> Self {
        let mut r = Self::zero();
        r.neg = self.neg;
        for i in 0..self.len() {
            let j = i + k / 64;
            assert!(j < L);
            r.a[j] |= self.a[i] << (k % 64);
            if k % 64 != 0 && self.a[i] >> (64 - k % 64) != 0 {
                assert!(j + 1 < L);
                r.a[j + 1] |= self.a[i] >> (64 - k % 64)
            }
        }
        r
    }
    fn add(&self, o: &Self) -> Self {
        let mut r = Self::zero();
        if self.neg == o.neg {
            r.neg = self.neg;
            let mut c = 0u128;
            for i in 0..L {
                let t = self.a[i] as u128 + o.a[i] as u128 + c;
                r.a[i] = t as u64;
                c = t >> 64
            }
            assert_eq!(c, 0)
        } else {
            let (a, b) = if self.cmpabs(o).is_lt() {
                (o, self)
            } else {
                (self, o)
            };
            r.neg = a.neg;
            let mut borrow = false;
            for i in 0..L {
                let (x, b1) = a.a[i].overflowing_sub(b.a[i]);
                let (y, b2) = x.overflowing_sub(borrow as u64);
                r.a[i] = y;
                borrow = b1 || b2
            }
            assert!(!borrow)
        }
        if r.len() == 0 {
            r.neg = false
        }
        r
    }
    fn sub(&self, o: &Self) -> Self {
        self.add(&o.clone().minus())
    }
    fn mul(&self, o: &Self) -> Self {
        let mut r = Self::zero();
        for i in 0..self.len() {
            let mut c = 0u128;
            for j in 0..o.len() {
                let k = i + j;
                assert!(k < L);
                let t = self.a[i] as u128 * o.a[j] as u128 + r.a[k] as u128 + c;
                r.a[k] = t as u64;
                c = t >> 64
            }
            let k = i + o.len();
            if c != 0 {
                assert!(k < L);
                assert_eq!(r.a[k], 0);
                r.a[k] = c as u64
            }
        }
        r.neg = self.neg != o.neg && r.len() != 0;
        r
    }
    fn f64(x: f64) -> Self {
        assert!(x.is_finite());
        let bits = x.to_bits();
        let e = ((bits >> 52) & 2047) as usize;
        let m = (bits & ((1u64 << 52) - 1)) | if e == 0 { 0 } else { 1u64 << 52 };
        let mut r = Self::small(m).shl(if e == 0 { 0 } else { e - 1 });
        r.neg = x.is_sign_negative() && r.len() != 0;
        r
    }
}
#[derive(Clone, Copy, Debug)]
struct I {
    lo: f64,
    hi: f64,
}
fn down(x: f64) -> f64 {
    if x.is_nan() || x == f64::NEG_INFINITY {
        x
    } else if x == 0.0 {
        -f64::from_bits(1)
    } else {
        f64::from_bits(if x > 0.0 {
            x.to_bits() - 1
        } else {
            x.to_bits() + 1
        })
    }
}
fn up(x: f64) -> f64 {
    -down(-x)
}
impl I {
    fn p(x: f64) -> Self {
        Self { lo: x, hi: x }
    }
    fn all() -> Self {
        Self {
            lo: f64::NEG_INFINITY,
            hi: f64::INFINITY,
        }
    }
    fn add(self, o: Self) -> Self {
        let a = self.lo + o.lo;
        let b = self.hi + o.hi;
        if a.is_nan() || b.is_nan() {
            Self::all()
        } else {
            Self {
                lo: down(a),
                hi: up(b),
            }
        }
    }
    fn neg(self) -> Self {
        Self {
            lo: -self.hi,
            hi: -self.lo,
        }
    }
    fn sub(self, o: Self) -> Self {
        self.add(o.neg())
    }
    fn mul(self, o: Self) -> Self {
        let v = [
            self.lo * o.lo,
            self.lo * o.hi,
            self.hi * o.lo,
            self.hi * o.hi,
        ];
        if v.iter().any(|x| x.is_nan()) {
            return Self::all();
        }
        Self {
            lo: down(v.iter().copied().fold(f64::INFINITY, f64::min)),
            hi: up(v.iter().copied().fold(f64::NEG_INFINITY, f64::max)),
        }
    }
    fn div(self, o: Self) -> Self {
        if o.lo <= 0.0 {
            return Self::all();
        }
        self.mul(Self {
            lo: down(1.0 / o.hi),
            hi: up(1.0 / o.lo),
        })
    }
}
fn q_exact(q: [f64; 4]) -> (bool, B, [B; 9]) {
    let [x, y, z, w] = q.map(B::f64);
    let xx = x.mul(&x);
    let yy = y.mul(&y);
    let zz = z.mul(&z);
    let ww = w.mul(&w);
    let norm = xx.add(&yy).add(&zz).add(&ww);
    let lo = B::small(999999999).mul(&B::small(999999999)).shl(2148);
    let hi = B::small(1000000001).mul(&B::small(1000000001)).shl(2148);
    let test = norm.mul(&B::small(1_000_000_000_000_000_000));
    let valid = !test.cmp(&lo).is_lt() && !test.cmp(&hi).is_gt();
    if !valid {
        return (false, norm, std::array::from_fn(|_| B::zero()));
    }
    let n = [
        ww.add(&xx).sub(&yy).sub(&zz),
        x.mul(&y).sub(&z.mul(&w)).shl(1),
        x.mul(&z).add(&y.mul(&w)).shl(1),
        x.mul(&y).add(&z.mul(&w)).shl(1),
        ww.sub(&xx).add(&yy).sub(&zz),
        y.mul(&z).sub(&x.mul(&w)).shl(1),
        x.mul(&z).sub(&y.mul(&w)).shl(1),
        y.mul(&z).add(&x.mul(&w)).shl(1),
        ww.sub(&xx).sub(&yy).add(&zz),
    ];
    (true, norm, n)
}
fn q_interval(q: [f64; 4]) -> (Option<bool>, I, [I; 9]) {
    let [x, y, z, w] = q.map(I::p);
    let xx = x.mul(x);
    let yy = y.mul(y);
    let zz = z.mul(z);
    let ww = w.mul(w);
    let norm = xx.add(yy).add(zz).add(ww);
    let eps = I::p(1.0).div(I::p(1e9));
    let lo = I::p(1.0).sub(eps);
    let lo = lo.mul(lo);
    let hi = I::p(1.0).add(eps);
    let hi = hi.mul(hi);
    let v = if norm.hi < lo.lo || norm.lo > hi.hi {
        Some(false)
    } else if norm.lo >= lo.hi && norm.hi <= hi.lo {
        Some(true)
    } else {
        None
    };
    let two = I::p(2.0);
    let n = [
        ww.add(xx).sub(yy).sub(zz),
        x.mul(y).sub(z.mul(w)).mul(two),
        x.mul(z).add(y.mul(w)).mul(two),
        x.mul(y).add(z.mul(w)).mul(two),
        ww.sub(xx).add(yy).sub(zz),
        y.mul(z).sub(x.mul(w)).mul(two),
        x.mul(z).sub(y.mul(w)).mul(two),
        y.mul(z).add(x.mul(w)).mul(two),
        ww.sub(xx).sub(yy).add(zz),
    ];
    (v, norm, n)
}
#[derive(Clone, Copy)]
struct Case {
    q: [f64; 4],
    t: [f64; 3],
    s: [f64; 3],
    lo: [f64; 3],
    hi: [f64; 3],
}
fn exact(c: Case) -> (bool, bool) {
    let (v, q, n) = q_exact(c.q);
    if !v {
        return (false, false);
    }
    let limit = q.mul(&B::small(1_000_000)).shl(2148);
    let t = c.t.map(B::f64);
    let s = c.s.map(B::f64);
    let lo = c.lo.map(B::f64);
    let hi = c.hi.map(B::f64);
    for a in 0..3 {
        let center = t[a].mul(&q).shl(1074);
        let mut mn = center.clone();
        let mut mx = center;
        for j in 0..3 {
            let coef = n[a * 3 + j].mul(&s[j]);
            let (l, h) = if coef.neg {
                (&hi[j], &lo[j])
            } else {
                (&lo[j], &hi[j])
            };
            mn = mn.add(&coef.mul(l));
            mx = mx.add(&coef.mul(h))
        }
        if mn.cmp(&limit.clone().minus()).is_lt() || mx.cmp(&limit).is_gt() {
            return (true, false);
        }
    }
    (true, true)
}
struct Prepared {
    q: B,
    coef: [B; 9],
}
fn prepare(c: Case) -> Prepared {
    let (v, q, n) = q_exact(c.q);
    assert!(v);
    let scale = c.s.map(B::f64);
    Prepared {
        q,
        coef: std::array::from_fn(|k| n[k].mul(&scale[k % 3])),
    }
}
fn exact_prepared(c: Case, p: &Prepared) -> bool {
    let limit = p.q.mul(&B::small(1_000_000)).shl(2148);
    let t = c.t.map(B::f64);
    let lo = c.lo.map(B::f64);
    let hi = c.hi.map(B::f64);
    for a in 0..3 {
        let center = t[a].mul(&p.q).shl(1074);
        let mut mn = center.clone();
        let mut mx = center;
        for j in 0..3 {
            let coef = &p.coef[a * 3 + j];
            let (l, h) = if coef.neg {
                (&hi[j], &lo[j])
            } else {
                (&lo[j], &hi[j])
            };
            mn = mn.add(&coef.mul(l));
            mx = mx.add(&coef.mul(h));
        }
        if mn.cmp(&limit.clone().minus()).is_lt() || mx.cmp(&limit).is_gt() {
            return false;
        }
    }
    true
}

fn filter(c: Case) -> Option<(bool, bool)> {
    let (v, q, n) = q_interval(c.q);
    if v == Some(false) {
        return Some((false, false));
    }
    if v != Some(true) {
        return None;
    }
    let mut certain = true;
    for a in 0..3 {
        let mut mn = I::p(c.t[a]);
        let mut mx = mn;
        for j in 0..3 {
            let coef = n[a * 3 + j].div(q).mul(I::p(c.s[j]));
            let p = I {
                lo: c.lo[j],
                hi: c.hi[j],
            };
            let term = coef.mul(p);
            mn = mn.add(I::p(term.lo));
            mx = mx.add(I::p(term.hi))
        }
        if mx.hi < -1e6 || mn.lo > 1e6 {
            return Some((true, false));
        }
        if mn.lo < -1e6 || mx.hi > 1e6 {
            certain = false
        }
    }
    if certain {
        Some((true, true))
    } else {
        None
    }
}
fn checked(c: Case) -> ((bool, bool), bool) {
    match filter(c) {
        Some(r) => (r, false),
        None => (exact(c), true),
    }
}
fn parse_case(l: &str) -> (String, Case, bool, bool) {
    let v: Vec<_> = l.split_whitespace().collect();
    let mut i = 1;
    let mut next = || {
        let x = f64::from_bits(u64::from_str_radix(v[i], 16).unwrap());
        i += 1;
        x
    };
    let q = std::array::from_fn(|_| next());
    let t = std::array::from_fn(|_| next());
    let s = std::array::from_fn(|_| next());
    let lo = std::array::from_fn(|_| next());
    let hi = std::array::from_fn(|_| next());
    (
        v[0].to_string(),
        Case { q, t, s, lo, hi },
        v[17] == "1",
        v[18] == "1",
    )
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    let data = std::fs::read_to_string(&args[1]).unwrap();
    let mut cases = Vec::new();
    let mut fallback = 0;
    let mut certified = 0;
    for l in data.lines() {
        let (name, c, q, b) = parse_case(l);
        let expected = (q, b);
        assert_eq!(exact(c), expected, "exact {name}");
        let (r, f) = checked(c);
        assert_eq!(r, expected, "filtered {name}");
        if f {
            fallback += 1
        } else {
            certified += 1
        }
        cases.push(c)
    }
    println!(
        "verified={} certified={} fallback={} scratch_integer_bytes={}",
        cases.len(),
        certified,
        fallback,
        std::mem::size_of::<B>()
    );
    if args.len() > 2 {
        let count: usize = args[2].parse().unwrap();
        let c = Case {
            q: [0.0, 0.0, 0.0, 1.0],
            t: [999999.0, 0.0, 0.0],
            s: [1.0; 3],
            lo: [-1.0; 3],
            hi: [1.0; 3],
        };
        assert!(filter(c).is_none());
        let start = Instant::now();
        let mut sum = 0;
        for _ in 0..count {
            let (r, f) = checked(black_box(c));
            assert!(f);
            sum += r.1 as usize
        }
        println!(
            "all_fallback count={} accepted={} elapsed_ns={}",
            count,
            sum,
            start.elapsed().as_nanos()
        );
        for (label, hard) in [
            (
                "wide_span_refusal",
                Case {
                    q: [f64::from_bits(1), f64::from_bits(1), f64::from_bits(1), 1.0],
                    t: [0.0; 3],
                    s: [f64::MAX; 3],
                    lo: [-1000.0; 3],
                    hi: [1000.0; 3],
                },
            ),
            (
                "subnormal_cancellation",
                Case {
                    q: [f64::from_bits(1), f64::from_bits(1), f64::from_bits(1), 1.0],
                    t: [1e6; 3],
                    s: [f64::MAX; 3],
                    lo: [-f64::from_bits(1); 3],
                    hi: [-f64::from_bits(1); 3],
                },
            ),
        ] {
            assert!(filter(hard).is_none());
            let start = Instant::now();
            let mut sum = 0;
            for _ in 0..count {
                let (r, f) = checked(black_box(hard));
                assert!(f);
                sum += r.1 as usize
            }
            println!(
                "{} count={} accepted={} elapsed_ns={}",
                label,
                count,
                sum,
                start.elapsed().as_nanos()
            );
        }

        let prep = prepare(c);
        for i in 0..100 {
            let unique = Case {
                t: [999999.0, i as f64 * 0.001, 0.0],
                ..c
            };
            assert_eq!(exact_prepared(unique, &prep), exact(unique).1);
            assert!(filter(unique).is_none());
        }
        let start = Instant::now();
        for i in 0..count {
            let unique = Case {
                t: [999999.0, i as f64 * 0.001, 0.0],
                ..c
            };
            black_box(checked(black_box(unique)));
        }
        println!(
            "unique_translation_uncached count={} elapsed_ns={}",
            count,
            start.elapsed().as_nanos()
        );
        let start = Instant::now();
        for i in 0..count {
            let unique = Case {
                t: [999999.0, i as f64 * 0.001, 0.0],
                ..c
            };
            assert!(filter(black_box(unique)).is_none());
            black_box(exact_prepared(black_box(unique), &prep));
        }
        println!(
            "unique_translation_prepared count={} prepared_bytes={} elapsed_ns={}",
            count,
            std::mem::size_of::<Prepared>(),
            start.elapsed().as_nanos()
        );
        let clear = Case { t: [0.0; 3], ..c };
        assert!(filter(clear).is_some());
        let start = Instant::now();
        for _ in 0..count {
            black_box(checked(black_box(clear)));
        }
        println!(
            "clear_filter count={} elapsed_ns={}",
            count,
            start.elapsed().as_nanos()
        );
        let vertices: Vec<[f64; 3]> = (0..20000)
            .map(|i| [i as f64 / 20.0, if i % 2 == 0 { -1.0 } else { 1.0 }, 0.0])
            .collect();
        let summarize = |vs: &[[f64; 3]]| {
            let mut lo = [f64::INFINITY; 3];
            let mut hi = [f64::NEG_INFINITY; 3];
            for p in vs {
                for j in 0..3 {
                    lo[j] = lo[j].min(p[j]);
                    hi[j] = hi[j].max(p[j]);
                }
            }
            (lo, hi)
        };
        let start = Instant::now();
        let summary = summarize(black_box(&vertices));
        for _ in 0..10000 {
            black_box(black_box(summary));
        }
        println!(
            "summary_reuse vertices=20000 instances=10000 elapsed_ns={}",
            start.elapsed().as_nanos()
        );
        let start = Instant::now();
        for _ in 0..10000 {
            black_box(summarize(black_box(&vertices)));
        }
        println!(
            "summary_rescan vertices=20000 instances=10000 elapsed_ns={}",
            start.elapsed().as_nanos()
        );
    }
}
