#!/usr/bin/env python3
"""Serial fresh-process runs; inner predicate times exclude oracle/TSV decoding."""
from pathlib import Path
import hashlib,json,os,platform,re,resource,statistics,subprocess,time
R=Path(__file__).resolve().parent
rows=[]
for i in range(5):
    start=time.perf_counter_ns()
    p=subprocess.run([str(R/'probe'),str(R/'cases.tsv'),'50000'],check=True,capture_output=True,text=True)
    elapsed=time.perf_counter_ns()-start
    # macOS getrusage reports bytes; cumulative children maximum, not per-run attribution.
    rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    parsed={}
    for line in p.stdout.splitlines():
        fields=line.split(); parsed[fields[0]]={k:int(v) for k,v in (x.split('=',1) for x in fields[1:] if '=' in x)}
    rows.append({'run':i+1,'wall_ns':elapsed,'cumulative_child_maxrss_bytes':rss,'stdout':p.stdout,'measurements':parsed})
    print(f'completed {i+1}/5',flush=True)
summary={}
for key in ('all_fallback','unique_translation_uncached','unique_translation_prepared','wide_span_refusal','subnormal_cancellation','clear_filter','summary_reuse','summary_rescan'):
    vals=[r['measurements'][key]['elapsed_ns'] for r in rows]
    summary[key]={'min_ns':min(vals),'median_ns':statistics.median(vals),'max_ns':max(vals)}
result={'host':platform.node(),'uname':tuple(platform.uname()),'machine_family':'T6031 (uname kernel)','rustc':subprocess.check_output(['rustup','run','1.99.1','rustc','-Vv'],text=True),'build_flags':'--edition=2021 -C opt-level=3 -C target-cpu=native','runs':rows,'summary':summary,'memory_scope':'Cumulative maximum RSS of fresh Rust child processes; includes TSV, decoded case structs and predicate; excludes JSON payload and Python oracle. macOS units bytes. Not F3 peak.'}
(R/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
