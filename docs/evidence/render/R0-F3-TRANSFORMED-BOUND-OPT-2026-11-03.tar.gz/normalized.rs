use std::{hint::black_box, time::Instant};
const L: usize = 84;
#[derive(Clone, Debug, PartialEq, Eq)]
struct B {
    neg: bool,
    a: [u64; L],
    used: usize,
    exp: i32,
}
impl B {
    fn zero() -> Self { Self { neg: false, a: [0; L], used: 0, exp: 0 } }
    fn small(x: u64) -> Self {
        let mut r = Self::zero();
        if x != 0 { r.a[0] = x; r.used = 1; }
        r.norm(); r
    }
    fn len(&self) -> usize { self.used }
    fn norm(&mut self) {
        while self.used > 0 && self.a[self.used-1] == 0 { self.used -= 1; }
        if self.used == 0 { self.neg = false; self.exp = 0; return; }
        let low = self.a[..self.used].iter().position(|x| *x != 0).unwrap();
        let shift = self.a[low].trailing_zeros();
        let old_used = self.used;
        for i in 0..old_used-low {
            let j = i+low;
            self.a[i] = self.a[j] >> shift;
            if shift != 0 && j+1 < old_used { self.a[i] |= self.a[j+1] << (64-shift); }
        }
        self.used -= low;
        self.exp += (low*64) as i32 + shift as i32;
        while self.used > 0 && self.a[self.used-1] == 0 { self.used -= 1; }
        self.a[self.used..old_used].fill(0);
    }
    fn aligned(&self, exp: i32) -> Self {
        if self.used == 0 { return Self::zero(); }
        let shift = usize::try_from(self.exp - exp).unwrap();
        let mut r = Self::zero(); r.exp = exp; r.neg = self.neg;
        for i in 0..self.used {
            let j = i + shift/64;
            assert!(j < L);
            r.a[j] |= self.a[i] << (shift%64);
            r.used = r.used.max(j+1);
            if shift%64 != 0 && self.a[i] >> (64-shift%64) != 0 {
                assert!(j+1 < L);
                r.a[j+1] |= self.a[i] >> (64-shift%64);
                r.used = r.used.max(j+2);
            }
        }
        r
    }
    fn cmpabs(&self, o: &Self) -> std::cmp::Ordering {
        if self.used == 0 || o.used == 0 { return self.used.cmp(&o.used); }
        let bit = self.exp + (self.used*64) as i32 - self.a[self.used-1].leading_zeros() as i32;
        let other = o.exp + (o.used*64) as i32 - o.a[o.used-1].leading_zeros() as i32;
        if bit != other { return bit.cmp(&other); }
        if self.exp == o.exp { return self.a[..self.used].iter().rev().cmp(o.a[..o.used].iter().rev()); }
        let exp = self.exp.min(o.exp);
        let a = self.aligned(exp); let b = o.aligned(exp);
        a.a[..a.used].iter().rev().cmp(b.a[..b.used].iter().rev())
    }
    fn cmp(&self, o: &Self) -> std::cmp::Ordering {
        if self.neg != o.neg { return if self.neg { std::cmp::Ordering::Less } else { std::cmp::Ordering::Greater }; }
        let c = self.cmpabs(o); if self.neg { c.reverse() } else { c }
    }
    fn minus(mut self) -> Self { if self.used != 0 { self.neg = !self.neg; } self }
    fn shl(&self, k: usize) -> Self {
        let mut r = self.clone(); if r.used != 0 { r.exp += i32::try_from(k).unwrap(); } r
    }
    fn add(&self, o: &Self) -> Self {
        if self.used == 0 { return o.clone(); }
        if o.used == 0 { return self.clone(); }
        let exp = self.exp.min(o.exp);
        let a = self.aligned(exp); let b = o.aligned(exp);
        let mut r = Self::zero(); r.exp = exp;
        let n = a.used.max(b.used);
        if a.neg == b.neg {
            r.neg = a.neg;
            let mut c = 0u128;
            for i in 0..n { let t = a.a[i] as u128+b.a[i] as u128+c; r.a[i] = t as u64; c=t>>64; }
            r.used=n;
            if c != 0 { assert!(n < L); r.a[n]=c as u64; r.used += 1; }
        } else {
            let (a,b) = if a.a[..n].iter().rev().cmp(b.a[..n].iter().rev()).is_lt() { (&b,&a) } else { (&a,&b) };
            r.neg=a.neg; r.used=n;
            let mut borrow=false;
            for i in 0..n { let (x,b1)=a.a[i].overflowing_sub(b.a[i]); let (y,b2)=x.overflowing_sub(borrow as u64); r.a[i]=y; borrow=b1||b2; }
            assert!(!borrow);
        }
        r.norm(); r
    }
    fn sub(&self, o: &Self) -> Self { self.add(&o.clone().minus()) }
    fn mul(&self, o: &Self) -> Self {
        if self.used == 0 || o.used == 0 { return Self::zero(); }
        let mut r = Self::zero(); r.exp=self.exp+o.exp;
        for i in 0..self.used {
            if self.a[i] == 0 { continue; }
            let mut c=0u128;
            for j in 0..o.used {
                let k=i+j; assert!(k < L);
                let t=self.a[i] as u128*o.a[j] as u128+r.a[k] as u128+c;
                r.a[k]=t as u64; c=t>>64;
            }
            let k=i+o.used;
            if c != 0 { assert!(k < L); assert_eq!(r.a[k],0); r.a[k]=c as u64; }
        }
        r.used=(self.used+o.used).min(L); r.neg=self.neg != o.neg; r.norm(); r
    }
    fn f64(x: f64) -> Self {
        assert!(x.is_finite()); let bits=x.to_bits(); let e=((bits>>52)&2047) as i32;
        let m=(bits&((1u64<<52)-1)) | if e==0 {0} else {1u64<<52};
        let mut r=Self::small(m);
        if r.used != 0 { r.exp += if e==0 {-1074} else {e-1075}; r.neg=x.is_sign_negative(); }
        r
    }
}
#[derive(Clone, Copy, Debug)]
struct I {
    lo: f64,
    hi: f64,
}
fn down(x: f64) -> f64 {
    if x.is_nan() || x == f64::NEG_INFINITY {
        x
    } else if x == 0.0 {
        -f64::from_bits(1)
    } else {
        f64::from_bits(if x > 0.0 {
            x.to_bits() - 1
        } else {
            x.to_bits() + 1
        })
    }
}
fn up(x: f64) -> f64 {
    -down(-x)
}
impl I {
    fn p(x: f64) -> Self {
        Self { lo: x, hi: x }
    }
    fn all() -> Self {
        Self {
            lo: f64::NEG_INFINITY,
            hi: f64::INFINITY,
        }
    }
    fn add(self, o: Self) -> Self {
        let a = self.lo + o.lo;
        let b = self.hi + o.hi;
        if a.is_nan() || b.is_nan() {
            Self::all()
        } else {
            Self {
                lo: down(a),
                hi: up(b),
            }
        }
    }
    fn neg(self) -> Self {
        Self {
            lo: -self.hi,
            hi: -self.lo,
        }
    }
    fn sub(self, o: Self) -> Self {
        self.add(o.neg())
    }
    fn mul(self, o: Self) -> Self {
        let v = [
            self.lo * o.lo,
            self.lo * o.hi,
            self.hi * o.lo,
            self.hi * o.hi,
        ];
        if v.iter().any(|x| x.is_nan()) {
            return Self::all();
        }
        Self {
            lo: down(v.iter().copied().fold(f64::INFINITY, f64::min)),
            hi: up(v.iter().copied().fold(f64::NEG_INFINITY, f64::max)),
        }
    }
    fn div(self, o: Self) -> Self {
        if o.lo <= 0.0 {
            return Self::all();
        }
        self.mul(Self {
            lo: down(1.0 / o.hi),
            hi: up(1.0 / o.lo),
        })
    }
}
fn q_exact(q: [f64; 4]) -> (bool, B, [B; 9]) {
    let [x, y, z, w] = q.map(B::f64);
    let xx = x.mul(&x);
    let yy = y.mul(&y);
    let zz = z.mul(&z);
    let ww = w.mul(&w);
    let norm = xx.add(&yy).add(&zz).add(&ww);
    let lo = B::small(999999999).mul(&B::small(999999999));
    let hi = B::small(1000000001).mul(&B::small(1000000001));
    let test = norm.mul(&B::small(1_000_000_000_000_000_000));
    let valid = !test.cmp(&lo).is_lt() && !test.cmp(&hi).is_gt();
    if !valid {
        return (false, norm, std::array::from_fn(|_| B::zero()));
    }
    let n = [
        ww.add(&xx).sub(&yy).sub(&zz),
        x.mul(&y).sub(&z.mul(&w)).shl(1),
        x.mul(&z).add(&y.mul(&w)).shl(1),
        x.mul(&y).add(&z.mul(&w)).shl(1),
        ww.sub(&xx).add(&yy).sub(&zz),
        y.mul(&z).sub(&x.mul(&w)).shl(1),
        x.mul(&z).sub(&y.mul(&w)).shl(1),
        y.mul(&z).add(&x.mul(&w)).shl(1),
        ww.sub(&xx).sub(&yy).add(&zz),
    ];
    (true, norm, n)
}
fn q_interval(q: [f64; 4]) -> (Option<bool>, I, [I; 9]) {
    let [x, y, z, w] = q.map(I::p);
    let xx = x.mul(x);
    let yy = y.mul(y);
    let zz = z.mul(z);
    let ww = w.mul(w);
    let norm = xx.add(yy).add(zz).add(ww);
    let eps = I::p(1.0).div(I::p(1e9));
    let lo = I::p(1.0).sub(eps);
    let lo = lo.mul(lo);
    let hi = I::p(1.0).add(eps);
    let hi = hi.mul(hi);
    let v = if norm.hi < lo.lo || norm.lo > hi.hi {
        Some(false)
    } else if norm.lo >= lo.hi && norm.hi <= hi.lo {
        Some(true)
    } else {
        None
    };
    let two = I::p(2.0);
    let n = [
        ww.add(xx).sub(yy).sub(zz),
        x.mul(y).sub(z.mul(w)).mul(two),
        x.mul(z).add(y.mul(w)).mul(two),
        x.mul(y).add(z.mul(w)).mul(two),
        ww.sub(xx).add(yy).sub(zz),
        y.mul(z).sub(x.mul(w)).mul(two),
        x.mul(z).sub(y.mul(w)).mul(two),
        y.mul(z).add(x.mul(w)).mul(two),
        ww.sub(xx).sub(yy).add(zz),
    ];
    (v, norm, n)
}
#[derive(Clone, Copy)]
struct Case {
    q: [f64; 4],
    t: [f64; 3],
    s: [f64; 3],
    lo: [f64; 3],
    hi: [f64; 3],
}
fn exact(c: Case) -> (bool, bool) {
    let (v, q, n) = q_exact(c.q);
    if !v {
        return (false, false);
    }
    let limit = q.mul(&B::small(1_000_000));
    let t = c.t.map(B::f64);
    let s = c.s.map(B::f64);
    let lo = c.lo.map(B::f64);
    let hi = c.hi.map(B::f64);
    for a in 0..3 {
        let center = t[a].mul(&q);
        let mut mn = center.clone();
        let mut mx = center;
        for j in 0..3 {
            let coef = n[a * 3 + j].mul(&s[j]);
            let (l, h) = if coef.neg {
                (&hi[j], &lo[j])
            } else {
                (&lo[j], &hi[j])
            };
            mn = mn.add(&coef.mul(l));
            mx = mx.add(&coef.mul(h))
        }
        if mn.cmp(&limit.clone().minus()).is_lt() || mx.cmp(&limit).is_gt() {
            return (true, false);
        }
    }
    (true, true)
}
struct Prepared {
    q: B,
    coef: [B; 9],
}
fn prepare(c: Case) -> Prepared {
    let (v, q, n) = q_exact(c.q);
    assert!(v);
    let scale = c.s.map(B::f64);
    Prepared {
        q,
        coef: std::array::from_fn(|k| n[k].mul(&scale[k % 3])),
    }
}
fn exact_prepared(c: Case, p: &Prepared) -> bool {
    let limit = p.q.mul(&B::small(1_000_000));
    let t = c.t.map(B::f64);
    let lo = c.lo.map(B::f64);
    let hi = c.hi.map(B::f64);
    for a in 0..3 {
        let center = t[a].mul(&p.q);
        let mut mn = center.clone();
        let mut mx = center;
        for j in 0..3 {
            let coef = &p.coef[a * 3 + j];
            let (l, h) = if coef.neg {
                (&hi[j], &lo[j])
            } else {
                (&lo[j], &hi[j])
            };
            mn = mn.add(&coef.mul(l));
            mx = mx.add(&coef.mul(h));
        }
        if mn.cmp(&limit.clone().minus()).is_lt() || mx.cmp(&limit).is_gt() {
            return false;
        }
    }
    true
}

fn filter(c: Case) -> Option<(bool, bool)> {
    let (v, q, n) = q_interval(c.q);
    if v == Some(false) {
        return Some((false, false));
    }
    if v != Some(true) {
        return None;
    }
    let mut certain = true;
    for a in 0..3 {
        let mut mn = I::p(c.t[a]);
        let mut mx = mn;
        for j in 0..3 {
            let coef = n[a * 3 + j].div(q).mul(I::p(c.s[j]));
            let p = I {
                lo: c.lo[j],
                hi: c.hi[j],
            };
            let term = coef.mul(p);
            mn = mn.add(I::p(term.lo));
            mx = mx.add(I::p(term.hi))
        }
        if mx.hi < -1e6 || mn.lo > 1e6 {
            return Some((true, false));
        }
        if mn.lo < -1e6 || mx.hi > 1e6 {
            certain = false
        }
    }
    if certain {
        Some((true, true))
    } else {
        None
    }
}
fn checked(c: Case) -> ((bool, bool), bool) {
    match filter(c) {
        Some(r) => (r, false),
        None => (exact(c), true),
    }
}
fn parse_case(l: &str) -> (String, Case, bool, bool) {
    let v: Vec<_> = l.split_whitespace().collect();
    let mut i = 1;
    let mut next = || {
        let x = f64::from_bits(u64::from_str_radix(v[i], 16).unwrap());
        i += 1;
        x
    };
    let q = std::array::from_fn(|_| next());
    let t = std::array::from_fn(|_| next());
    let s = std::array::from_fn(|_| next());
    let lo = std::array::from_fn(|_| next());
    let hi = std::array::from_fn(|_| next());
    (
        v[0].to_string(),
        Case { q, t, s, lo, hi },
        v[17] == "1",
        v[18] == "1",
    )
}
fn family(label: &str, i: usize) -> Case {
    let c=Case { q:[0.,0.,0.,1.], t:[999999.,0.,0.], s:[1.;3], lo:[-1.;3], hi:[1.;3] };
    match label {
        "clear" => Case { t:[0.;3], ..c },
        "equality" | "prepared" | "prepare_cost" => c,
        "unique_translation" => Case {t:[999999.,i as f64*0.001,0.],..c},
        "unique_scalar_q_scale" => Case {q:[0.,0.,0.,f64::from_bits(1f64.to_bits()+i as u64)],s:[1.,1.+i as f64*1e-9,-1.-i as f64*1e-9],..c},
        "wide" | "unique_wide" => Case {
            q: if label=="wide" {[f64::from_bits(1),f64::from_bits(1),f64::from_bits(1),1.]} else {[f64::from_bits(i as u64+1),f64::from_bits(i as u64+2),f64::from_bits(i as u64+3),1.]},
            t:[0.;3], s:[f64::from_bits(f64::MAX.to_bits()-if label=="wide" {0} else {i as u64});3], lo:[-1000.;3],hi:[1000.;3],
        },
        "cancellation" | "unique_cancellation" => {
            let mut c=family(if label=="cancellation" {"wide"} else {"unique_wide"},i);
            c.t=[1e6;3]; c.lo=[-f64::from_bits(1);3];c.hi=c.lo;c
        },
        _ => panic!("unknown family"),
    }
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    if args[1]=="verify" {
        let data=std::fs::read_to_string(&args[2]).unwrap();
        let mut fallback=0; let mut certified=0; let mut count=0;
        for l in data.lines() {
            let (name,c,q,b)=parse_case(l); let expected=(q,b);
            assert_eq!(exact(c),expected,"exact {name}");
            let (r,f)=checked(c);assert_eq!(r,expected,"checked {name}");
            if q { assert_eq!(exact_prepared(c,&prepare(c)),b,"prepared {name}"); }
            if f {fallback+=1} else {certified+=1};count+=1;
        }
        println!("verified count={count} certified={certified} fallback={fallback} integer_bytes={} prepared_bytes={}",std::mem::size_of::<B>(),std::mem::size_of::<Prepared>());
    } else {
        let label=&args[1]; let count:usize=args[2].parse().unwrap();
        let prep=prepare(family("equality",0));
        let start=Instant::now(); let mut accepted=0;let mut fallback=0;
        for i in 0..count {
            let c=black_box(family(label,i));
            if label=="prepare_cost" {black_box(prepare(c));continue;}
            if label=="prepared" { assert!(filter(c).is_none()); accepted+=exact_prepared(c,black_box(&prep)) as usize;fallback+=1; }
            else {let (r,f)=checked(c);accepted+=r.1 as usize;fallback+=f as usize;}
        }
        let elapsed=start.elapsed().as_nanos();
        if label!="clear" && label!="prepare_cost" {assert_eq!(fallback,count);}
        println!("{label} count={count} accepted={accepted} fallback={fallback} elapsed_ns={elapsed} integer_bytes={} prepared_bytes={}",std::mem::size_of::<B>(),std::mem::size_of::<Prepared>());
    }
}
