fn family(label: &str, i: usize) -> Case {
    let c=Case { q:[0.,0.,0.,1.], t:[999999.,0.,0.], s:[1.;3], lo:[-1.;3], hi:[1.;3] };
    match label {
        "clear" => Case { t:[0.;3], ..c },
        "equality" | "prepared" | "prepare_cost" => c,
        "unique_translation" => Case {t:[999999.,i as f64*0.001,0.],..c},
        "unique_scalar_q_scale" => Case {q:[0.,0.,0.,f64::from_bits(1f64.to_bits()+i as u64)],s:[1.,1.+i as f64*1e-9,-1.-i as f64*1e-9],..c},
        "wide" | "unique_wide" => Case {
            q: if label=="wide" {[f64::from_bits(1),f64::from_bits(1),f64::from_bits(1),1.]} else {[f64::from_bits(i as u64+1),f64::from_bits(i as u64+2),f64::from_bits(i as u64+3),1.]},
            t:[0.;3], s:[f64::from_bits(f64::MAX.to_bits()-if label=="wide" {0} else {i as u64});3], lo:[-1000.;3],hi:[1000.;3],
        },
        "cancellation" | "unique_cancellation" => {
            let mut c=family(if label=="cancellation" {"wide"} else {"unique_wide"},i);
            c.t=[1e6;3]; c.lo=[-f64::from_bits(1);3];c.hi=c.lo;c
        },
        _ => panic!("unknown family"),
    }
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    if args[1]=="verify" {
        let data=std::fs::read_to_string(&args[2]).unwrap();
        let mut fallback=0; let mut certified=0; let mut count=0;
        for l in data.lines() {
            let (name,c,q,b)=parse_case(l); let expected=(q,b);
            assert_eq!(exact(c),expected,"exact {name}");
            let (r,f)=checked(c);assert_eq!(r,expected,"checked {name}");
            if q { assert_eq!(exact_prepared(c,&prepare(c)),b,"prepared {name}"); }
            if f {fallback+=1} else {certified+=1};count+=1;
        }
        println!("verified count={count} certified={certified} fallback={fallback} integer_bytes={} prepared_bytes={}",std::mem::size_of::<B>(),std::mem::size_of::<Prepared>());
    } else {
        let label=&args[1]; let count:usize=args[2].parse().unwrap();
        let prep=prepare(family("equality",0));
        let start=Instant::now(); let mut accepted=0;let mut fallback=0;
        for i in 0..count {
            let c=black_box(family(label,i));
            if label=="prepare_cost" {black_box(prepare(c));continue;}
            if label=="prepared" { assert!(filter(c).is_none()); accepted+=exact_prepared(c,black_box(&prep)) as usize;fallback+=1; }
            else {let (r,f)=checked(c);accepted+=r.1 as usize;fallback+=f as usize;}
        }
        let elapsed=start.elapsed().as_nanos();
        if label!="clear" && label!="prepare_cost" {assert_eq!(fallback,count);}
        println!("{label} count={count} accepted={accepted} fallback={fallback} elapsed_ns={elapsed} integer_bytes={} prepared_bytes={}",std::mem::size_of::<B>(),std::mem::size_of::<Prepared>());
    }
}
