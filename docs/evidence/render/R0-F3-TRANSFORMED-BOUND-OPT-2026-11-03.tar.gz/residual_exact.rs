fn exact(c: Case) -> (bool, bool) {
    let (valid,q,n)=q_exact(c.q);
    if !valid {return (false,false);}
    let p=Prepared {q,coef:std::array::from_fn(|k| n[k].mul(&B::f64(c.s[k%3])))};
    (true,exact_prepared(c,&p))
}
struct Prepared { q:B,coef:[B;9] }
fn prepare(c: Case) -> Prepared {
    let (valid,q,n)=q_exact(c.q);assert!(valid);
    Prepared {q,coef:std::array::from_fn(|k|n[k].mul(&B::f64(c.s[k%3])))}
}
fn exact_prepared(c: Case,p:&Prepared) -> bool {
    let extent=B::small(1_000_000);
    let t=c.t.map(B::f64);let lo=c.lo.map(B::f64);let hi=c.hi.map(B::f64);
    for a in 0..3 {
        let mut mn=B::zero();let mut mx=B::zero();
        for j in 0..3 {
            let coef=&p.coef[a*3+j];
            let (l,h)=if coef.neg {(&hi[j],&lo[j])} else {(&lo[j],&hi[j])};
            mn=mn.add(&coef.mul(l));mx=mx.add(&coef.mul(h));
        }
        let lower=p.q.mul(&extent.clone().minus().sub(&t[a]));
        let upper=p.q.mul(&extent.sub(&t[a]));
        if mn.cmp(&lower).is_lt() || mx.cmp(&upper).is_gt() {return false;}
    }
    true
}
