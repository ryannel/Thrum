#!/usr/bin/env python3
from pathlib import Path
import hashlib,importlib.util,json,math,random,struct,sys
R=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('reference',R/'base/oracle.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
def fbits(x):return struct.unpack('>d',struct.pack('>Q',x))[0]
def family(label,i):
    q=(fbits(i+1),fbits(i+2),fbits(i+3),1.)
    s=(fbits(0x7fefffffffffffff-i),)*3
    if label=='unique_wide':return o.case(q=q,s=s,lo=(-1000.,)*3,hi=(1000.,)*3)
    if label=='unique_cancellation':return o.case(q=q,t=(1e6,)*3,s=s,lo=(-fbits(1),)*3,hi=(-fbits(1),)*3)
    return o.case(q=(0.,0.,0.,fbits(0x3ff0000000000000+i)),t=(999999.,0.,0.),s=(1.,1.+i*1e-9,-1.-i*1e-9))
cases=[]
for label in ['unique_wide','unique_cancellation','unique_scalar_q_scale']:
    for i in [0,1,2,63,64,65,127,255,1023,32767,49999]:cases.append((label+'_'+str(i),family(label,i)))
rng=random.Random(0xf3e0aabb)
for i in range(900):
    # Valid and invalid norms; broad exponents, signed components/scales, wide cancellation.
    small=tuple(math.ldexp(rng.uniform(-1.,1.),rng.choice([-1073,-1022,-900,-500,-100,-30,-20,-10])) for _ in range(3))
    q=small+(rng.choice([1.,-1.,math.nextafter(1.,math.inf)]),)
    s=tuple(math.ldexp(rng.uniform(-1.,1.),rng.choice([-1073,-1022,-700,0,500,1023])) for _ in range(3))
    ends=[sorted([rng.choice([0.,fbits(1),-fbits(1),-1000.,1000.,math.ldexp(rng.random(),rng.randrange(-1074,10))]) for _ in range(2)]) for _ in range(3)]
    lo=tuple(e[0] for e in ends);hi=tuple(e[1] for e in ends)
    t=tuple(rng.choice([0.,1e6,-1e6,999999.,math.nextafter(999999.,math.inf)]) for _ in range(3))
    cases.append(('broad_'+str(i),o.case(q,t,s,lo,hi)))
rows=[]
for name,c in cases:
    q,b,_=o.ref(c);rows.append(' '.join([name,*[o.bits(x) for v in c for x in v],str(int(q)),str(int(b))]))
(R/'extra.tsv').write_text('\n'.join(rows)+'\n')
summary={'cases':len(cases),'fixture_sha256':hashlib.sha256((R/'extra.tsv').read_bytes()).hexdigest(),'seed':'0xf3e0aabb','unique_family_sample_indices':[0,1,2,63,64,65,127,255,1023,32767,49999]}
# Streaming reconstruction of unique instance fragment. Mesh extrema are separate shared source data.
for label in ['unique_wide','unique_cancellation','unique_scalar_q_scale']:
    h=hashlib.sha256();size=0
    def put(b):
        global size
        size+=len(b);h.update(b)
    put(b'{"instances":[')
    for i in range(50000):
        q,t,s,lo,hi=family(label,i)
        inst={'mesh':'10000000-0000-4000-8000-000000000001','material':'10000000-0000-4000-8000-000000000002','translation_m':list(t),'orientation_xyzw':list(q),'scale':list(s),'id':f'20000000-0000-4000-8000-{i:012x}'}
        if i:put(b',')
        put(json.dumps(inst,separators=(',',':')).encode())
    put(b']}')
    summary[label]={'instance_fragment_bytes':size,'json_value_nodes':850002,'sha256':h.hexdigest(),'fits_16MiB_fragment':size<16*1024*1024,'unique_q_scale':50000}
(R/'extra-oracle-results.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
