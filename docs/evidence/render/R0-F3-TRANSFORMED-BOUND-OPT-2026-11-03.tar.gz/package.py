#!/usr/bin/env python3
from pathlib import Path
import gzip,hashlib,tarfile
R=Path(__file__).resolve().parent
files=['OWNER.md','README.md','WIDTH-OPT.md','context.json','source-grammar.md','make.py','normalized_impl.rs','residual_exact.rs','main.rs','baseline.rs','sparse.rs','normalized.rs','residual.rs','extra_oracle.py','extra.tsv','extra-oracle-results.json','verification.json','restore-verification.json','results.json','run.py','package.py','verify-package.py']
files += ['base/'+p.name for p in sorted((R/'base').iterdir()) if p.is_file() and p.name not in ['many-instances.json'] and p.suffix not in ['.pyc']]
(R/'SHA256SUMS').write_text(''.join(hashlib.sha256((R/name).read_bytes()).hexdigest()+'  '+name+'\n' for name in files))
with (R/'selected.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name in files+['SHA256SUMS']:
    info=tar.gettarinfo(R/name,arcname=name)
    info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname=''
    with (R/name).open('rb') as source:tar.addfile(info,source)
print(hashlib.sha256((R/'selected.tar.gz').read_bytes()).hexdigest())
