from pathlib import Path
R=Path(__file__).resolve().parent
base=(R/'base/probe.rs').read_text()
end=base.index('#[derive(Clone, Copy, Debug)]')
start=base.index('#[derive(Clone, Debug, PartialEq, Eq)]')
sparse=base[:base.index('fn main()')]
ms=sparse.index('    fn mul(&self, o: &Self) -> Self {')
me=sparse.index('    fn f64(x: f64) -> Self {',ms)
sparse=sparse[:ms]+'''    fn mul(&self, o: &Self) -> Self {
        let mut r = Self::zero();
        let al = self.len(); let bl = o.len();
        for i in 0..al {
            if self.a[i] == 0 { continue; }
            for j in 0..bl {
                if o.a[j] == 0 { continue; }
                let k=i+j; assert!(k < L);
                let p=self.a[i] as u128*o.a[j] as u128;
                let low=(p as u64) as u128+r.a[k] as u128;
                r.a[k]=low as u64;
                let mut carry=(p>>64)+(low>>64); let mut k=k+1;
                while carry != 0 {
                    assert!(k < L);
                    let t=r.a[k] as u128+carry; r.a[k]=t as u64;
                    carry=t>>64; k+=1;
                }
            }
        }
        r.neg=self.neg != o.neg && r.len() != 0; r
    }
'''+sparse[me:]
normal=base[:start]+(R/'normalized_impl.rs').read_text()+base[end:base.index('fn main()')]
normal=normal.replace('.shl(2148)','').replace('.shl(1074)','')
residual=normal[:normal.index('fn exact(c: Case)')]+(R/'residual_exact.rs').read_text()+normal[normal.index('fn filter(c: Case)'):]
main=(R/'main.rs').read_text()
for name,src in [('baseline',base[:base.index('fn main()')]),('sparse',sparse),('normalized',normal),('residual',residual)]:
    (R/(name+'.rs')).write_text(src+main)
