#!/usr/bin/env python3
"""One timed family per fresh process; all child processes run serially."""
from pathlib import Path
import hashlib,json,os,platform,re,statistics,subprocess,time
R=Path(__file__).resolve().parent
variants=['baseline','sparse','normalized','residual']
families=['clear','equality','wide','cancellation','unique_translation','unique_scalar_q_scale','unique_wide','unique_cancellation','prepared','prepare_cost']
rows=[]
# Round-robin variants/families reduces systematic late-run bias. No parallel children.
for repeat in range(5):
    for family in families:
        for variant in variants:
            start=time.perf_counter_ns()
            p=subprocess.Popen([str(R/variant),family,'50000'],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            stdout=p.stdout.read();stderr=p.stderr.read()
            _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
            if p.returncode:raise RuntimeError((p.returncode,stdout,stderr))
            fields=stdout.split();record={k:int(v) for k,v in (x.split('=',1) for x in fields[1:])}
            rows.append({'repeat':repeat+1,'variant':variant,'family':family,'measurements':record,'wall_ns':time.perf_counter_ns()-start,'rss_bytes':usage.ru_maxrss,'stdout':stdout,'stderr':stderr})
    (R/'partial-results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(f'completed round {repeat+1}/5',flush=True)
summary={}
for variant in variants:
    summary[variant]={}
    for family in families:
        rr=[r for r in rows if r['variant']==variant and r['family']==family]
        vals=[r['measurements']['elapsed_ns'] for r in rr]
        summary[variant][family]={'min_ns':min(vals),'median_ns':statistics.median(vals),'max_ns':max(vals),'max_rss_bytes':max(r['rss_bytes'] for r in rr)}
result={'host':platform.node(),'uname':tuple(platform.uname()),'machine_family':'T6031 (uname kernel)','rustc':subprocess.check_output(['rustup','run','1.99.1','rustc','-Vv'],text=True),'build_flags':'--edition=2021 -C opt-level=3 -C target-cpu=native','count':50000,'repeats':5,'rows':rows,'summary':summary,'memory_scope':'Per-process maximum RSS from macOS wait4 rusage, in bytes. No TSV, JSON, Python oracle or F3 pipeline loaded in timed processes. Fixed count instances are streamed with no whole-array/cache allocation. One Prepared entry exists outside timed region in all variants; prepare_cost includes constructing/discarding 50k entries in its region.'}
(R/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(summary,indent=2))
