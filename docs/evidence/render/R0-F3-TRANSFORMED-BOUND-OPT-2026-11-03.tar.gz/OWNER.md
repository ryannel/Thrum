Owner: /root/f3_aabb_exact_opt, 2026-11-03.
Purpose: bounded exact transformed-AABB optimization experiment; no production edits.
Inputs: retained R0-F3-TRANSFORMED-BOUND-PROBE-2026-11-03 archive and candidate grammar.
Expected peak: under 100 MB disk, under 256 MB host RAM; serial native measurements.
Retain: selected source, fixture generator, baseline identity, raw measurements, width argument, compact report.
Closeout: verify extracted retained archive before deleting owned binaries/generated bulk.
