#!/usr/bin/env python3
"""Independent, finite Decimal oracle; no third-party modules or GPU execution.

Reference evaluates the SPEC's BRDF D*G2*F/(4ci*co), then multiplies E*ci.
Candidate evaluates its alternate D polynomial, scaled half vector and Smith ratio.
Only sampled equivalence is asserted; the analytic bound is checked separately.
"""
import decimal
from decimal import Decimal as Q
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import random
import struct
import subprocess
import time

decimal.getcontext().prec = 240
ZERO, ONE, TWO = Q(0), Q(1), Q(2)
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def atan_inv(n):
    x = ONE / n
    power, total, k = x, x, 1
    while True:
        power *= -x*x
        term = power / (2*k+1)
        newer = total + term
        if newer == total:
            return total
        total, k = newer, k+1


PI = 16*atan_inv(Q(5)) - 4*atan_inv(Q(239))
SFLOOR, HFLOOR = TWO**-16, TWO**-12


def dot(a, b):
    return sum((x*y for x, y in zip(a, b)), ZERO)


def unit(v):
    length = dot(v, v).sqrt()
    return tuple(x/length for x in v)


def clamp(v):
    return min(ONE, max(ZERO, v))


def fixture(name, ci, co, r='.32', f0='.04', az='opposed', axis=2, sign_certificate=True):
    ci, co, r, f0 = map(Q, (ci, co, r, f0))
    si, so = (ONE-ci*ci).sqrt(), (ONE-co*co).sqrt()
    cp, sp = {'opposed': (-ONE, ZERO), 'same': (ONE, ZERO),
              'right': (ZERO, ONE), 'three_fifths': (Q('.6'), Q('.8'))}[az]
    wi, wo, n = (si, ZERO, ci), (so*cp, so*sp, co), (ZERO, ZERO, ONE)
    if axis != 2:
        def perm(v):
            return (v[2], v[0], v[1]) if axis == 0 else (v[1], v[2], v[0])
        wi, wo, n = map(perm, (wi, wo, n))
    return dict(name=name, wi=wi, wo=wo, n=n, r=r, f0=f0, sign_certificate=sign_certificate)


def validate(c):
    vals = [*c['wi'], *c['wo'], *c['n'], c['r'], c['f0']]
    if not all(x.is_finite() for x in vals):
        return 'nonfinite_input'
    if not (ZERO <= c['r'] <= ONE and ZERO <= c['f0'] <= ONE):
        return 'material_outside_real_domain'
    if any(abs(dot(c[v], c[v])-ONE) > Q('1e-210') for v in ('wi', 'wo', 'n')):
        return 'nonunit_input'
    return None


def reference(c):
    """Original SPEC expression, including the SPEC's perceptual roughness floor."""
    if reason := validate(c):
        return dict(status=reason)
    ci, co = dot(c['n'], c['wi']), dot(c['n'], c['wo'])
    if ci <= ZERO or co <= ZERO:
        return dict(status='zero_hemisphere', L=ZERO)
    h = unit(tuple(i+o for i, o in zip(c['wi'], c['wo'])))
    ch, vh = dot(c['n'], h), dot(c['wo'], h)
    alpha = max(Q('.045'), c['r'])**2
    a = alpha**2
    D = a / (PI * (ONE + ch**2*(a-ONE))**2)
    gi = (a + (ONE-a)*ci**2).sqrt()
    go = (a + (ONE-a)*co**2).sqrt()
    G2 = TWO*ci*co / (ci*go+co*gi)
    F = c['f0'] + (ONE-c['f0'])*(ONE-vh)**5
    brdf = D*G2*F / (4*ci*co)
    return dict(status='positive', L=brdf*ci, bound=ONE/(TWO*PI*alpha**3),
                D=D, F=F, ci=ci, co=co, alpha=alpha)


def candidate(c, enforce=True):
    if reason := validate(c):
        return dict(status=reason)
    if enforce and not c['sign_certificate']:
        return dict(status='sign_uncertified')
    ci_raw, co_raw = dot(c['n'], c['wi']), dot(c['n'], c['wo'])
    if ci_raw <= ZERO or co_raw <= ZERO:
        return dict(status='zero_hemisphere', L=ZERO)
    ci, co = clamp(ci_raw), clamp(co_raw)
    s = max(ci, co)
    v = tuple(i+o for i, o in zip(c['wi'], c['wo']))
    hm = max(map(abs, v))
    if enforce and c['r'] < Q('.32'):
        return dict(status='roughness_outside_fixture')
    if enforce and s < SFLOOR:
        return dict(status='s_floor_refusal')
    if enforce and hm < HFLOOR:
        return dict(status='hm_floor_refusal')
    z = tuple(max(-ONE, min(ONE, t/hm)) for t in v)
    h = unit(z)
    ch, vh = clamp(dot(c['n'], h)), clamp(dot(c['wo'], h))
    alpha = c['r']*c['r']
    a = alpha*alpha
    ch2 = ch*ch
    d = max(a, (ONE-ch2)+a*ch2)
    D = a/(PI*d*d)
    gi = (a+(ONE-a)*ci*ci).sqrt()
    go = (a+(ONE-a)*co*co).sqrt()
    x, y = clamp(ci/s), clamp(co/s)
    den = max(alpha, x*go+y*gi)
    K = x/(TWO*den)
    F = clamp(c['f0']+(ONE-c['f0'])*(ONE-vh)**5)
    return dict(status='positive', L=D*F*K, D=D, F=F, K=K, d=d, den=den,
                alpha=alpha, a=a, s=s, hm=hm, x=x, y=y)


class F32:
    """Round each explicit op to binary32; optional input/output FTZ.

    Inputs are the independently authored high-precision geometric vectors rounded
    to f32. The scalar n is an exact axis. FMA uses exact Decimal product+sum before
    binary32 conversion. Decimal->float->f32 can double round on halfway cases;
    this is a selected numerical experiment, not a full IEEE/WGSL interpreter.
    """
    def __init__(self, ftz=False, fused=False, reassoc=False):
        self.ftz, self.fused, self.reassoc = ftz, fused, reassoc
        self.min_nonzero = math.inf
        self.max_finite = 0.0
        self.zero_divisions = 0

    def q(self, v):
        try:
            v = struct.unpack('f', struct.pack('f', float(v)))[0]
        except OverflowError:
            v = math.copysign(math.inf, float(v))
        if self.ftz and 0 < abs(v) < 2**-126:
            v = math.copysign(0., v)
        if math.isfinite(v):
            self.max_finite = max(self.max_finite, abs(v))
            if v:
                self.min_nonzero = min(self.min_nonzero, abs(v))
        return v

    def add(self, a, b): return self.q(a+b)
    def sub(self, a, b): return self.q(a-b)
    def mul(self, a, b): return self.q(a*b)
    def div(self, a, b):
        if b == 0:
            self.zero_divisions += 1
            return float('nan') if a == 0 else math.copysign(float('inf'), a)
        return self.q(a/b)
    def sqrt(self, a): return self.q(math.sqrt(a))
    def fma(self, a, b, c): return self.q(Q(a)*Q(b)+Q(c))
    def dot(self, a, b):
        if self.fused:
            return self.fma(a[0], b[0], self.fma(a[1], b[1], self.mul(a[2], b[2])))
        return self.add(self.add(self.mul(a[0],b[0]),self.mul(a[1],b[1])),self.mul(a[2],b[2]))

    def evaluate(self, c, scaled=True, guards=True):
        wi, wo, n = (tuple(map(self.q, c[v])) for v in ('wi', 'wo', 'n'))
        ci, co = self.dot(n, wi), self.dot(n, wo)
        if ci <= 0 or co <= 0:
            return dict(status='zero_hemisphere', L=0.)
        ci, co = min(1., ci), min(1., co)
        s = max(ci, co)
        v = tuple(self.add(i, o) for i, o in zip(wi, wo))
        hm = max(map(abs, v))
        if scaled and guards and (s < 2**-16 or hm < 2**-12):
            return dict(status='floor_refusal')
        z = tuple(self.div(t, hm) for t in v) if scaled else v
        length = self.sqrt(self.dot(z, z))
        h = tuple(self.div(t, length) for t in z)
        ch, vh = (min(1.,max(0.,self.dot(vv,h))) for vv in (n,wo))
        alpha = self.mul(self.q(c['r']), self.q(c['r']))
        a = self.mul(alpha, alpha)
        ch2 = self.mul(ch,ch)
        d = max(a, self.fma(a,ch2,self.sub(1.,ch2)) if self.fused else
                    self.add(self.sub(1.,ch2),self.mul(a,ch2)))
        dden = self.mul(self.q(PI),self.mul(d,d)) if self.reassoc else self.mul(self.mul(self.q(PI),d),d)
        D = self.div(a,dden)
        def g(cos):
            t = self.mul(self.sub(1.,a),self.mul(cos,cos))
            return self.sqrt(self.add(a,t))
        gi, go = g(ci), g(co)
        if scaled:
            x,y = self.div(ci,s),self.div(co,s)
            den = max(alpha,self.add(self.mul(x,go),self.mul(y,gi)))
            K = self.div(x,self.mul(2.,den))
        else:
            den = self.mul(2.,self.add(self.mul(ci,go),self.mul(co,gi)))
            K = self.div(ci,den)
        one_vh = self.sub(1.,vh)
        fifth = one_vh
        for _ in range(4): fifth = self.mul(fifth,one_vh)
        f0 = self.q(c['f0'])
        F = min(1.,max(0.,self.add(f0,self.mul(self.sub(1.,f0),fifth))))
        L = self.mul(D,self.mul(F,K)) if self.reassoc else self.mul(self.mul(D,F),K)
        return dict(status='evaluated', L=L, ci=ci,co=co,hm=hm,den=den, D=D,K=K)


def short(v):
    if isinstance(v, Q): return format(v,'.24g')
    if isinstance(v, dict): return {k:short(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [short(x) for x in v]
    if isinstance(v,float) and not math.isfinite(v): return str(v)
    return v


def cases():
    # Normal/material corners and permutations include F0=0 and 1.
    for r,f0,axis in itertools.product(['.045','.32','.5','1'],['0','.04','1'],range(3)):
        yield fixture(f'normal_r{r}_f{f0}_axis{axis}','1','1',r,f0,axis=axis)
    for k in [1,2,4,8,11,12,13,16,24,63,126,140]:
        t = TWO**-k
        for r in ['.045','.32','1']:
            yield fixture(f'sharp_k{k}_r{r}',t,t*t,r)
    # Boundary values use exact binary32 neighbours, represented in Decimal.
    eps = TWO**-24
    for d in [-eps,ZERO,eps*TWO]:
        yield fixture(f's_floor_neighbour_{d}',SFLOOR*(ONE+d),SFLOOR/3,az='same')
        yield fixture(f'hm_floor_neighbour_{d}',HFLOOR*(ONE+d)/2,HFLOOR*(ONE+d)/2)
    rounded_r=Q(struct.unpack('f',struct.pack('f',.32))[0])
    yield fixture('r32_narrows_below_exact_floor','1','1',rounded_r)
    yield fixture('r32_next_float_above_floor','1','1',rounded_r+TWO**-25)
    for ci,co in [(ONE,TWO**-140),(TWO**-10,TWO**-140),
                  (TWO**-140,ONE),(TWO**-126,TWO**-126)]:
        yield fixture(f'ratio_{ci}_{co}',ci,co)
    yield fixture('negative_co',Q('.5'),Q('-.1'))
    yield fixture('zero_co',Q('.5'),ZERO)
    yield fixture('negative_ci',Q('-.1'),Q('.5'))
    yield fixture('opposed_horizon',ZERO,ZERO)
    yield fixture('ambiguous_positive_subnormal',TWO**-10,TWO**-140,sign_certificate=False)
    c=fixture('ambiguous_dot_cancellation','1','1',sign_certificate=False)
    c['n']=(Q('.6'),ZERO,Q('.8'))
    tiny=TWO**-140
    c['wi']=unit((Q('.8')+tiny*Q('.6'),ZERO,Q('-.6')+tiny*Q('.8')))
    yield c
    c=dict(c,name='ambiguous_negative_dot_cancellation')
    c['wi']=unit((Q('.8')-tiny*Q('.6'),ZERO,Q('-.6')-tiny*Q('.8')))
    yield c
    yield fixture('below_semantic_roughness_floor','1','1','.02')
    rng = random.Random(0x600DCAFE)
    for j in range(5000):
        # A reproducible mixture of log grazing and interior values, no trig lib.
        ci = Q(rng.randrange(1,1000000))/1000000 if j%2 else TWO**-rng.randrange(1,151)
        co = Q(rng.randrange(1,1000000))/1000000 if j%3 else TWO**-rng.randrange(1,151)
        yield fixture(f'random_{j}',ci,co,r=rng.choice(['.045','.32','.321','.5','1']),
                      f0=rng.choice(['0','.04','.5','1']),az=rng.choice(['opposed','same','right','three_fifths']),axis=j%3)
    for key,val in [('r',Q('NaN')),('f0',Q('Infinity')),('f0',Q('-.1')),('r',Q('-1')),('r',Q('1.01'))]:
        c=fixture(f'invalid_{key}_{val}','1','1');c[key]=val;yield c
    c=fixture('invalid_nonunit','1','1');c['n']=(ZERO,ZERO,TWO);yield c


def main():
    started=time.perf_counter()
    fixtures=list(cases())
    equivalence_count, admitted_count, bound_count = 0,0,0
    max_relative, max_ratio = ZERO,ZERO
    statuses={}
    records=[]
    f32records=[]
    f32summaries={}
    for c in fixtures:
        ref, cand = reference(c),candidate(c)
        statuses[cand['status']]=statuses.get(cand['status'],0)+1
        if ref['status']=='positive':
            bound_count+=1
            ratio=ref['L']/ref['bound']
            assert ratio <= ONE+Q('1e-210'),(c['name'],'bound',ratio)
            max_ratio=max(max_ratio,ratio)
            if c['r'] >= Q('.045'):
                mathematical=candidate(c,enforce=False)
                err=abs(ref['L']-mathematical['L'])/max(abs(ref['L']),ONE)
                assert err < Q('1e-210'),(c['name'],'equivalence',err)
                equivalence_count+=1
                max_relative=max(max_relative,err)
            if cand['status']=='positive':
                admitted_count+=1
                assert cand['D']<=32 and cand['K']<=5 and cand['L']<=160
                assert cand['d']>=cand['a'] and cand['den']>=cand['alpha']
        if not c['name'].startswith('random_'):
            records.append(dict(input=c,reference=ref,candidate=cand,
                                mathematical=candidate(c,False) if ref['status']=='positive' else None))
        if cand['status']=='positive' or c['name'] in ['ambiguous_positive_subnormal','ambiguous_dot_cancellation','ambiguous_negative_dot_cancellation','sharp_k126_r.32','ratio_'+str(TWO**-126)+'_'+str(TWO**-126)]:
            for ftz,fused,reassoc in itertools.product([False,True],repeat=3):
                mode=f'ftz{int(ftz)}_fma{int(fused)}_reassoc{int(reassoc)}'
                sim=F32(ftz,fused,reassoc)
                got=sim.evaluate(c)
                summary=f32summaries.setdefault(mode,dict(count=0,nonfinite=0,zero_divisions=0,max_rel=0.,worst=None,sign_lost=0,max_abs=0.,evaluated_max_abs=0.,evaluated_max_bound_scaled_abs=0.,evaluated_worst_abs=None,evaluated_count=0))
                summary['count']+=1
                summary['zero_divisions']+=sim.zero_divisions
                if 'L' in got and not math.isfinite(got['L']):
                    summary['nonfinite']+=1
                if ref['status']=='positive' and 'L' in got:
                    rel=float(abs(Q(got['L'])-ref['L'])/max(abs(ref['L']),Q('1e-220')))
                    absolute=float(abs(Q(got['L'])-ref['L']))
                    if rel>summary['max_rel']:
                        summary['max_rel'],summary['worst']=rel,c['name']
                    summary['max_abs']=max(summary['max_abs'],absolute)
                    if got['status']=='zero_hemisphere':summary['sign_lost']+=1
                    if got['status']=='evaluated':
                        summary['evaluated_count']+=1
                        if absolute>summary['evaluated_max_abs']:
                            summary['evaluated_max_abs']=absolute
                            summary['evaluated_worst_abs']=c['name']
                        summary['evaluated_max_bound_scaled_abs']=max(summary['evaluated_max_bound_scaled_abs'],absolute/float(ref['bound']))
                if not c['name'].startswith('random_'):
                    f32records.append(dict(name=c['name'],mode=mode,result=got))
    # An explicit unsafe combined denominator FTZ witness, outside candidate floors.
    c=fixture('combined_FTZ_witness',TWO**-126,TWO**-126)
    unscaled=F32(ftz=True)
    ci=unscaled.q(TWO**-126)
    alpha=unscaled.mul(unscaled.q('.32'),unscaled.q('.32'))
    a=unscaled.mul(alpha,alpha)
    g=unscaled.sqrt(unscaled.add(a,unscaled.mul(unscaled.sub(1.,a),unscaled.mul(ci,ci))))
    den=unscaled.mul(2.,unscaled.add(unscaled.mul(ci,g),unscaled.mul(ci,g)))
    K=unscaled.div(ci,den)
    unsafe=dict(ci=ci,co=ci,g=g,den=den,K=K,L=unscaled.mul(unscaled.q(reference(c)['D']),K),
                note='Only the combined Smith ratio is simulated here; D supplied from oracle, F=1.')
    assert not math.isfinite(unsafe['L']) and unscaled.zero_divisions>0
    # Half-range counterexample and sufficient fixture budget are separate checks.
    normal=fixture('half_overflow','1','1','.045')
    half_dielectric=reference(normal)['L']*100000/1024
    assert half_dielectric>65504
    E=Q(100000)+Q(4000)/Q('.0722')
    stored=(Q(10000)+Q(1000)/PI+E*(ONE/PI+160))/1024
    assert stored<Q(24341)
    tight=(Q(10000)+Q(1000)/PI+E*(ONE/PI+ONE/(TWO*PI*(Q('.32')**2)**3)))/1024
    named={c['name']:c for c in fixtures}
    expected={'negative_co':'zero_hemisphere','zero_co':'zero_hemisphere',
              'negative_ci':'zero_hemisphere','opposed_horizon':'zero_hemisphere',
              'ambiguous_dot_cancellation':'sign_uncertified',
              'ambiguous_negative_dot_cancellation':'sign_uncertified',
              'ambiguous_positive_subnormal':'sign_uncertified',
              'sharp_k12_r.32':'positive','sharp_k13_r.32':'hm_floor_refusal',
              'sharp_k140_r.32':'s_floor_refusal',
              'r32_narrows_below_exact_floor':'roughness_outside_fixture',
              'r32_next_float_above_floor':'positive',
              'invalid_nonunit':'nonunit_input'}
    for name,status in expected.items():assert candidate(named[name])['status']==status
    assert reference(named['ambiguous_negative_dot_cancellation'])['status']=='zero_hemisphere'
    reciprocal_count=0
    reciprocal_max=ZERO
    for c in fixtures:
        if reciprocal_count==256:break
        r=reference(c)
        if r['status']!='positive':continue
        swapped=dict(c,wi=c['wo'],wo=c['wi'])
        other=reference(swapped)
        reciprocal_error=abs(r['L']/r['ci']-other['L']/other['ci'])/max(ONE,r['L']/r['ci'])
        reciprocal_max=max(reciprocal_max,reciprocal_error)
        assert reciprocal_error<Q('1e-180')
        reciprocal_count+=1
    # Recompute particularly ill-conditioned reference cases at higher precision.
    cross=[]
    for name in ['sharp_k140_r.045','sharp_k140_r.32','normal_r.045_f.04_axis2']:
        c=next(c for c in fixtures if c['name']==name)
        old=reference(c)['L']
        with decimal.localcontext() as ctx:
            ctx.prec=320
            # The fixture remains its exact saved 240-digit authored approximation.
            fresh=reference(c)['L']
        error=abs(old-fresh)/fresh
        assert error<Q('1e-210')
        cross.append(dict(name=name,relative_difference=error))
    files=['docs/design/CONTRACTS.md','docs/design/RENDER-SPEC.md','docs/design/research/R0-ARITHMETIC-ENVELOPE-2026-11-03.md']
    report=dict(source_revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
                source_hashes={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in files},
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),python=platform.python_version(),
                decimal_precision=240,fixture_seed='0x600DCAFE',fixtures=len(fixtures),
                reciprocity_checks=reciprocal_count,reciprocity_max_unit_scaled_difference=reciprocal_max,explicit_classification_checks=len(expected),
                equivalence_count=equivalence_count,admitted_count=admitted_count,bound_count=bound_count,
                max_unit_scaled_difference=max_relative,max_bound_fraction=max_ratio,statuses=statuses,
                stored_loose_budget=stored,stored_alpha_exact_budget=tight,half_overflow_witness=half_dielectric,
                precision_crosscheck=cross,unsafe_combined_ftz=unsafe,
                f32_summaries=f32summaries,selected_cases=records,selected_f32=f32records,
                wall_seconds=time.perf_counter()-started)
    (OUT/'results.json').write_text(json.dumps(short(report),indent=2,sort_keys=True)+'\n')
    print(json.dumps(short({k:v for k,v in report.items() if k not in ['selected_cases','selected_f32']}),indent=2,sort_keys=True))


if __name__=='__main__':main()
