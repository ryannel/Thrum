# Bounded independent GGX oracle — scratch, 3 November 2026

This is independent CPU numerical research executed at main
`50024fa8bbe57fa9d22c651a359f73cb4dccd4e3`; the evaluated candidate was
introduced at ancestor `599baacae4a2550927b304127dcf1fae2a3a678c`.
No shader, GPU execution, source
admission, visual acceptance or exhaustive WGSL arithmetic proof is supplied.
Only this scratch directory was written. Existing unrelated tracked edits were
left alone. No dependency install or network access was needed.

Run from the repository root:

```sh
python3 tmp/r0-ggx-oracle/oracle.py > tmp/r0-ggx-oracle/run-summary.json
```

`oracle.py` is the complete reproducible source. `results.json` records the
selected cases and eight selected f32 modes. Long Decimal values are displayed
to 24 significant digits in JSON; their complete construction is in the source,
including every power of two, deterministic seed and 240-digit direction.

## Real reference and independent comparison

The stdlib Decimal context uses 240 decimal digits. Pi is computed with Machin's
arctangent identity rather than a binary64 constant. No combined Smith identity
is used in the reference: it evaluates the RENDER-SPEC's original `D`, original
height-correlated `G2`, Schlick `F`, `D*G2*F/(4ci*co)`, then multiplies by `ci`
(illuminance is one). It applies the specification's `.045` roughness floor.

The comparison evaluator separately constructs the scaled half vector, alternate
`d` polynomial, `x/y`, guarded denominator and `K` from the proposed expression.
Real-domain assumptions are finite unit directions/normal, `roughness,F0` in
`[0,1]`, and positive incident/view hemisphere dots. Nonpositive hemispheres
return zero before the half vector is formed. Material and nonunit violations
refuse. The finite authored Decimal unit-vector tolerance is `1e-210`.

The fixture admission additionally requires exact `roughness>=.32`, the stated
`s>=2^-16` and `hm>=2^-12` floors, and a supplied sign-certificate flag. This flag
is a test input, **not an implemented certificate or margin proof**. Mathematical
equivalence is also checked with these fixture exclusions disabled, so excluded
bright angles cannot disappear from the reference comparison.

The quantitative bound is separately derived: `D<=1/(pi*alpha²)` follows from
`0<=ch²<=1` and `0<alpha<=1`; `gi,go>=alpha` gives the combined cosine-weighted
Smith factor at most `ci/[2*alpha*(ci+co)] <= 1/(2*alpha)`; `0<=F<=1` completes
`L/E<=1/(2*pi*alpha³)`. In the specified opposing family `ci=t,co=t²`, the half
vector tends to the normal and the Fresnel term tends to one, attaining the
bound as a limit. This derivation does not presume the candidate evaluator.

## Completed self-check

Final run: Python 3.15.2 on the local host, **2.5459 s** wall time for the entire
oracle and selected simulations (not a render-cost measurement).

- 5,098 fixtures, including 5,000 deterministic mixed linear/log grazing samples.
- 5,086 original-versus-scaled positive-hemisphere evaluations passed with
  `abs(delta)/max(1,abs(reference)) < 1e-210`; maximum was
  `8.02593108655808049861920e-234`.
- 5,087 positive real-reference results passed the sharp quantitative bound.
- 3,507 cases passed the exact mathematical fixture gates and the loose bounds
  `D<=32`, `K<=5`, `L/E<=160`, `d>=a`, `den>=alpha`.
- 13 explicit classification assertions passed; 256 sampled BRDF reciprocity
  checks passed at `1e-180` unit-scaled tolerance (maximum `8.04222554e-198`).
  This tolerance accounts for authored vectors stored with finite 240-digit
  precision near almost opposite directions.
- Three ill-conditioned references were recomputed at 320 digits over those
  same saved 240-digit inputs; maximum relative change was `2.02287183e-235`.
- Separate range witness: normal `.045` dielectric, 100,000 lux, `p=1/1024`
  stores `75805.3950864461`, above 65,504.
- Illustrative blue budget using loose coefficient 160:
  `24339.8926984608266022812 < 24341`. Using the exact `.32` alpha bound gives
  `22552.8633298213391664013`.

The candidate classifications were 3,507 positive, 531 s-floor refusals,
17 hm-floor refusals, 1,030 roughness-profile exclusions, three uncertified
sign refusals, four zero hemispheres, two nonfinite inputs, three invalid
material-domain values, and one nonunit input.

## Exact discriminating cases

All values below have `r=.32,F0=.04,E=1`, unless specified. Let
`wi=(sqrt(1-ci²),0,ci)` and `wo=(-sqrt(1-co²),0,co)` with `n=(0,0,1)`.

| Case | Original real L | Candidate fixture outcome |
| --- | ---: | --- |
| `ci=2^-8,co=2^-16` | 146.158833311684740678621 | positive; equivalent |
| `ci=2^-12,co=2^-24` | 148.101166996892454673179 | positive; equivalent |
| `ci=2^-13,co=2^-26` | 148.162975717771350322372 | hm-floor refusal |
| `ci=2^-140,co=2^-280` | 148.224591363123930775452 | s-floor refusal |
| `ci=2^-10,co=2^-140` | 147.870875074353955170855 | sign-uncertified test refuses |
| `ci=.5,co=-.1` | zero | zero before clamps |
| `ci=co=0`, exactly opposite | zero | zero before half normalization |

The last positive-subnormal case meets both mathematical scale floors; a raw
f32 sign test can still lose its bright contribution. The suite also exercises
ratios with the tiny cosine in the numerator, ratios equal to one, `s` and `hm`
at and immediately beside their floors, axes 0/1/2, aligned and right-angle
azimuths, roughness `.045/.32/.321/.5/1`, and `F0=0/.04/.5/1`.

At normal incidence with authored `roughness=.02`, the original uses `.045` and
has `L=776.247245685208161043176`, whereas blindly evaluating the unfloored
candidate would give `19894.3678864869169711`. The fixture correctly refuses;
the candidate is not the full-material-domain specification without its
admission prerequisite.

Exact `.32` narrows to binary32 `0.319999992847442626953125`, below the literal
real `.32` admission floor. The next float is `0.3200000226497650146484375`.
The suite refuses/admits these neighbours respectively. Both retain the looser
alpha `.1` bound; the selected contract still needs to say which actual cooked
roughness values it promises. This is not a storage-overflow discovery.

## Selected f32 observations

The optional simulation rounds explicit scalar operations to binary32, with
FTZ off/on, selected fused dot/polynomial operations off/on, and two selected
product associations. It starts with the high-precision directions narrowed
to binary32. FMA is evaluated with Decimal exact product-plus-sum before
narrowing. Square roots use host sqrt then f32 narrowing. This does not model
WGSL's allowed approximate transcendental accuracy or every reassociation.
The Decimal→binary64→binary32 conversion can double-round halfway cases;
there is no claim that this is an exhaustive IEEE/WGSL interpreter.

- Across eight modes no sampled scaled evaluation produced nonfinite output or
  a zero division. This includes deliberately bypassed sign-certification
  diagnostics, whose accuracy failures must not be counted as admissions.
  The saved `evaluated_max_abs` fields include such diagnostic rows; they are
  not certified-admission error bounds. The simulator reports final outputs,
  not every intermediate value's finiteness.
- For the admitted real `ci=2^-12,co=2^-24` sharp case, all selected modes
  returned `148.0148468017578`, versus `148.10116699689245` in the reference.
  Absolute error is `0.08632019513464217` (about 0.0583%); direction narrowing
  changes the nearly cancelling horizontal half-vector component. The scale
  floors alone do not establish a small directional-error tolerance.
- The exact-positive `ci=2^-10,co=2^-140` case yields `147.8708953857422`
  without FTZ, but the FTZ raw sign branch yields **zero** instead of
  `147.87087507435396`. This case is excluded when its sign certificate is
  absent. Even without FTZ, smaller positive source cosines may narrow to zero.
- A separate unscaled-ratio witness with `ci=co=2^-126` has
  `gi=go≈.1023999974`. Flushing `ci*go` and `co*gi` makes its denominator zero
  and the ratio infinite. Only this Smith ratio is simulated in that witness;
  its D is independently supplied by the oracle. The candidate refuses its
  scale domain before division.
- More subtly, use `n=(.6,0,.8)`, `wo=(0,0,1)`, and
  `wi=normalize((.8,0,-.6) ± 2^-140*n)`. The opposite real signs produce the
  **same f32 vectors**. The unfused dot rounds to zero; the selected fused dot
  becomes `+7.152557657263969e-9`, yielding `3.004809456808033e-10` for both
  signs. The exact negative input has zero BRDF and the exact positive input
  has `3.014090486136593e-44`. Both are sign-uncertified and refused. This
  shows why raw comparisons and a particular fusion order cannot create a
  source sign certificate.

No exposure, tone/encode/FXAA, f16 packing, scene transforms, interpolation,
filtering, local-light distance, shader validation, backend/device behavior or
ordinary moving-image tolerance is qualified here. No renderer was selected
and no tracked change or maturity promotion was made.

## Source identity

SHA-256:

| File | Digest |
| --- | --- |
| `oracle.py` | `2759658594e418f6caa2ba8865785fc31ac4888037bbad348b982c8a7254c1f4` |
| `results.json` | `e90b1e432b6cd9338ecfe3a7a530e27372efcb8317803969c8351ed98d7fb52b` |
| `docs/design/CONTRACTS.md` | `093bd2e4e4d724efdc22d746e4bbb9899795c1d049849d5b7ded85d1e2d92154` |
| `docs/design/RENDER-SPEC.md` | `522519e26ce8b03be7064b52226771de65f998e23928378b6baf88a8acd5f557` |
| `docs/design/research/R0-ARITHMETIC-ENVELOPE-2026-11-03.md` | `31207083a1d8960856ad1bdff9e22db913b226e7d9dcab4d0ce2b0ab374c1976` |

The generated report contains measured wall time, so rerunning will change its
file hash even when numerical results are unchanged.
