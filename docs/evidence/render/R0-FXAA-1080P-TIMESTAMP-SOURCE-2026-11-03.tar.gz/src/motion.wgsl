// Encoded RGB + encoded-channel luma. This is a diagnostic animation, not a scene renderer.
@group(0) @binding(0) var<uniform> params: vec4<f32>; // width, height, x motion in pixels, unused

@vertex fn vs_full(@builtin(vertex_index) index: u32) -> @builtin(position) vec4<f32> {
    let corners = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
    return vec4<f32>(corners[index], 0.0, 1.0);
}

@fragment fn fs_motion(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32> {
    let p = position.xy;
    let u = p / params.xy;
    let x = p.x - params.z;
    var rgb = vec3<f32>(0.08 + 0.12 * u.y, 0.11 + 0.10 * u.y, 0.16 + 0.08 * u.y);
    let diagonal = smoothstep(-0.8, 0.8, x - (0.54 * p.y + 0.10 * params.x));
    rgb = mix(rgb, vec3<f32>(0.88, 0.72, 0.44), diagonal);
    if (u.x > 0.48 && u.x < 0.95 && u.y > 0.12 && u.y < 0.88) {
        let glyph_x = x - floor(x / 37.0) * 37.0;
        let glyph_y = p.y - floor(p.y / 51.0) * 51.0;
        let stroke = min(min(abs(glyph_x - 5.4), abs(glyph_x - 24.8)), abs(glyph_y - 8.7));
        let ink = 1.0 - smoothstep(0.25, 1.15, stroke);
        rgb = mix(rgb, vec3<f32>(0.96, 0.95, 0.86), ink);
    }
    let line = 1.0 - smoothstep(0.35, 1.15, abs(x - 0.78 * params.x));
    rgb = mix(rgb, vec3<f32>(0.03, 0.96, 0.80), line);
    let luma = dot(rgb, vec3<f32>(0.299, 0.587, 0.114));
    return vec4<f32>(rgb, luma);
}
