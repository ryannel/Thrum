//! Counter lifetime/resolve ordering diagnosis. No renderer or shader changes.
use sha2::{Digest, Sha256};
use std::{
    fs,
    sync::mpsc,
    time::{Duration, Instant},
};
use wgpu::*;
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
const W: u32 = 1920;
const H: u32 = 1080;
const WARM: i32 = 16;
const N: i32 = 128;
fn main() -> Result<()> {
    let rep: usize = std::env::args().nth(1).unwrap_or("0".into()).parse()?;
    let src = fs::read_to_string(std::env::var("FXAA_SHADER_PATH")?)?;
    let hash = hex(Sha256::digest(src.as_bytes()));
    assert_eq!(
        hash,
        "5f26af44c01e3e605c7822b1881b4200ec8bebb6dfcdbabd41fe850cacb64384"
    );
    let m = naga::front::wgsl::parse_str(&src)?;
    naga::valid::Validator::new(
        naga::valid::ValidationFlags::all(),
        naga::valid::Capabilities::empty(),
    )
    .validate(&m)?;
    let mut desc = InstanceDescriptor::new_without_display_handle();
    desc.backends = Backends::METAL;
    let inst = Instance::new(desc);
    let adapter = pollster::block_on(inst.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    println!("# adapter={:?}", adapter.get_info());
    println!("# shader_sha256={hash},rep={rep},width={W},height={H},warmup={WARM},measured={N}");
    let (d, q) = pollster::block_on(adapter.request_device(&DeviceDescriptor {
        required_features: Features::TIMESTAMP_QUERY,
        ..Default::default()
    }))?;
    println!("# timestamp_period_ns={}", q.get_timestamp_period());
    let shader = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("unchanged selected FXAA"),
        source: ShaderSource::Wgsl(src.into()),
    });
    let motion = d.create_shader_module(ShaderModuleDescriptor {
        label: Some("held encoded input"),
        source: ShaderSource::Wgsl(include_str!("motion.wgsl").into()),
    });
    let fxaa = pipe(&d, &shader, "vs_fxaa", "fs_fxaa");
    let source = pipe(&d, &motion, "vs_full", "fs_motion");
    let sampler = d.create_sampler(&SamplerDescriptor {
        address_mode_u: AddressMode::ClampToEdge,
        address_mode_v: AddressMode::ClampToEdge,
        min_filter: FilterMode::Linear,
        mag_filter: FilterMode::Linear,
        mipmap_filter: MipmapFilterMode::Nearest,
        lod_min_clamp: 0.,
        lod_max_clamp: 0.,
        ..Default::default()
    });
    let a = tex(
        &d,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING,
    );
    let b = tex(
        &d,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC,
    );
    let av = a.create_view(&Default::default());
    let bv = b.create_view(&Default::default());
    let params = d.create_buffer(&BufferDescriptor {
        label: None,
        size: 16,
        usage: BufferUsages::UNIFORM,
        mapped_at_creation: true,
    });
    {
        let mut m = params.slice(..).get_mapped_range_mut()?;
        for (i, v) in [W as f32, H as f32, 0.37, 0.].iter().enumerate() {
            m.slice(i * 4..i * 4 + 4).copy_from_slice(&v.to_le_bytes());
        }
    }
    params.unmap();
    let sbg = d.create_bind_group(&BindGroupDescriptor {
        label: None,
        layout: &source.get_bind_group_layout(0),
        entries: &[BindGroupEntry {
            binding: 0,
            resource: params.as_entire_binding(),
        }],
    });
    let bg = d.create_bind_group(&BindGroupDescriptor {
        label: None,
        layout: &fxaa.get_bind_group_layout(0),
        entries: &[
            BindGroupEntry {
                binding: 0,
                resource: BindingResource::TextureView(&av),
            },
            BindGroupEntry {
                binding: 1,
                resource: BindingResource::Sampler(&sampler),
            },
        ],
    });
    let mut e = d.create_command_encoder(&Default::default());
    draw(&mut e, &av, &source, &sbg, None, true);
    let si = q.submit([e.finish()]);
    wait(&d, si)?;
    println!(
        "method,rep,sample,slot,begin_ticks,end_ticks,encode_submit_us,render_submit_complete_us,resolve_submit_complete_us,total_sample_us"
    );
    let mut methods = [
        "reuse_early",
        "reuse_same",
        "unique_same",
        "reuse_delayed",
        "unique_delayed",
        "no_queries",
        "clear_delayed",
    ];
    methods.rotate_left(rep % 7);
    let mut expected_hash = None;
    for method in methods {
        let delayed = method.ends_with("delayed");
        let counter = method != "no_queries";
        let reuse = method.starts_with("reuse");
        let drawing = method != "clear_delayed";
        let count = if reuse { 2 } else { ((WARM + N) * 2) as u32 };
        let qs = counter.then(|| {
            d.create_query_set(&QuerySetDescriptor {
                label: Some(method),
                ty: QueryType::Timestamp,
                count,
            })
        });
        let resolve = d.create_buffer(&BufferDescriptor {
            label: None,
            size: 256,
            usage: BufferUsages::QUERY_RESOLVE | BufferUsages::COPY_SRC,
            mapped_at_creation: false,
        });
        let rb = d.create_buffer(&BufferDescriptor {
            label: None,
            size: 16,
            usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        for index in 0..(WARM + N) {
            let sample = index - WARM;
            let slot = if reuse { 0 } else { index as u32 * 2 };
            let total = Instant::now();
            let mut e = d.create_command_encoder(&Default::default());
            draw(
                &mut e,
                &bv,
                &fxaa,
                &bg,
                qs.as_ref().map(|s| (s, slot)),
                drawing,
            );
            if !delayed && let Some(s) = &qs {
                e.resolve_query_set(s, slot..slot + 2, &resolve, 0);
                e.copy_buffer_to_buffer(&resolve, 0, &rb, 0, 16);
            }
            let submitted = Instant::now();
            let si = q.submit([e.finish()]);
            let encode_submit = total.elapsed();
            let early_rx = if method == "reuse_early" {
                let (tx, rx) = mpsc::channel();
                rb.slice(..).map_async(MapMode::Read, move |r| {
                    let _ = tx.send(r);
                });
                Some(rx)
            } else {
                None
            };
            wait(&d, si)?;
            let render_wall = submitted.elapsed();
            let mut resolve_wall = Duration::ZERO;
            if delayed {
                let mut e = d.create_command_encoder(&Default::default());
                let s = qs.as_ref().unwrap();
                e.resolve_query_set(s, slot..slot + 2, &resolve, 0);
                e.copy_buffer_to_buffer(&resolve, 0, &rb, 0, 16);
                let now = Instant::now();
                let si = q.submit([e.finish()]);
                wait(&d, si)?;
                resolve_wall = now.elapsed();
            }
            let (begin, end_ticks) = if counter {
                let data = if let Some(rx) = early_rx {
                    rx.recv_timeout(Duration::from_secs(2))??;
                    mapped(&rb)?
                } else {
                    read(&d, &rb)?
                };
                (
                    u64::from_le_bytes(data[..8].try_into()?),
                    u64::from_le_bytes(data[8..16].try_into()?),
                )
            } else {
                (0, 0)
            };
            println!(
                "{method},{rep},{sample},{slot},{begin},{end_ticks},{:.6},{:.6},{:.6},{:.6}",
                encode_submit.as_secs_f64() * 1e6,
                render_wall.as_secs_f64() * 1e6,
                resolve_wall.as_secs_f64() * 1e6,
                total.elapsed().as_secs_f64() * 1e6
            );
        }
        // Untimed output guard: four FXAA modes must produce identical image bytes.
        let output_hash = capture_hash(&d, &q, &b)?;
        if drawing {
            if let Some(ref expected) = expected_hash {
                assert_eq!(expected, &output_hash);
            } else {
                expected_hash = Some(output_hash.clone());
            }
        }
        println!("# output_sha256 method={method} value={output_hash}");
    }
    Ok(())
}
fn wait(d: &Device, i: SubmissionIndex) -> Result<()> {
    d.poll(PollType::Wait {
        submission_index: Some(i),
        timeout: Some(Duration::from_secs(30)),
    })?;
    Ok(())
}
fn read(d: &Device, b: &Buffer) -> Result<Vec<u8>> {
    let (tx, rx) = mpsc::channel();
    b.slice(..).map_async(MapMode::Read, move |r| {
        let _ = tx.send(r);
    });
    d.poll(PollType::Wait {
        submission_index: None,
        timeout: Some(Duration::from_secs(30)),
    })?;
    rx.recv_timeout(Duration::from_secs(2))??;
    mapped(b)
}
fn mapped(b: &Buffer) -> Result<Vec<u8>> {
    let m = b.slice(..).get_mapped_range()?;
    let result = m.as_ref().to_vec();
    drop(m);
    b.unmap();
    Ok(result)
}
fn capture_hash(d: &Device, q: &Queue, t: &Texture) -> Result<String> {
    let b = d.create_buffer(&BufferDescriptor {
        label: None,
        size: u64::from(W) * u64::from(H) * 8,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let mut e = d.create_command_encoder(&Default::default());
    e.copy_texture_to_buffer(
        TexelCopyTextureInfo {
            texture: t,
            mip_level: 0,
            origin: Origin3d::ZERO,
            aspect: TextureAspect::All,
        },
        TexelCopyBufferInfo {
            buffer: &b,
            layout: TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(W * 8),
                rows_per_image: Some(H),
            },
        },
        Extent3d {
            width: W,
            height: H,
            depth_or_array_layers: 1,
        },
    );
    wait(d, q.submit([e.finish()]))?;
    Ok(hex(Sha256::digest(read(d, &b)?)))
}
fn tex(d: &Device, usage: TextureUsages) -> Texture {
    d.create_texture(&TextureDescriptor {
        label: None,
        size: Extent3d {
            width: W,
            height: H,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: TextureDimension::D2,
        format: TextureFormat::Rgba16Float,
        usage,
        view_formats: &[],
    })
}
fn draw(
    e: &mut CommandEncoder,
    v: &TextureView,
    p: &RenderPipeline,
    b: &BindGroup,
    q: Option<(&QuerySet, u32)>,
    drawing: bool,
) {
    let mut pass = e.begin_render_pass(&RenderPassDescriptor {
        label: Some("timestamp diagnosis"),
        color_attachments: &[Some(RenderPassColorAttachment {
            view: v,
            depth_slice: None,
            resolve_target: None,
            ops: Operations {
                load: LoadOp::Clear(Color::BLACK),
                store: StoreOp::Store,
            },
        })],
        timestamp_writes: q.map(|(query_set, s)| RenderPassTimestampWrites {
            query_set,
            beginning_of_pass_write_index: Some(s),
            end_of_pass_write_index: Some(s + 1),
        }),
        ..Default::default()
    });
    if drawing {
        pass.set_pipeline(p);
        pass.set_bind_group(0, b, &[]);
        pass.draw(0..3, 0..1);
    }
}
fn pipe(d: &Device, s: &ShaderModule, v: &str, f: &str) -> RenderPipeline {
    d.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(f),
        layout: None,
        vertex: VertexState {
            module: s,
            entry_point: Some(v),
            buffers: &[],
            compilation_options: Default::default(),
        },
        primitive: Default::default(),
        depth_stencil: None,
        multisample: Default::default(),
        fragment: Some(FragmentState {
            module: s,
            entry_point: Some(f),
            targets: &[Some(ColorTargetState {
                format: TextureFormat::Rgba16Float,
                blend: None,
                write_mask: ColorWrites::ALL,
            })],
            compilation_options: Default::default(),
        }),
        multiview_mask: None,
        cache: None,
    })
}

fn hex(bytes: impl AsRef<[u8]>) -> String {
    bytes.as_ref().iter().map(|b| format!("{b:02x}")).collect()
}
