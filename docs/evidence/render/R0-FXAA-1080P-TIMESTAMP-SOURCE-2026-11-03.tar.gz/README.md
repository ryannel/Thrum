# Bounded 1080p Metal timestamp diagnosis

The shader is unchanged. This scratch executable consumes the retained package via `FXAA_SHADER_PATH` and asserts its SHA-256 before preparing GPU state. It is a diagnostic, not a renderer API or shipping profiler.

From this directory, build with `RUSTC_WRAPPER= CARGO_TARGET_DIR=out/target rustup run 1.99.1 cargo build --locked --offline`. From `out/`, execute `FXAA_SHADER_PATH=../package/fxaa.wgsl ./target/debug/fxaa-1080p-timestamp 0 > rep-0.csv`, then repetitions1 and2; an extracted archive includes `package/`. The live scratch run consumed the original repository package instead. GPU access requires Metal and the scoped sandbox override. No network fetch is required with the pinned crates cached.

Run `python3 validate.py` here. It independently evaluates raw counters, chronology, records/slots, CPU enclosure, source/output guards and three corruption selfchecks. It requires all selected `unique_delayed` pairs, including warmup, to pass. Same-submission invalid variants remain preserved; their valid-subset statistics are diagnostic only. `no_queries` has no GPU clock result; clear-only zero counters do not mean zero cost.

The accepted scope is one held synthetic1080p FXAA input/target and a finite serial-completion capture. Native Metal command-buffer GPU duration, whole-R0 cost, sustained throughput, ordinary moving content and general profiling conformance remain outside this proof.
