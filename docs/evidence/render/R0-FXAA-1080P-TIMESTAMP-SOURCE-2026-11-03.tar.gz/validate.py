"""Independent raw-clock evaluator. No producer validity flags are trusted."""
from pathlib import Path
import csv,json,math,statistics,hashlib,struct,sys
METHODS=['reuse_early','reuse_same','unique_same','reuse_delayed','unique_delayed','no_queries','clear_delayed']
SHADER='5f26af44c01e3e605c7822b1881b4200ec8bebb6dfcdbabd41fe850cacb64384'
HEADER=['method','rep','sample','slot','begin_ticks','end_ticks','encode_submit_us','render_submit_complete_us','resolve_submit_complete_us','total_sample_us']
def distribution(v):
 a=sorted(v)
 return {'n':len(a),'min':a[0],'median':statistics.median(a),'p95_nearest_rank':a[math.ceil(.95*len(a))-1],'max':a[-1]} if a else None
def load(path):
 lines=path.read_text().splitlines();assert any('Apple M3 Max' in x and 'Metal' in x for x in lines)
 assert any(f'shader_sha256={SHADER}' in x for x in lines)
 assert '# timestamp_period_ns=1' in lines
 reader=csv.DictReader(x for x in lines if not x.startswith('#'));assert reader.fieldnames==HEADER
 rows=list(reader);assert len(rows)==len(METHODS)*144
 hashes={}
 for line in lines:
  if line.startswith('# output_sha256 '):
   parts=dict(x.split('=',1) for x in line.split()[2:]);hashes[parts['method']]=parts['value']
 assert set(hashes)==set(METHODS)
 aa={v for k,v in hashes.items() if k!='clear_delayed'};assert len(aa)==1,'timestamps altered FXAA output'
 clear=hashlib.sha256(struct.pack('<4e',0,0,0,1)*(1920*1080)).hexdigest();assert hashes['clear_delayed']==clear
 return rows,hashes
def evaluate(rows):
 out={}
 for method in METHODS:
  rs=[r for r in rows if r['method']==method];assert len(rs)==144
  assert [int(r['sample']) for r in rs]==list(range(-16,128));assert len({r['rep'] for r in rs})==1
  previous_end=None;previous_pair=None;invalid=[];dur=[];measured=[]
  for r in rs:
   sample=int(r['sample']);start,end=int(r['begin_ticks']),int(r['end_ticks'])
   slot=int(r['slot']);assert slot==(0 if method.startswith('reuse') else (sample+16)*2)
   fields=['encode_submit_us','render_submit_complete_us','resolve_submit_complete_us','total_sample_us']
   for key in fields:assert math.isfinite(float(r[key])) and float(r[key])>=0
   assert float(r['total_sample_us'])+.001>=float(r['render_submit_complete_us'])+float(r['resolve_submit_complete_us'])
   assert (float(r['resolve_submit_complete_us'])>0)==method.endswith('delayed')
   if method=='no_queries':assert start==end==0;continue
   reasons=[]
   if start in (2**64-1,) or end in (2**64-1,):reasons.append('Metal_counter_error_sentinel')
   if start==0 or end==0:reasons.append('zero')
   if end<=start:reasons.append('nonpositive_interval')
   if previous_pair==(start,end) and start>0:reasons.append('duplicate_pair')
   if previous_end is not None and start<previous_end:reasons.append('overlap_previous_completed_interval')
   if end>start and (end-start)/1000>float(r['render_submit_complete_us'])+.001:reasons.append('GPU_interval_exceeds_enclosing_CPU_wall')
   stale=previous_end is not None and end==previous_end and start>end
   if stale:reasons.append('mixed_generation_previous_end')
   if reasons:invalid.append({'sample':sample,'begin_ticks':start,'end_ticks':end,'previous_end_ticks':previous_end,'reasons':reasons})
   elif sample>=0:dur.append((end-start)/1000)
   if end>start and end>0:previous_end=end
   previous_pair=(start,end)
  measured=[r for r in rs if int(r['sample'])>=0]
  out[method]={'rows':len(rs),'measured_rows':len(measured),'warmup_rows':16,'counter_applicable':method!='no_queries','all_counter_rows_valid':method!='no_queries' and not invalid,'invalid_measured':sum(x['sample']>=0 for x in invalid),'invalid_warmup':sum(x['sample']<0 for x in invalid),'invalid_rows':invalid,'GPU_us_valid_measured_subset':distribution(dur),'CPU_encode_submit_us':distribution([float(r['encode_submit_us'])for r in measured]),'CPU_render_submit_complete_us':distribution([float(r['render_submit_complete_us'])for r in measured]),'CPU_resolve_submit_complete_us':distribution([float(r['resolve_submit_complete_us'])for r in measured]),'CPU_total_sample_us':distribution([float(r['total_sample_us'])for r in measured])}
 return out
def selftest(rows):
 # Independent evaluator must catch corrupted counter chronology, slot identity and coverage.
 altered=[dict(r)for r in rows];r=next(r for r in altered if r['method']=='unique_delayed' and r['sample']=='0');r['end_ticks']=str(int(r['begin_ticks'])-1)
 assert evaluate(altered)['unique_delayed']['invalid_measured']>0
 altered=[dict(r)for r in rows];next(r for r in altered if r['method']=='unique_delayed' and r['sample']=='0')['slot']='0'
 try:evaluate(altered)
 except AssertionError:pass
 else:raise AssertionError('wrong-slot mutation undetected')
 try:evaluate(rows[:-1])
 except AssertionError:pass
 else:raise AssertionError('missing row undetected')
 return ['end-before-begin detected','wrong query slot rejected','missing record rejected']
if __name__=='__main__':
 root=Path(__file__).resolve().parent;paths=[Path(x)for x in sys.argv[1:]]or sorted((root/'out').glob('rep-*.csv'));assert len(paths)==3
 summary={'repetitions':{},'raw_sha256':{},'selftests':None}
 for path in paths:
  rows,hashes=load(path);assert {int(r['rep']) for r in rows}=={int(path.stem.split('-')[1])};summary['selftests']=selftest(rows);summary['repetitions'][path.name]={'methods':evaluate(rows),'output_sha256':hashes};summary['raw_sha256'][path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 assert len({x['output_sha256']['unique_delayed'] for x in summary['repetitions'].values()})==1
 for data in summary['repetitions'].values():assert data['methods']['unique_delayed']['all_counter_rows_valid'],'selected capture failed; do not claim a timing'
 summary['selected_capture_gate']='unique_delayed passed all raw/coverage/output/clock checks in all repetitions; isolated scope only'
 (root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
 for name,data in summary['repetitions'].items():
  for method,v in data['methods'].items():print(name,method,'invalid measured/warmup',v['invalid_measured'],v['invalid_warmup'],'GPU',v['GPU_us_valid_measured_subset'],'CPUtotal',v['CPU_total_sample_us'])
