Owner: `/root/r0_exact_triangle_proof`.
Purpose: standalone exact-dyadic triangle admission probe for the candidate R0/F3 schema.
Expected peak disk: under 100 MiB, including one regenerable near-limit source JSON.
Inputs: generated binary64 fixtures, Rust 1.99.1, Python 3 standard library.
Retained output: dated selected evidence in `docs/evidence/render/`, with source/log archive if approved.
Expiry: after parent verifies the selected evidence and archive; large generated JSON is disposable.
