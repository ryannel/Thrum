# Reproduce the isolated predicate probe

From this directory on a host with Python 3 and Rust 1.99.1:

```sh
python3 generate.py
python3 verify_source.py
rustc --edition=2021 -C opt-level=3 -C target-cpu=native probe.rs -o probe
./probe cases.tsv 39000
```

`generate.py` deterministically creates `cases.tsv` and a 16.66 MB
`source_like.json`. The latter is deliberately omitted from the selected
archive; regenerate it and check its SHA-256 against `RESULTS.txt`.
`probe.rs` uses a next-neighbor outward interval fast filter and a signed
36-limb exact binary-integer fallback on decoded f64 input. The independent
oracle is Python `Fraction.from_float`. The executable measures the predicate
only and does not parse Thrum source.
