#!/usr/bin/env python3
import hashlib
import json
import math
from pathlib import Path

p = Path(__file__).resolve().parent / "source_like.json"
raw = p.read_bytes()
value = json.loads(raw)
assert set(value) == {"positions_m", "uv0", "triangles"}
assert len(value["positions_m"]) == len(value["uv0"]) == 117_000
assert len(value["triangles"]) == 39_000
assert value["triangles"][0] == [0, 1, 2]
assert value["triangles"][-1] == [116_997, 116_998, 116_999]
assert value["positions_m"][2] == [1.0, math.nextafter(1.0, math.inf), math.ldexp(1.0, -1074)]
assert value["positions_m"][-1] == value["positions_m"][2]

def nodes(v):
    if isinstance(v, dict):
        return 1 + sum(map(nodes, v.values()))
    if isinstance(v, list):
        return 1 + sum(map(nodes, v))
    return 1

count = nodes(value)
assert count == 975_004
print(f"parsed_source_like_bytes={len(raw)} nodes={count} sha256={hashlib.sha256(raw).hexdigest()}")
