use std::env;
use std::hint::black_box;
use std::fs::File;
use std::io::{BufRead, BufReader};
use std::time::Instant;

const LIMBS: usize = 36;

#[derive(Clone, Copy)]
struct Big {
    sign: i8,
    n: usize,
    limb: [u64; LIMBS],
}
impl Default for Big {
    fn default() -> Self { Self { sign:0, n:0, limb:[0;LIMBS] } }
}

impl Big {
    fn from_f64(x: f64, common_exp: i32) -> Self {
        assert!(x.is_finite());
        let bits = x.to_bits();
        let frac = bits & ((1u64 << 52) - 1);
        let raw_exp = ((bits >> 52) & 0x7ff) as i32;
        let (mant, exp) = if raw_exp == 0 {
            (frac, -1074)
        } else {
            ((1u64 << 52) | frac, raw_exp - 1023 - 52)
        };
        if mant == 0 { return Self::default(); }
        let shift = (exp - common_exp) as usize;
        let word = shift / 64;
        let offset = shift % 64;
        assert!(word + 1 < LIMBS);
        let mut result = Self::default();
        result.limb[word] = mant << offset;
        if offset != 0 { result.limb[word + 1] = mant >> (64 - offset); }
        result.n = if result.limb[word + 1] == 0 { word + 1 } else { word + 2 };
        result.sign = if bits >> 63 == 0 { 1 } else { -1 };
        result
    }

    fn trim(&mut self) {
        while self.n > 0 && self.limb[self.n - 1] == 0 { self.n -= 1; }
        if self.n == 0 { self.sign = 0; }
    }

    fn abs_cmp(&self, rhs: &Self) -> std::cmp::Ordering {
        match self.n.cmp(&rhs.n) {
            std::cmp::Ordering::Equal => {
                for i in (0..self.n).rev() {
                    let c = self.limb[i].cmp(&rhs.limb[i]);
                    if c != std::cmp::Ordering::Equal { return c; }
                }
                std::cmp::Ordering::Equal
            }
            c => c,
        }
    }

    fn abs_add(a: &Self, b: &Self) -> Self {
        let mut out = Self::default();
        let mut carry: u128 = 0;
        let n = a.n.max(b.n);
        assert!(n < LIMBS);
        for i in 0..n {
            let sum = a.limb[i] as u128 + b.limb[i] as u128 + carry;
            out.limb[i] = sum as u64;
            carry = sum >> 64;
        }
        out.n = n;
        if carry != 0 { out.limb[n] = carry as u64; out.n += 1; }
        out.trim();
        out
    }

    fn abs_sub(a: &Self, b: &Self) -> Self {
        assert!(a.abs_cmp(b) != std::cmp::Ordering::Less);
        let mut out = Self::default();
        let mut borrow: u128 = 0;
        for i in 0..a.n {
            let ai = a.limb[i] as u128;
            let bi = b.limb[i] as u128 + borrow;
            out.limb[i] = ai.wrapping_sub(bi) as u64;
            borrow = u128::from(ai < bi);
        }
        assert_eq!(borrow, 0);
        out.n = a.n;
        out.trim();
        out
    }

    fn add(a: &Self, b: &Self) -> Self {
        if a.sign == 0 { return *b; }
        if b.sign == 0 { return *a; }
        if a.sign == b.sign {
            let mut out = Self::abs_add(a,b);
            out.sign = a.sign;
            out
        } else {
            match a.abs_cmp(b) {
                std::cmp::Ordering::Greater => {
                    let mut out = Self::abs_sub(a,b);
                    if out.n > 0 { out.sign = a.sign; }
                    out
                }
                std::cmp::Ordering::Less => {
                    let mut out = Self::abs_sub(b,a);
                    if out.n > 0 { out.sign = b.sign; }
                    out
                }
                std::cmp::Ordering::Equal => Self::default(),
            }
        }
    }

    fn sub(a: &Self, b: &Self) -> Self {
        let mut neg = *b;
        neg.sign = -neg.sign;
        Self::add(a, &neg)
    }

    fn mul(a: &Self, b: &Self) -> Self {
        if a.sign == 0 || b.sign == 0 { return Self::default(); }
        assert!(a.n + b.n <= LIMBS);
        let mut out = Self::default();
        out.sign = a.sign * b.sign;
        for i in 0..a.n {
            let mut carry: u128 = 0;
            for j in 0..b.n {
                let k = i + j;
                let sum = (a.limb[i] as u128) * (b.limb[j] as u128)
                    + out.limb[k] as u128 + carry;
                out.limb[k] = sum as u64;
                carry = sum >> 64;
            }
            let mut k = i + b.n;
            while carry != 0 {
                assert!(k < LIMBS);
                let sum = out.limb[k] as u128 + carry;
                out.limb[k] = sum as u64;
                carry = sum >> 64;
                k += 1;
            }
        }
        out.n = a.n + b.n;
        out.trim();
        out
    }
}

fn exponent(x: f64) -> Option<i32> {
    if x == 0.0 { return None; }
    let bits = x.to_bits();
    let raw = ((bits >> 52) & 0x7ff) as i32;
    Some(if raw == 0 { -1074 } else { raw - 1023 - 52 })
}

fn exact_cross(p: [[f64; 3]; 3]) -> [i8; 3] {
    let common_exp = p.iter().flat_map(|v| v.iter()).filter_map(|&x| exponent(x)).min().unwrap_or(0);
    let mut d = [[Big::default();3];2];
    for i in 0..2 {
        for j in 0..3 {
            d[i][j] = Big::sub(&Big::from_f64(p[i+1][j],common_exp),
                                &Big::from_f64(p[0][j],common_exp));
        }
    }
    let mut signs = [0;3];
    for k in 0..3 {
        let a = (k+1)%3;
        let b = (k+2)%3;
        let v = Big::sub(&Big::mul(&d[0][a], &d[1][b]),
                         &Big::mul(&d[0][b], &d[1][a]));
        signs[k] = v.sign;
    }
    signs
}

fn up(x: f64) -> f64 {
    if x == f64::INFINITY { return x; }
    if x == 0.0 { return f64::from_bits(1); }
    f64::from_bits(if x > 0.0 { x.to_bits()+1 } else { x.to_bits()-1 })
}
fn down(x: f64) -> f64 {
    if x == f64::NEG_INFINITY { return x; }
    if x == 0.0 { return -f64::from_bits(1); }
    f64::from_bits(if x > 0.0 { x.to_bits()-1 } else { x.to_bits()+1 })
}

#[derive(Clone, Copy)]
struct I { lo: f64, hi: f64 }
impl I {
    fn point(x: f64) -> Self { Self { lo:x, hi:x } }
    fn sub(self, rhs: Self) -> Self {
        Self {lo:down(self.lo-rhs.hi), hi:up(self.hi-rhs.lo)}
    }
    fn mul(self, rhs: Self) -> Self {
        let v = [self.lo*rhs.lo,self.lo*rhs.hi,self.hi*rhs.lo,self.hi*rhs.hi];
        let lo = v.iter().copied().fold(f64::INFINITY,f64::min);
        let hi = v.iter().copied().fold(f64::NEG_INFINITY,f64::max);
        Self {lo:down(lo),hi:up(hi)}
    }
    fn excludes_zero(self) -> bool { self.lo > 0.0 || self.hi < 0.0 }
}

fn filter(p: [[f64;3];3]) -> bool {
    let mut d = [[I::point(0.0);3];2];
    for i in 0..2 {
        for j in 0..3 {
            d[i][j] = I::point(p[i+1][j]).sub(I::point(p[0][j]));
        }
    }
    (0..3).any(|k| {
        let a = (k+1)%3;
        let b = (k+2)%3;
        d[0][a].mul(d[1][b]).sub(d[0][b].mul(d[1][a])).excludes_zero()
    })
}

fn bits_from_line(line: &str) -> ([[f64;3];3],[i8;3]) {
    let fields: Vec<_> = line.split_whitespace().collect();
    assert_eq!(fields.len(), 12);
    let mut p = [[0.0;3];3];
    for i in 0..9 { p[i/3][i%3] = f64::from_bits(u64::from_str_radix(fields[i],16).unwrap()); }
    let mut signs=[0;3];
    for i in 0..3 { signs[i]=fields[9+i].parse().unwrap(); }
    (p,signs)
}

fn main() {
    let args: Vec<_> = env::args().collect();
    let file = BufReader::new(File::open(&args[1]).unwrap());
    let mut count = 0usize;
    let mut fast = 0usize;
    let mut fallback = 0usize;
    for line in file.lines() {
        let line = line.unwrap();
        let (p, expected) = bits_from_line(&line);
        let found = exact_cross(p);
        assert_eq!(found,expected,"case {count}");
        if filter(p) {
            assert!(expected.iter().any(|&x| x!=0),"false fast accept {}",count);
            fast += 1;
        } else { fallback += 1; }
        count += 1;
    }
    println!("oracle_cases={count} fast={fast} fallback={fallback}");
    let normal = [[0.0,0.0,0.0],[1.0,0.0,0.0],[0.0,1.0,0.0]];
    let pathological = [[0.0,0.0,0.0],[1.0,1.0,0.0],
                        [1.0,f64::from_bits(1.0f64.to_bits()+1),f64::from_bits(1)]];
    assert!(filter(normal));
    assert!(!filter(pathological));
    assert_eq!(exact_cross(pathological),[1,-1,1]);
    let n: usize = args[2].parse().unwrap();
    let t = Instant::now();
    let mut checksum = 0i64;
    for _ in 0..n {
        let p = black_box(pathological);
        if !filter(p) {
            let signs = black_box(exact_cross(p));
            checksum += signs.iter().map(|&x| x as i64).sum::<i64>();
        }
        else { panic!("not all fallback"); }
    }
    println!("all_fallback_count={n} elapsed_ns={} checksum={checksum}",t.elapsed().as_nanos());
    let t = Instant::now();
    let mut fast_count = 0usize;
    for _ in 0..n {
        fast_count += usize::from(filter(black_box(normal)));
    }
    println!("clear_fast_count={fast_count} elapsed_ns={}",t.elapsed().as_nanos());
}
