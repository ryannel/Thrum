#!/usr/bin/env python3
"""Independent Fraction oracle and regenerable near-limit source-like payload."""
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import random
import struct

HERE = Path(__file__).resolve().parent
RNG = random.Random(0xA0F3_2026)
MINSUB = math.ldexp(1.0, -1074)
UP1 = math.nextafter(1.0, math.inf)


def exact_signs(p):
    f = [[Fraction.from_float(x) for x in point] for point in p]
    d = [[f[i + 1][k] - f[0][k] for k in range(3)] for i in range(2)]
    cross = [d[0][(k + 1) % 3] * d[1][(k + 2) % 3]
             - d[0][(k + 2) % 3] * d[1][(k + 1) % 3]
             for k in range(3)]
    return tuple((x > 0) - (x < 0) for x in cross)


def bithex(x):
    return f"{struct.unpack('>Q', struct.pack('>d', x))[0]:016x}"


cases = [
    [[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]],
    [[0., 0., 0.], [0., 1., 0.], [1., 0., 0.]],
    [[0., 0., 0.], [1., 1., 0.], [1., UP1, MINSUB]],
    [[0., 0., 0.], [UP1, 1., 0.],
     [1., math.nextafter(1., -math.inf), 0.]],
    [[0., 0., 0.], [MINSUB, 0., 0.], [0., MINSUB, 0.]],
    [[0., 0., 0.], [1., 1., 0.], [1., 1., MINSUB]],
    [[0., 0., 0.], [1., 1., 0.], [2., 2., 0.]],
    [[-0., 0., 0.], [-0., 0., 0.], [MINSUB, 0., 0.]],
    [[-1000., -1000., -1000.], [1000., 1000., 1000.],
     [1000., UP1, MINSUB]],
]

pool = [-1000., -512., -1., -MINSUB, -0., 0., MINSUB, 1., UP1,
        math.nextafter(1., -math.inf), 512., 1000.,
        math.ldexp(1., -1022), math.ldexp(1., -500)]
for _ in range(4000):
    p = [[RNG.choice(pool) for _ in range(3)] for _ in range(3)]
    cases.append(p)
for _ in range(4000):
    p0 = [RNG.choice(pool) for _ in range(3)]
    p1 = [RNG.choice(pool) for _ in range(3)]
    p2 = [max(-1000., min(1000., math.nextafter(
          p1[k], math.inf if RNG.getrandbits(1) else -math.inf)))
          for k in range(3)]
    cases.append([p0, p1, p2])

fixture_path = HERE / "cases.tsv"
with fixture_path.open("w") as out:
    for p in cases:
        assert all(math.isfinite(x) and abs(x) <= 1000. for row in p for x in row)
        out.write(" ".join(bithex(x) for row in p for x in row))
        out.write(" " + " ".join(map(str, exact_signs(p))) + "\n")
print(f"oracle_cases={len(cases)} fixtures_bytes={fixture_path.stat().st_size} fixtures_sha256={hashlib.sha256(fixture_path.read_bytes()).hexdigest()}")
naive_mismatch = 0
naive_false_zero = 0
for p in cases:
    a = [p[1][k] - p[0][k] for k in range(3)]
    b = [p[2][k] - p[0][k] for k in range(3)]
    naive = tuple((v > 0) - (v < 0) for v in
                  [a[(k + 1) % 3] * b[(k + 2) % 3]
                   - a[(k + 2) % 3] * b[(k + 1) % 3]
                   for k in range(3)])
    exact = exact_signs(p)
    if naive != exact:
        naive_mismatch += 1
    if not any(naive) and any(exact):
        naive_false_zero += 1
print(f"naive_sign_mismatches={naive_mismatch} naive_false_zero={naive_false_zero}")

# This is one schema-shaped mesh value, not a complete admitted source. It
# shares no vertices between triangles, maximizing exact-predicate count under
# the one-million-node record limit. Long decimal spellings stress bytes while
# retaining the same decoded f64 values. The Rust probe measures predicate
# work, not JSON parsing, UUID closure, or product preparation.
N = 39_000
ZERO = "0.00000000000000000000000000000000000000000000"
ONE = "1.00000000000000000000000000000000000000000000"
UP = "1.00000000000000020000000000000000000000000000"
TINY = "5e-324"
assert json.loads(UP) == UP1 and json.loads(TINY) == MINSUB
source_path = HERE / "source_like.json"
with source_path.open("w") as out:
    out.write('{"positions_m":[')
    for i in range(N):
        if i: out.write(',')
        out.write(f'[{ZERO},{ZERO},{ZERO}],[{ONE},{ONE},{ZERO}],[{ONE},{UP},{TINY}]')
    out.write('],"uv0":[')
    for i in range(N):
        if i: out.write(',')
        out.write('[0,0],[1,0],[1,1]')
    out.write('],"triangles":[')
    for i in range(N):
        if i: out.write(',')
        out.write(f'[{3*i},{3*i+1},{3*i+2}]')
    out.write(']}')
source_bytes = source_path.stat().st_size
nodes = 1 + 3 + N * (3 + 9 + 3 + 6 + 1 + 3)
assert source_bytes <= 16 * 1024 * 1024
assert nodes <= 1_000_000
print(f"source_like_triangles={N} source_like_bytes={source_bytes} source_like_nodes={nodes} source_like_sha256={hashlib.sha256(source_path.read_bytes()).hexdigest()}")
