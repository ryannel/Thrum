// Independent, deterministic encoded-image fixture for the FXAA port.
// RGB values are already display encoded; alpha is weighted encoded RGB luma.

@vertex fn vs_fixture(@builtin(vertex_index) index: u32) -> @builtin(position) vec4<f32> {
    let corners = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
    return vec4<f32>(corners[index], 0.0, 1.0);
}

@fragment fn fs_fixture(@builtin(position) p: vec4<f32>) -> @location(0) vec4<f32> {
    let xy = p.xy;
    var rgb: vec3<f32>;
    if (xy.x < 128.0 && xy.y < 128.0) {
        let edge = smoothstep(-0.6, 0.6, xy.x - 0.67 * xy.y - 29.37);
        rgb = mix(vec3<f32>(0.07, 0.10, 0.13), vec3<f32>(0.91, 0.82, 0.63), edge);
    } else if (xy.y < 128.0) {
        let local = xy - vec2<f32>(128.0, 0.0);
        let gx = local.x - floor(local.x / 29.0) * 29.0;
        let gy = local.y - floor(local.y / 37.0) * 37.0;
        let stroke_distance = min(min(abs(gx - 5.2), abs(gx - 20.8)), abs(gy - 7.4));
        let ink = 1.0 - smoothstep(0.35, 1.2, stroke_distance);
        rgb = mix(vec3<f32>(0.10, 0.14, 0.20), vec3<f32>(0.88, 0.94, 0.82), ink);
    } else if (xy.x < 128.0) {
        let wave = 0.45 + 0.16 * sin(xy.x * 0.137 + xy.y * 0.071);
        let thin = 0.075 * sin(xy.x * 0.72 - xy.y * 0.19);
        rgb = vec3<f32>(wave + thin, wave * 0.93, wave * 0.82 - thin);
    } else {
        let a = smoothstep(-0.85, 0.85, xy.x + 0.57 * xy.y - 239.11);
        let b = smoothstep(-0.85, 0.85, xy.x - 0.83 * xy.y + 31.73);
        rgb = mix(vec3<f32>(0.12, 0.15, 0.22), vec3<f32>(0.93, 0.43, 0.17), a * (1.0 - b));
    }
    let luma = dot(rgb, vec3<f32>(0.299, 0.587, 0.114));
    return vec4<f32>(rgb, luma);
}
