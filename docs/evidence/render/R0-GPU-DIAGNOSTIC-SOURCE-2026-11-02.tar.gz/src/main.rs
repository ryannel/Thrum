//! A disposable offscreen diagnostic for masked depth/shadow/forward agreement.
//! It does not implement Thrum's source binding or full R0 material law.

use std::{fs::File, io::Write, sync::mpsc, time::Duration};

use wgpu::{
    Backends, BufferDescriptor, BufferUsages, Color, ColorTargetState, ColorWrites,
    CommandEncoderDescriptor, CompareFunction, DepthStencilState, DeviceDescriptor,
    Extent3d, FragmentState, Instance, InstanceDescriptor, LoadOp, MapMode,
    Operations, PipelineCompilationOptions, PowerPreference, PrimitiveState,
    RenderPassColorAttachment, RenderPassDepthStencilAttachment, RenderPassDescriptor,
    RenderPipelineDescriptor, RequestAdapterOptions, StoreOp, TextureDescriptor,
    TextureDimension, TextureFormat, TextureUsages, TextureViewDescriptor,
    VertexState,
};

const SIZE: u32 = 256;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut descriptor = InstanceDescriptor::new_without_display_handle();
    descriptor.backends = Backends::METAL;
    let instance = Instance::new(descriptor);
    let adapter = pollster::block_on(instance.request_adapter(&RequestAdapterOptions {
        power_preference: PowerPreference::HighPerformance,
        ..Default::default()
    }))?;
    let info = adapter.get_info();
    println!("adapter={} backend={:?}", info.name, info.backend);
    let (device, queue) = pollster::block_on(adapter.request_device(&DeviceDescriptor::default()))?;
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("r0 masked diagnostic"),
        source: wgpu::ShaderSource::Wgsl(include_str!("proof.wgsl").into()),
    });
    let fxaa_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("fxaa port diagnostic"),
        source: wgpu::ShaderSource::Wgsl(include_str!("fxaa.wgsl").into()),
    });
    let fixture_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some("fixed encoded-image fixture"),
        source: wgpu::ShaderSource::Wgsl(include_str!("fixture.wgsl").into()),
    });

    let shadow = texture(&device, "shadow", TextureFormat::Depth32Float,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING);
    let depth = texture(&device, "camera depth", TextureFormat::Depth32Float,
        TextureUsages::RENDER_ATTACHMENT);
    let hdr = texture(&device, "hdr", TextureFormat::Rgba16Float,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING);
    let encoded = texture(&device, "encoded scene with luma", TextureFormat::Rgba16Float,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING | TextureUsages::COPY_SRC);
    let output = texture(&device, "output", TextureFormat::Rgba8Unorm,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC);
    let fixture = texture(&device, "encoded image fixture", TextureFormat::Rgba16Float,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::TEXTURE_BINDING | TextureUsages::COPY_SRC);
    let fixture_output = texture(&device, "fixture FXAA output", TextureFormat::Rgba8Unorm,
        TextureUsages::RENDER_ATTACHMENT | TextureUsages::COPY_SRC);
    let shadow_view = shadow.create_view(&TextureViewDescriptor::default());
    let depth_view = depth.create_view(&TextureViewDescriptor::default());
    let hdr_view = hdr.create_view(&TextureViewDescriptor::default());
    let encoded_view = encoded.create_view(&TextureViewDescriptor::default());
    let output_view = output.create_view(&TextureViewDescriptor::default());
    let fixture_view = fixture.create_view(&TextureViewDescriptor::default());
    let fixture_output_view = fixture_output.create_view(&TextureViewDescriptor::default());

    let shadow_pipeline = pipeline(&device, &shader, "vs_shadow", "fs_mask", None, true, true);
    let depth_pipeline = pipeline(&device, &shader, "vs_camera", "fs_mask", None, true, true);
    let color_pipeline = pipeline(&device, &shader, "vs_camera", "fs_color",
        Some(TextureFormat::Rgba16Float), true, false);
    let tone_pipeline = pipeline(&device, &shader, "vs_screen", "fs_tone",
        Some(TextureFormat::Rgba16Float), false, false);
    let fxaa_pipeline = pipeline(&device, &fxaa_shader, "vs_fxaa", "fs_fxaa",
        Some(TextureFormat::Rgba8Unorm), false, false);
    let fixture_pipeline = pipeline(&device, &fixture_shader, "vs_fixture", "fs_fixture",
        Some(TextureFormat::Rgba16Float), false, false);

    let shadow_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("shadow input"),
        layout: &color_pipeline.get_bind_group_layout(0),
        entries: &[wgpu::BindGroupEntry { binding: 0,
            resource: wgpu::BindingResource::TextureView(&shadow_view) }],
    });
    let hdr_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("hdr input"),
        layout: &tone_pipeline.get_bind_group_layout(0),
        entries: &[wgpu::BindGroupEntry { binding: 1,
            resource: wgpu::BindingResource::TextureView(&hdr_view) }],
    });
    let encoded_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        label: Some("fxaa clamp linear"),
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        ..Default::default()
    });
    let fxaa_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("encoded scene"),
        layout: &fxaa_pipeline.get_bind_group_layout(0),
        entries: &[
            wgpu::BindGroupEntry { binding: 0,
                resource: wgpu::BindingResource::TextureView(&encoded_view) },
            wgpu::BindGroupEntry { binding: 1,
                resource: wgpu::BindingResource::Sampler(&encoded_sampler) },
        ],
    });
    let fixture_fxaa_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("fixture encoded input"),
        layout: &fxaa_pipeline.get_bind_group_layout(0),
        entries: &[
            wgpu::BindGroupEntry { binding: 0,
                resource: wgpu::BindingResource::TextureView(&fixture_view) },
            wgpu::BindGroupEntry { binding: 1,
                resource: wgpu::BindingResource::Sampler(&encoded_sampler) },
        ],
    });

    let mut encoder = device.create_command_encoder(&CommandEncoderDescriptor::default());
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("masked shadow"),
            color_attachments: &[],
            depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
                view: &shadow_view,
                depth_ops: Some(Operations { load: LoadOp::Clear(0.0), store: StoreOp::Store }),
                stencil_ops: None,
            }),
            ..Default::default()
        });
        pass.set_pipeline(&shadow_pipeline);
        pass.draw(0..6, 1..2);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("masked camera depth"),
            color_attachments: &[],
            depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
                view: &depth_view,
                depth_ops: Some(Operations { load: LoadOp::Clear(0.0), store: StoreOp::Store }),
                stencil_ops: None,
            }),
            ..Default::default()
        });
        pass.set_pipeline(&depth_pipeline);
        pass.draw(0..6, 0..2);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("forward diagnostic"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &hdr_view, depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            depth_stencil_attachment: Some(RenderPassDepthStencilAttachment {
                view: &depth_view,
                depth_ops: Some(Operations { load: LoadOp::Load, store: StoreOp::Store }),
                stencil_ops: None,
            }),
            ..Default::default()
        });
        pass.set_pipeline(&color_pipeline);
        pass.set_bind_group(0, &shadow_group, &[]);
        pass.draw(0..6, 0..2);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("tone diagnostic"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &encoded_view, depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(&tone_pipeline);
        pass.set_bind_group(0, &hdr_group, &[]);
        pass.draw(0..3, 0..1);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("FXAA diagnostic"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &output_view, depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(&fxaa_pipeline);
        pass.set_bind_group(0, &fxaa_group, &[]);
        pass.draw(0..3, 0..1);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("fixed encoded-image fixture"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &fixture_view, depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(&fixture_pipeline);
        pass.draw(0..3, 0..1);
    }
    {
        let mut pass = encoder.begin_render_pass(&RenderPassDescriptor {
            label: Some("fixture FXAA"),
            color_attachments: &[Some(RenderPassColorAttachment {
                view: &fixture_output_view, depth_slice: None, resolve_target: None,
                ops: Operations { load: LoadOp::Clear(Color::BLACK), store: StoreOp::Store },
            })],
            ..Default::default()
        });
        pass.set_pipeline(&fxaa_pipeline);
        pass.set_bind_group(0, &fixture_fxaa_group, &[]);
        pass.draw(0..3, 0..1);
    }

    let row_bytes = SIZE * 4;
    let readback = device.create_buffer(&BufferDescriptor {
        label: Some("readback"), size: (row_bytes * SIZE) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let encoded_readback = device.create_buffer(&BufferDescriptor {
        label: Some("encoded input readback"), size: (SIZE * SIZE * 8) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let fixture_readback = device.create_buffer(&BufferDescriptor {
        label: Some("fixture output readback"), size: (row_bytes * SIZE) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    let fixture_encoded_readback = device.create_buffer(&BufferDescriptor {
        label: Some("fixture input readback"), size: (SIZE * SIZE * 8) as u64,
        usage: BufferUsages::COPY_DST | BufferUsages::MAP_READ,
        mapped_at_creation: false,
    });
    encoder.copy_texture_to_buffer(
        wgpu::TexelCopyTextureInfo { texture: &output, mip_level: 0,
            origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyBufferInfo { buffer: &readback,
            layout: wgpu::TexelCopyBufferLayout { offset: 0,
                bytes_per_row: Some(row_bytes), rows_per_image: Some(SIZE) } },
        Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 });
    encoder.copy_texture_to_buffer(
        wgpu::TexelCopyTextureInfo { texture: &encoded, mip_level: 0,
            origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyBufferInfo { buffer: &encoded_readback,
            layout: wgpu::TexelCopyBufferLayout { offset: 0,
                bytes_per_row: Some(SIZE * 8), rows_per_image: Some(SIZE) } },
        Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 });
    encoder.copy_texture_to_buffer(
        wgpu::TexelCopyTextureInfo { texture: &fixture_output, mip_level: 0,
            origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyBufferInfo { buffer: &fixture_readback,
            layout: wgpu::TexelCopyBufferLayout { offset: 0,
                bytes_per_row: Some(row_bytes), rows_per_image: Some(SIZE) } },
        Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 });
    encoder.copy_texture_to_buffer(
        wgpu::TexelCopyTextureInfo { texture: &fixture, mip_level: 0,
            origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        wgpu::TexelCopyBufferInfo { buffer: &fixture_encoded_readback,
            layout: wgpu::TexelCopyBufferLayout { offset: 0,
                bytes_per_row: Some(SIZE * 8), rows_per_image: Some(SIZE) } },
        Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 });
    let submission = queue.submit([encoder.finish()]);
    let (sender, receiver) = mpsc::channel();
    readback.slice(..).map_async(MapMode::Read, move |result| { let _ = sender.send(result); });
    let (encoded_sender, encoded_receiver) = mpsc::channel();
    encoded_readback.slice(..).map_async(MapMode::Read,
        move |result| { let _ = encoded_sender.send(result); });
    let (fixture_sender, fixture_receiver) = mpsc::channel();
    fixture_readback.slice(..).map_async(MapMode::Read,
        move |result| { let _ = fixture_sender.send(result); });
    let (fixture_encoded_sender, fixture_encoded_receiver) = mpsc::channel();
    fixture_encoded_readback.slice(..).map_async(MapMode::Read,
        move |result| { let _ = fixture_encoded_sender.send(result); });
    device.poll(wgpu::PollType::Wait { submission_index: Some(submission),
        timeout: Some(Duration::from_secs(10)) })?;
    receiver.recv_timeout(Duration::from_secs(1))??;
    encoded_receiver.recv_timeout(Duration::from_secs(1))??;
    fixture_receiver.recv_timeout(Duration::from_secs(1))??;
    fixture_encoded_receiver.recv_timeout(Duration::from_secs(1))??;
    let mapped = readback.slice(..).get_mapped_range()?;
    let bytes = mapped.as_ref();
    write_ppm(bytes)?;
    let encoded_mapped = encoded_readback.slice(..).get_mapped_range()?;
    std::fs::write("encoded.rgba16f", encoded_mapped.as_ref())?;
    let fixture_mapped = fixture_readback.slice(..).get_mapped_range()?;
    write_ppm_file("fixture.ppm", fixture_mapped.as_ref())?;
    let fixture_encoded_mapped = fixture_encoded_readback.slice(..).get_mapped_range()?;
    std::fs::write("fixture.rgba16f", fixture_encoded_mapped.as_ref())?;
    let samples = [(64, 128), (128, 128), (190, 64), (190, 95), (128, 64)];
    for (x, y) in samples {
        let base = ((y * SIZE + x) * 4) as usize;
        println!("pixel({x},{y})={:?}", &bytes[base..base + 4]);
    }
    let rgb = |x: u32, y: u32| {
        let base = ((y * SIZE + x) * 4) as usize;
        [bytes[base], bytes[base + 1], bytes[base + 2]]
    };
    let lit = rgb(64, 64);
    let opaque_fence = rgb(85, 64);
    // Camera centre falls in checker tile (4,3), a fence hole; its shifted
    // light ray also falls in a source hole, so the ground remains lit.
    let hole = rgb(128, 128);
    // The light-shifted fence lies at source x≈0.378 for camera x=190.
    // At y=64 its source checker tile is (7,6), a hole; at y=95 it is
    // (7,5), an opaque blocker. A vertically mirrored shadow lookup reverses
    // these classifications while the basic lit/fence checks can still pass.
    let asymmetric_hole = rgb(190, 64);
    let shifted_shadow = rgb(190, 95);
    let outside_shadow = rgb(200, 95);
    assert!(opaque_fence[0] > lit[0] + 50, "masked fence did not cover expected texel");
    assert!(hole[0].abs_diff(lit[0]) <= 2, "fence hole did not reveal lit ground");
    assert!(asymmetric_hole[0].abs_diff(lit[0]) <= 2,
        "shadow lookup mirrored the source mask at asymmetric hole");
    assert!(u16::from(shifted_shadow[0]) * 2 < u16::from(lit[0]),
        "shadow did not shift onto visible ground");
    assert!(outside_shadow[0].abs_diff(lit[0]) <= 2, "shadow leaked outside fence footprint");
    println!("five independent pixel-class checks passed");
    drop(mapped);
    readback.unmap();
    drop(encoded_mapped);
    encoded_readback.unmap();
    drop(fixture_mapped);
    fixture_readback.unmap();
    drop(fixture_encoded_mapped);
    fixture_encoded_readback.unmap();
    Ok(())
}

fn texture(device: &wgpu::Device, label: &str, format: TextureFormat, usage: TextureUsages) -> wgpu::Texture {
    device.create_texture(&TextureDescriptor {
        label: Some(label), size: Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 },
        mip_level_count: 1, sample_count: 1, dimension: TextureDimension::D2,
        format, usage, view_formats: &[],
    })
}

fn pipeline(device: &wgpu::Device, shader: &wgpu::ShaderModule,
            vertex: &str, fragment: &str, color: Option<TextureFormat>,
            depth: bool, write_depth: bool) -> wgpu::RenderPipeline {
    let targets = color.map(|format| [Some(ColorTargetState {
        format, blend: None, write_mask: ColorWrites::ALL,
    })]);
    device.create_render_pipeline(&RenderPipelineDescriptor {
        label: Some(fragment), layout: None,
        vertex: VertexState { module: shader, entry_point: Some(vertex), buffers: &[],
            compilation_options: PipelineCompilationOptions::default() },
        primitive: PrimitiveState::default(),
        depth_stencil: depth.then_some(DepthStencilState {
            format: TextureFormat::Depth32Float,
            depth_write_enabled: Some(write_depth),
            depth_compare: Some(if write_depth { CompareFunction::Greater } else { CompareFunction::Equal }),
            stencil: Default::default(), bias: Default::default(),
        }),
        multisample: Default::default(),
        fragment: Some(FragmentState { module: shader, entry_point: Some(fragment),
            targets: targets.as_ref().map_or(&[], |x| x.as_slice()),
            compilation_options: PipelineCompilationOptions::default() }),
        multiview_mask: None, cache: None,
    })
}

fn write_ppm(bytes: &[u8]) -> Result<(), Box<dyn std::error::Error>> {
    write_ppm_file("frame.ppm", bytes)
}

fn write_ppm_file(path: &str, bytes: &[u8]) -> Result<(), Box<dyn std::error::Error>> {
    let mut file = File::create(path)?;
    write!(file, "P6\n{SIZE} {SIZE}\n255\n")?;
    for pixel in bytes.chunks_exact(4) { file.write_all(&pixel[..3])?; }
    Ok(())
}
