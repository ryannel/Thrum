// Diagnostic only. The R0 render ABI and material closure are not implemented here.

struct VertexOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) uv: vec2<f32>,
    @location(1) world: vec3<f32>,
    @location(2) @interpolate(flat) kind: u32,
};

fn corner(index: u32) -> vec2<f32> {
    let corners = array<vec2<f32>, 6>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(1.0, -1.0),
        vec2<f32>(-1.0, 1.0), vec2<f32>(-1.0, 1.0),
        vec2<f32>(1.0, -1.0), vec2<f32>(1.0, 1.0));
    return corners[index];
}

fn vertex(index: u32, instance: u32, shadow: bool) -> VertexOut {
    let q = corner(index);
    let fence = instance == 1u;
    let scale = select(vec2<f32>(1.0, 1.0), vec2<f32>(0.42, 0.72), fence);
    let z = select(0.25, 0.75, fence);
    let xy = q * scale;
    let shifted = xy + select(vec2<f32>(0.0, 0.0), vec2<f32>(0.22 * z, 0.0), shadow);
    var out: VertexOut;
    out.clip = vec4<f32>(shifted, z, 1.0);
    out.uv = q * 0.5 + vec2<f32>(0.5, 0.5);
    out.world = vec3<f32>(xy, z);
    out.kind = instance;
    return out;
}

@vertex fn vs_camera(@builtin(vertex_index) index: u32,
                     @builtin(instance_index) instance: u32) -> VertexOut {
    return vertex(index, instance, false);
}

@vertex fn vs_shadow(@builtin(vertex_index) index: u32,
                     @builtin(instance_index) instance: u32) -> VertexOut {
    return vertex(index, instance, true);
}

fn accepted(in: VertexOut) -> bool {
    if (in.kind == 0u) { return true; }
    let tile = vec2<i32>(floor(in.uv * 8.0));
    return ((tile.x + tile.y) & 1) == 0;
}

@fragment fn fs_mask(in: VertexOut) {
    if (!accepted(in)) { discard; }
}

@group(0) @binding(0) var shadow_depth: texture_depth_2d;

@fragment fn fs_color(in: VertexOut) -> @location(0) vec4<f32> {
    if (!accepted(in)) { discard; }
    if (in.kind == 1u) {
        return vec4<f32>(2.0, 1.3, 0.25, 1.0);
    }
    let light_xy = in.world.xy + vec2<f32>(0.22 * in.world.z, 0.0);
    // Clip +Y is up while texture row 0 is at the top.
    let uv = vec2<f32>(light_xy.x * 0.5 + 0.5, 0.5 - light_xy.y * 0.5);
    let size = textureDimensions(shadow_depth);
    let pixel = clamp(vec2<i32>(uv * vec2<f32>(size)), vec2<i32>(0), vec2<i32>(size) - vec2<i32>(1));
    let blocker = textureLoad(shadow_depth, pixel, 0);
    let lit = select(0.14, 1.0, blocker <= in.world.z + 0.0001);
    return vec4<f32>(vec3<f32>(0.5, 0.68, 0.8) * lit, 1.0);
}

@vertex fn vs_screen(@builtin(vertex_index) index: u32) -> @builtin(position) vec4<f32> {
    let corners = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0));
    let q = corners[index];
    return vec4<f32>(q, 0.0, 1.0);
}

@group(0) @binding(1) var hdr_image: texture_2d<f32>;

fn to_srgb(linear: vec3<f32>) -> vec3<f32> {
    let low = linear * 12.92;
    let high = 1.055 * pow(linear, vec3<f32>(1.0 / 2.4)) - 0.055;
    return select(high, low, linear <= vec3<f32>(0.0031308));
}

@fragment fn fs_tone(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32> {
    let pixel = vec2<i32>(position.xy);
    let c = textureLoad(hdr_image, pixel, 0).rgb;
    let y = dot(c, vec3<f32>(0.2126, 0.7152, 0.0722));
    let mapped = c / (1.0 + y);
    let display = mapped / max(1.0, max(mapped.r, max(mapped.g, mapped.b)));
    let encoded = to_srgb(display);
    // FXAA's perceptual RGBL input follows its source example; scene Y above
    // remains the separate Rec.709 photometric display quantity.
    let luma = dot(encoded, vec3<f32>(0.299, 0.587, 0.114));
    return vec4<f32>(encoded, luma);
}
