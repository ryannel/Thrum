"""Scalar FXAA 3.11 Quality-12 RGB reference from the pinned HLSL branch.

The input is the GPU tone pass's actual RGBA16Float texture. This separate
Python execution path checks sampling, orientation and search against the WGSL
port; it is not a visual acceptance or whole-renderer test.
"""

from __future__ import annotations

import math
import struct
import sys
from pathlib import Path

WIDTH = HEIGHT = 256
assert len(sys.argv) == 3, "usage: reference_fxaa.py INPUT.rgba16f OUTPUT.ppm"
PIXELS = list(struct.iter_unpack("<4e", Path(sys.argv[1]).read_bytes()))
assert len(PIXELS) == WIDTH * HEIGHT
AMBIGUOUS: set[tuple[int, int]] = set()
REASONS: dict[tuple[int, int], set[str]] = {}


def mark(x: int, y: int, reason: str) -> None:
    AMBIGUOUS.add((x, y))
    REASONS.setdefault((x, y), set()).add(reason)


def stopped(value: float, gradient: float, x: int, y: int) -> bool:
    if abs(abs(value) - gradient) < 1e-6:
        mark(x, y, "search_stop")
    return abs(value) >= gradient


def sample(uv: tuple[float, float]) -> tuple[float, float, float, float]:
    xf = uv[0] * WIDTH - 0.5
    yf = uv[1] * HEIGHT - 0.5
    x0, y0 = math.floor(xf), math.floor(yf)
    tx, ty = xf - x0, yf - y0
    x1, y1 = x0 + 1, y0 + 1
    x0 = max(0, min(WIDTH - 1, x0))
    x1 = max(0, min(WIDTH - 1, x1))
    y0 = max(0, min(HEIGHT - 1, y0))
    y1 = max(0, min(HEIGHT - 1, y1))
    a = PIXELS[y0 * WIDTH + x0]
    b = PIXELS[y0 * WIDTH + x1]
    c = PIXELS[y1 * WIDTH + x0]
    d = PIXELS[y1 * WIDTH + x1]
    return tuple(
        (1 - ty) * ((1 - tx) * a[k] + tx * b[k])
        + ty * ((1 - tx) * c[k] + tx * d[k])
        for k in range(4)
    )


def luma(uv: tuple[float, float]) -> float:
    return sample(uv)[3]


def reference_rgb(x: int, y: int) -> tuple[int, int, int]:
    texel = (1 / WIDTH, 1 / HEIGHT)
    uv = ((x + 0.5) / WIDTH, (y + 0.5) / HEIGHT)
    centre = sample(uv)
    m = centre[3]
    n = luma((uv[0], uv[1] - texel[1]))
    s = luma((uv[0], uv[1] + texel[1]))
    e = luma((uv[0] + texel[0], uv[1]))
    w = luma((uv[0] - texel[0], uv[1]))
    high = max(m, n, s, e, w)
    low = min(m, n, s, e, w)
    span = high - low
    if abs(span - max(0.0625, high * 0.125)) < 1e-6:
        mark(x, y, "early_exit")
    if span < max(0.0625, high * 0.125):
        color = centre[:3]
    else:
        nw = luma((uv[0] - texel[0], uv[1] - texel[1]))
        ne = luma((uv[0] + texel[0], uv[1] - texel[1]))
        sw = luma((uv[0] - texel[0], uv[1] + texel[1]))
        se = luma((uv[0] + texel[0], uv[1] + texel[1]))
        edge_h = abs(-2 * m + n + s) * 2 + abs(-2 * e + ne + se) + abs(-2 * w + nw + sw)
        edge_v = abs(-2 * m + w + e) * 2 + abs(-2 * n + nw + ne) + abs(-2 * s + sw + se)
        if abs(edge_h - edge_v) < 1e-6:
            mark(x, y, "edge_axis")
        horizontal = edge_h >= edge_v
        subpix_a = 2 * (n + s + w + e) + nw + ne + sw + se
        c = min(1.0, max(0.0, abs(subpix_a / 12 - m) / span))
        subpix_f = (3 - 2 * c) * c * c
        subpix = subpix_f * subpix_f * 0.75
        if not horizontal:
            n, s = w, e
        if abs(abs(n - m) - abs(s - m)) < 1e-6:
            mark(x, y, "pair_side")
        pair_n = abs(n - m) >= abs(s - m)
        gradient = max(abs(n - m), abs(s - m)) * 0.25
        sign = texel[1] if horizontal else texel[0]
        if pair_n:
            sign = -sign
        base = (uv[0], uv[1] + sign * 0.5) if horizontal else (uv[0] + sign * 0.5, uv[1])
        axis = (texel[0], 0.0) if horizontal else (0.0, texel[1])
        near = [base[0] - axis[0], base[1] - axis[1]]
        far = [base[0] + axis[0], base[1] + axis[1]]
        local_mean = (m + (n if pair_n else s)) * 0.5
        end_near = luma(tuple(near)) - local_mean
        end_far = luma(tuple(far)) - local_mean
        done_near = stopped(end_near, gradient, x, y)
        done_far = stopped(end_far, gradient, x, y)
        for step in (1.5, 2.0, 4.0):
            if done_near and done_far:
                break
            if not done_near:
                near = [near[0] - step * axis[0], near[1] - step * axis[1]]
                end_near = luma(tuple(near)) - local_mean
                done_near = stopped(end_near, gradient, x, y)
            if not done_far:
                far = [far[0] + step * axis[0], far[1] + step * axis[1]]
                end_far = luma(tuple(far)) - local_mean
                done_far = stopped(end_far, gradient, x, y)
        if not done_near:
            near = [near[0] - 12 * axis[0], near[1] - 12 * axis[1]]
        if not done_far:
            far = [far[0] + 12 * axis[0], far[1] + 12 * axis[1]]
        near_dist = uv[0] - near[0] if horizontal else uv[1] - near[1]
        far_dist = far[0] - uv[0] if horizontal else far[1] - uv[1]
        good_near = (end_near < 0) != (m - local_mean < 0)
        good_far = (end_far < 0) != (m - local_mean < 0)
        if abs(near_dist - far_dist) < 1e-6 or abs(end_near) < 1e-6 or abs(end_far) < 1e-6 or abs(m - local_mean) < 1e-6:
            mark(x, y, "span_sign_or_side")
        good = good_near if near_dist < far_dist else good_far
        edge = 0.5 - min(near_dist, far_dist) / (near_dist + far_dist) if good else 0.0
        offset = max(edge, subpix) * sign
        final_uv = (uv[0], uv[1] + offset) if horizontal else (uv[0] + offset, uv[1])
        color = sample(final_uv)[:3]
    return tuple(max(0, min(255, round(v * 255))) for v in color)


raw = Path(sys.argv[2]).read_bytes()
start = raw.index(b"\n255\n") + 5
actual = raw[start:]
assert len(actual) == WIDTH * HEIGHT * 3
errors: list[int] = []
stable_errors: list[int] = []
outlier_reasons: dict[str, int] = {}
outliers: list[tuple[int, int, tuple[int, int, int], tuple[int, int, int]]] = []
for y in range(HEIGHT):
    for x in range(WIDTH):
        expected = reference_rgb(x, y)
        offset = 3 * (y * WIDTH + x)
        got = tuple(actual[offset:offset + 3])
        delta = max(abs(a - b) for a, b in zip(expected, got))
        errors.append(delta)
        if (x, y) not in AMBIGUOUS:
            stable_errors.append(delta)
        if delta > 2 and len(outliers) < 12:
            outliers.append((x, y, expected, got))
        if delta > 2:
            for reason in REASONS.get((x, y), ()):
                outlier_reasons[reason] = outlier_reasons.get(reason, 0) + 1
errors.sort()
print(f"pixels={len(errors)} max_error={errors[-1]} p99={errors[int(.99 * len(errors))]} over_2={sum(e > 2 for e in errors)}")
print(f"ambiguous={len(AMBIGUOUS)} stable={len(stable_errors)} stable_max={max(stable_errors)} stable_over_2={sum(e > 2 for e in stable_errors)}")
print("outlier_reasons=", sorted(outlier_reasons.items()))
print("first_outliers=", outliers)
assert max(stable_errors) <= 1, "FXAA RGB differs on a numerically stable pixel"
assert outlier_reasons.get("search_stop", 0) == sum(e > 2 for e in errors), \
    "a large FXAA difference lacks a scalar search-threshold tie"
