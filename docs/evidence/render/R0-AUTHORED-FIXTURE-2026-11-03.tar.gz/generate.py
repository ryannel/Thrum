#!/usr/bin/env python3
"""Generate exact candidate source bytes; Python stdlib only, no runtime claim."""
import base64
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TREE = ROOT / "source"

def uid(n):
    return f"a6b9c300-0000-4000-8000-{n:012x}"

def emit(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(obj, sort_keys=True, separators=(",", ":"),
                                ensure_ascii=True, allow_nan=False) + "\n").encode("ascii"))

def record(n, kind, schema, fields):
    return {"id": uid(n), "type": kind, "schema": schema, "fields": fields}

def sampler():
    return {"min_filter":"nearest", "mag_filter":"nearest",
            "address_u":"clamp-to-edge", "address_v":"clamp-to-edge"}

def material(n, **overrides):
    m = {"id":uid(n), "alpha_mode":"opaque", "two_sided":False,
         "sampler":sampler(), "base_factor_rgba":[1,1,1,1],
         "emissive_radiance_factor_cd_m2":[0,0,0], "metallic_factor":0,
         "roughness_factor":0.8, "occlusion_strength":1}
    m.update(overrides)
    return m

def texture(n, width, height, fmt, texels):
    data = bytes(x for texel in texels for x in texel)
    assert len(data) == 4 * width * height
    return {"id":uid(n), "width":width, "height":height, "format":fmt,
            "rgba8":base64.b64encode(data).decode("ascii")}

def quad(n, x0, x1, y0, y1, z):
    return {"id":uid(n), "positions_m":[[x0,y0,z],[x1,y0,z],[x1,y1,z],[x0,y1,z]],
            "uv0":[[0,1],[1,1],[1,0],[0,0]], "triangles":[[0,1,2],[0,2,3]]}

def main():
    paths = ["records/environment.record.json", "records/render.record.json",
             "records/sun.record.json", "scenes/main.scene.json"]
    records = {
        "project.json":record(1,"core.project",2,{
            "project.format":1, "project.records":paths, "project.schemas":[],
            "project.registryHistory":"schemas/history.registry.json",
            "project.entryScenes":[uid(3)]}),
        "schemas/history.registry.json":record(2,"core.registry-history",1,{
            "registry.fields":[],"registry.versions":[]}),
        "scenes/main.scene.json":record(3,"core.scene",3,{
            "scene.label":"R0 candidate receiver, fence and offscreen caster",
            "environment.source":uid(4), "render.source":uid(6)}),
        "records/environment.record.json":record(4,"thrum.environment.authored",1,{
            "profile":"constant-light-v1", "sun":{
                "light_ref":uid(5), "toward_source_unit":[0.6,0,0.8],
                "perpendicular_illuminance_lux":100000,
                "unit_luminance_linear_rec709":[1,1,1], "angular_radius_rad":0.00465,
                "direction_model":"geometric-straight", "applied_attenuation":[]},
            "ambient_irradiance_lux":[1000,1000,1000],
            "background_radiance_cd_m2":[0,0,0],
            "unsupported":["wind","cloud_tau","precipitation","air","thermal","moon","air_quality"]}),
        "records/sun.record.json":record(5,"thrum.light.identity",1,{
            "driver_binding":"incoming-environment-sun"}),
    }
    cameras = [{"id":uid(10), "position_m":[0,0,5], "orientation_xyzw":[0,0,0,1],
                "vertical_fov_rad":1.0471975511965976, "near_m":0.1,"far_m":20,
                "exposure":0.0001}]
    meshes = [quad(20,-3,3,-2,2,0), quad(21,-0.6,0.6,-1,1,1),
              quad(22,3.4,3.8,-0.4,0.4,2)]
    materials = [
        material(40, base_factor_rgba=[0.8,0.85,0.9,1],
                 base_texture=uid(50),orm_texture=uid(52)),
        material(41, alpha_mode="mask",alpha_cutoff=0.5,
                 base_factor_rgba=[0.8,1,0.8,1],roughness_factor=0.6,
                 base_texture=uid(51)),
        material(42, base_factor_rgba=[0.7,0.7,0.72,1],metallic_factor=1,
                 orm_texture=uid(52),emissive_texture=uid(53),
                 emissive_radiance_factor_cd_m2=[8,4,2]),
    ]
    textures = [
        texture(50,2,2,"rgba8-srgb",[(192,200,208,255),(160,192,176,255),
                                    (192,152,112,255),(128,144,192,255)]),
        texture(51,4,4,"rgba8-srgb",[(160+16*x,80+24*y,48+8*(x+y),
                                    255 if (x+y)%2 == 0 else 0)
                                   for y in range(4) for x in range(4)]),
        texture(52,2,2,"rgba8-linear",[(192,128,0,255),(224,160,85,255),
                                      (240,192,170,255),(255,255,255,255)]),
        texture(53,1,1,"rgba8-srgb",[(128,64,32,255)]),
    ]
    instances = [{"id":uid(30+i),"mesh":uid(20+i),"material":uid(40+i),
                  "translation_m":[0,0,0],"orientation_xyzw":[0,0,0,1],"scale":[1,1,1]}
                 for i in range(3)]
    lights = [{"id":uid(60+i),"position_m":[x,y,3],"luminous_intensity_cd":1000,
               "unit_luminance_linear_rec709":[1,1,1],"radius_m":0.1}
              for i,(x,y) in enumerate([(-1,-1),(-1,1),(1,-1),(1,1)])]
    records["records/render.record.json"] = record(6,"thrum.render.scene",1,{
        "cameras":cameras,"active_camera":uid(10),"meshes":meshes,"instances":instances,
        "materials":materials,"textures":textures,"local_lights":lights})
    for path, obj in records.items():
        emit(TREE/path, obj)
    emit(ROOT/"declared_tree.json",{"kind":"candidate-declared-files-not-TreeManifest",
                                   "paths":sorted(records)})
    emit(ROOT/"candidate_recipe.json",{
        "status":"candidate-only-not-selected-F2-recipe",
        "viewport_pixels":[1280,720],"storage_scale":0.0009765625,
        "shadow":{"extent_pixels":[2048,2048],"format":"depth32float",
                  "xi_interval_m":[-2.5,2.5],"eta_interval_m":[-2.1,2.1],
                  "zeta_interval_m":[-2,4],"origin_m":[0,0,0],
                  "clear_depth":0,"depth_test":"greater","comparison":"greater-equal",
                  "fixed_function_depth_bias":0,"tap_offsets":[[0,0],[1,0],[0,1],[1,1]],
                  "b0_m":None,"beta_texels":None,"grazing_cutoff":None,
                  "maximum_contact_detachment_m":None},
        "unresolved":["F3/F4/W1/V2/V3 adoption and immutable definition/evaluator hashes",
                      "constant-light authenticated 160-byte product and normalized Sun basis",
                      "bias, grazing, contact and source-to-packed/GPU error certificates",
                      "actual admitted SourceRevision and complete ready F4 BuildRevision",
                      "target mask/front-face, filtering, WGSL ABI and whole-frame qualification"]})

if __name__ == "__main__":
    main()
