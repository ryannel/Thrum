# Candidate R0 authored fixture reproduction

This package is original Thrum research fixture code and data, created for this
repository; no third-party assets or code were imported. Python 3.11+ standard
library only. Exact interpreter/version and consulted repository-file hashes are
recorded in `manifest.json`. The consulted hashes are historical research inputs,
not built-in schema definition hashes.

Extract to a fresh owned directory, then run:

```sh
python3 check_package.py
python3 generate.py
python3 verify.py
python3 check_package.py
```

Both package checks must pass, so regeneration and verification must reproduce
all retained bytes. `pack.py <output.tar.gz>` packs the protected files with
fixed names, sorted order, uid/gid/mtime=0 and gzip mtime=0. It does not run an
engine or create an admitted source root. It refuses a changed protected file.

`source/` is the entire candidate authored tree: core.project@2; empty game-schema
history; core.scene@3; thrum.render.scene@1; the existing constant-light-v1
thrum.environment.authored@1; identity-only thrum.light.identity@1. The project
record membership is explicit. `declared_tree.json` lists all six files, including
project/history, for a prospective capture caller. This list is **not** a
Foundation TreeManifest. No SDK command, admitted SourceRevision, RecoveryRoot,
ready BuildRevision, built-in definition hash or durable store is fabricated.

`candidate_recipe.json` lives outside `source/`. Its null bias, slope, grazing
and contact limits are deliberate unresolved decisions, not shader defaults.
Viewport/storage scale/shadow volume are candidate preparation settings and
never become universal source capacities. Exposure has one authority in the
source camera. There is no environment selector in the render record.

The generator uses ASCII sorted compact Python JSON plus one newline. This is
a byte-generation convention for the fixture, not a claim that Python JSON is
JCS for all values. Numeric source meaning is exact binary64 after decoding;
`Fraction.from_float` in the independent verifier supplies the dyadic geometry
oracle. The verifier does not import the generator. It checks the complete
candidate graph, unknown/missing keys, decoded duplicate keys, UUID namespace,
typed edges, byte dimensions/transfer/base64, finite domains, exact local radius,
exact triangles and source signs. Its strict subset is deliberately scoped to
these fixture record kinds and does not implement production F3 or all general
legal source cases. It does not run the Rust decoder or prove its conformance.

The three meshes have +Z winding, identity instances and bottom-left vertex UV
(0,1), so image row zero maps to the quad's upper edge. The masked 4x4 image has
alpha rows `255,0,255,0 / 0,255,0,255 / 255,0,255,0 / 0,255,0,255`.
All material samplers are nearest min/mag and clamp-to-edge. The saved mask's
alpha factor is 1 and cutoff is 0.5; each listed texel-center sample in
`results.json` keeps exactly the eight nonzero-alpha texels using alpha >=
cutoff. Auxiliary scalar controls at 127/255, 128/255 and exact equality via a
0.5 alpha factor are explicitly separate from saved texture content. No nearest
texel-boundary tie, GPU filtering, derivative, depth/shadow/forward, packed
cutoff or actual device coverage guarantee follows from these CPU controls.

Four unique textures are used across three materials: two sRGB base images,
one shared linear ORM image and one sRGB emissive image. There are three
optional authored texture **slots per material**, not a three-image scene cap.
A schema-1 normal map is absent by contract; the future F4 flat-normal default
is not a new source texture. Decoded texel hex and hashes are in `results.json`.

The camera-FOV half-width uses this host's binary64 math.tan and is labeled as
an observation. Exact ray projection uses the raw decoded Sun ratio, not a
nonexistent authenticated normalized F4 Sun product. Normalization/evaluator
closure, source-to-packed intervals, actual raster/D32 error, four comparisons,
bias/contact limits, retained-map certificates, WGSL reflection, target image
quality and CPU/GPU/residency/whole-frame cost remain open. The CPU checker is
proof content for a candidate, not production admission or device evidence.

The full-Sun-negation ray mutant negates every Sun component, then derives the
travel direction as minus that source vector. Every caster corner has negative
receiver-plane intersection time and the forward-ray intersection routine
refuses it. An unchecked infinite-line control would incorrectly project behind
the ray origin into the original receiver interval. A separately named
horizontal-ray-sign mutant flips only travel's x component while retaining its
negative z; those forward intersections lie at x approximately [4.9,5.3].
