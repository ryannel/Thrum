#!/usr/bin/env python3
"""Check each protected byte before and after regenerating a candidate package."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    m=json.loads((ROOT/"manifest.json").read_bytes())
    for entry in m["protected_files"]:
        p=ROOT/entry["path"]
        assert not p.is_symlink(),p
        raw=p.read_bytes()
        assert len(raw) == entry["bytes"] and hashlib.sha256(raw).hexdigest() == entry["sha256"],p
    print(f"PASS: {len(m['protected_files'])} protected files match exact lengths and SHA-256")

if __name__ == "__main__":main()
