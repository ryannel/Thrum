#!/usr/bin/env python3
"""Independent candidate checks. Does not import generator or claim F3 admission.

Fraction arithmetic means exact values AFTER binary64 JSON decoding. Binary64
camera tan is separately labeled; product-normalized Sun is not available here.
"""
import base64
import copy
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\Z")
RENDER = "records/render.record.json"
SCENE = "scenes/main.scene.json"
ENV = "records/environment.record.json"


def need(ok, why):
    if not ok:
        raise ValueError(why)


def keys(obj, required, optional=()):
    need(type(obj) is dict, "object required")
    need(set(required) <= obj.keys() <= set(required) | set(optional), "unknown/missing field")


def number(v, lo=None, hi=None):
    need(type(v) in (int, float), "number required")
    try:
        x = float(v)
    except OverflowError as e:
        raise ValueError("finite number required") from e
    need(math.isfinite(x), "finite number required")
    need((lo is None or x >= lo) and (hi is None or x <= hi), "number domain")
    return x


def vec(v, n, lo=None, hi=None):
    need(type(v) is list and len(v) == n, "vector shape")
    return [number(x, lo, hi) for x in v]


def rotation(v):
    x,y,z,w = vec(v,4)
    length = math.hypot(math.hypot(math.hypot(x,y),z),w)
    need(length > 0 and abs(length-1) <= 1e-9, "quaternion norm")


def position(v):
    return vec(v,3,-1e6,1e6)


def colour(v):
    x,y,z = vec(v,3,0)
    need(abs((0.2126*x + 0.7152*y + 0.0722*z)-1) <= 1e-9, "unit luminance")


def rational(v):
    return Q.from_float(float(v))


def point(v):
    return tuple(map(rational,v))


def minus(a,b):
    return tuple(x-y for x,y in zip(a,b))


def cross(a,b):
    return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])


def dot(a,b):
    return sum(x*y for x,y in zip(a,b))


def pairs(items):
    out = {}
    for key,value in items:
        need(key not in out, "duplicate decoded key")
        out[key] = value
    return out


def load(raw):
    need(len(raw) <= 16*1024*1024, "record byte limit")
    obj = json.loads(raw.decode("utf-8"), object_pairs_hook=pairs,
                     parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    nodes = 0
    def walk(x, depth):
        nonlocal nodes
        nodes += 1
        need(nodes <= 1_000_000 and depth <= 64, "record node/depth limit")
        if isinstance(x,dict):
            for k,v in x.items():
                need(not any(0xD800 <= ord(c) <= 0xDFFF for c in k), "invalid Unicode")
                walk(v,depth+1)
        elif isinstance(x,list):
            for v in x:
                walk(v,depth+1)
        elif isinstance(x,str):
            need(not any(0xD800 <= ord(c) <= 0xDFFF for c in x), "invalid Unicode")
        elif type(x) in (float,int):
            number(x)
    walk(obj,0)
    return obj


def validate(records):
    ids, edges, textures, triangles = {}, [], {}, []
    def identity(uid, kind, owner):
        need(type(uid) is str and UUID.fullmatch(uid), "canonical UUID")
        need(uid not in ids,"global UUID collision")
        ids[uid] = (kind,owner)
    def edge(source, field, target, kind, owner=None):
        need(type(target) is str and UUID.fullmatch(target), "edge UUID")
        edges.append((source,field,target,kind,owner))
    for path,r in records.items():
        keys(r,["id","type","schema","fields"],["documentation"])
        need(type(r["schema"]) is int and r["schema"] > 0,"schema number")
        if "documentation" in r:
            need(type(r["documentation"]) is str and len(r["documentation"].encode()) <= 4096,"documentation")
        identity(r["id"],(r["type"],r["schema"]),None)
    project = records["project.json"]; f=project["fields"]
    need((project["type"],project["schema"]) == ("core.project",2), "project version")
    keys(f,["project.format","project.records","project.schemas","project.registryHistory","project.entryScenes"])
    need(f["project.format"] == 1 and f["project.schemas"] == [], "project fixture grammar")
    paths = f["project.records"]
    need(type(paths) is list and paths == sorted(set(paths)), "sorted declared record paths")
    need(set(records) == set(paths) | {"project.json",f["project.registryHistory"]}, "complete tree membership")
    history=records[f["project.registryHistory"]]
    need((history["type"],history["schema"]) == ("core.registry-history",1),"history version")
    keys(history["fields"],["registry.fields","registry.versions"])
    need(history["fields"] == {"registry.fields":[],"registry.versions":[]},"empty game schema history")
    for uid in f["project.entryScenes"]:
        edge(project["id"],"project.entryScenes",uid,("core.scene",3))
    for path in paths:
        r=records[path]; f=r["fields"]; kind=(r["type"],r["schema"]); root=r["id"]
        if kind == ("core.scene",3):
            keys(f,["render.source"],["scene.label","environment.source"])
            if "scene.label" in f:
                need(type(f["scene.label"]) is str and len(f["scene.label"].encode()) <= 4096,"scene label")
            edge(root,"render.source",f["render.source"],("thrum.render.scene",1))
            if "environment.source" in f:
                edge(root,"environment.source",f["environment.source"],("thrum.environment.authored",1))
        elif kind == ("thrum.environment.authored",1):
            keys(f,["profile","sun","ambient_irradiance_lux","background_radiance_cd_m2","unsupported"])
            need(f["profile"] == "constant-light-v1","environment profile")
            s=f["sun"]
            keys(s,["light_ref","toward_source_unit","perpendicular_illuminance_lux",
                    "unit_luminance_linear_rec709","angular_radius_rad","direction_model","applied_attenuation"])
            x,y,z=vec(s["toward_source_unit"],3)
            length=math.hypot(math.hypot(x,y),z)
            need(length > 0 and abs(length-1) <= 1e-9,"Sun norm")
            colour(s["unit_luminance_linear_rec709"])
            number(s["perpendicular_illuminance_lux"],0); number(s["angular_radius_rad"],0)
            need(s["direction_model"] == "geometric-straight" and s["applied_attenuation"] == [], "Sun direction model")
            vec(f["ambient_irradiance_lux"],3,0);vec(f["background_radiance_cd_m2"],3,0)
            need(type(f["unsupported"]) is list and len(f["unsupported"]) == 7 and
                 set(f["unsupported"]) == {"wind","cloud_tau","precipitation","air","thermal","moon","air_quality"}, "unsupported set")
            edge(root,"sun.light_ref",s["light_ref"],("thrum.light.identity",1))
        elif kind == ("thrum.light.identity",1):
            keys(f,["driver_binding"])
            need(f["driver_binding"] == "incoming-environment-sun","Sun driver")
        elif kind == ("thrum.render.scene",1):
            keys(f,["cameras","active_camera","meshes","instances","materials","textures","local_lights"])
            edge(root,"active_camera",f["active_camera"],"camera",root)
            for field,ekind in [("cameras","camera"),("meshes","mesh"),("instances","instance"),
                                ("materials","material"),("textures","texture"),("local_lights","point-light")]:
                need(type(f[field]) is list,"embedded array")
                for obj in f[field]:
                    identity(obj["id"],ekind,root)
            for c in f["cameras"]:
                keys(c,["id","position_m","orientation_xyzw","vertical_fov_rad","near_m","far_m","exposure"])
                position(c["position_m"]);rotation(c["orientation_xyzw"])
                need(0 < number(c["vertical_fov_rad"]) < math.pi,"camera FOV")
                need(0 < number(c["near_m"]) < number(c["far_m"]),"camera depth")
                need(number(c["exposure"]) > 0,"camera exposure")
            for m in f["meshes"]:
                keys(m,["id","positions_m","uv0","triangles"])
                need(type(m["positions_m"]) is list and type(m["uv0"]) is list and
                     len(m["positions_m"]) == len(m["uv0"]),"mesh vertex/UV count")
                ps=[]
                for p in m["positions_m"]:
                    vec(p,3);p=point(p)
                    need(dot(p,p) <= 1_000_000,"exact local radius")
                    ps.append(p)
                for uv in m["uv0"]: vec(uv,2)
                need(type(m["triangles"]) is list,"triangle array")
                for t in m["triangles"]:
                    need(type(t) is list and len(t) == 3 and all(type(i) is int and 0 <= i <= 2**32-1 and i < len(ps) for i in t), "index range")
                    need(len(set(t)) == 3,"distinct triangle indices")
                    a,b,c=(ps[i] for i in t);n=cross(minus(b,a),minus(c,a))
                    need(any(n),"exact degenerate triangle")
                    triangles.append((m["id"],a,n))
            for inst in f["instances"]:
                keys(inst,["id","mesh","material","translation_m","orientation_xyzw","scale"])
                position(inst["translation_m"]);rotation(inst["orientation_xyzw"]);vec(inst["scale"],3)
                edge(inst["id"],"mesh",inst["mesh"],"mesh",root)
                edge(inst["id"],"material",inst["material"],"material",root)
            for tex in f["textures"]:
                keys(tex,["id","width","height","format","rgba8"])
                w,h=tex["width"],tex["height"]
                need(type(w) is int and type(h) is int and w > 0 and h > 0,"texture dimensions")
                need(tex["format"] in ("rgba8-srgb","rgba8-linear"),"texture transfer")
                encoded=tex["rgba8"]
                need(type(encoded) is str and encoded.isascii(),"base64 string")
                expected=4*w*h
                need(len(encoded) == 4*((expected+2)//3),"texture encoded size")
                try: raw=base64.b64decode(encoded,validate=True)
                except (ValueError,base64.binascii.Error) as e: raise ValueError("invalid base64") from e
                need(len(raw) == expected,"texture decoded size")
                need(base64.b64encode(raw).decode() == encoded,"canonical base64")
                textures[tex["id"]]=(tex,raw)
            for mat in f["materials"]:
                keys(mat,["id","alpha_mode","two_sided","sampler"],
                     ["alpha_cutoff","base_factor_rgba","emissive_radiance_factor_cd_m2",
                      "metallic_factor","roughness_factor","occlusion_strength","base_texture","orm_texture","emissive_texture"])
                need(mat["alpha_mode"] in ("opaque","mask") and type(mat["two_sided"]) is bool,"material policy")
                need(("alpha_cutoff" in mat) == (mat["alpha_mode"] == "mask"),"mask cutoff presence")
                if "alpha_cutoff" in mat:number(mat["alpha_cutoff"],0,1)
                for k in ["metallic_factor","roughness_factor","occlusion_strength"]:
                    if k in mat:number(mat[k],0,1)
                if "base_factor_rgba" in mat:vec(mat["base_factor_rgba"],4,0,1)
                if "emissive_radiance_factor_cd_m2" in mat:vec(mat["emissive_radiance_factor_cd_m2"],3,0)
                samp=mat["sampler"];keys(samp,["min_filter","mag_filter","address_u","address_v"])
                need(all(samp[k] in ("nearest","linear") for k in ["min_filter","mag_filter"]),"sampler filter")
                need(all(samp[k] in ("clamp-to-edge","repeat","mirror-repeat") for k in ["address_u","address_v"]),"sampler address")
                for slot in ["base_texture","orm_texture","emissive_texture"]:
                    if slot in mat:edge(mat["id"],slot,mat[slot],"texture",root)
            for light in f["local_lights"]:
                keys(light,["id","position_m","luminous_intensity_cd","unit_luminance_linear_rec709","radius_m"])
                position(light["position_m"]);number(light["luminous_intensity_cd"],0)
                number(light["radius_m"],0);colour(light["unit_luminance_linear_rec709"])
        else:
            raise ValueError("unsupported candidate record type/version")
    for src,field,target,kind,owner in edges:
        need(target in ids,"unresolved typed edge")
        need(ids[target] == (kind,owner),"wrong-type or cross-root edge")
        if field in ("base_texture","orm_texture","emissive_texture"):
            want="rgba8-linear" if field == "orm_texture" else "rgba8-srgb"
            need(textures[target][0]["format"] == want,"slot texture transfer")
    sun_id=records[ENV]["fields"]["sun"]["light_ref"]
    need(sum(e[1] == "sun.light_ref" and e[2] == sun_id for e in edges) == 1,"one Sun driver")
    return {"ids":ids,"edges":edges,"textures":textures,"triangles":triangles}


def geometry(records, state):
    f=records[RENDER]["fields"];c=f["cameras"][0]
    need([len(f[k]) for k in ["cameras","meshes","instances","materials","textures","local_lights"]] == [1,3,3,3,4,4],"recipe counts")
    need(len(records["project.json"]["fields"]["project.entryScenes"]) == 1,"one recipe entry")
    need(c["position_m"] == [0,0,5] and c["orientation_xyzw"] == [0,0,0,1] and
         c["vertical_fov_rad"] == 1.0471975511965976 and c["near_m"] == 0.1 and
         c["far_m"] == 20 and c["exposure"] == 0.0001,"camera recipe values")
    ef=records[ENV]["fields"]
    need(ef["sun"]["toward_source_unit"] == [0.6,0,0.8] and
         ef["sun"]["perpendicular_illuminance_lux"] == 100000 and
         ef["ambient_irradiance_lux"] == [1000,1000,1000] and
         ef["background_radiance_cd_m2"] == [0,0,0],"Sun/ambient recipe values")
    need(sorted(x["position_m"] for x in f["local_lights"]) == [[-1,-1,3],[-1,1,3],[1,-1,3],[1,1,3]] and
         all(x["luminous_intensity_cd"] == 1000 and x["radius_m"] == 0.1 and
             x["unit_luminance_linear_rec709"] == [1,1,1] for x in f["local_lights"]),"local light recipe values")
    for inst in f["instances"]:
        need(inst["translation_m"] == [0,0,0] and inst["orientation_xyzw"] == [0,0,0,1] and inst["scale"] == [1,1,1],"recipe identity transforms")
    bounds=[(-3,3,-2,2,0),(-0.6,0.6,-1,1,1),(3.4,3.8,-0.4,0.4,2)]
    for mesh, expected in zip(f["meshes"],bounds):
        ps=mesh["positions_m"];actual=(min(p[0] for p in ps),max(p[0] for p in ps),min(p[1] for p in ps),max(p[1] for p in ps),ps[0][2])
        need(actual == expected and all(p[2] == expected[4] for p in ps),"recipe quad bounds")
        need(mesh["triangles"] == [[0,1,2],[0,2,3]],"recipe winding")
        need(mesh["uv0"] == [[0,1],[1,1],[1,0],[0,0]],"top-left UV convention")
    sun=point(records[ENV]["fields"]["sun"]["toward_source_unit"])
    camera=point(c["position_m"]);lights=[point(x["position_m"]) for x in f["local_lights"]]
    signs=[]
    for mid,a,n in state["triangles"]:
        need(n[0] == n[1] == 0 and n[2] > 0,"+Z flat normals")
        values=[dot(n,sun),dot(n,minus(camera,a))]+[dot(n,minus(x,a)) for x in lights]
        need(all(x > 0 for x in values),"positive source predicates")
        signs.append({"mesh":mid,"values_exact":[str(x) for x in values]})
    # Exact closest point on each axis-aligned rectangle, for every local light.
    d2=[]
    for x0,x1,y0,y1,z in bounds:
        for light in f["local_lights"]:
            p=point(light["position_m"])
            q=(min(max(p[0],rational(x0)),rational(x1)),min(max(p[1],rational(y0)),rational(y1)),rational(z))
            dist2=dot(minus(p,q),minus(p,q))
            need(dist2 > rational(light["radius_m"])**2,"outside emitter radius")
            d2.append(dist2)
    # FOV is decoded binary64; math.tan result is an observation, not interval proof.
    caster=f["meshes"][2]["positions_m"]
    half_x=(number(c["position_m"][2])-number(caster[0][2]))*math.tan(number(c["vertical_fov_rad"])/2)*(1280/720)
    need(min(p[0] for p in caster) > half_x,"caster outside camera")
    shift=rational(caster[0][2])*sun[0]/sun[2]
    interval=[rational(min(p[0] for p in caster))-shift,rational(max(p[0] for p in caster))-shift]
    need(rational(1.8) < interval[0] < interval[1] < rational(2.4),"caster shadow inside receiver")
    def forward_receiver_hit(origin, ray):
        need(ray[2] != 0,"receiver-parallel ray")
        t=-origin[2]/ray[2]
        need(t > 0,"receiver intersection has nonpositive ray time")
        return tuple(p+t*d for p,d in zip(origin,ray))
    caster_exact=[point(p) for p in caster]
    correct_ray=tuple(-x for x in sun)
    projected=[forward_receiver_hit(p,correct_ray) for p in caster_exact]
    need([min(p[0] for p in projected),max(p[0] for p in projected)] == interval,
         "forward-ray source projection agrees with ratio")
    # Reversing only travel's horizontal component still points toward z=0.
    # It is distinct from negating the entire receiver-to-source Sun vector.
    horizontal_ray=(sun[0],-sun[1],-sun[2])
    horizontal_hits=[forward_receiver_hit(p,horizontal_ray) for p in caster_exact]
    horizontal_interval=[min(p[0] for p in horizontal_hits),max(p[0] for p in horizontal_hits)]
    need(horizontal_interval[0] > 3,"horizontal ray-sign mutant misses receiver")
    negated_sun=tuple(-x for x in sun)
    full_negation_ray=tuple(-x for x in negated_sun)
    negation_times=[]
    for p in caster_exact:
        t=-p[2]/full_negation_ray[2]
        need(t < 0,"full Sun negation must point away from receiver")
        negation_times.append(t)
        try:
            forward_receiver_hit(p,full_negation_ray)
        except ValueError as e:
            need(str(e) == "receiver intersection has nonpositive ray time",
                 "full Sun negation rejected at forward-time gate")
        else:
            raise ValueError("full Sun negation survived forward-time gate")
    # An incorrect infinite-line projector would recover the same receiver
    # interval behind the ray origin, so interval containment alone is unsound.
    unchecked=[tuple(x+t*d for x,d in zip(p,full_negation_ray))
               for p,t in zip(caster_exact,negation_times)]
    need([min(p[0] for p in unchecked),max(p[0] for p in unchecked)] == interval,
         "behind-origin line projection control")
    masked=[m for m in f["materials"] if m["alpha_mode"] == "mask"]
    need(len(masked) == 1,"one fence mask")
    mat=masked[0];tex,raw=state["textures"][mat["base_texture"]]
    need((tex["width"],tex["height"]) == (4,4) and mat["alpha_cutoff"] == 0.5,"mask recipe")
    need(mat["sampler"]["min_filter"] == mat["sampler"]["mag_filter"] == "nearest","shared mask filter")
    alpha=[raw[i] for i in range(3,len(raw),4)]
    expected=[255,0,255,0,0,255,0,255,255,0,255,0,0,255,0,255]
    need(alpha == expected,"saved checker alpha")
    pass_bits=[Q(x,255)*rational(mat["base_factor_rgba"][3]) >= rational(mat["alpha_cutoff"]) for x in alpha]
    need(sum(pass_bits) == 8,"eight passed mask texels")
    center_samples=[]
    for j in range(4):
        for i in range(4):
            u,v=Q(2*i+1,8),Q(2*j+1,8)
            tx,ty=int(u*4),int(v*4)
            a=Q(raw[4*(ty*4+tx)+3],255)
            actual=a*rational(mat["base_factor_rgba"][3]) >= rational(mat["alpha_cutoff"])
            need(actual == ((i+j)%2 == 0),"nearest texel-center mask decision")
            center_samples.append({"uv_exact":[str(u),str(v)],"texel":[tx,ty],
                                   "sample_alpha_exact":str(a),"keep":actual})
    boundary_cases=[("below cutoff",Q(127,255),Q(1),False),
                    ("above cutoff",Q(128,255),Q(1),True),
                    ("exact equality via alpha factor",Q(1),Q(1,2),True)]
    boundaries=[]
    for name,a,factor,expected_keep in boundary_cases:
        actual=a*factor >= Q(1,2)
        need(actual == expected_keep,"scalar cutoff boundary")
        boundaries.append({"name":name,"alpha_exact":str(a),"factor_exact":str(factor),
                           "cutoff_exact":"1/2","keep":actual,
                           "scope":"CPU scalar auxiliary case; not a texel in the saved source"})
    roughness=[]
    for m in f["materials"]:
        g=[255]
        if "orm_texture" in m:g=list(state["textures"][m["orm_texture"]][1][1::4])
        effective=min(max(Q(45,1000),rational(m.get("roughness_factor",1))*Q(x,255)) for x in g)
        need(effective >= rational(0.32),"fixture actual roughness")
        roughness.append(str(effective))
    return {"triangle_predicates":signs,"positive_predicate_count":36,
            "minimum_local_distance_squared_exact":str(min(d2)),"local_rectangle_distance_checks":12,
            "camera_caster_half_width_binary64_m":half_x,
            "caster_min_x_m":min(p[0] for p in caster),
            "raw_decoded_Sun_shadow_x_interval_exact":[str(x) for x in interval],
            "raw_decoded_Sun_shadow_x_interval_binary64":[float(x) for x in interval],
            "horizontal_ray_sign_mutant":{
                "travel_direction_exact":[str(x) for x in horizontal_ray],
                "forward_receiver_x_interval_binary64":[float(x) for x in horizontal_interval],
                "outcome":"forward intersections lie outside receiver"},
            "full_Sun_negation_ray_mutant":{
                "negated_toward_source_exact":[str(x) for x in negated_sun],
                "travel_direction_exact":[str(x) for x in full_negation_ray],
                "receiver_intersection_times_exact":[str(x) for x in negation_times],
                "forward_time_refusals":len(negation_times),
                "outcome":"receiver intersection has nonpositive ray time",
                "unchecked_infinite_line_would_hit_receiver":True},
            "passed_mask_texel_count":sum(pass_bits),"mask_nearest_texel_center_samples":center_samples,
            "mask_scalar_cutoff_boundary_controls":boundaries,
            "minimum_local_distance_squared_binary64":float(min(d2)),
            "effective_min_roughness_exact":roughness}


def mutants(records):
    outcomes=[]
    def reject(name, change, reason):
        bad=copy.deepcopy(records);change(bad)
        try:validate(bad)
        except (ValueError,KeyError) as e:
            need(reason in str(e),f"mutant {name} failed at wrong gate: {e}")
            outcomes.append({"name":name,"refusal":str(e)})
        else:raise ValueError(f"mutant survived: {name}")
    def rf(r):return r[RENDER]["fields"]
    reject("unused embedded/global collision",lambda r:rf(r)["textures"][3].update(id=r["project.json"]["id"]),"global UUID collision")
    reject("instance mesh wrong type",lambda r:rf(r)["instances"][0].update(mesh=rf(r)["materials"][0]["id"]),"wrong-type")
    reject("dangling material texture",lambda r:rf(r)["materials"][1].update(base_texture="a6b9c300-0000-4000-8000-ffffffffffff"),"unresolved")
    reject("scene render targets environment",lambda r:r[SCENE]["fields"].update({"render.source":r[ENV]["id"]}),"wrong-type")
    reject("second environment selector in render",lambda r:rf(r).update({"environment.source":r[ENV]["id"]}),"unknown/missing")
    reject("missing mask cutoff",lambda r:rf(r)["materials"][1].pop("alpha_cutoff"),"mask cutoff")
    reject("null present texture",lambda r:rf(r)["materials"][0].update(base_texture=None),"edge UUID")
    reject("wrong texture transfer",lambda r:rf(r)["textures"][0].update(format="rgba8-linear"),"slot texture transfer")
    reject("texture dimension overflow-shaped",lambda r:rf(r)["textures"][0].update(width=2**64),"texture encoded size")
    reject("bad base64 alphabet",lambda r:rf(r)["textures"][3].update(rgba8="!EAg/w=="),"invalid base64")
    reject("noncanonical base64 pad bits",lambda r:rf(r)["textures"][3].update(rgba8="gEAg/x=="),"canonical base64")
    reject("degenerate exact triangle",lambda r:rf(r)["meshes"][0]["positions_m"].__setitem__(2,rf(r)["meshes"][0]["positions_m"][1]),"exact degenerate")
    reject("local radius rounded-boundary trap",lambda r:rf(r)["meshes"][0]["positions_m"].__setitem__(0,[600,800,1e-6]),"exact local radius")
    reject("unknown normal map",lambda r:rf(r)["materials"][0].update(normal_texture=None),"unknown/missing")
    reject("nonunit quaternion",lambda r:rf(r)["cameras"][0].update(orientation_xyzw=[0,0,0,0]),"quaternion norm")
    reject("contrary unsupported set",lambda r:r[ENV]["fields"]["unsupported"].__setitem__(0,"moon"),"unsupported set")
    # Parser must compare decoded keys; this escaped spelling duplicates `id`.
    raw=b'{"id":1,"\\u0069d":2}'
    try:load(raw)
    except ValueError as e:
        need(str(e) == "duplicate decoded key","duplicate parser gate")
        outcomes.append({"name":"escaped duplicate key","refusal":str(e)})
    else:raise ValueError("duplicate survived")
    return outcomes


def main():
    declaration=load((ROOT/"declared_tree.json").read_bytes())
    paths=declaration["paths"]
    need(paths == sorted(set(paths)),"declared tree order")
    actual=sorted(p.relative_to(ROOT/"source").as_posix() for p in (ROOT/"source").rglob("*") if p.is_file())
    need(paths == actual,"no undeclared source files")
    records={p:load((ROOT/"source"/p).read_bytes()) for p in paths}
    state=validate(records);geo=geometry(records,state)
    # Identity-array order has no semantic effect; our topology checks agree.
    reordered=copy.deepcopy(records)
    for k,v in reordered[RENDER]["fields"].items():
        if isinstance(v,list):v.reverse()
    other=validate(reordered)
    need(state["ids"] == other["ids"] and sorted(state["edges"]) == sorted(other["edges"]),"array reordering semantics")
    result={"status":"candidate structural/geometry checks pass; not F3/F4/device admission",
            "source_file_count":len(records),"top_level_uuid_count":len(records),
            "embedded_uuid_count":len(state["ids"])-len(records),"global_uuid_count":len(state["ids"]),
            "typed_required_edges_including_entry_scene":len(state["edges"]),
            "edge_list":[{"source":s,"field":f,"target":t,"expected_kind":k,"owner":o} for s,f,t,k,o in state["edges"]],
            "identity_array_reordering_control":"pass",
            "geometry":geo,"refusal_mutants":mutants(records),
            "source_files":[{"path":p,"bytes":(ROOT/"source"/p).stat().st_size,
                             "sha256":hashlib.sha256((ROOT/"source"/p).read_bytes()).hexdigest()} for p in paths],
            "texture_bytes":[{"id":uid,"decoded_bytes":len(raw),"hex":raw.hex(),
                              "sha256":hashlib.sha256(raw).hexdigest()} for uid,(tex,raw) in sorted(state["textures"].items())],
            "limits":"Existing whole-record byte/node/depth checks only; no new universal source cap.",
            "unresolved":load((ROOT/"candidate_recipe.json").read_bytes())["unresolved"]}
    output=(json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    (ROOT/"results.json").write_bytes(output)
    print(f"PASS: {len(records)} source files, {len(state['ids'])} UUIDs, {len(state['edges'])} typed edges, 6 triangles, 36 source predicates, {len(result['refusal_mutants'])} source refusal mutants, 4 full-Sun-negation forward-time refusals")

if __name__ == "__main__":main()
