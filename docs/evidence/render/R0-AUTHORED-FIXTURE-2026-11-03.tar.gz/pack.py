#!/usr/bin/env python3
"""Pack already-verified protected bytes in a reproducible archive."""
import gzip
import io
import json
from pathlib import Path
import sys
import tarfile
from check_package import main as check

ROOT=Path(__file__).resolve().parent
check()
manifest=json.loads((ROOT/"manifest.json").read_bytes())
paths=sorted([e["path"] for e in manifest["protected_files"]]+["manifest.json"])
out=Path(sys.argv[1])
with out.open("wb") as sink:
    with gzip.GzipFile(fileobj=sink,mode="wb",filename="",mtime=0,compresslevel=9) as gz:
        with tarfile.open(fileobj=gz,mode="w",format=tarfile.USTAR_FORMAT) as tar:
            for name in paths:
                data=(ROOT/name).read_bytes()
                info=tarfile.TarInfo(name)
                info.size=len(data);info.mode=0o644;info.uid=info.gid=0
                info.uname=info.gname="";info.mtime=0
                tar.addfile(info,io.BytesIO(data))
print(out)
