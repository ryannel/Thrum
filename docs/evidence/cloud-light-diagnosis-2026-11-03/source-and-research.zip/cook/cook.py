#!/usr/bin/env python3
"""Deterministic static Cb challenger; authoring only, no renderer changes."""
from __future__ import annotations

import hashlib
import json
import math
import mmap
import os
import resource
import subprocess
import struct
import sys
import time
import zlib
from pathlib import Path

import numpy as np
import scipy
from scipy import ndimage
from scipy.interpolate import PchipInterpolator
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parent
N = 256
BMIN = np.array([-6000., 0., -6000.])
EXT = np.array([12000., 14000., 12000.])
PITCH = EXT / N
SAMPLE_ZYX = (PITCH[2], PITCH[1], PITCH[0])
SEED = 19381103
RNG = np.random.Generator(np.random.PCG64(SEED))
MAX_DIST = 800.
HALO_Z = 20
CORE_Z = 8
WORKER_GROUP_Z = 16
WORKER_PEAKS = []
PARENT_AT_WORKER = []
SCRATCH_MAPS = []
assert HALO_Z * PITCH[2] > MAX_DIST + 2 * max(PITCH)

BRANCHES = [
    dict(id='main', h=[900, 1550, 2700, 4000, 5500, 7000, 8350, 9500, 10100],
         rx=[180, 1200, 2050, 2350, 2200, 1950, 1650, 850, 60],
         rz=[180, 1050, 1750, 1950, 1830, 1680, 1390, 790, 60],
         cx=[-750, -650, -520, -380, -230, -70, 100, 270, 420],
         cz=[100, 90, 110, 140, 170, 120, 50, 0, -30]),
    dict(id='left', h=[1900, 2850, 4000, 5500, 6800, 8100, 9300],
         rx=[120, 850, 1320, 1420, 1250, 760, 50],
         rz=[120, 820, 1190, 1260, 1090, 730, 50],
         cx=[-1250, -1550, -1840, -2170, -2380, -2510, -2530],
         cz=[-150, -270, -420, -500, -530, -470, -420]),
    dict(id='rear', h=[1700, 2700, 4200, 5700, 7200, 8500, 9550],
         rx=[130, 790, 1230, 1360, 1160, 750, 50],
         rz=[130, 750, 1110, 1200, 1010, 680, 50],
         cx=[50, 330, 710, 1060, 1370, 1550, 1600],
         cz=[250, 430, 650, 790, 800, 700, 650]),
]
for b in BRANCHES:
    b['_f'] = {key: PchipInterpolator(b['h'], b[key], extrapolate=False)
               for key in ('rx', 'rz', 'cx', 'cz')}


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0., 1.)
    return t * t * (3. - 2. * t)


def branch_params(b, h):
    if not b['h'][0] <= h <= b['h'][-1]:
        return None
    return {k: float(f(h)) for k, f in b['_f'].items()}


def branch_d(b, h, x, z):
    p = branch_params(b, h)
    if p is None:
        return np.full(np.broadcast_shapes(np.shape(x), np.shape(z)), -10000., np.float32)
    rho = np.sqrt(((x - p['cx']) / p['rx']) ** 2 + ((z - p['cz']) / p['rz']) ** 2)
    radial = (1. - rho) * min(p['rx'], p['rz'])
    # Closed, finite loft; tapered end sections are part of the authored profile.
    return np.minimum(radial, min(h - b['h'][0], b['h'][-1] - h)).astype(np.float32)


def scaffold_d(h, x, z):
    return np.maximum.reduce([branch_d(b, h, x, z) for b in BRANCHES])


def cap_geometry(h, x, z):
    s = x - 150.
    t = np.clip((s + 1550.) / 6900., 0., 1.)
    center = -80. + .14 * s + 110. * np.sin(s / 2200.)
    width = 470. + 2150. * np.sin(np.pi * t) ** .83
    top = 10850. - 0.000023 * (s - 500.) ** 2 - 0.000012 * (z - center) ** 2
    thick = 190. + 1850. * (1. - t) ** 1.3
    plan = np.minimum.reduce([s + 1550., 5350. - s, width - np.abs(z - center)])
    return np.minimum(np.minimum(plan, h - (top - thick)), top - h).astype(np.float32)


def surface_point(b, h, theta):
    p = branch_params(b, h)
    if p is None:
        return None
    x = p['cx'] + p['rx'] * math.cos(theta)
    z = p['cz'] + p['rz'] * math.sin(theta)
    nx, nz = math.cos(theta) / p['rx'], math.sin(theta) / p['rz']
    norm = math.hypot(nx, nz)
    return x, h, z, nx / norm, nz / norm, min(p['rx'], p['rz'])


def make_lobe(point, tier, serial):
    x, h, z, nx, nz, local_r = point
    if tier == 0:
        r = float(np.clip(.30 * local_r, 260., 680.)) * RNG.uniform(.84, 1.16)
    else:
        r = float(np.clip(.11 * local_r, 105., 260.)) * RNG.uniform(.82, 1.18)
    inset = .42 * r
    return dict(id=f'{tier}-{serial}', c=(x - inset * nx, h, z - inset * nz), r=r, tier=tier)


def sample_surface_sites():
    lobes = []
    serial = 0
    for b in BRANCHES:
        for tier, dh, arc in ((0, 260., 310.), (1, 460., 430.)):
            heights = np.arange(b['h'][0] + 220., b['h'][-1] - 170., dh)
            for ih, base_h in enumerate(heights):
                p = branch_params(b, float(base_h))
                circumference = 2 * np.pi * np.sqrt((p['rx'] ** 2 + p['rz'] ** 2) / 2)
                count = max(8, int(np.ceil(circumference / arc)))
                phase = (ih * .61803398875 + tier * .37) % 1.
                for j in range(count):
                    h = float(np.clip(base_h + RNG.uniform(-.16, .16) * dh,
                                      b['h'][0] + 160, b['h'][-1] - 120))
                    theta = 2 * np.pi * ((j + phase + RNG.uniform(-.12, .12)) / count)
                    point = surface_point(b, h, theta)
                    if point is None:
                        continue
                    # Buried branch patches do not need an outward stamp.
                    if scaffold_d(h, point[0], point[2]) > 75.:
                        continue
                    lobes.append(make_lobe(point, tier, serial))
                    serial += 1
    return lobes


def coverage(lobes, fill=False):
    samples = []
    added = 0
    for b in BRANCHES:
        for base_h in np.arange(b['h'][0] + 180., b['h'][-1] - 120., 105.):
            p = branch_params(b, float(base_h))
            circumference = 2 * np.pi * np.sqrt((p['rx'] ** 2 + p['rz'] ** 2) / 2)
            count = max(12, int(np.ceil(circumference / 140.)))
            for j in range(count):
                theta = 2 * np.pi * (j + .5) / count
                point = surface_point(b, float(base_h), theta)
                if scaffold_d(base_h, point[0], point[2]) > 75.:
                    continue
                samples.append((b['id'], float(base_h), theta, point))
    # Spatial lookup is only an acceleration for exact sphere-footprint evaluation.
    for _ in range(2 if fill else 1):
        tree = cKDTree(np.array([l['c'] for l in lobes]))
        uncovered = []
        records = []
        for bid, h, theta, point in samples:
            indices = tree.query_ball_point(point[:3], r=820.)
            cover = max((lobes[i]['r'] - math.dist(lobes[i]['c'], point[:3]) for i in indices), default=-1e4)
            records.append((bid, h, theta, cover))
            if cover < 15.:
                uncovered.append(point)
        if not fill or not uncovered:
            break
        for point in uncovered:
            lobes.append(make_lobe(point, 0, len(lobes)))
        added += len(uncovered)
    by_band = {}
    for bid, h, theta, cover in records:
        key = f'{bid}:{int(h//1000)}km:{int(theta//(np.pi/4))}oct'
        item = by_band.setdefault(key, [0, 0, 1e9])
        item[0] += 1
        item[1] += int(cover >= 15.)
        item[2] = min(item[2], cover)
    return lobes, dict(samples=len(records), covered=sum(r[3] >= 15. for r in records),
                       min_margin_m=min(r[3] for r in records), added_fill_sites=added,
                       bins={k: dict(samples=v[0], covered=v[1], min_margin_m=v[2])
                             for k, v in by_band.items()})


def build_mask(path, lobes):
    mask = np.memmap(path, dtype=np.uint8, mode='w+', shape=(N, N, N))
    xs = BMIN[0] + (np.arange(N) + .5) * PITCH[0]
    ys = BMIN[1] + (np.arange(N) + .5) * PITCH[1]
    zs = BMIN[2] + (np.arange(N) + .5) * PITCH[2]
    X, Z = np.meshgrid(xs, zs, indexing='xy')
    for iy, y in enumerate(ys):
        body = scaffold_d(float(y), X, Z) > 0
        cap = cap_geometry(float(y), X, Z) > 0
        mask[:, iy, :] = np.logical_or(body, cap)
    mask.flush()
    for l in lobes:
        cx, cy, cz = l['c']; r = l['r']
        x0, x1 = np.searchsorted(xs, [cx-r, cx+r]); y0, y1 = np.searchsorted(ys, [cy-r, cy+r]); z0, z1 = np.searchsorted(zs, [cz-r, cz+r])
        if x0 >= x1 or y0 >= y1 or z0 >= z1:
            continue
        xx = (xs[x0:x1] - cx)[None, None, :]
        yy = (ys[y0:y1] - cy)[None, :, None]
        zz = (zs[z0:z1] - cz)[:, None, None]
        stamp = xx*xx + yy*yy + zz*zz <= r*r
        mask[z0:z1, y0:y1, x0:x1] |= stamp
    mask.flush()
    return mask


def redistance_range(mask, out, start_z, end_z):
    for z0 in range(start_z, end_z, CORE_Z):
        z1 = min(N, z0 + CORE_Z)
        lo, hi = max(0, z0-HALO_Z), min(N, z1+HALO_Z)
        sub = np.asarray(mask[lo:hi, :, :] > 0, dtype=np.bool_)
        inner = ndimage.distance_transform_edt(sub, sampling=SAMPLE_ZYX)
        out[z0:z1] = np.minimum(inner[z0-lo:z1-lo],MAX_DIST).astype(np.float32)
        del inner
        # SciPy regards (-1,0,0) as a zero for an all-true EDT input. For
        # outside-distance, that point is not cloud. Push it beyond the
        # retained 800 m band at the global lower-Z edge.
        offset = math.ceil(MAX_DIST / PITCH[2]) + 1 if lo == 0 else 0
        outside = np.pad(~sub, ((offset,0),(0,0),(0,0)), constant_values=True) if offset else ~sub
        outer = ndimage.distance_transform_edt(outside, sampling=SAMPLE_ZYX)
        out[z0:z1] = np.maximum(-MAX_DIST, out[z0:z1] - outer[z0-lo+offset:z1-lo+offset]).astype(np.float32)
        del outer, outside, sub
    out.flush()


def redistance(mask, out):
    mask.flush();out.flush()
    for start_z in range(0,N,WORKER_GROUP_Z):
        end_z=min(N,start_z+WORKER_GROUP_Z)
        for mapped in SCRATCH_MAPS:
            mapped.flush();mapped._mmap.madvise(mmap.MADV_DONTNEED)
        parent_kib=int(subprocess.run(['ps','-o','rss=','-p',str(os.getpid())],check=True,capture_output=True,text=True).stdout.strip())
        run=subprocess.run([sys.executable,str(ROOT/'cook.py'),'--distance-worker',
                            str(mask.filename),str(out.filename),str(start_z),str(end_z)],
                           check=True,capture_output=True,text=True)
        peak=float(run.stdout.strip())
        WORKER_PEAKS.append(peak)
        PARENT_AT_WORKER.append(parent_kib/1024.)
    out.flush()


def displacement(src, dst, element_m, amplitude_m, seed, stage):
    rng = np.random.Generator(np.random.PCG64(seed))
    grid_shape = tuple(int(math.ceil(e / element_m)) + 8 for e in EXT[::-1])
    grid = rng.normal(0., 1., grid_shape).astype(np.float32)
    # Cubic interpolation of a fixed, bounded 3D field, evaluated in Z slabs.
    grid = np.clip(grid / 1.4, -1., 1.)
    gx = (np.arange(N) + .5) * PITCH[0] / element_m + 3.
    gy = (np.arange(N) + .5) * PITCH[1] / element_m + 3.
    for z0 in range(0, N, CORE_Z):
        z1 = min(N, z0 + CORE_Z)
        gz = ((np.arange(z0, z1) + .5) * PITCH[2] / element_m + 3.)[:, None, None]
        coords = np.broadcast_arrays(gz, gy[None, :, None], gx[None, None, :])
        noise = ndimage.map_coordinates(grid, coords, order=3, mode='nearest', prefilter=True)
        noise = np.clip(noise, -1., 1.)
        d = np.asarray(src[z0:z1], np.float32)
        y = BMIN[1] + (np.arange(N) + .5) * PITCH[1]
        region = 1. - smooth(8750., 10000., y)
        band = np.clip((MAX_DIST - np.abs(d)) / 350., 0., 1.)
        dst[z0:z1] = d + amplitude_m * noise * band * region[None, :, None]
    dst.flush()
    return dict(stage=stage, element_m=element_m, amplitude_m=amplitude_m, seed=seed,
                grid_shape_zyx=grid_shape, band_limit_m=MAX_DIST, body_region_fade_y_m=[8750, 10000])


def strands():
    rng = np.random.Generator(np.random.PCG64(SEED + 33))
    records = []
    for i in range(17):
        u = (i - 8) / 8
        records.append(dict(id=f'ice-{i:02d}', root_z_m=float(rng.uniform(-320, 320)),
                            end_z_m=float(u * rng.uniform(1700, 2550)),
                            phase=float(rng.uniform(-np.pi, np.pi)),
                            tip_s_m=float(rng.uniform(3650, 5200)),
                            radius_z_m=float(rng.uniform(95, 155)),
                            radius_y_m=float(rng.uniform(85, 130)),
                            peak=float(rng.uniform(.055, .085))))
    return records


def make_density(d, path, fibres):
    q = np.memmap(path, dtype='<f2', mode='w+', shape=(N, N, N))
    xs = BMIN[0] + (np.arange(N) + .5) * PITCH[0]
    ys = BMIN[1] + (np.arange(N) + .5) * PITCH[1]
    zs = BMIN[2] + (np.arange(N) + .5) * PITCH[2]
    X, Z = np.meshgrid(xs, zs, indexing='xy')
    s = X - 150.
    t = np.clip((s + 1550.) / 6900., 0., 1.)
    center = -80. + .14 * s + 110. * np.sin(s / 2200.)
    top = 10850. - .000023 * (s - 500.) ** 2 - .000012 * (Z - center) ** 2
    thick = 190. + 1850. * (1. - t) ** 1.3
    cap_plan = (s >= -1550.) & (s <= 5350.) & (np.abs(Z-center) < (470. + 2150.*np.sin(np.pi*t)**.83))
    for iy, y in enumerate(ys):
        D = np.asarray(d[:, iy, :], np.float32)
        F = smooth(-160., 170., D)
        body_owner = (1.-smooth(8750.,9600.,y)) + smooth(8750.,9600.,y)*smooth(-700.,-250.,scaffold_d(float(y),X,Z))
        body = F * body_owner * (.092 + .055*smooth(160., 650., D)) * (1. - smooth(9100., 10450., y))
        cap_layer = cap_plan & (y >= top-thick-160.) & (y <= top+160.)
        root = F * cap_layer * .11 * np.exp(-.5*(s/1000.)**2) * np.exp(-.5*((Z-center)/900.)**2) * smooth(-1500.,-600.,s)
        fibre = np.zeros_like(D)
        if y > 9250.:
            for f in fibres:
                u = np.clip((s + 300.) / (f['tip_s_m'] + 300.), 0., 1.)
                line_z = f['root_z_m'] * (1.-u) + f['end_z_m'] * u**.83 + 95.*np.sin(2*np.pi*u + f['phase']) * smooth(0., .3, u)
                line_y = top - (.28 + .16*u)*thick + 85.*np.sin(2*np.pi*u + .6*f['phase'])
                dist = ((Z-line_z)/f['radius_z_m'])**2 + ((y-line_y)/f['radius_y_m'])**2
                taper = smooth(-300., 500., s) * (1. - smooth(f['tip_s_m']-450., f['tip_s_m'], s))
                np.maximum(fibre, f['peak'] * np.exp(-.5*dist) * taper, out=fibre)
        capq = np.maximum(root, fibre * cap_layer)
        q[:, iy, :] = np.clip(np.maximum(body, capq), 0., 1.).astype('<f2')
    q.flush()
    return q


def metrics(q, coverage_metrics, lobes, fibres, passes, elapsed):
    a = q
    nonzero = a > 0
    support_axes=[np.flatnonzero(np.any(nonzero,axis=tuple(j for j in range(3) if j!=i))) for i in range(3)]
    low_zyx=np.array([v[0] for v in support_axes]);high_zyx=np.array([v[-1] for v in support_axes])
    collar_zyx = np.minimum(low_zyx, N-1-high_zyx)
    xs = BMIN[0] + (np.arange(N)+.5)*PITCH[0]
    ys = BMIN[1] + (np.arange(N)+.5)*PITCH[1]
    zs = BMIN[2] + (np.arange(N)+.5)*PITCH[2]
    roi = a[np.ix_((zs>=-900)&(zs<=900), (ys>=3500)&(ys<=7800), (xs>=-1100)&(xs<=1100))]
    root = (np.abs(xs)<=900, (ys>=6500)&(ys<=8500), np.abs(zs)<=900)
    cap = ((xs>=600)&(xs<=2000), (ys>=9800)&(ys<=10800), np.abs(zs)<=1500)
    connects = {}
    for threshold in (.02, .05, .08):
        binary = a >= threshold
        labels, num = ndimage.label(binary, structure=ndimage.generate_binary_structure(3, 1))
        body_ids = np.unique(labels[np.ix_(root[2], root[1], root[0])]);body_ids=body_ids[body_ids>0]
        cap_ids = np.unique(labels[np.ix_(cap[2], cap[1], cap[0])]);cap_ids=cap_ids[cap_ids>0]
        counts = np.bincount(labels.ravel())
        connects[str(threshold)] = dict(components=int(num), body_cap_connected=bool(np.intersect1d(body_ids,cap_ids).size),
                                        largest_fraction=float(counts[1:].max()/max(binary.sum(),1)) if num else 0.)
        del labels, binary
    neck = []
    for y in (3500,5000,6500,8000,9000,9700,10200):
        iy = int(np.argmin(abs(ys-y)))
        neck.append(dict(height_m=float(ys[iy]), area_q_ge_05_m2=int(np.count_nonzero(a[:,iy,:]>=.05))*PITCH[0]*PITCH[2]))
    result = dict(id='thrum.cb-covered-anatomy.static256.v1', classification='Unaccepted static authored Cb challenger',
                  output=dict(file='cb-covered-256.density.r16f', bytes=N**3*2, dimensions_xyz=[N]*3,
                              storage='little-endian R16F X fastest, numpy [Z,Y,X]',
                              bounds_min_corner_xyz_m=BMIN.tolist(), bounds_max_corner_xyz_m=(BMIN+EXT).tolist(),
                              voxel_pitch_xyz_m=PITCH.tolist(), sha256=hashlib.sha256((ROOT/'cb-covered-256.density.r16f').read_bytes()).hexdigest()),
                  world_target_m=[0,6500,0], seed=SEED,
                  anatomy=dict(branches=[{k:v for k,v in b.items() if not k.startswith('_')} for b in BRANCHES],
                               cap=dict(root_s_m=-1550,tip_s_m=5350,top_base_m=10850,root_thickness_m=2040,distal_thickness_m=190,
                                        max_width_m=2620,wind_axis_world=[1,0,0]),
                               lobe_count=len(lobes),lobe_tiers={str(t):sum(l['tier']==t for l in lobes) for t in (0,1)},
                               lobe_hash_sha256=hashlib.sha256(json.dumps(lobes,sort_keys=True).encode()).hexdigest(),
                               fibres=fibres,displacement_passes=passes),
                  metrics=dict(peak=float(a.max()),sum=float(a.sum(dtype=np.float64)),nonzero=int(nonzero.sum()),
                               support_bbox_min_zyx=low_zyx.tolist(), support_bbox_max_zyx=high_zyx.tolist(),
                               zero_collar_min_zyx=collar_zyx.tolist(),
                               deep_core_roi_xyz_m=[[-1100,1100],[3500,7800],[-900,900]],
                               deep_core_fraction_q_ge_05=float(np.mean(roi>=.05)),
                               deep_core_fraction_q_ge_10=float(np.mean(roi>=.10)),
                               deep_core_mean_q=float(roi.mean()),
                               connectivity_6_neighbor=connects,horizontal_neck_sections=neck,
                               full_surface_footprint=coverage_metrics,
                               smallest_retained_element_m=220,
                               smallest_cap_fibre_fwhm_m=float(2*math.sqrt(2*math.log(2))*85),
                               min_feature_over_max_pitch=float(2*math.sqrt(2*math.log(2))*85/max(PITCH))),
                  preparation=dict(python=os.sys.version.split()[0],numpy=np.__version__,scipy=scipy.__version__,
                                   recipe_sha256=hashlib.sha256((ROOT/'cook.py').read_bytes()).hexdigest(),
                                   elapsed_s=elapsed,peak_parent_rss_mib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,
                                   peak_worker_rss_mib=max(WORKER_PEAKS),
                                   peak_concurrent_parent_plus_worker_mib=max(p+w for p,w in zip(PARENT_AT_WORKER,WORKER_PEAKS)),
                                   peak_rss_mib=max(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,max(WORKER_PEAKS)),
                                   rss_limit_mib=768,disk_unique_limit_mib=512),
                  scope=['One frozen scalar source only; ice phase split and lifecycle are not proved',
                         'No κ/light/renderer change or 384³ cook',
                         'Surface footprint coverage is a source operation diagnostic, not image acceptance'])
    return result


def save_panels(q):
    a = q
    panels = [('front_max',a.max(axis=0)[::-1,:]),('side_max',a.max(axis=2).T[::-1,:]),
              ('front_opacity',(1-np.exp(-a.sum(axis=0,dtype=np.float32)*PITCH[2]*.0045))[::-1,:]),
              ('side_opacity',(1-np.exp(-a.sum(axis=2,dtype=np.float32)*PITCH[0]*.0045)).T[::-1,:]),
              ('slice_y5000',a[:,int(5000/PITCH[1]),:]),
              ('slice_y7500',a[:,int(7500/PITCH[1]),:]),
              ('slice_y10000',a[:,int(10000/PITCH[1]),:]),
              ('slice_y10600',a[:,int(10600/PITCH[1]),:])]
    board=np.zeros((2*260,4*260),np.uint8)
    for i,(label,arr) in enumerate(panels):
        b=np.clip(arr/(.18 if 'max' in label or 'slice' in label else 1.),0.,1.)
        row,col=divmod(i,4)
        board[row*260:row*260+256,col*260:col*260+256]=(b*255).astype(np.uint8)
    def chunk(kind,data):
        return struct.pack('>I',len(data))+kind+data+struct.pack('>I',zlib.crc32(kind+data)&0xffffffff)
    payload=b''.join(b'\x00'+board[y].tobytes() for y in range(board.shape[0]))
    png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',board.shape[1],board.shape[0],8,0,0,0,0))+chunk(b'IDAT',zlib.compress(payload,6))+chunk(b'IEND',b'')
    (ROOT/'native-panels.png').write_bytes(png)
    (ROOT/'native-panels.json').write_text(json.dumps(dict(layout='4 columns x 2 rows, 256 native pixels per panel, 4px separator',
                                                       panels=[p[0] for p in panels],q_display_scale=.18,
                                                       opacity_kappa_per_m=.0045),indent=2)+'\n')


def main():
    start=time.monotonic()
    lobes=sample_surface_sites()
    lobes,cover=coverage(lobes,fill=True)
    (ROOT/'lobes.json').write_text(json.dumps(lobes,separators=(',',':'))+'\n')
    (ROOT/'coverage.json').write_text(json.dumps(cover,indent=2)+'\n')
    print('surface coverage',cover['covered'],'/',cover['samples'],'lobes',len(lobes),flush=True)
    mask=build_mask(ROOT/'scratch-mask.u8',lobes)
    d0=np.memmap(ROOT/'scratch-distance-a.f32',dtype='<f4',mode='w+',shape=(N,N,N))
    d1=np.memmap(ROOT/'scratch-distance-b.f32',dtype='<f4',mode='w+',shape=(N,N,N))
    SCRATCH_MAPS.extend((mask,d0,d1))
    redistance(mask,d0)
    passes=[]
    for j,(elem,amp) in enumerate(((1250.,300.),(540.,145.),(220.,65.))):
        passes.append(displacement(d0,d1,elem,amp,SEED+100+j,j))
        mask[:]=(d1>0)
        mask.flush();redistance(mask,d0)
        print('distance pass',j,'rssMiB',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2,flush=True)
    fibre=strands()
    q=make_density(d0,ROOT/'cb-covered-256.density.r16f',fibre)
    save_panels(q)
    meta=metrics(q,cover,lobes,fibre,passes,time.monotonic()-start)
    (ROOT/'cb-covered-256.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('complete',meta['output']['sha256'],'peak',meta['metrics']['peak'],
          'rssMiB',meta['preparation']['peak_rss_mib'],'elapsed',meta['preparation']['elapsed_s'],flush=True)
    del q,d0,d1,mask
    for p in ('scratch-mask.u8','scratch-distance-a.f32','scratch-distance-b.f32'):
        (ROOT/p).unlink()


if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--distance-worker':
        _,_,mask_file,out_file,start_z,end_z=sys.argv
        mask=np.memmap(mask_file,dtype=np.uint8,mode='r',shape=(N,N,N))
        out=np.memmap(out_file,dtype='<f4',mode='r+',shape=(N,N,N))
        redistance_range(mask,out,int(start_z),int(end_z))
        print(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024**2)
    else:
        main()
