@group(0) @binding(18) var<storage,read> probePoints:array<vec4f,16>;
@group(0) @binding(19) var<storage,read_write> probeResult:array<vec4f,32>;
@compute @workgroup_size(16) fn main(@builtin(global_invocation_id) id:vec3u) {
  if(id.x>=16u){return;}
  let x=probePoints[id.x].xyz;
  let cached=cacheT(x);
  let t128=tauRay(x,p.sun.xyz,128u,1.);
  let t256=tauRay(x,p.sun.xyz,256u,1.);
  let t512=tauRay(x,p.sun.xyz,512u,1.);
  probeResult[id.x*2u]=vec4f(cached.x,exp(-t128),exp(-t256),exp(-t512));
  probeResult[id.x*2u+1u]=vec4f(cached.y,exp(-p.domain.y*t128),exp(-p.domain.y*t256),exp(-p.domain.y*t512));
}
