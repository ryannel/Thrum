import { halfToFloat } from './reference.js';
import { assertGpuHealthy, frameFence } from './frame-lifecycle.js';

export function surfaceProbePoints(asset) {
  const heights=[2500,4500,6500,8500];
  const centers=[[-520,110],[-380,140],[-100,120],[100,50]];
  const result=[];
  const pitch=asset.transform.pitch_m,bmin=asset.transform.bounds[0],side=asset.side;
  const value=(ix,iy,iz)=>halfToFloat(asset.raw[(iz*side+iy)*side+ix]);
  const linear=(x,y,z)=>{
    const p=[x,y,z].map((v,i)=>(v-bmin[i])/pitch[i]-.5);
    if(p.some(v=>v<-.5||v>side-.5))return 0;
    const lo=p.map(v=>Math.max(0,Math.min(side-1,Math.floor(v))));
    const hi=lo.map(v=>Math.min(side-1,v+1));
    const t=p.map((v,i)=>Math.max(0,Math.min(1,v-lo[i])));
    let q=0;
    for(let k=0;k<2;k++)for(let j=0;j<2;j++)for(let i=0;i<2;i++){
      const w=(i?t[0]:1-t[0])*(j?t[1]:1-t[1])*(k?t[2]:1-t[2]);
      q+=w*value(i?hi[0]:lo[0],j?hi[1]:lo[1],k?hi[2]:lo[2]);
    }
    return q;
  };
  for(let band=0;band<4;band++)for(let direction=0;direction<4;direction++){
    const angle=direction*Math.PI/2+.23;
    const [cx,cz]=centers[band],y=heights[band],dx=Math.cos(angle),dz=Math.sin(angle);
    let lastInside=null;
    for(let r=0;r<=5500;r+=25){
      const x=cx+dx*r,z=cz+dz*r,q=linear(x,y,z);
      if(q>=.03)lastInside={x,y,z,q,r};
    }
    if(!lastInside)throw Error(`No q>=.03 surface probe for band ${band} direction ${direction}`);
    let a=lastInside.r,b=Math.min(5500,a+25);
    if(linear(cx+dx*b,y,cz+dz*b)>=.03)throw Error(`Unbracketed outer q=.03 probe for band ${band} direction ${direction}`);
    for(let n=0;n<12;n++){
      const m=(a+b)*.5;
      if(linear(cx+dx*m,y,cz+dz*m)>=.03)a=m;else b=m;
    }
    const r=(a+b)*.5,x=cx+dx*r,z=cz+dz*r;
    result.push({id:`h${heights[band]}-d${direction}`,world_m:[x,y,z],linearQ:linear(x,y,z)});
  }
  return result;
}

export async function runLightProbe(adapter,ui,weather) {
  const s=adapter.scene,g=s.gpu,d=g.device;
  if(adapter.profile==='high'&&s.referenceLightSlice<s.lightDims[2])throw Error('High light cache is not complete');
  await frameFence(g);assertGpuHealthy(g);
  const points=surfaceProbePoints(adapter.asset),raw=new Float32Array(16*4);
  for(let i=0;i<16;i++)raw.set([...points[i].world_m,0],i*4);
  const uniform=d.createBuffer({label:'light probe uniform',size:176,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});
  const positions=d.createBuffer({label:'light probe positions',size:raw.byteLength,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});
  const output=d.createBuffer({label:'light probe result',size:512,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_SRC});
  const read=d.createBuffer({label:'light probe readback',size:512,usage:GPUBufferUsage.MAP_READ|GPUBufferUsage.COPY_DST});
  try{
    s.write(uniform,weather.sample(0),ui,null,0);
    d.queue.writeBuffer(positions,0,raw);
    s.pointReferencePipeline??=await g.compute('16 point full Sun reference',s.codes.optics+s.codes['light-probe']);
    const group=g.group(s.pointReferencePipeline,[
      [0,uniform],[1,s.q[s.current].createView()],[2,s.noise.createView()],[3,s.clamp],
      [4,s.rest[s.currentRest].createView()],[5,s.light.createView()],
      [10,s.q[1-s.current].createView()],[11,s.rest[1-s.currentRest].createView()],
      [14,s.repeat],[16,s.restB[s.currentRest].createView()],
      [17,s.restB[1-s.currentRest].createView()],[18,positions],[19,output],
    ]);
    const encoder=d.createCommandEncoder();
    s.compute(encoder,s.pointReferencePipeline,group,[16,1,1]);
    encoder.copyBufferToBuffer(output,0,read,0,512);
    g.submit(encoder);
    await read.mapAsync(GPUMapMode.READ);assertGpuHealthy(g);
    const values=Array.from(new Float32Array(read.getMappedRange().slice(0)));
    read.unmap();
    const cases=points.map((point,i)=>{
      const ordinary=values.slice(i*8,i*8+4),ms=values.slice(i*8+4,i*8+8);
      return {...point,ordinary:{cached:ordinary[0],direct128:ordinary[1],direct256:ordinary[2],direct512:ordinary[3],absCache512:Math.abs(ordinary[0]-ordinary[3]),abs256512:Math.abs(ordinary[2]-ordinary[3])},
               ms:{cached:ms[0],direct128:ms[1],direct256:ms[2],direct512:ms[3],absCache512:Math.abs(ms[0]-ms[3]),abs256512:Math.abs(ms[2]-ms[3])}};
    });
    return {scope:'16 frozen q≈.03 surface points; actual trilinear cache T versus complete point-to-box Sun midpoint integration at 128/256/512 using common coefficients, source bounds metres. No image-wide, ambient or budget conclusion.',
      sourceSha256:adapter.asset.sha,lightProfile:adapter.profile,lightDims:s.lightDims,sunSamples:adapter.profile==='high'?128:32,
      scatterProfile:ui.scatterProfile,scatterParameters:ui.scatterProfile==='legacy'?[1,.25,0]:ui.scatterProfile==='first'?[0,.5,.5]:[.5,.5,.5],
      cloudAmbientEnabled:ui.scatterProfile!=='first',sunElevationDeg:ui.sun,kappaPerM:[.0045,.0018].map(v=>v*ui.extinctionScale),
      coordinates:'world metres; outer q=.03 crossing bracketed at 25 m radial increments and refined 12 times by trilinear CPU sampling',
      maxAbsOrdinaryCache512:Math.max(...cases.map(v=>v.ordinary.absCache512)),
      maxAbsOrdinary256512:Math.max(...cases.map(v=>v.ordinary.abs256512)),
      maxAbsMsCache512:Math.max(...cases.map(v=>v.ms.absCache512)),cases};
  }finally{
    try{read.unmap();}catch{}
    uniform.destroy();positions.destroy();output.destroy();read.destroy();
  }
}
