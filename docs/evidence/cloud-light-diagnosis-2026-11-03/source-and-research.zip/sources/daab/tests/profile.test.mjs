import assert from 'node:assert/strict';
import test from 'node:test';
import { Scene } from '../src/scene.js';

test('selected, legacy and first-solar profiles pack exact optical uniforms',()=>{
  let staged;
  const gpu={device:{features:{has:()=>false},queue:{writeBuffer:(_buffer,_offset,values)=>{staged=Float32Array.from(values);}}}};
  const scene=new Scene(gpu,{},0,1);
  scene.bounds=()=>[[-6000,0,-6000],[6000,14000,6000]];
  scene.target=()=>[0,6500,0];
  scene.cameraPosition=()=>[0,6000,25000];
  const snapshot={wind:0,windIntegral:0,moist:0,dry:0,lift:0,frontX:1e6,storm:0};
  const base={sun:30,mode:0,mirror:true,extinctionScale:1,materialSpace:'world',materialFilter:false,materialStructure:false,preparedDensity:true,viewSteps:384,main:true,resolved:true,fog:false,provider:0,alpha:1,dualRest:false};
  for(const [name,values,ambientOff] of [['selected',[.5,.5,.5],false],['legacy',[1,.25,0],false],['first',[0,.5,.5],true]]){
    scene.write({},snapshot,{...base,scatterProfile:name},null,0);
    assert.deepEqual([staged[11],staged[37],staged[38]],values,name);
    assert.equal((staged[27]&64)!==0,ambientOff,name);
    assert.ok(Math.abs(staged[15]-.0045)<1e-9,name);
    assert.ok(Math.abs(staged[19]-.0018)<1e-9,name);
    assert.equal(staged[27]&32,32,name);
  }
  scene.write({},snapshot,base,null,0);
  assert.deepEqual([staged[11],staged[37],staged[38]],[.5,.5,.5],'default is selected');
});
