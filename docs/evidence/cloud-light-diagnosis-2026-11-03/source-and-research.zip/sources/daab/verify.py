#!/usr/bin/env python3
"""Static source/loader/cost closure; GPU compilation remains a browser gate."""
from pathlib import Path
import hashlib,json,os,re,subprocess

root=Path(__file__).resolve().parent
frozen=root.parent/'cloud-cb-covered-proof'
source=root.parent/'cloud-cb-covered-anatomy/cb-covered-256.density.r16f'
linked=root/'assets/cb-covered-256.density.r16f'
meta=json.loads((root/'assets/cb-covered-256.json').read_text())
index=json.loads((root/'assets/asset-index.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert os.stat(source).st_ino==os.stat(linked).st_ino
assert sha(linked)==meta['output']['sha256']==index['qualities']['256']['sha256']
assert linked.stat().st_size==256**3*2
assert sha(root/'assets/cb-covered-256.json')==index['qualities']['256']['metadata_sha256']
assert (root/'shaders/light.wgsl').read_bytes()==(frozen/'shaders/light.wgsl').read_bytes()
for f in (frozen/'shaders').glob('*.wgsl'):
    if f.name!='view.wgsl':assert f.read_bytes()==(root/'shaders'/f.name).read_bytes()
adapter=(root/'src/master-adapter.js').read_text()
names=re.findall(r"'([^']+)'",re.search(r'const SHADERS=\[([^\]]+)\]',adapter).group(1))
for name in names:assert (root/'shaders'/f'{name}.wgsl').is_file(),name
assert (root/'shaders/light-reference.wgsl').is_file()
assert "codes['normal-stencil']+codes.mix" in adapter
assert "fn applyFrontMotion" in (root/'shaders/normal-stencil.wgsl').read_text()
assert "applyFrontMotion(" in (root/'shaders/mix.wgsl').read_text()
low=(root/'shaders/light.wgsl').read_text();high=(root/'shaders/light-reference.wgsl').read_text()
assert high[high.index('  let uv='):].replace('128u','32u')==low[low.index('  let uv='):]
view=(root/'shaders/view.wgsl').read_text()
assert 'fn sourceNormalRay(' in view and 'if(mode==7u)' in view
assert 'let pitch=(p.bmax.xyz-p.bmin.xyz)/vec3f(textureDimensions(densityTex));' in view
assert 'source=sigma*.995*(firstSolar+extraSolar+ambient);' in view
assert 'source=sigma*.995*firstSolar;' in view
assert 'source=sigma*.995*extraSolar;' in view
assert 'source=sigma*.995*ambient;' in view
assert '(u32(p.control.w)&64u)!=0u' in view
scene=(root/'src/scene.js').read_text()
assert 'legacy:[1,.25,0],selected:[.5,.5,.5],first:[0,.5,.5]' in scene
assert "const lightKey=`${this.sourceHash}/${ui.sun}/${ui.extinctionScale}/${ui.scatterProfile??'selected'}`;" in scene
assert '@binding(18) var<storage,read> probePoints' in (root/'shaders/light-probe.wgsl').read_text()
assert '512u' in (root/'shaders/light-probe.wgsl').read_text()
lowbytes=32*24*24*8;highbytes=128*160*128*8
assert highbytes-lowbytes==20_824_064
baseline=44_908_556
assert baseline+highbytes-lowbytes<256*1024*1024
for name in ('master-adapter.js','master-lab.js','scene.js','light-probe.js'):
    subprocess.run(['node','--check',str(root/'src'/name)],check=True,capture_output=True)
subprocess.run(['node','--test',str(root/'tests/profile.test.mjs')],check=True,capture_output=True)
print(json.dumps({'source_sha256':meta['output']['sha256'],'shader_file_count':len(names)+1,
                  'low_light_bytes':lowbytes,'high_light_bytes':highbytes,
                  'expected_high_logical_bytes':baseline+highbytes-lowbytes,
                  'light_query_multiplier':(128*160*128*(128+4*20))/(32*24*24*(32+4*20)),
                  'scope':'Static file/helper/hash/count closure only; actual GPU compilation, image and point probe require browser.'},indent=2))
