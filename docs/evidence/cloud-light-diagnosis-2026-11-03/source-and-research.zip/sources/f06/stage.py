#!/usr/bin/env python3
"""Pin the selected static source into this unchanged-lighting viewer."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'cloud-cb-covered-anatomy'
ASSETS=ROOT/'assets'
META_NAME='cb-covered-256.json'
SCALAR_NAME='cb-covered-256.density.r16f'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

meta=json.loads((SOURCE/META_NAME).read_text())
assert meta['output']['dimensions_xyz']==[256]*3
assert meta['output']['bytes']==256**3*2
assert meta['output']['sha256']==sha(SOURCE/SCALAR_NAME)
assert meta['preparation']['recipe_sha256']==sha(SOURCE/'cook.py')
assert meta['metrics']['zero_collar_min_zyx'][0]>0 and all(v>0 for v in meta['metrics']['zero_collar_min_zyx'])
assert meta['metrics']['full_surface_footprint']['covered']==meta['metrics']['full_surface_footprint']['samples']
assert meta['preparation']['peak_rss_mib']<768
assert meta['preparation']['peak_concurrent_parent_plus_worker_mib']<768
for name in (META_NAME,SCALAR_NAME):
    link=ASSETS/name
    if link.exists() or link.is_symlink():link.unlink()
    link.symlink_to(Path('../../cloud-cb-covered-anatomy')/name)
pin=dict(file=SCALAR_NAME,sha256=meta['output']['sha256'],bytes=meta['output']['bytes'],
         metadata_file=META_NAME,metadata_sha256=sha(SOURCE/META_NAME))
index=dict(id='cb-covered',sourceMode='One frozen static 256-cubed authored source; no lifecycle/art acceptance',
           qualities={'256':pin})
(ASSETS/'asset-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps(index,indent=2))
