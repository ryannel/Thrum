# Frozen covered Cb source viewer

Run `python3 serve.py --port 8151`, then open `http://127.0.0.1:8151/` in a WebGPU browser. The browser is owned by the root agent. This viewer is event driven: one pinned R16F scalar, 1³ unused PDE/rest textures, no source simulation, static time zero. It is a 256³ authoring experiment, not Cb art/lifecycle/device acceptance.

Renderer, lighting, shadow and reflection files are byte-for-byte copies of `../cloud-cb-anatomy/negative-f30d/instrument/`; the UI and initial quality changed. `assets/renderer-baseline.json` describes the two prepared-density patches relative to the shared `6045d1ce1c9ccebe` baseline. `assets/asset-index.json` pins the exact scalar and metadata hashes after the authoring cook. Capture receipts include build identity, source hash, settings and GPU queue fence.
