#!/usr/bin/env python3
"""Verify this staged package and optionally restore one frozen browser viewer.

This tool reads the large scalar from an explicit existing path and symlinks it.
It never cooks a source, runs a browser, or starts a GPU workload.
"""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
MANIFEST = json.loads((PACKAGE / "manifest.json").read_text())
SCALAR_NAME = "cb-covered-256.density.r16f"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verified_scalar(path):
    expected = next(item for item in MANIFEST["external_references"]
                    if item["label"] == "covered_scalar")
    assert path.is_file(), f"Missing scalar: {path}"
    assert path.stat().st_size == expected["bytes"], "Scalar size differs"
    assert sha(path) == expected["sha256"], "Scalar hash differs"


def verify_package(scalar):
    for item in MANIFEST["files"]:
        path = PACKAGE / item["path"]
        assert path.is_file(), f"Missing package file: {path}"
        assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"], \
            f"Package file differs: {path}"
    verified_scalar(scalar)
    for name, identity in MANIFEST["identities"].items():
        folder = PACKAGE / "sources" / name
        for rel, expected in identity["files"].items():
            path = scalar if rel == f"assets/{SCALAR_NAME}" else folder / rel
            assert sha(path) == expected, f"Served-file mismatch {name}/{rel}"
        files = identity["files"]
        build = hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()[:16]
        assert build == identity["build"], f"Build identity mismatch: {name}"
    return True


def restore(name, target, scalar):
    assert not target.exists() or not any(target.iterdir()), \
        f"Destination must be absent or empty: {target}"
    source = PACKAGE / "sources" / name
    target.mkdir(parents=True, exist_ok=True)
    for path in source.rglob("*"):
        if path.is_file() and path.name not in ("identity.json", "served-identity.json"):
            dest = target / path.relative_to(source)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
    (target / "assets" / SCALAR_NAME).symlink_to(scalar.resolve())
    print(f"Restored {name} ({MANIFEST['identities'][name]['build']}) to {target}")
    print("Start with: python3 serve.py --port PORT")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scalar", type=Path, required=True,
                        help="Existing exact 256³ R16F scalar; checked by SHA-256")
    parser.add_argument("--variant", choices=("daab", "0c3", "f06"))
    parser.add_argument("--target", type=Path)
    args = parser.parse_args()
    if bool(args.variant) != bool(args.target):
        parser.error("Provide --variant and --target together, or neither to verify only")
    verify_package(args.scalar)
    print("Package files, source scalar and all three served identities verified")
    if args.variant:
        restore(args.variant, args.target, args.scalar)


if __name__ == "__main__":
    main()
