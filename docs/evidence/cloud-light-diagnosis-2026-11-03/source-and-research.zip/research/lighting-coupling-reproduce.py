#!/usr/bin/env python3
"""Reproduce the bounded CPU lighting diagnosis. No GPU/browser or source mutation.
Python3.14.10, NumPy2.4.6, SciPy1.17.1 were used for the original result.
"""
from pathlib import Path
import argparse, hashlib, json, math, platform
import numpy as np
import scipy
from scipy.ndimage import map_coordinates
ROOT=Path(__file__).resolve().parents[2]
EXPECTED_SHA='377e8f9def4ff30ac38c02266b8666ae5c592d59f9a36820c62731fb52d89eef'
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--density',type=Path,default=ROOT/'tmp/cloud-cb-covered-proof/assets/cb-covered-256.density.r16f')
p.add_argument('--output',type=Path)
a=p.parse_args()
raw=a.density.read_bytes()
assert len(raw)==33554432 and hashlib.sha256(raw).hexdigest()==EXPECTED_SHA,'Wrong scalar input'
q=np.frombuffer(raw,dtype='<f2').reshape(256,256,256).astype(np.float32)
lo=np.array([-6000.,0.,-6000.]);ext=np.array([12000.,14000.,12000.]);hi=lo+ext
sun=np.array([math.cos(math.pi/6)*math.cos(-.7),.5,math.cos(math.pi/6)*math.sin(-.7)])
kappa=.0045

def density(points):
    c=(points-lo)/ext*256-.5
    return map_coordinates(q,c[...,::-1].reshape(-1,3).T,order=1,mode='constant',cval=0,prefilter=False).reshape(points.shape[:-1])

def tau(points,count):
    out=[]
    for first in range(0,len(points),512):
        x=points[first:first+512]
        aa=(lo-x)/sun;bb=(hi-x)/sun
        start=np.maximum(0,np.min(np.stack([aa,bb]),axis=0).max(axis=1))
        end=np.maximum(start,np.max(np.stack([aa,bb]),axis=0).min(axis=1))
        ds=(end-start)/count
        t=start[:,None]+(np.arange(count)[None,:]+.5)*ds[:,None]
        # Preserve original float32 SciPy samples/NumPy summation, then float64 ds.
        out.append(density(x[:,None,:]+t[:,:,None]*sun).sum(axis=1)*ds*kappa)
    return np.concatenate(out) if out else np.empty(0)

z,y,x=np.indices((24,24,32))
gridpoints=lo+(np.stack([x,y,z],axis=-1).reshape(-1,3)+.5)/np.array([32,24,24])*ext
cache=np.exp(-tau(gridpoints,32)).astype(np.float16).astype(np.float32).reshape(24,24,32)
zz,yy,xx=np.where((q>=.015)&(q<=.12))
ids=np.random.default_rng(731).choice(len(xx),2048,replace=False)
points=lo+(np.stack([xx[ids],yy[ids],zz[ids]],axis=1)+.5)/256*ext
tail=points+200*sun
uv=(tail-lo)/ext*np.array([32,24,24])-.5
cached=map_coordinates(cache,uv[:,::-1].T,order=1,mode='nearest',prefilter=False)
outside=np.any((tail<lo)|(tail>hi),axis=1)
cached[outside]=np.exp(-tau(tail[outside],32))
t32=np.exp(-tau(tail,32));t256=np.exp(-tau(tail,256));t512=np.exp(-tau(tail,512))
local=np.exp(-kappa*100*(density(points+50*sun)+density(points+150*sun)))
full=np.exp(-tau(points,512))
current=local*cached
metrics={}
for name,error in [('tail32_vs512',abs(t32-t512)),('cache32_vs512',abs(cached-t512)),('current_local_plus_cache_vs_full512',abs(current-full)),('reference256_vs512',abs(t256-t512))]:
    metrics[name]={'mean':float(np.mean(error)),'p95':float(np.quantile(error,.95)),'max':float(np.max(error))}
view=np.array([-math.sin(.3)*math.cos(-.05),-math.sin(-.05),-math.cos(.3)*math.cos(-.05)])
mu=float(np.dot(view,sun))
def phase(factor):
    def hg(g):return (1-g*g)/(4*math.pi*(1+g*g-2*g*mu)**1.5)
    return .8*hg(.8*factor)+.2*hg(-.2*factor)
phase_data={'mu_at_focus':mu,'liquid_first_phase_sr_inverse':phase(1),'legacy_extra_phase_times_amplitude':phase(0),'legacy_extra_over_first_at_tau0':phase(0)/phase(1),'selected_extra_phase_times_amplitude':.5*phase(.5),'selected_extra_over_first_at_tau0':.5*phase(.5)/phase(1)}
projection=[]
e1=np.array([-math.sin(-.7),0,math.cos(-.7)]);e2=np.cross(sun,e1)
for name,extent in [('full_box',ext),('tight_native_support',np.array([206*46.875,190*54.6875,116*46.875]))]:
    spans=np.array([np.abs(e1)@extent,np.abs(e2)@extent,np.abs(sun)@extent])
    for transverse,longitudinal in [(128,128),(64,128)]:
        n=(np.ceil(spans/np.array([transverse,transverse,longitudinal])/8)*8).astype(int);cells=int(np.prod(n))
        projection.append({'domain':name,'projected_spans_m':spans.tolist(),'transverse_pitch_m':transverse,'longitudinal_pitch_m':longitudinal,'rounded_dimensions':n.tolist(),'cells':cells,'R32_bytes':cells*4,'RGBA16_bytes':cells*8,'scope':'Illustrative dense directional allocation, BEFORE guards/padding/other media/staging/old-new overlap; no timing or quality admission'})
result={'scope':'Sampled CPU dense-equivalent scalar/light comparison, not GPU precision, view-radiance/art, full-sky, or timing admission.512steps is a converged sample reference, not exact transport. No new cache implementation.',
 'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
 'source':{'file':str(a.density),'sha256':EXPECTED_SHA,'bytes':len(raw),'dimensions_xyz':[256]*3,'storage':'little-endian R16F, numpy[Z,Y,X]','bounds':[lo.tolist(),hi.tolist()],'pitch_m':(ext/256).tolist(),'kappa_per_m':kappa,'frozen_build':'f06bd77e72c5d79d'},
 'sampling':{'native_q_range_inclusive':[.015,.12],'eligible_native_points':len(xx),'count':2048,'rng':'numpy.default_rng(731), choice without replacement from np.where C-order mask','seed':731,'native_flat_indices_xyz_xfast':((zz[ids]*256+yy[ids])*256+xx[ids]).tolist(),'positions':'Native texel centres; no pixel/view weighting','sun_elevation_deg':30,'sun_azimuth_rad':-.7,'sun_unit_vector':sun.tolist(),'cache_dimensions_xyz':[32,24,24],'cache_pitch_m':[375,14000/24,500],'cache_storage_emulation':'exp(-tau32) rounded to binary16 then CPU trilinear clamp-to-edge; outside cache uses directtau32','near_segment':'two100m midpoint cells at50/150m; cache at200m endpoint','source_sampling':'SciPy order1/prefilterFalse float32 trilinear outputs; outside native array zero (source collar is zero). CPU summation is not WGSL rounding emulation.'},
 'absolute_T_errors':metrics,'phase_profiles':phase_data,'directional_grid_screens':projection,
 'raw_transmittance_samples':{'tail32':t32.tolist(),'tail256':t256.tolist(),'tail512':t512.tolist(),'cache32':cached.tolist(),'local200':local.tolist(),'current_local_plus_cache':current.tolist(),'full512':full.tolist()}}
text=json.dumps(result,indent=2)+'\n'
if a.output:a.output.write_text(text)
else:print(text,end='')
if a.output:print(json.dumps({'source_sha256':EXPECTED_SHA,'metrics':metrics,'phase':phase_data,'output':str(a.output) if a.output else 'stdout'},indent=2))
