# Staged covered-Cb source and light comparison

Internal, unaccepted scratch package, 3 November 2026. This is a compact restoration and review checkpoint. The root agent owns subsequent 8152 browser captures and any selection or promotion. The package contains no 32 MiB density duplicate, no GPU cache output, and no full-lifecycle movie.

## Frozen identities

| Viewer | Build | Role |
| --- | --- | --- |
| `sources/f06/` | `f06bd77e72c5d79d` | Original 256³ covered source, legacy scattering uniforms, low light cache; actual 384-ray f06 capture retained here. |
| `sources/0c3/` | `0c3e028a5bf5622c` | First low/high comparison instrument, frozen before browser review because it inherited the legacy uniforms. Its `negative.json` and `to-selected.patch` are retained. |
| `sources/daab/` | `daab547852af225b` | Current light comparison instrument: selected `.5/.5/.5` profile by default, explicit legacy and first-solar profiles, first/extra/ambient source-term views, low/high caches, native-source-normal view, and 16-point direct Sun probe. No 8152 beauty result is included yet. |

Each `served-identity.json` records the SHA-256 of every byte served by that variant. The `manifest.json` records SHA-256 and size of every staged file and the external scalar. The three build IDs were recomputed from those served-file hashes using the viewer's `serve.py` identity rule, and match the original frozen IDs. `sources/0c3/assets/` reuses the identical small asset metadata and index from daab, with hashes matched to the retained 0c3 served identity. `sources/f06/` retains the failed 84f record and the corrected loader closure.

## Scalar and cook

`cook/` contains the complete independent deterministic NumPy/SciPy source recipe, seed, anatomical controls, per-lobe output, coverage, native panels, metadata, final log and five compact failed-cook logs. The actual scalar remains at `../cloud-cb-covered-anatomy/cb-covered-256.density.r16f`: 33,554,432 bytes, SHA-256 `377e8f9def4ff30ac38c02266b8666ae5c592d59f9a36820c62731fb52d89eef`, little-endian R16F `[Z,Y,X]` with X fastest. It spans `[-6000,0,-6000]..[6000,14000,6000]` metres. The recipe has no external VDB/master input and is pinned to Python 3.14.10, NumPy 2.5.4, SciPy 1.18.1 in metadata. The exact scalar was hash-verified in all three source identities and in the packaged cook metadata. A second full cook was **not** run for this staging task, so bit-exact regeneration from a fresh machine remains unverified. The raw file is currently an ignored local input, not a durable remote backup. Before durable promotion, preserve that exact raw file through the repository asset storage contract or re-cook in a pinned environment and verify its hash.

The final cook recorded peak parent RSS 510.22 MiB, worker RSS 487.09 MiB, and maximum simultaneous parent-plus-worker RSS 763.75 MiB against the 768 MiB limit; elapsed 101.36 s. `cook/README.md` explains the 8-slice/20-halo distance method and earlier memory/collar failures. All 8,133 sampled original scaffold patches were covered by a lobe footprint, deep-core ROI q≥.10 fraction was 1, six-neighbour body/cap threshold connection passed, and the minimum zero collar was `[66,11,11]` voxels `[Z,Y,X]`. These are producer checks, not visual acceptance. The f06 native capture still reads as a smooth white bulb and thin cap.

## Lighting question and limits

The CPU `research/lighting-coupling-reproduce.py` and retained result study 2,048 sampled source points. On that sample, current cached tail versus 512-step direct tail has mean absolute T error 0.01970 and p95 0.05826; direct 32-step tail versus 512 has mean 0.00243 and p95 0.00819. This implicates coarse spatial light-cache interpolation in the *sampled* point error. It does not assign the f06 beauty failure solely to lighting. The f06 viewer also used legacy extra-octave `(a,b,c)=(1,.25,0)`, while the selected baseline specifies `(.5,.5,.5)`. The daab viewer exposes both profiles and separates cloud first-solar, extra-MS and true ambient terms without changing the scalar, κ, Beer, phase functions or clear-air/ground code.

The retained 2023 Nubis Cubed deck is referenced by SHA in `manifest.json` and interpreted narrowly in `research/lighting-coupling-review.md`: its slides 126–127 describe two local Sun samples plus a cached long-ray remainder; slides 147 and 154 cover ambient/cache decoupling. This does not imply that the exact Thrum profiles, grid, timings or an authored Cb geometry were shipped by Guerrilla. The suggested Sun-aligned scan in the review is a conditional Thrum design study, not part of these frozen viewers.

## Restore and verify

From this directory, with the existing exact scalar:

```sh
python3 restore.py --scalar ../cloud-cb-covered-anatomy/cb-covered-256.density.r16f
python3 restore.py --scalar ../cloud-cb-covered-anatomy/cb-covered-256.density.r16f --variant daab --target /tmp/cloud-daab-restored
```

The first command verifies every staged file, the scalar and all three served identities. The second copies only small code/metadata and symlinks the scalar into an empty target. It does not launch a browser/GPU. Start the restored viewer from its directory with `python3 serve.py --port PORT`; use an unused port. The 0c3 and f06 variants restore the same way. The `source-cook` recipe can recreate a missing scalar in the recorded environment, but the hash must match before `restore.py` accepts it. `sources/daab/verify.py` and `sources/daab/tests/profile.test.mjs` preserve the original non-GPU source/helper/profile checks.

`captures/f06/` retains the actual original f06 96/384-ray PNGs and receipts. The planned daab selected-profile low/high, component-term, normal and 16-point probe captures remain with the root agent; this package does not imply those outcomes or source-art acceptance.

`research/optical-calibration.md` records the bounded κ=.0045/.019/.038 image and optical-depth diagnosis; `research/next-cb-anatomy-decision.md` is a pre-cook structural challenger for root review. Neither changes the scalar, viewers, or source selection.
