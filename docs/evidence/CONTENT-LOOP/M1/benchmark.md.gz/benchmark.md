# G5 in-game edit-to-visible and upload cost
release bench, macos aarch64, budget 8 MiB/frame, 640x360, each frame waited for

## realistic: 256-grid mesh, 1024² texture, 256³ volume, all profiles

source generation 139 ms, first cook 67 ms
selected cooked path: Indirect (adapter-backed record)
startup (attach → first set drawn): 92.1 ms; profiles drawn: texture Some(AppleAstc), volume Some(DesktopBc)

| generation | uploaded | frames | write+cook → HEAD seen | → staged | → first copy | → swapped | write → swapped |
|---|---|---|---|---|---|---|---|
| 1 | 13.75 MiB | 3 | 0.0 ms | 1.3 ms | 5.2 ms | 59.6 ms | startup |
| 2 | 1.34 MiB | 2 | 42.1 ms | 0.1 ms | 0.6 ms | 17.9 ms | 60.8 ms |
| 3 | 9.33 MiB | 2 | 172.4 ms | 0.1 ms | 4.6 ms | 3.9 ms | 181.0 ms |
| 4 | 1.34 MiB | 1 | 40.6 ms | 0.1 ms | 4.6 ms | 0.0 ms | 45.3 ms |
| 5 | 9.33 MiB | 2 | 184.7 ms | 0.1 ms | 4.5 ms | 4.3 ms | 193.6 ms |
| 6 | 1.34 MiB | 1 | 40.8 ms | 0.1 ms | 1.0 ms | 0.0 ms | 41.9 ms |
| 7 | 9.33 MiB | 2 | 170.1 ms | 0.1 ms | 4.3 ms | 4.0 ms | 178.4 ms |

largest copy bytes recorded in one frame: 8.00 MiB
staging peak: 16.00 MiB (bounded ring of 4 chunks)

| frames | n | latency p50 | p99 | max | render CPU p50 | p99 | max |
|---|---|---|---|---|---|---|---|
| steady | 210 | 3.36 | 24.03 | 24.33 | 0.792 | 1.181 | 2.333 |
| uploading | 17 | 4.37 | 47.79 | 47.79 | 1.169 | 5.546 | 5.546 |
upload-frame after 0 swaps, 0 bytes: latency 47.79 ms, render CPU 5.546 ms
upload-frame after 0 swaps, 7780960 bytes: latency 15.43 ms, render CPU 1.938 ms
upload-frame after 1 swaps, 6641408 bytes: latency 22.08 ms, render CPU 2.110 ms
upload-frame after 1 swaps, 0 bytes: latency 17.66 ms, render CPU 1.023 ms
upload-frame after 2 swaps, 1401088 bytes: latency 10.49 ms, render CPU 1.339 ms
upload-frame after 2 swaps, 0 bytes: latency 4.26 ms, render CPU 1.169 ms
upload-frame after 2 swaps, 8388608 bytes: latency 3.97 ms, render CPU 1.310 ms
upload-frame after 3 swaps, 1398528 bytes: latency 3.64 ms, render CPU 1.283 ms
upload-frame after 3 swaps, 0 bytes: latency 4.15 ms, render CPU 0.979 ms
upload-frame after 4 swaps, 1401088 bytes: latency 4.09 ms, render CPU 0.934 ms
upload-frame after 4 swaps, 0 bytes: latency 4.46 ms, render CPU 1.108 ms
upload-frame after 4 swaps, 8388608 bytes: latency 4.38 ms, render CPU 1.248 ms
upload-frame after 5 swaps, 1398528 bytes: latency 4.35 ms, render CPU 1.211 ms
upload-frame after 6 swaps, 1401088 bytes: latency 4.46 ms, render CPU 1.125 ms
upload-frame after 6 swaps, 0 bytes: latency 4.37 ms, render CPU 0.995 ms
upload-frame after 6 swaps, 8388608 bytes: latency 4.06 ms, render CPU 1.109 ms
upload-frame after 7 swaps, 1398528 bytes: latency 3.52 ms, render CPU 1.076 ms

single-submit contrast (render thread `write_texture` of the 16.0 MiB portable volume level 0, then that frame): write CPU p50 1.88 ms, frame latency p50 4.21 ms, max 4.68 ms

## large: 512³ R8 volume (portable only)

source generation 1124 ms, first cook 322 ms
selected cooked path: Indirect (adapter-backed record)
startup (attach → first set drawn): 242.8 ms; profiles drawn: texture Some(Portable), volume Some(Portable)

| generation | uploaded | frames | write+cook → HEAD seen | → staged | → first copy | → swapped | write → swapped |
|---|---|---|---|---|---|---|---|
| 1 | 157.76 MiB | 21 | 0.0 ms | 1.0 ms | 4.1 ms | 228.8 ms | startup |
| 2 | 149.33 MiB | 20 | 1469.1 ms | 0.2 ms | 1.4 ms | 243.0 ms | 1713.7 ms |
| 3 | 149.33 MiB | 19 | 1320.5 ms | 0.2 ms | 16.3 ms | 186.2 ms | 1523.1 ms |

largest copy bytes recorded in one frame: 8.00 MiB
staging peak: 32.00 MiB (bounded ring of 4 chunks)

| frames | n | latency p50 | p99 | max | render CPU p50 | p99 | max |
|---|---|---|---|---|---|---|---|
| steady | 90 | 4.84 | 23.91 | 24.50 | 0.830 | 1.092 | 1.144 |
| uploading | 61 | 4.86 | 63.26 | 91.14 | 0.941 | 2.413 | 4.327 |
upload-frame after 0 swaps, 0 bytes: latency 91.14 ms, render CPU 4.327 ms
upload-frame after 0 swaps, 7428448 bytes: latency 15.75 ms, render CPU 1.672 ms
upload-frame after 0 swaps, 7700224 bytes: latency 45.99 ms, render CPU 1.626 ms
upload-frame after 0 swaps, 8388608 bytes: latency 15.93 ms, render CPU 0.945 ms
upload-frame after 0 swaps, 8388608 bytes: latency 10.00 ms, render CPU 0.700 ms
upload-frame after 0 swaps, 8388608 bytes: latency 15.15 ms, render CPU 0.791 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.81 ms, render CPU 0.758 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.76 ms, render CPU 0.770 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.64 ms, render CPU 0.665 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.81 ms, render CPU 0.757 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.62 ms, render CPU 0.667 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.67 ms, render CPU 0.655 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.58 ms, render CPU 0.638 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.66 ms, render CPU 0.649 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.86 ms, render CPU 0.652 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.63 ms, render CPU 0.640 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.60 ms, render CPU 0.627 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.58 ms, render CPU 0.619 ms
upload-frame after 0 swaps, 8388608 bytes: latency 3.05 ms, render CPU 0.939 ms
upload-frame after 0 swaps, 8388608 bytes: latency 2.68 ms, render CPU 0.641 ms
upload-frame after 1 swaps, 7689472 bytes: latency 5.84 ms, render CPU 2.413 ms
upload-frame after 1 swaps, 0 bytes: latency 15.48 ms, render CPU 1.299 ms
upload-frame after 1 swaps, 8388608 bytes: latency 59.34 ms, render CPU 1.781 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.86 ms, render CPU 1.117 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.78 ms, render CPU 1.011 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.76 ms, render CPU 0.901 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.95 ms, render CPU 0.944 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.79 ms, render CPU 1.152 ms
upload-frame after 1 swaps, 8388608 bytes: latency 15.35 ms, render CPU 1.422 ms
upload-frame after 1 swaps, 8388608 bytes: latency 12.46 ms, render CPU 1.261 ms
upload-frame after 1 swaps, 8388608 bytes: latency 20.08 ms, render CPU 1.002 ms
upload-frame after 1 swaps, 8388608 bytes: latency 18.64 ms, render CPU 0.888 ms
upload-frame after 1 swaps, 8388608 bytes: latency 20.88 ms, render CPU 0.853 ms
upload-frame after 1 swaps, 8388608 bytes: latency 25.46 ms, render CPU 0.910 ms
upload-frame after 1 swaps, 8388608 bytes: latency 9.18 ms, render CPU 0.925 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.41 ms, render CPU 1.188 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.21 ms, render CPU 1.218 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.08 ms, render CPU 0.976 ms
upload-frame after 1 swaps, 8388608 bytes: latency 5.30 ms, render CPU 1.190 ms
upload-frame after 1 swaps, 8388608 bytes: latency 4.06 ms, render CPU 0.872 ms
upload-frame after 2 swaps, 5592320 bytes: latency 4.42 ms, render CPU 2.130 ms
upload-frame after 2 swaps, 0 bytes: latency 15.05 ms, render CPU 1.413 ms
upload-frame after 2 swaps, 8388608 bytes: latency 63.26 ms, render CPU 1.785 ms
upload-frame after 2 swaps, 8388608 bytes: latency 5.87 ms, render CPU 1.841 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.37 ms, render CPU 1.211 ms
upload-frame after 2 swaps, 8388608 bytes: latency 5.07 ms, render CPU 1.196 ms
upload-frame after 2 swaps, 8388608 bytes: latency 18.57 ms, render CPU 1.358 ms
upload-frame after 2 swaps, 8388608 bytes: latency 16.17 ms, render CPU 1.155 ms
upload-frame after 2 swaps, 8388608 bytes: latency 17.47 ms, render CPU 0.915 ms
upload-frame after 2 swaps, 8388608 bytes: latency 11.30 ms, render CPU 0.916 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.13 ms, render CPU 0.986 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.96 ms, render CPU 0.882 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.18 ms, render CPU 1.043 ms
upload-frame after 2 swaps, 8388608 bytes: latency 3.90 ms, render CPU 0.890 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.75 ms, render CPU 0.899 ms
upload-frame after 2 swaps, 8388608 bytes: latency 3.88 ms, render CPU 0.853 ms
upload-frame after 2 swaps, 8388608 bytes: latency 4.62 ms, render CPU 0.865 ms
upload-frame after 2 swaps, 8388608 bytes: latency 3.90 ms, render CPU 0.818 ms
upload-frame after 2 swaps, 8388608 bytes: latency 5.35 ms, render CPU 1.147 ms
upload-frame after 2 swaps, 8388608 bytes: latency 5.03 ms, render CPU 0.941 ms
upload-frame after 3 swaps, 5592320 bytes: latency 5.63 ms, render CPU 2.180 ms

single-submit contrast (render thread `write_texture` of the 128.0 MiB portable volume level 0, then that frame): write CPU p50 22.96 ms, frame latency p50 19.32 ms, max 27.33 ms

## leased: twelve 128³ volumes beside placements; one-volume edits

source generation 202 ms, first cook 74 ms
selected cooked path: Indirect (adapter-backed record)
startup (attach → first set drawn): 80.5 ms; profiles drawn: texture Some(DesktopBc), volume Some(DesktopBc)

| generation | uploaded | frames | write+cook → HEAD seen | → staged | → first copy | → swapped | write → swapped |
|---|---|---|---|---|---|---|---|
| 1 | 20.43 MiB | 3 | 0.0 ms | 1.4 ms | 5.4 ms | 61.8 ms | startup |
| 2 | 1.33 MiB | 1 | 23.8 ms | 0.1 ms | 17.8 ms | 10.0 ms | 51.7 ms |
| 3 | 1.33 MiB | 1 | 23.8 ms | 0.1 ms | 7.2 ms | 7.0 ms | 38.1 ms |
| 4 | 1.33 MiB | 1 | 22.9 ms | 0.2 ms | 1.1 ms | 17.3 ms | 41.5 ms |

largest copy bytes recorded in one frame: 8.00 MiB
staging peak: 24.00 MiB (bounded ring of 4 chunks)

| frames | n | latency p50 | p99 | max | render CPU p50 | p99 | max |
|---|---|---|---|---|---|---|---|
| steady | 120 | 5.44 | 23.98 | 24.09 | 1.015 | 1.470 | 1.673 |
| uploading | 12 | 15.48 | 30.71 | 30.71 | 1.393 | 4.203 | 4.203 |
upload-frame after 0 swaps, 7432288 bytes: latency 30.71 ms, render CPU 4.203 ms
upload-frame after 0 swaps, 8385280 bytes: latency 17.96 ms, render CPU 1.597 ms
upload-frame after 0 swaps, 5600000 bytes: latency 15.48 ms, render CPU 1.141 ms
upload-frame after 1 swaps, 0 bytes: latency 9.43 ms, render CPU 2.140 ms
upload-frame after 1 swaps, 0 bytes: latency 17.83 ms, render CPU 1.512 ms
upload-frame after 1 swaps, 1398528 bytes: latency 10.01 ms, render CPU 1.209 ms
upload-frame after 2 swaps, 0 bytes: latency 15.13 ms, render CPU 1.210 ms
upload-frame after 2 swaps, 0 bytes: latency 6.86 ms, render CPU 1.128 ms
upload-frame after 2 swaps, 1398528 bytes: latency 7.24 ms, render CPU 1.393 ms
upload-frame after 3 swaps, 0 bytes: latency 5.71 ms, render CPU 1.195 ms
upload-frame after 3 swaps, 1398528 bytes: latency 17.00 ms, render CPU 1.250 ms
upload-frame after 4 swaps, 0 bytes: latency 23.93 ms, render CPU 1.578 ms

single-submit contrast (render thread `write_texture` of the 2.0 MiB portable volume level 0, then that frame): write CPU p50 0.33 ms, frame latency p50 5.26 ms, max 6.67 ms
tripwires (/Users/ryannel/Workspace/thrum/.claude/worktrees/content-loop/examples/v1-game/../../docs/evidence/integration/tripwires/g5-cooked-edit.tsv, load 3.6 on 14 CPUs, quiet):
  ok realistic_startup_ms: 92.056 against a limit of 750.000 (4 quiet runs)
  ok realistic_write_swapped_median_ms: 178.427 against a limit of 342.239 (4 quiet runs)
  ok realistic_upload_cpu_p99_ms: 5.546 against a limit of 14.657 (4 quiet runs)
  ok realistic_staging_peak_mib: 16.000 against a limit of 16.000 (13 quiet runs)
  ok large_startup_ms: 242.801 against a limit of 1000.000 (4 quiet runs)
  ok large_upload_frames_max: 21.000 against a limit of 33.600 (4 quiet runs)
  ok large_upload_cpu_p99_ms: 2.413 against a limit of 6.680 (4 quiet runs)
  ok large_staging_peak_mib: 32.000 against a limit of 32.000 (13 quiet runs)
  seeding leased_upload_cpu_p99_ms: 4.203 (1 of 3 quiet runs)
  seeding leased_staging_peak_mib: 24.000 (1 of 3 quiet runs)
