from pathlib import Path
import json,hashlib,resource,time,platform
import numpy as np
R=Path(__file__).resolve().parent;START=time.perf_counter()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def smooth(x):
 x=np.clip(x,0,1);return x*x*(3-2*x)
def cells(rho,d,name):
 shape=tuple(np.array(rho.shape)-1);lower=np.memmap(R/(name+'.lower.f32'),mode='w+',dtype='<f4',shape=shape);occ=np.zeros(shape,bool)
 for z in range(shape[0]):
  rr=rho[z:z+2].astype('f4');dd=d[z:z+2].astype('f4');corners=[rr[k,j:j+shape[1],i:i+shape[2]]for k in[0,1]for j in[0,1]for i in[0,1]];dc=[dd[k,j:j+shape[1],i:i+shape[2]]for k in[0,1]for j in[0,1]for i in[0,1]]
  lower[z]=np.minimum.reduce(corners)*smooth((np.minimum.reduce(dc)+8)/16);occ[z]=np.maximum.reduce(corners).astype('f8')*smooth((np.maximum.reduce(dc).astype('f8')+8)/16)>.005-1e-9
 lower.flush();return lower,occ

def box(mask,lo,hi):
 sub=mask[lo[0]:hi[0],lo[1]:hi[1],lo[2]:hi[2]]
 if not sub.any():return None
 a=[];b=[]
 for k in range(3):
  line=np.any(sub,axis=tuple(i for i in range(3)if i!=k));ids=np.flatnonzero(line);a.append(lo[k]+int(ids[0]));b.append(lo[k]+int(ids[-1])+1)
 return a,b

def bvh(mask,origin):
 initial=box(mask,[0,0,0],list(mask.shape));assert initial is not None,'empty support';leaves=[initial]
 # Split the largest conservative occupied bounding volume; no list is silently truncated.
 while len(leaves)<128:
  candidates=sorted(range(len(leaves)),key=lambda i:np.prod(np.subtract(leaves[i][1],leaves[i][0])),reverse=True);split=False
  for i in candidates:
   lo,hi=leaves[i];length=np.subtract(hi,lo);axes=np.argsort(length)[::-1]
   for ax in axes:
    if length[ax]<=1:continue
    mid=(lo[ax]+hi[ax])//2;left_hi=hi.copy();left_hi[ax]=mid;right_lo=lo.copy();right_lo[ax]=mid;a=box(mask,lo,left_hi);b=box(mask,right_lo,hi)
    if a is not None and b is not None:leaves[i:i+1]=[a,b];split=True;break
   if split:break
  if not split:break
 nodes=[]
 def add(items):
  i=len(nodes);nodes.append(None);lo=np.min([x[0]for x in items],axis=0);hi=np.max([x[1]for x in items],axis=0)
  # Cell i covers [origin+1+2i,origin+3+2i]; include both native vertices.
  n={'lo':(np.array(origin)+(lo[::-1]*2+1)).tolist(),'hi':(np.array(origin)+(hi[::-1]*2+1)).tolist(),'left':-1,'right':-1}
  if len(items)>1:
   ax=int(np.argmax(hi-lo));items=sorted(items,key=lambda x:x[0][ax]+x[1][ax]);cut=len(items)//2;n['left']=add(items[:cut]);n['right']=add(items[cut:])
  nodes[i]=n;return i
 add(leaves);assert len(nodes)<=255
 # The partition covers all occupied cells exactly once (coarse boxes may also cover empty cells).
 covered=0
 for lo,hi in leaves:covered+=int(mask[lo[0]:hi[0],lo[1]:hi[1],lo[2]:hi[2]].sum())
 assert covered==int(mask.sum())
 return {'threshold':.005,'definition':'cell upper=max(decoded rho corners)*smoothstep(-8,8,max(decoded d corners)); occupied iff float64 upper>.005−1e-9 safety guard; loss-free A<=1; outside domain zero','root':0,'leafCount':len(leaves),'occupiedCells':int(mask.sum()),'nodes':nodes}


m=json.loads((R/'assets/templates/crown-b.json').read_text());assert sha(R/'assets/templates/original-crown-b.json')=='29a35c2c171c339142db94e30cce12d1dbb350f2d449500d8192d7459cc2b339';shape=tuple(m['dimensions_xyz'][::-1]);rho=np.memmap(R/'assets/templates/crown-b.density.r16f',dtype='<f2',mode='r',shape=shape);d=np.memmap(R/'assets/templates/crown-b.distance.r16f',dtype='<f2',mode='r',shape=shape)
assert sha(R/'assets/templates/crown-b.density.r16f')==m['density']['sha256']and sha(R/'assets/templates/crown-b.distance.r16f')==m['distance']['sha256'];lower,occ=cells(rho,d,'crown-b');tree=bvh(occ,m['domain_origin_global_xyz_local_m']);assert tree['leafCount']==128 and len(tree['nodes'])==255
heads=[]
for h in m['headWitnesses']:
 heads.append({**h,'chain':h['rootChain'],'resolvedSubballRadiusLocal':6.,'selection':'freshopticalcertificate/principaloriginalScentroid +deterministicspread; no oldframe'})
result={'templateID':'crown-b','domain':m['domain'],'rootLocal':m['root_global_xyz_local_m'],'rootBall':m['rootBall'],'support':tree,'potentialSupport':m['potentialSupport'],'endpointLocal':m['finite_extinction']['endpointLocal'],'maxDecodedDLocal':m['finite_extinction']['max_decoded_d_local_m'],'supportRadiusLocal':m['potentialSupport']['conservative_radius_about_root_local_m'],'sourcePins':{'metadata':{'file':'templates/crown-b.json','sha256':sha(R/'assets/templates/crown-b.json')},**{k:{**m[k],'file':'templates/crown-b.'+k+'.r16f'}for k in['density','distance']}},'assetFrameColumns':m['root_to_crown_frame']['root_to_crown_orthoframe_columns'],'headWitnesses':heads,'proof':{'cellLowerSha256':sha(R/'crown-b.lower.f32'),'cellShapeZYX':list(lower.shape),'recipeSha256':sha(__file__),'originalProducerSha256':sha(R/'original-prepare.py'),'elapsed_s':time.perf_counter()-START,'processPeakRssBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'numpy':np.__version__,'continuousUpper':'maxrho*SMOOTHmaxD inF64; threshold.005−1e−9','geometryCertificateSHA256':m['verification']['sha256']}}
(R/'crown-b.prepared.json').write_text(json.dumps(result,indent=2)+'\n');body=json.loads((R/'body.prepared.json').read_text())
for k in['density','distance']:body['sourcePins'][k]['file']='templates/body.'+k+'.r16f'
out={'schemaVersion':1,'frozenInputsSha256':sha(R/'SOURCE-PINS.json'),'preflightSha256':sha(R/'PREFLIGHT.md'),'recipeSha256':sha(__file__),'kappaPerWorldM':.019,'scope':'Freshnaturalcrown cue-admission metadata, not opticalculling/art/replaypass; BODYunchanged; oldBfacts not reused','limits':{'maxSites':8,'maxOldReferences':8,'maxHeads':4,'maxLeaves':128,'maxNodes':255,'maxChainBalls':16,'leaseSeconds':45,'resolvedSubballRadiusLocal':6},'templates':{'body':body,'crown-b':result}}
(R/'admission.json').write_text(json.dumps(out,indent=2)+'\n');(R/'assets/admission/admission.json').write_bytes((R/'admission.json').read_bytes())
records=lambda file:{'file':file,'bytes':(R/'assets'/file).stat().st_size,'sha256':sha(R/'assets'/file)}
frozen={'scope':'Newnaturalcrownoriginalopticalmetadata plusunchangedBODY; provenanceonly, notadopted','files':{}}
for n in['body','crown-b']:
 for kind in['density','distance']:frozen['files'][n+'.'+kind+'.r16f']={'bytes':(R/'assets/templates'/(n+'.'+kind+'.r16f')).stat().st_size,'sha256':sha(R/'assets/templates'/(n+'.'+kind+'.r16f'))}
 f=R/'assets/templates'/('original-'+n+'.json');frozen['files'][n+'.json']={'bytes':f.stat().st_size,'sha256':sha(f)}
(R/'assets/templates/original-FROZEN-INPUTS.json').write_text(json.dumps(frozen,indent=2)+'\n')
index={'version':1,'qualification':'UNQUALIFIED newnaturalcrown admission/replaycandidate','source_geometry_frozen_inputs_sha256':sha(R/'assets/templates/original-FROZEN-INPUTS.json'),'source_geometry_frozen_inputs_bytes':(R/'assets/templates/original-FROZEN-INPUTS.json').stat().st_size,'rendering':{'kappa_per_world_m':.019,'additional_scattering_abc':[.5,.5,.5]},'templates':{n:{'metadata':records('templates/'+n+'.json'),'original_metadata':records('templates/original-'+n+'.json'),'density':records('templates/'+n+'.density.r16f'),'distance':records('templates/'+n+'.distance.r16f')}for n in['body','crown-b']},'noise':{**records('noise/channels-32.r16f'),'dimensions_xyz':[32,32,32],'metadata':records('noise/channels-32.json')},'admission':records('admission/admission.json')};(R/'assets/input-index.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps({'admissionSHA256':sha(R/'admission.json'),'leafCount':tree['leafCount'],'nodes':len(tree['nodes']),'occupiedCells':tree['occupiedCells'],'peakRSS':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'heads':[(h['centerLocal'],h['radiusLocal'],len(h['chain']))for h in heads]}))
