# Independent streamed native point/ball checks. No full volume mesh or coordinate list.
from pathlib import Path
import json,hashlib,math,resource,itertools
import numpy as np
R=Path(__file__).resolve().parent;I=R/'assets';m=json.loads((R/'admission.json').read_text());rows=[]
def qpoint(rho,d,p,origin):
 co=[(p[i]-origin[i])/2-.5 for i in range(3)];lo=[math.floor(x)for x in co];t=[co[i]-lo[i]for i in range(3)];r=dd=0.
 for k,j,i in itertools.product([0,1],repeat=3):
  a=[max(0,min(rho.shape[2-n]-1,lo[n]+[i,j,k][n]))for n in range(3)];w=math.prod(t[n]if [i,j,k][n]else 1-t[n]for n in range(3));r+=float(rho[a[2],a[1],a[0]])*w;dd+=float(d[a[2],a[1],a[0]])*w
 u=max(0,min(1,(dd+8)/16));return r*u*u*(3-2*u)
for name,T in m['templates'].items():
 shape=tuple(T['domain']['dims'][::-1]);origin=T['domain']['origin'];rho=np.memmap(I/T['sourcePins']['density']['file'],mode='r',dtype='<f2',shape=shape);d=np.memmap(I/T['sourcePins']['distance']['file'],mode='r',dtype='<f2',shape=shape)
 pins=True
 for k in ['density','distance']:
  with open(I/T['sourcePins'][k]['file'],'rb')as f:pins&=hashlib.file_digest(f,'sha256').hexdigest()==T['sourcePins'][k]['sha256']
 leaves=[n for n in T['support']['nodes']if n['left']==-1];uncovered=0;positive=0;tail_outside=0
 for z in range(shape[0]):
  zz=origin[2]+2*z+1;covered=np.zeros(shape[1:],bool)
  for n in leaves:
   if n['lo'][2]<=zz<=n['hi'][2]:
    x0=max(0,math.ceil((n['lo'][0]-origin[0]-1)/2));x1=min(shape[2],math.floor((n['hi'][0]-origin[0]-1)/2)+1);y0=max(0,math.ceil((n['lo'][1]-origin[1]-1)/2));y1=min(shape[1],math.floor((n['hi'][1]-origin[1]-1)/2)+1);covered[y0:y1,x0:x1]=True
  rr=rho[z].astype('f8');dd=d[z].astype('f8');u=np.clip((dd+8)/16,0,1);q=rr*u*u*(3-2*u);positive+=int((q>.005).sum());uncovered+=int(((q>.005)&~covered).sum());tail_outside+=int(((q>0)&(q<=.005)&~covered).sum())
 balls=[T['rootBall']]
 if name=='body':balls += [{'centerLocal':s['local'],'radiusLocal':s['positiveRadiusLocal']}for s in T['sites']]
 else:
  for h in T['headWitnesses']:balls+=h['chain']+[h]
 minimum=math.inf;points=0
 for b in balls:
  for v in itertools.product([-1,0,1],repeat=3):
   if v==(0,0,0):p=b['centerLocal']
   else:
    length=math.sqrt(sum(x*x for x in v));p=[b['centerLocal'][j]+v[j]/length*b['radiusLocal']*.999 for j in range(3)]
   minimum=min(minimum,qpoint(rho,d,p,origin));points+=1
 assert pins and uncovered==0 and minimum>=.041-1e-7
 rows.append({'template':name,'sourcePinsMatch':pins,'nativeAbove005':positive,'above005OutsideBVH':uncovered,'positiveTailOutsideBVH':tail_outside,'ballSurfacePoints':points,'minimumSampledBallQ':minimum,'proofScope':'native sample/BVH and26direction ball checks only; continuous conservatism from cell bounds/boxes, not a sampled theorem'})
 del rho,d
out={'pass':True,'rows':rows,'peakRssBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss};(R/'native-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
