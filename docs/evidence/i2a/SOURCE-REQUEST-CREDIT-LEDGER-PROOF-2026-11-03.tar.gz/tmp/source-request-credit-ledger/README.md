# Safe request-credit ledger proof

Owner: `/root/source_binding_review`, 3 November 2026. Purpose: prove a bounded
safe resource ledger and outer-close protocol before any native unsafe adapter.
Owned scope: this scratch, its evidence Markdown and selected archive. No production,
contract, Build Plan or maturity edits. Expected scratch peak <100 MiB; no native
files, source payload buffers or disk-full experiment are created.

The crate has zero third-party dependencies and forbids unsafe code. It is a protocol
model, not a VFS, source authenticator, OS lock, durable grant broker or APFS guard.
Source bindings in the tests are synthetic immutable tuples. SourceVerifier and the
outer-close function are trusted external witnesses whose native/durable truth is
outside this proof. Process-local instance/slot generations have no serialization
API and cannot serve as restart authority.

Retain source/Cargo lock, exact requirements text, deterministic input specification,
raw tests and benchmark/RSS logs, tool identities and a byte-verified archive. Remove
only this task's build outputs after archive verification. No masters/assets are
created. Ignored scratch is local evidence, not a durable backup.

Reproduce (pinned Rust 1.99.1, Python 3.11+):

```sh
python3 tmp/source-request-credit-ledger/run.py
```

The runner stops on any build/check/test failure before executing benchmark binaries.
The source-input trace is synthetic WAL/checkpoint-shaped work: 4471/63 WAL frames,
4296/56 main pages, two/one SHM maps. It does not replay native SQLite calls or measure
publication/cook latency. The contended worker has eight threads and 80,000 writes.

Storage is fixed within each Ledger (8 owners, 8 objects, 8 handles, 16 ordinary and
8 independent cleanup receipts). std::Mutex internals, caller allocations, reference
model event Vecs and thread stacks are outside the inline-state measurement. The
host must keep the ledger alive; no native callback-storage lifetime is claimed.
