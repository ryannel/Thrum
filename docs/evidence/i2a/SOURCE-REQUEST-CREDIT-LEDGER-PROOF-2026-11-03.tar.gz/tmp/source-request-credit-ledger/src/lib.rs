//! Safe request-credit/close protocol model. No native I/O, source authentication,
//! durable recovery, admitted-source or physical-space authority.
#![forbid(unsafe_code)]
use std::sync::{
    Mutex, MutexGuard,
    atomic::{AtomicU64, Ordering},
};
static NEXT_INSTANCE: AtomicU64 = AtomicU64::new(1);
fn next_instance(counter: &AtomicU64) -> Result<u64> {
    counter
        .try_update(Ordering::Relaxed, Ordering::Relaxed, |n| n.checked_add(1))
        .map_err(|_| Error::Generation)
}
pub const OWNERS: usize = 8;
pub const OBJECTS: usize = 8;
pub const HANDLES: usize = 8;
pub const FLIGHTS: usize = 16;
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Credits {
    pub w: u64,
    pub e: u64,
    pub s: u64,
    pub m: u64,
}
impl Credits {
    fn debit(self, c: Self) -> Result<Self> {
        Ok(Self {
            w: self.w.checked_sub(c.w).ok_or(Error::Credit)?,
            e: self.e.checked_sub(c.e).ok_or(Error::Credit)?,
            s: self.s.checked_sub(c.s).ok_or(Error::Credit)?,
            m: self.m.checked_sub(c.m).ok_or(Error::Credit)?,
        })
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Error {
    Stale,
    Binding,
    Credit,
    Capacity,
    RoleCap,
    Linked,
    Unlinked,
    Busy,
    Phase,
    Quarantined,
    Range,
    Completion,
    OutcomeUnknown,
    OutcomeMismatch,
    Poisoned,
    OuterPanicked,
    Generation,
}
pub type Result<T> = std::result::Result<T, Error>;
macro_rules! key {
    ($name:ident) => {
        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub struct $name {
            instance: u64,
            index: usize,
            generation: u64,
        }
    };
}
key!(Owner);
key!(Object);
key!(Handle);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Grant {
    owner: Owner,
    sequence: u64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Receipt {
    instance: u64,
    index: usize,
    generation: u64,
    cleanup: bool,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Tag {
    pub store: [u8; 16],
    pub project: [u8; 16],
    pub epoch: [u8; 16],
    pub policy: [u8; 32],
    /// Immutable, externally qualified native mapping-page size.
    pub os_page: u64,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Binding {
    pub store: [u8; 16],
    pub project: [u8; 16],
    pub base_generation: u64,
    pub base_revision: Option<[u8; 32]>,
    pub key: [u8; 16],
    pub target: Option<[u8; 32]>,
}
impl Binding {
    fn valid(self) -> bool {
        (self.base_generation == 0) == self.base_revision.is_none()
            && self.base_generation < u64::MAX
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Uncertain {
    grant: Grant,
    binding: Binding,
}
impl Uncertain {
    pub fn binding(self) -> Binding {
        self.binding
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SourceOutcome {
    Unknown,
    NoCommit,
    Committed { generation: u64, revision: [u8; 32] },
}
#[derive(Clone, Copy, Debug)]
pub struct Evidence {
    pub binding: Binding,
    pub outcome: SourceOutcome,
}
/// Supplied by a separately authenticated source-store adapter. The model cannot
/// prove that an implementation queried durable storage or held an OS lock.
pub trait SourceVerifier {
    fn lookup(&self, binding: Binding) -> Evidence;
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Role {
    Main,
    Wal,
    Journal,
}
impl Role {
    fn index(self) -> usize {
        match self {
            Self::Main => 0,
            Self::Wal => 1,
            Self::Journal => 2,
        }
    }
    pub fn cap(self) -> u64 {
        match self {
            Self::Main => 256 << 20,
            Self::Wal => 64 << 20,
            Self::Journal => 16 << 20,
        }
    }
}
#[derive(Clone, Copy)]
struct Slot<T: Copy> {
    generation: u64,
    retired: bool,
    value: Option<T>,
}
impl<T: Copy> Slot<T> {
    const fn empty() -> Self {
        Self {
            generation: 1,
            retired: false,
            value: None,
        }
    }
    fn clear(&mut self) {
        self.value = None;
        if let Some(n) = self.generation.checked_add(1) {
            self.generation = n
        } else {
            self.retired = true
        }
    }
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum Stage {
    Running,
    Await,
    Settled,
}
#[derive(Clone, Copy)]
struct Active {
    key: Grant,
    binding: Binding,
    left: Credits,
    stage: Stage,
    fault: bool,
}
#[derive(Clone, Copy)]
struct OwnerRecord {
    tag: Tag,
    next: u64,
    active: Option<Active>,
    retained: [u64; 3],
    inflight: u16,
    closing: bool,
    closed: bool,
    quarantine: bool,
}
#[derive(Clone, Copy)]
struct ObjectRecord {
    owner: Owner,
    role: Role,
    hwm: u64,
    map_hwm: u64,
    linked: bool,
    delete_pending: bool,
    handles: u8,
    flights: u8,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum HandlePhase {
    Opening,
    Open,
    Partial,
    Closing,
    Unmapping,
    Unknown,
}
#[derive(Clone, Copy)]
struct HandleRecord {
    owner: Owner,
    object: Object,
    phase: HandlePhase,
    flights: u8,
    map_cleanup: u32,
    close_paid: bool,
}
#[derive(Clone, Copy, PartialEq, Eq)]
enum Kind {
    Open,
    Write,
    Truncate,
    Map,
    Delete,
    Sync,
    Close,
    Unmap,
}
#[derive(Clone, Copy)]
struct Flight {
    owner: Owner,
    grant: Option<Grant>,
    object: Object,
    handle: Option<Handle>,
    kind: Kind,
}
struct State {
    instance: u64,
    owners: [Slot<OwnerRecord>; OWNERS],
    objects: [Slot<ObjectRecord>; OBJECTS],
    handles: [Slot<HandleRecord>; HANDLES],
    flights: [Slot<Flight>; FLIGHTS],
    cleanup: [Slot<Flight>; HANDLES],
}
impl State {
    fn new(instance: u64) -> Self {
        Self {
            instance,
            owners: [Slot::empty(); OWNERS],
            objects: [Slot::empty(); OBJECTS],
            handles: [Slot::empty(); HANDLES],
            flights: [Slot::empty(); FLIGHTS],
            cleanup: [Slot::empty(); HANDLES],
        }
    }
}
pub struct Ledger {
    state: Mutex<State>,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct View {
    pub credits: Option<Credits>,
    pub retained: [u64; 3],
    pub inflight: u16,
    pub handles: usize,
    pub objects: usize,
    pub closing: bool,
    pub closed: bool,
    pub quarantined: bool,
    pub registration_held: bool,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Opened {
    pub receipt: Receipt,
    pub handle: Handle,
    pub object: Object,
}
#[derive(Clone, Copy, Debug)]
pub enum Native {
    Ok,
    Failed,
    Opened { length: u64 },
    OpenFailed { methods: bool },
}
impl Ledger {
    pub fn new() -> Result<Self> {
        Ok(Self {
            state: Mutex::new(State::new(next_instance(&NEXT_INSTANCE)?)),
        })
    }
    pub fn inline_bytes() -> usize {
        std::mem::size_of::<Self>()
    }
    fn lock(&self) -> Result<MutexGuard<'_, State>> {
        self.state.lock().map_err(|_| Error::Poisoned)
    }
    pub fn register(&self, tag: Tag) -> Result<Owner> {
        if tag.os_page == 0 || !tag.os_page.is_power_of_two() || tag.os_page > 65536 {
            return Err(Error::Range);
        }
        let mut s = self.lock()?;
        if s.owners
            .iter()
            .any(|x| x.value.is_some_and(|o| o.tag.store == tag.store))
        {
            return Err(Error::Busy);
        }
        let i = free(&s.owners)?;
        let key = Owner {
            instance: s.instance,
            index: i,
            generation: s.owners[i].generation,
        };
        s.owners[i].value = Some(OwnerRecord {
            tag,
            next: 1,
            active: None,
            retained: [0; 3],
            inflight: 0,
            closing: false,
            closed: false,
            quarantine: false,
        });
        Ok(key)
    }
    pub fn arm(&self, owner: Owner, binding: Binding, credits: Credits) -> Result<Grant> {
        let mut s = self.lock()?;
        let mut o = own(&s, owner)?;
        live(o)?;
        if o.active.is_some() || o.inflight != 0 {
            return Err(Error::Busy);
        }
        if credits.w > 256 << 20 || credits.e > 336 << 20 || credits.s > 131072 || credits.m > 65536
        {
            return Err(Error::Range);
        }
        if !binding.valid() || binding.store != o.tag.store || binding.project != o.tag.project {
            return Err(Error::Binding);
        }
        let next = o.next.checked_add(1).ok_or(Error::Generation)?;
        let key = Grant {
            owner,
            sequence: o.next,
        };
        o.next = next;
        o.active = Some(Active {
            key,
            binding,
            left: credits,
            stage: Stage::Running,
            fault: false,
        });
        s.owners[owner.index].value = Some(o);
        Ok(key)
    }
    pub fn view(&self, owner: Owner) -> Result<View> {
        let s = self.lock()?;
        let o = own(&s, owner)?;
        Ok(View {
            credits: o.active.map(|a| a.left),
            retained: o.retained,
            inflight: o.inflight,
            handles: s
                .handles
                .iter()
                .filter(|h| h.value.is_some_and(|v| v.owner == owner))
                .count(),
            objects: s
                .objects
                .iter()
                .filter(|h| h.value.is_some_and(|v| v.owner == owner))
                .count(),
            closing: o.closing,
            closed: o.closed,
            quarantined: o.quarantine,
            registration_held: true,
        })
    }
    pub fn object_hwm(&self, key: Object) -> Result<(u64, u64, bool)> {
        let s = self.lock()?;
        let o = obj(&s, key)?;
        Ok((o.hwm, o.map_hwm, o.linked))
    }
    pub fn open_new(&self, g: Grant, b: Binding, role: Role, length: u64) -> Result<Opened> {
        let mut s = self.lock()?;
        let mut o = check(&s, g, b)?;
        if s.objects.iter().any(|x| {
            x.value
                .is_some_and(|v| v.owner == g.owner && v.role == role && v.linked)
        }) {
            return Err(Error::Linked);
        }
        let oi = free(&s.objects)?;
        let hi = free(&s.handles)?;
        let fi = free(&s.flights)?;
        grow(&mut o, role, length)?;
        debit(
            &mut o,
            Credits {
                e: length,
                m: 2,
                ..Credits::default()
            },
        )?;
        let object = Object {
            instance: s.instance,
            index: oi,
            generation: s.objects[oi].generation,
        };
        let handle = Handle {
            instance: s.instance,
            index: hi,
            generation: s.handles[hi].generation,
        };
        s.objects[oi].value = Some(ObjectRecord {
            owner: g.owner,
            role,
            hwm: length,
            map_hwm: 0,
            linked: true,
            delete_pending: false,
            handles: 1,
            flights: 1,
        });
        s.handles[hi].value = Some(HandleRecord {
            owner: g.owner,
            object,
            phase: HandlePhase::Opening,
            flights: 1,
            map_cleanup: 0,
            close_paid: true,
        });
        o.inflight += 1;
        s.owners[g.owner.index].value = Some(o);
        let receipt = install(
            &mut s,
            fi,
            Flight {
                owner: g.owner,
                grant: Some(g),
                object,
                handle: Some(handle),
                kind: Kind::Open,
            },
            false,
        );
        Ok(Opened {
            receipt,
            handle,
            object,
        })
    }
    pub fn open_existing(&self, g: Grant, b: Binding, object: Object) -> Result<Opened> {
        let mut s = self.lock()?;
        let mut o = check(&s, g, b)?;
        let mut ob = obj(&s, object)?;
        if ob.owner != g.owner {
            return Err(Error::Binding);
        }
        if !ob.linked || ob.delete_pending {
            return Err(Error::Unlinked);
        }
        let hi = free(&s.handles)?;
        let fi = free(&s.flights)?;
        debit(
            &mut o,
            Credits {
                m: 2,
                ..Credits::default()
            },
        )?;
        let handle = Handle {
            instance: s.instance,
            index: hi,
            generation: s.handles[hi].generation,
        };
        ob.handles += 1;
        ob.flights += 1;
        o.inflight += 1;
        s.objects[object.index].value = Some(ob);
        s.handles[hi].value = Some(HandleRecord {
            owner: g.owner,
            object,
            phase: HandlePhase::Opening,
            flights: 1,
            map_cleanup: 0,
            close_paid: true,
        });
        s.owners[g.owner.index].value = Some(o);
        let receipt = install(
            &mut s,
            fi,
            Flight {
                owner: g.owner,
                grant: Some(g),
                object,
                handle: Some(handle),
                kind: Kind::Open,
            },
            false,
        );
        Ok(Opened {
            receipt,
            handle,
            object,
        })
    }
    pub fn write(
        &self,
        g: Grant,
        b: Binding,
        h: Handle,
        offset: u64,
        length: u64,
    ) -> Result<Receipt> {
        if length == 0 {
            return Err(Error::Range);
        }
        let end = offset.checked_add(length).ok_or(Error::Range)?;
        self.data(g, b, h, Kind::Write, end, length)
    }
    pub fn truncate(&self, g: Grant, b: Binding, h: Handle, length: u64) -> Result<Receipt> {
        self.data(g, b, h, Kind::Truncate, length, 0)
    }
    pub fn sync(&self, g: Grant, b: Binding, h: Handle) -> Result<Receipt> {
        self.data(g, b, h, Kind::Sync, 0, 0)
    }
    fn data(
        &self,
        g: Grant,
        b: Binding,
        h: Handle,
        kind: Kind,
        end: u64,
        w: u64,
    ) -> Result<Receipt> {
        let mut s = self.lock()?;
        let mut o = check(&s, g, b)?;
        let mut hr = handle(&s, h)?;
        let mut ob = obj(&s, hr.object)?;
        ready(hr, ob, g.owner)?;
        let fi = free(&s.flights)?;
        if end > ob.role.cap() {
            return Err(Error::RoleCap);
        }
        let e = end.saturating_sub(ob.hwm);
        grow(&mut o, ob.role, e)?;
        debit(
            &mut o,
            Credits {
                w,
                e,
                m: u64::from(kind != Kind::Write),
                s: 0,
            },
        )?;
        ob.hwm = ob.hwm.max(end);
        ob.flights += 1;
        hr.flights += 1;
        o.inflight += 1;
        s.objects[hr.object.index].value = Some(ob);
        s.handles[h.index].value = Some(hr);
        s.owners[g.owner.index].value = Some(o);
        Ok(install(
            &mut s,
            fi,
            Flight {
                owner: g.owner,
                grant: Some(g),
                object: hr.object,
                handle: Some(h),
                kind,
            },
            false,
        ))
    }
    pub fn map(&self, g: Grant, b: Binding, h: Handle, index: u32) -> Result<Receipt> {
        let mut s = self.lock()?;
        let mut o = check(&s, g, b)?;
        let group = o.tag.os_page.max(32768);
        let end = (u64::from(index) + 1)
            .checked_mul(32768)
            .and_then(|n| n.checked_add(group - 1))
            .map(|n| n / group * group)
            .ok_or(Error::Range)?;
        if end > 131072 {
            return Err(Error::RoleCap);
        }
        let mut hr = handle(&s, h)?;
        let mut ob = obj(&s, hr.object)?;
        ready(hr, ob, g.owner)?;
        if ob.role != Role::Main {
            return Err(Error::Binding);
        }
        let fi = free(&s.flights)?;
        let paid = hr.map_cleanup.checked_add(1).ok_or(Error::Capacity)?;
        debit(
            &mut o,
            Credits {
                s: end.saturating_sub(ob.map_hwm),
                m: 4,
                ..Credits::default()
            },
        )?;
        ob.map_hwm = ob.map_hwm.max(end);
        hr.map_cleanup = paid;
        ob.flights += 1;
        hr.flights += 1;
        o.inflight += 1;
        s.objects[hr.object.index].value = Some(ob);
        s.handles[h.index].value = Some(hr);
        s.owners[g.owner.index].value = Some(o);
        Ok(install(
            &mut s,
            fi,
            Flight {
                owner: g.owner,
                grant: Some(g),
                object: hr.object,
                handle: Some(h),
                kind: Kind::Map,
            },
            false,
        ))
    }
    pub fn delete(&self, g: Grant, b: Binding, key: Object) -> Result<Receipt> {
        let mut s = self.lock()?;
        let mut o = check(&s, g, b)?;
        let mut ob = obj(&s, key)?;
        if ob.owner != g.owner || ob.role == Role::Main {
            return Err(Error::Binding);
        }
        if !ob.linked {
            return Err(Error::Unlinked);
        }
        if ob.flights != 0 || ob.delete_pending {
            return Err(Error::Busy);
        }
        let fi = free(&s.flights)?;
        debit(
            &mut o,
            Credits {
                m: 1,
                ..Credits::default()
            },
        )?;
        ob.delete_pending = true;
        ob.flights += 1;
        o.inflight += 1;
        s.objects[key.index].value = Some(ob);
        s.owners[g.owner.index].value = Some(o);
        Ok(install(
            &mut s,
            fi,
            Flight {
                owner: g.owner,
                grant: Some(g),
                object: key,
                handle: None,
                kind: Kind::Delete,
            },
            false,
        ))
    }
    pub fn unmap(&self, h: Handle) -> Result<Receipt> {
        self.cleanup(h, false)
    }
    pub fn close_handle(&self, h: Handle) -> Result<Receipt> {
        self.cleanup(h, true)
    }
    fn cleanup(&self, h: Handle, close: bool) -> Result<Receipt> {
        let mut s = self.lock()?;
        let mut hr = handle(&s, h)?;
        let mut ob = obj(&s, hr.object)?;
        let mut o = own(&s, hr.owner)?;
        if hr.flights != 0 || !matches!(hr.phase, HandlePhase::Open | HandlePhase::Partial) {
            return Err(Error::Busy);
        }
        if (close && (!hr.close_paid || hr.map_cleanup != 0)) || (!close && hr.map_cleanup == 0) {
            return Err(Error::Phase);
        }
        let fi = free(&s.cleanup)?;
        hr.phase = if close {
            HandlePhase::Closing
        } else {
            HandlePhase::Unmapping
        };
        if close {
            hr.close_paid = false;
        }
        hr.flights += 1;
        ob.flights += 1;
        o.inflight += 1;
        s.handles[h.index].value = Some(hr);
        s.objects[hr.object.index].value = Some(ob);
        s.owners[hr.owner.index].value = Some(o);
        Ok(install(
            &mut s,
            fi,
            Flight {
                owner: hr.owner,
                grant: None,
                object: hr.object,
                handle: Some(h),
                kind: if close { Kind::Close } else { Kind::Unmap },
            },
            true,
        ))
    }
    pub fn complete(&self, r: Receipt, native: Native) -> Result<()> {
        let mut s = self.lock()?;
        let f = flight(&s, r)?;
        let mut o = own(&s, f.owner)?;
        let mut ob = obj(&s, f.object)?;
        let mut hr = f.handle.map(|h| handle(&s, h)).transpose()?;
        let valid = if f.kind == Kind::Open {
            matches!(native, Native::Opened { .. } | Native::OpenFailed { .. })
        } else {
            matches!(native, Native::Ok | Native::Failed)
        };
        if !valid {
            return Err(Error::Completion);
        }
        if let Some(g) = f.grant
            && o.active
                .is_none_or(|a| a.key != g || a.stage != Stage::Running)
        {
            return Err(Error::Stale);
        }
        let failed = matches!(native, Native::Failed | Native::OpenFailed { .. });
        if failed && let Some(mut a) = o.active {
            a.fault = true;
            o.active = Some(a)
        }
        match (f.kind, native) {
            (Kind::Open, Native::Opened { length }) => {
                if length > ob.hwm {
                    o.quarantine = true;
                    if let Some(mut a) = o.active {
                        a.fault = true;
                        o.active = Some(a)
                    }
                    hr.as_mut().ok_or(Error::Completion)?.phase = HandlePhase::Partial;
                } else {
                    hr.as_mut().ok_or(Error::Completion)?.phase = HandlePhase::Open;
                }
            }
            (Kind::Open, Native::OpenFailed { methods }) => {
                o.quarantine = true;
                if methods {
                    hr.as_mut().ok_or(Error::Completion)?.phase = HandlePhase::Partial;
                } else {
                    let h = f.handle.ok_or(Error::Completion)?;
                    s.handles[h.index].clear();
                    hr = None;
                    ob.handles -= 1;
                }
            }
            (Kind::Delete, Native::Ok) => {
                ob.linked = false;
                ob.delete_pending = false;
            }
            (Kind::Delete, Native::Failed) => {
                o.quarantine = true;
                ob.delete_pending = false;
            }
            (Kind::Close, Native::Ok) => {
                let h = f.handle.ok_or(Error::Completion)?;
                s.handles[h.index].clear();
                hr = None;
                ob.handles -= 1;
            }
            (Kind::Close, Native::Failed) => {
                o.quarantine = true;
                hr.as_mut().ok_or(Error::Completion)?.phase = HandlePhase::Unknown;
            }
            (Kind::Unmap, Native::Ok) => {
                let h = hr.as_mut().ok_or(Error::Completion)?;
                h.map_cleanup = 0;
                h.phase = HandlePhase::Open;
            }
            (Kind::Unmap, Native::Failed) => {
                o.quarantine = true;
                hr.as_mut().ok_or(Error::Completion)?.phase = HandlePhase::Unknown;
            }
            _ => {}
        }
        if let (Some(key), Some(mut value)) = (f.handle, hr) {
            value.flights -= 1;
            s.handles[key.index].value = Some(value);
        }
        ob.flights -= 1;
        o.inflight -= 1;
        s.objects[f.object.index].value = Some(ob);
        s.owners[f.owner.index].value = Some(o);
        if r.cleanup {
            s.cleanup[r.index].clear()
        } else {
            s.flights[r.index].clear()
        }
        Ok(())
    }
    pub fn seal(&self, g: Grant, autocommit: bool, uncertain: bool) -> Result<Option<Uncertain>> {
        let mut s = self.lock()?;
        let mut o = own(&s, g.owner)?;
        let mut a = active(o, g)?;
        if o.inflight != 0 || !autocommit {
            return Err(Error::Busy);
        }
        if a.stage != Stage::Running {
            return Err(Error::Phase);
        }
        a.stage = if uncertain || a.fault {
            Stage::Await
        } else {
            Stage::Settled
        };
        o.active = Some(a);
        s.owners[g.owner.index].value = Some(o);
        Ok((a.stage == Stage::Await).then_some(Uncertain {
            grant: g,
            binding: a.binding,
        }))
    }
    pub fn resolve(&self, token: Uncertain, verifier: &impl SourceVerifier) -> Result<()> {
        {
            let s = self.lock()?;
            let a = active(own(&s, token.grant.owner)?, token.grant)?;
            if a.stage != Stage::Await || a.binding != token.binding {
                return Err(Error::Stale);
            }
        }
        // Source I/O/verification is never invoked while holding the ledger mutex.
        let evidence = verifier.lookup(token.binding);
        let mut s = self.lock()?;
        let mut o = own(&s, token.grant.owner)?;
        let mut a = active(o, token.grant)?;
        if a.stage != Stage::Await || a.binding != token.binding {
            return Err(Error::Stale);
        }
        if evidence.binding != token.binding {
            return Err(Error::OutcomeMismatch);
        }
        match evidence.outcome {
            SourceOutcome::Unknown => return Err(Error::OutcomeUnknown),
            SourceOutcome::NoCommit => {}
            SourceOutcome::Committed {
                generation,
                revision,
            } => {
                if Some(revision) != a.binding.target || generation != a.binding.base_generation + 1
                {
                    return Err(Error::OutcomeMismatch);
                }
            }
        }
        a.stage = Stage::Settled;
        o.active = Some(a);
        s.owners[token.grant.owner.index].value = Some(o);
        Ok(())
    }
    pub fn barrier(&self, g: Grant) -> Result<()> {
        let mut s = self.lock()?;
        let mut o = own(&s, g.owner)?;
        let a = active(o, g)?;
        if o.inflight != 0 {
            return Err(Error::Busy);
        }
        if a.stage != Stage::Settled {
            return Err(Error::Phase);
        }
        o.active = None;
        s.owners[g.owner.index].value = Some(o);
        Ok(())
    }
    pub fn retire_object(&self, owner: Owner, key: Object) -> Result<()> {
        let mut s = self.lock()?;
        let mut o = own(&s, owner)?;
        let ob = obj(&s, key)?;
        if o.quarantine {
            return Err(Error::Quarantined);
        }
        if ob.owner != owner {
            return Err(Error::Binding);
        }
        if o.active.is_some() || o.inflight != 0 || ob.linked || ob.handles != 0 || ob.flights != 0
        {
            return Err(Error::Busy);
        }
        o.retained[ob.role.index()] -= ob.hwm;
        s.owners[owner.index].value = Some(o);
        s.objects[key.index].clear();
        Ok(())
    }
    /// The outer mock/native function executes outside the mutex while Closing.
    /// Only this runner records its return; a last file completion cannot do so.
    pub fn close_owner(&self, owner: Owner, outer: impl FnOnce(&Self) -> bool) -> Result<()> {
        {
            let mut s = self.lock()?;
            let mut o = own(&s, owner)?;
            if o.closing
                || o.closed
                || o.inflight != 0
                || o.active.is_some_and(|a| a.stage == Stage::Running)
            {
                return Err(Error::Busy);
            }
            o.closing = true;
            s.owners[owner.index].value = Some(o);
        }
        let returned = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| outer(self)));
        let mut s = self.lock()?;
        let mut o = own(&s, owner)?;
        o.closing = false;
        let clear = o.inflight == 0
            && !s
                .handles
                .iter()
                .any(|h| h.value.is_some_and(|v| v.owner == owner));
        match returned {
            Ok(true) if clear => o.closed = true,
            Ok(_) => o.quarantine = true,
            Err(_) => {
                o.quarantine = true;
                s.owners[owner.index].value = Some(o);
                return Err(Error::OuterPanicked);
            }
        }
        s.owners[owner.index].value = Some(o);
        if o.quarantine {
            Err(Error::Quarantined)
        } else {
            Ok(())
        }
    }
    pub fn retire_owner(&self, owner: Owner) -> Result<()> {
        let mut s = self.lock()?;
        let o = own(&s, owner)?;
        if o.quarantine {
            return Err(Error::Quarantined);
        }
        if !o.closed
            || o.closing
            || o.inflight != 0
            || o.active.is_some()
            || s.handles
                .iter()
                .any(|h| h.value.is_some_and(|v| v.owner == owner))
        {
            return Err(Error::Busy);
        }
        for slot in &mut s.objects {
            if slot.value.is_some_and(|v| v.owner == owner) {
                slot.clear();
            }
        }
        s.owners[owner.index].clear();
        Ok(())
    }
}
fn free<T: Copy, const N: usize>(slots: &[Slot<T>; N]) -> Result<usize> {
    slots
        .iter()
        .position(|x| !x.retired && x.value.is_none())
        .ok_or(Error::Capacity)
}
fn own(s: &State, k: Owner) -> Result<OwnerRecord> {
    if k.instance != s.instance {
        return Err(Error::Stale);
    }
    s.owners
        .get(k.index)
        .filter(|x| x.generation == k.generation)
        .and_then(|x| x.value)
        .ok_or(Error::Stale)
}
fn obj(s: &State, k: Object) -> Result<ObjectRecord> {
    if k.instance != s.instance {
        return Err(Error::Stale);
    }
    s.objects
        .get(k.index)
        .filter(|x| x.generation == k.generation)
        .and_then(|x| x.value)
        .ok_or(Error::Stale)
}
fn handle(s: &State, k: Handle) -> Result<HandleRecord> {
    if k.instance != s.instance {
        return Err(Error::Stale);
    }
    s.handles
        .get(k.index)
        .filter(|x| x.generation == k.generation)
        .and_then(|x| x.value)
        .ok_or(Error::Stale)
}
fn flight(s: &State, k: Receipt) -> Result<Flight> {
    if k.instance != s.instance {
        return Err(Error::Stale);
    }
    let slot = if k.cleanup {
        s.cleanup.get(k.index)
    } else {
        s.flights.get(k.index)
    };
    slot.filter(|x| x.generation == k.generation)
        .and_then(|x| x.value)
        .ok_or(Error::Stale)
}
fn active(o: OwnerRecord, g: Grant) -> Result<Active> {
    o.active.filter(|a| a.key == g).ok_or(Error::Stale)
}
fn live(o: OwnerRecord) -> Result<()> {
    if o.quarantine {
        return Err(Error::Quarantined);
    }
    if o.closing || o.closed {
        return Err(Error::Phase);
    }
    Ok(())
}
fn check(s: &State, g: Grant, b: Binding) -> Result<OwnerRecord> {
    let o = own(s, g.owner)?;
    live(o)?;
    let a = active(o, g)?;
    if a.binding != b {
        return Err(Error::Binding);
    }
    if a.stage != Stage::Running || a.fault {
        return Err(Error::Phase);
    }
    Ok(o)
}
fn debit(o: &mut OwnerRecord, c: Credits) -> Result<()> {
    let mut a = o.active.ok_or(Error::Phase)?;
    a.left = a.left.debit(c)?;
    o.active = Some(a);
    Ok(())
}
fn grow(o: &mut OwnerRecord, role: Role, n: u64) -> Result<()> {
    let next = o.retained[role.index()]
        .checked_add(n)
        .filter(|&v| v <= role.cap())
        .ok_or(Error::RoleCap)?;
    o.retained[role.index()] = next;
    Ok(())
}
fn ready(h: HandleRecord, o: ObjectRecord, owner: Owner) -> Result<()> {
    if h.owner != owner || o.owner != owner {
        return Err(Error::Binding);
    }
    if h.phase != HandlePhase::Open || o.delete_pending {
        return Err(Error::Busy);
    }
    Ok(())
}
fn install(s: &mut State, index: usize, value: Flight, cleanup: bool) -> Receipt {
    let slot = if cleanup {
        &mut s.cleanup[index]
    } else {
        &mut s.flights[index]
    };
    slot.value = Some(value);
    Receipt {
        instance: s.instance,
        index,
        generation: slot.generation,
        cleanup,
    }
}

#[cfg(test)]
mod numeric_tests {
    use super::*;
    #[test]
    fn counters_never_wrap_or_reuse_exhausted_slots() {
        let counter = AtomicU64::new(u64::MAX);
        assert_eq!(next_instance(&counter), Err(Error::Generation));
        assert_eq!(counter.load(Ordering::Relaxed), u64::MAX);
        let mut slot = Slot {
            generation: u64::MAX,
            retired: false,
            value: Some(7u8),
        };
        slot.clear();
        assert!(slot.retired && slot.value.is_none());
        assert_eq!(free(&[slot]), Err(Error::Capacity));
        let l = Ledger::new().unwrap();
        let tag = Tag {
            store: [1; 16],
            project: [2; 16],
            epoch: [3; 16],
            policy: [4; 32],
            os_page: 16384,
        };
        let o = l.register(tag).unwrap();
        {
            let mut s = l.lock().unwrap();
            let mut r = own(&s, o).unwrap();
            r.next = u64::MAX;
            s.owners[o.index].value = Some(r);
        }
        let b = Binding {
            store: [1; 16],
            project: [2; 16],
            base_generation: 0,
            base_revision: None,
            key: [0; 16],
            target: None,
        };
        assert_eq!(l.arm(o, b, Credits::default()), Err(Error::Generation));
        assert!(l.view(o).unwrap().registration_held);
    }
}
