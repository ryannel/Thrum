#![forbid(unsafe_code)]
use source_request_credit_ledger::*;
use std::{
    hint::black_box,
    sync::{Arc, Barrier},
    time::{Duration, Instant},
};
fn tag() -> Tag {
    Tag {
        store: [1; 16],
        project: [2; 16],
        epoch: [3; 16],
        policy: [4; 32],
        os_page: 16384,
    }
}
fn binding() -> Binding {
    Binding {
        store: [1; 16],
        project: [2; 16],
        base_generation: 1,
        base_revision: Some([10; 32]),
        key: [7; 16],
        target: Some([11; 32]),
    }
}
fn grant() -> Credits {
    Credits {
        w: 64 << 20,
        e: 64 << 20,
        s: 65536,
        m: 32,
    }
}
fn done(l: &Ledger, r: Receipt) {
    l.complete(black_box(r), Native::Ok).unwrap();
}
fn settle(l: &Ledger, g: Grant) {
    assert!(l.seal(g, true, false).unwrap().is_none());
    l.barrier(g).unwrap();
}
fn open(l: &Ledger, g: Grant, role: Role) -> Opened {
    let h = l.open_new(g, binding(), role, 0).unwrap();
    l.complete(h.receipt, Native::Opened { length: 0 }).unwrap();
    h
}
fn trace(l: &Ledger, g: Grant, main: Handle, wal: Handle, edit: bool) -> (u64, u64) {
    let frames = if edit { 63 } else { 4471 };
    let mut requests = 0;
    let mut bytes = 0;
    done(l, l.write(g, binding(), wal, 0, 32).unwrap());
    requests += 1;
    bytes += 32;
    for i in 0..frames {
        let offset = 32 + i * 4120;
        done(l, l.write(g, binding(), wal, offset, 24).unwrap());
        done(l, l.write(g, binding(), wal, offset + 24, 4096).unwrap());
        requests += 2;
        bytes += 4120;
    }
    let count = if edit { 56 } else { 4296 };
    for i in 0..count {
        let page = if edit && i >= 15 { 4296 + i - 15 } else { i };
        done(l, l.write(g, binding(), main, page * 4096, 4096).unwrap());
        requests += 1;
        bytes += 4096;
    }
    for index in 0..if edit { 1 } else { 2 } {
        done(l, l.map(g, binding(), main, index).unwrap());
        requests += 1;
    }
    done(l, l.sync(g, binding(), wal).unwrap());
    done(l, l.sync(g, binding(), main).unwrap());
    done(l, l.truncate(g, binding(), wal, 0).unwrap());
    requests += 3;
    (requests, bytes)
}
fn main() {
    let mode = std::env::args().nth(1).unwrap_or_else(|| "trace".into());
    if mode == "contended" {
        contended();
        return;
    }
    let l = Ledger::new().unwrap();
    let rounds = 100u64;
    let mut fresh = Duration::ZERO;
    let mut edit = Duration::ZERO;
    let mut counts = (0, 0, 0, 0);
    for _ in 0..rounds {
        let o = l.register(tag()).unwrap();
        let g = l.arm(o, binding(), grant()).unwrap();
        let m = open(&l, g, Role::Main);
        let w = open(&l, g, Role::Wal);
        let t = Instant::now();
        let a = trace(&l, g, m.handle, w.handle, false);
        fresh += t.elapsed();
        settle(&l, g);
        let g = l.arm(o, binding(), grant()).unwrap();
        let t = Instant::now();
        let b = trace(&l, g, m.handle, w.handle, true);
        edit += t.elapsed();
        settle(&l, g);
        l.close_owner(o, |l| {
            done(l, l.unmap(m.handle).unwrap());
            done(l, l.close_handle(m.handle).unwrap());
            done(l, l.close_handle(w.handle).unwrap());
            true
        })
        .unwrap();
        l.retire_owner(o).unwrap();
        counts = (a.0, a.1, b.0, b.1);
    }
    println!(
        "{{\"workload\":\"synthetic fresh/edit request replay, not native I/O\",\"rounds\":{rounds},\"ledger_inline_bytes\":{},\"fresh_requests\":{},\"fresh_requested_write_bytes\":{},\"fresh_mean_ns\":{},\"fresh_ns_per_request\":{},\"edit_requests\":{},\"edit_requested_write_bytes\":{},\"edit_mean_ns\":{},\"edit_ns_per_request\":{}}}",
        Ledger::inline_bytes(),
        counts.0,
        counts.1,
        fresh.as_nanos() / rounds as u128,
        fresh.as_nanos() / (rounds * counts.0) as u128,
        counts.2,
        counts.3,
        edit.as_nanos() / rounds as u128,
        edit.as_nanos() / (rounds * counts.2) as u128
    );
}
fn contended() {
    let l = Arc::new(Ledger::new().unwrap());
    let o = l.register(tag()).unwrap();
    let g = l.arm(o, binding(), grant()).unwrap();
    let h = open(&l, g, Role::Main);
    let start = Arc::new(Barrier::new(9));
    let mut threads = Vec::new();
    for _ in 0..8 {
        let l = l.clone();
        let b = start.clone();
        threads.push(std::thread::spawn(move || {
            b.wait();
            for _ in 0..10000 {
                done(&l, l.write(g, binding(), h.handle, 0, 1).unwrap());
            }
        }));
    }
    let t = Instant::now();
    start.wait();
    for worker in threads {
        worker.join().unwrap();
    }
    let elapsed = t.elapsed();
    assert_eq!(l.view(o).unwrap().credits.unwrap().w, (64 << 20) - 80000);
    settle(&l, g);
    l.close_owner(o, |l| {
        done(l, l.close_handle(h.handle).unwrap());
        true
    })
    .unwrap();
    l.retire_owner(o).unwrap();
    println!(
        "{{\"workload\":\"8-thread same-offset reserve+complete\",\"requests\":80000,\"elapsed_ns\":{},\"ns_per_request\":{},\"ledger_inline_bytes\":{}}}",
        elapsed.as_nanos(),
        elapsed.as_nanos() / 80000,
        Ledger::inline_bytes()
    );
}
