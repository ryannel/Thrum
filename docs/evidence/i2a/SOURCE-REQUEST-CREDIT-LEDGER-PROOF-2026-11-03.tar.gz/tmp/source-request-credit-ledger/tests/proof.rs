#![forbid(unsafe_code)]
use source_request_credit_ledger::*;
use std::sync::{
    Arc, Barrier,
    atomic::{AtomicUsize, Ordering},
    mpsc,
};
fn tag(n: u8) -> Tag {
    Tag {
        store: [n; 16],
        project: [2; 16],
        epoch: [3; 16],
        policy: [4; 32],
        os_page: 16384,
    }
}
fn binding() -> Binding {
    Binding {
        store: [1; 16],
        project: [2; 16],
        base_generation: 1,
        base_revision: Some([0xA; 32]),
        key: [7; 16],
        target: Some([0xB; 32]),
    }
}
fn budget() -> Credits {
    Credits {
        w: 2 << 20,
        e: 100 << 20,
        s: 131072,
        m: 65536,
    }
}
struct Verifier {
    binding: Binding,
    outcome: SourceOutcome,
}
impl SourceVerifier for Verifier {
    fn lookup(&self, _: Binding) -> Evidence {
        Evidence {
            binding: self.binding,
            outcome: self.outcome,
        }
    }
}
fn settled(l: &Ledger, g: Grant) {
    if let Some(t) = l.seal(g, true, false).unwrap() {
        l.resolve(
            t,
            &Verifier {
                binding: t.binding(),
                outcome: SourceOutcome::NoCommit,
            },
        )
        .unwrap();
    }
    l.barrier(g).unwrap();
}
fn opened(l: &Ledger, g: Grant, b: Binding, role: Role, length: u64) -> Opened {
    let x = l.open_new(g, b, role, length).unwrap();
    l.complete(x.receipt, Native::Opened { length }).unwrap();
    x
}
fn fixture(c: Credits) -> (Ledger, Owner, Grant, Opened) {
    fixture_page(c, 16384)
}
fn fixture_page(c: Credits, os_page: u64) -> (Ledger, Owner, Grant, Opened) {
    let l = Ledger::new().unwrap();
    let o = l.register(Tag { os_page, ..tag(1) }).unwrap();
    let g = l.arm(o, binding(), c).unwrap();
    let h = opened(&l, g, binding(), Role::Main, 0);
    (l, o, g, h)
}
#[test]
fn vector_is_atomic_and_failure_burns_full_range() {
    let (l, o, g, h) = fixture(Credits {
        w: 4096,
        e: 4096,
        m: 2,
        s: 0,
    });
    let before = l.view(o).unwrap();
    assert_eq!(
        l.write(g, binding(), h.handle, 4096, 4096),
        Err(Error::Credit)
    );
    assert_eq!(l.view(o).unwrap(), before);
    let r = l.write(g, binding(), h.handle, 0, 4096).unwrap();
    assert_eq!(l.object_hwm(h.object).unwrap().0, 4096);
    l.complete(r, Native::Failed).unwrap();
    assert_eq!(l.view(o).unwrap().credits.unwrap(), Credits::default());
    assert_eq!(l.object_hwm(h.object).unwrap().0, 4096);
    assert_eq!(l.write(g, binding(), h.handle, 0, 1), Err(Error::Phase));
    settled(&l, g);
    let next = l
        .arm(
            o,
            binding(),
            Credits {
                w: 1,
                ..Credits::default()
            },
        )
        .unwrap();
    let r = l.write(next, binding(), h.handle, 0, 1).unwrap();
    l.complete(r, Native::Ok).unwrap();
    assert_eq!(l.object_hwm(h.object).unwrap().0, 4096);
}
#[test]
fn repeated_offsets_and_shrinks_do_not_refund() {
    let (l, o, g, h) = fixture(Credits {
        w: 2,
        e: 4096,
        m: 3,
        s: 0,
    });
    let r = l.truncate(g, binding(), h.handle, 4096).unwrap();
    l.complete(r, Native::Ok).unwrap();
    assert_eq!(l.object_hwm(h.object).unwrap().0, 4096);
    for _ in 0..2 {
        let r = l.write(g, binding(), h.handle, 0, 1).unwrap();
        l.complete(r, Native::Ok).unwrap();
    }
    assert_eq!(l.write(g, binding(), h.handle, 0, 1), Err(Error::Credit));
    assert_eq!(l.view(o).unwrap().credits.unwrap().e, 0);
}
#[test]
fn mapping_rounding_and_prepaid_cleanup_survive_empty_grant() {
    let (l, o, g, h) = fixture_page(
        Credits {
            w: 0,
            e: 0,
            s: 65536,
            m: 6,
        },
        65536,
    );
    let r = l.map(g, binding(), h.handle, 0).unwrap();
    l.complete(r, Native::Ok).unwrap();
    assert_eq!(l.object_hwm(h.object).unwrap().1, 65536);
    assert_eq!(l.view(o).unwrap().credits.unwrap(), Credits::default());
    assert_eq!(l.close_handle(h.handle), Err(Error::Phase));
    let r = l.unmap(h.handle).unwrap();
    l.complete(r, Native::Ok).unwrap();
    let r = l.close_handle(h.handle).unwrap();
    l.complete(r, Native::Ok).unwrap();
    assert_eq!(l.view(o).unwrap().handles, 0);
    assert_eq!(l.object_hwm(h.object).unwrap().1, 65536);
    settled(&l, g);
    l.close_owner(o, |l| {
        assert_eq!(l.retire_owner(o), Err(Error::Busy));
        true
    })
    .unwrap();
    l.retire_owner(o).unwrap();
    assert_eq!(l.view(o), Err(Error::Stale));
}
#[test]
fn mapping_without_capacity_and_range_overflow_are_noops() {
    let (l, o, g, h) = fixture(Credits {
        m: 6,
        ..Credits::default()
    });
    let before = l.view(o).unwrap();
    assert_eq!(l.map(g, binding(), h.handle, 0), Err(Error::Credit));
    assert_eq!(
        l.write(g, binding(), h.handle, u64::MAX, 1),
        Err(Error::Range)
    );
    assert_eq!(l.map(g, binding(), h.handle, u32::MAX), Err(Error::RoleCap));
    assert_eq!(l.view(o).unwrap(), before);
}
#[test]
fn cleanup_pool_is_not_consumed_by_normal_flights() {
    let (l, o, g, h) = fixture(budget());
    let extra = l.open_existing(g, binding(), h.object).unwrap();
    l.complete(extra.receipt, Native::Opened { length: 0 })
        .unwrap();
    let mut receipts = Vec::new();
    for _ in 0..FLIGHTS {
        receipts.push(l.write(g, binding(), h.handle, 0, 1).unwrap());
    }
    let before = l.view(o).unwrap();
    assert_eq!(l.write(g, binding(), h.handle, 0, 1), Err(Error::Capacity));
    assert_eq!(l.view(o).unwrap(), before);
    let close = l.close_handle(extra.handle).unwrap();
    l.complete(close, Native::Ok).unwrap();
    for r in receipts {
        l.complete(r, Native::Ok).unwrap();
    }
    assert_eq!(l.view(o).unwrap().inflight, 0);
}
#[test]
fn partial_open_keeps_prepaid_close_and_owner_quarantine() {
    let l = Ledger::new().unwrap();
    let o = l.register(tag(1)).unwrap();
    let g = l
        .arm(
            o,
            binding(),
            Credits {
                m: 2,
                ..Credits::default()
            },
        )
        .unwrap();
    let h = l.open_new(g, binding(), Role::Wal, 0).unwrap();
    l.complete(h.receipt, Native::OpenFailed { methods: true })
        .unwrap();
    assert!(l.view(o).unwrap().quarantined);
    assert_eq!(l.view(o).unwrap().credits.unwrap().m, 0);
    let close = l.close_handle(h.handle).unwrap();
    l.complete(close, Native::Ok).unwrap();
    settled(&l, g);
    assert_eq!(l.close_owner(o, |_| true), Err(Error::Quarantined));
    assert_eq!(l.retire_owner(o), Err(Error::Quarantined));
    assert!(l.view(o).unwrap().registration_held);
}
#[test]
fn failed_open_without_methods_and_failed_close_never_release_context() {
    for methods in [false, true] {
        let l = Ledger::new().unwrap();
        let o = l.register(tag(1)).unwrap();
        let g = l
            .arm(
                o,
                binding(),
                Credits {
                    m: 2,
                    ..Credits::default()
                },
            )
            .unwrap();
        let h = l.open_new(g, binding(), Role::Wal, 0).unwrap();
        l.complete(h.receipt, Native::OpenFailed { methods })
            .unwrap();
        if methods {
            let r = l.close_handle(h.handle).unwrap();
            l.complete(r, Native::Failed).unwrap();
            assert_eq!(l.close_handle(h.handle), Err(Error::Busy));
        }
        settled(&l, g);
        assert_eq!(l.retire_owner(o), Err(Error::Quarantined));
        assert!(l.view(o).unwrap().registration_held);
    }
}
#[test]
fn outer_return_is_required_even_after_last_callback() {
    let (l, o, g, h) = fixture(budget());
    settled(&l, g);
    l.close_owner(o, |l| {
        let r = l.close_handle(h.handle).unwrap();
        l.complete(r, Native::Ok).unwrap();
        let v = l.view(o).unwrap();
        assert_eq!(v.handles, 0);
        assert!(v.closing && !v.closed && v.registration_held);
        assert_eq!(l.retire_owner(o), Err(Error::Busy));
        true
    })
    .unwrap();
    assert!(l.view(o).unwrap().closed);
    l.retire_owner(o).unwrap();
}
#[test]
fn outer_panic_and_false_success_hold_finite_quarantine() {
    for panic in [false, true] {
        let (l, o, g, _) = fixture(budget());
        settled(&l, g);
        let result = l.close_owner(o, |_| {
            if panic {
                panic!("mock outer close panic")
            };
            true
        });
        assert_eq!(
            result,
            Err(if panic {
                Error::OuterPanicked
            } else {
                Error::Quarantined
            })
        );
        assert!(l.view(o).unwrap().quarantined);
        assert_eq!(l.retire_owner(o), Err(Error::Quarantined));
    }
    let l = Ledger::new().unwrap();
    for n in 1..=OWNERS as u8 {
        let o = l.register(tag(n)).unwrap();
        assert_eq!(l.close_owner(o, |_| false), Err(Error::Quarantined));
    }
    assert_eq!(l.register(tag(99)), Err(Error::Capacity));
}
#[test]
fn unlink_retains_old_generation_until_explicit_idle_retirement() {
    let l = Ledger::new().unwrap();
    let o = l.register(tag(1)).unwrap();
    let g = l.arm(o, binding(), budget()).unwrap();
    let old = opened(&l, g, binding(), Role::Wal, Role::Wal.cap());
    let d = l.delete(g, binding(), old.object).unwrap();
    l.complete(d, Native::Ok).unwrap();
    let new = opened(&l, g, binding(), Role::Wal, 0);
    assert_eq!(l.write(g, binding(), new.handle, 0, 1), Err(Error::RoleCap));
    let c = l.close_handle(old.handle).unwrap();
    l.complete(c, Native::Ok).unwrap();
    assert_eq!(l.retire_object(o, old.object), Err(Error::Busy));
    settled(&l, g);
    l.retire_object(o, old.object).unwrap();
    let next = l.arm(o, binding(), budget()).unwrap();
    assert_eq!(
        l.open_existing(next, binding(), old.object),
        Err(Error::Stale)
    );
    assert_eq!(l.close_handle(old.handle), Err(Error::Stale));
    let reused = l.open_existing(next, binding(), new.object).unwrap();
    l.complete(reused.receipt, Native::Opened { length: 0 })
        .unwrap();
    assert_ne!(reused.handle, old.handle);
    let w = l.write(next, binding(), reused.handle, 0, 1).unwrap();
    l.complete(w, Native::Ok).unwrap();
    assert_eq!(l.view(o).unwrap().retained[1], 1);
}
#[test]
fn instance_and_owner_generation_prevent_cross_ledger_aba() {
    let (l, o, g, h) = fixture(budget());
    let r = l.write(g, binding(), h.handle, 0, 1).unwrap();
    l.complete(r, Native::Ok).unwrap();
    settled(&l, g);
    l.close_owner(o, |l| {
        let c = l.close_handle(h.handle).unwrap();
        l.complete(c, Native::Ok).unwrap();
        true
    })
    .unwrap();
    l.retire_owner(o).unwrap();
    let again = l.register(tag(1)).unwrap();
    assert_ne!(o, again);
    assert_eq!(l.view(o), Err(Error::Stale));
    let (other, oo, gg, hh) = fixture(budget());
    assert_eq!(other.view(o), Err(Error::Stale));
    assert_eq!(other.close_handle(h.handle), Err(Error::Stale));
    assert_eq!(other.complete(r, Native::Ok), Err(Error::Stale));
    assert!(other.write(gg, binding(), hh.handle, 0, 1).is_ok());
    assert!(other.view(oo).unwrap().registration_held);
}
#[test]
fn uncertain_outcome_is_exact_bound_and_cannot_regrant_itself() {
    let (l, o, g, h) = fixture(budget());
    let t = l.seal(g, true, true).unwrap().unwrap();
    let before = l.view(o).unwrap();
    assert_eq!(l.arm(o, binding(), budget()), Err(Error::Busy));
    let mut wrong = binding();
    wrong.target = Some([99; 32]);
    assert_eq!(
        l.resolve(
            t,
            &Verifier {
                binding: wrong,
                outcome: SourceOutcome::NoCommit
            }
        ),
        Err(Error::OutcomeMismatch)
    );
    assert_eq!(
        l.resolve(
            t,
            &Verifier {
                binding: binding(),
                outcome: SourceOutcome::Unknown
            }
        ),
        Err(Error::OutcomeUnknown)
    );
    assert_eq!(
        l.resolve(
            t,
            &Verifier {
                binding: binding(),
                outcome: SourceOutcome::Committed {
                    generation: 3,
                    revision: [0xB; 32]
                }
            }
        ),
        Err(Error::OutcomeMismatch)
    );
    assert_eq!(l.view(o).unwrap(), before);
    struct Reentrant<'a>(&'a Ledger, Owner);
    impl SourceVerifier for Reentrant<'_> {
        fn lookup(&self, b: Binding) -> Evidence {
            assert!(self.0.view(self.1).unwrap().registration_held);
            Evidence {
                binding: b,
                outcome: SourceOutcome::Committed {
                    generation: 2,
                    revision: [0xB; 32],
                },
            }
        }
    }
    l.resolve(t, &Reentrant(&l, o)).unwrap();
    assert_eq!(l.resolve(t, &Reentrant(&l, o)), Err(Error::Stale));
    l.barrier(g).unwrap();
    let new = l.arm(o, binding(), budget()).unwrap();
    assert_ne!(new, g);
    assert_eq!(l.write(new, wrong, h.handle, 0, 1), Err(Error::Binding));
    let (other, _, _, _) = fixture(budget());
    assert_eq!(
        other.resolve(
            t,
            &Verifier {
                binding: binding(),
                outcome: SourceOutcome::NoCommit
            }
        ),
        Err(Error::Stale)
    );
}
#[test]
fn inflight_barrier_and_close_races_fail_closed() {
    let (l, o, g, h) = fixture(budget());
    let l = Arc::new(l);
    let (sync_tx, sync_rx) = mpsc::channel();
    let release = Arc::new(Barrier::new(2));
    let child_l = l.clone();
    let child_release = release.clone();
    let worker = std::thread::spawn(move || {
        let r = child_l.write(g, binding(), h.handle, 0, 4096).unwrap();
        sync_tx.send(r).unwrap();
        child_release.wait();
        child_l.complete(r, Native::Failed).unwrap();
    });
    let receipt = sync_rx.recv().unwrap();
    assert_eq!(l.seal(g, true, false), Err(Error::Busy));
    assert_eq!(l.close_owner(o, |_| true), Err(Error::Busy));
    assert_eq!(l.arm(o, binding(), budget()), Err(Error::Busy));
    release.wait();
    worker.join().unwrap();
    settled(&l, g);
    let _new = l.arm(o, binding(), budget()).unwrap();
    assert_eq!(l.complete(receipt, Native::Ok), Err(Error::Stale));
}
#[test]
fn eight_thread_reservation_is_all_or_nothing() {
    let (l, o, g, h) = fixture(Credits {
        w: 4096,
        e: 4096,
        m: 2,
        s: 0,
    });
    let l = Arc::new(l);
    let b = Arc::new(Barrier::new(8));
    let accepted = Arc::new(AtomicUsize::new(0));
    let mut workers = Vec::new();
    for _ in 0..8 {
        let l = l.clone();
        let b = b.clone();
        let count = accepted.clone();
        workers.push(std::thread::spawn(move || {
            b.wait();
            let r = l.write(g, binding(), h.handle, 0, 1024);
            b.wait();
            if let Ok(r) = r {
                count.fetch_add(1, Ordering::Relaxed);
                l.complete(r, Native::Ok).unwrap();
            }
        }));
    }
    for w in workers {
        w.join().unwrap();
    }
    assert_eq!(accepted.load(Ordering::Relaxed), 4);
    let v = l.view(o).unwrap();
    assert_eq!(v.credits.unwrap().w, 0);
    assert_eq!(v.credits.unwrap().e, 3072);
    assert_eq!(v.inflight, 0);
}

// Independent reference: append-only accepted-event log, then recompute all
// work/metadata sums and per-object maxima. It never uses ledger slots/debits.
#[derive(Clone, Copy)]
enum Event {
    Write { object: usize, end: u64, n: u64 },
    Truncate { object: usize, end: u64 },
    Map { end: u64 },
}
fn reduce(events: &[Event], base: [u64; 2], map_base: u64) -> (Credits, [u64; 2], u64) {
    let mut ends = base;
    let mut map = map_base;
    let mut c = Credits::default();
    for &e in events {
        match e {
            Event::Write { object, end, n } => {
                ends[object] = ends[object].max(end);
                c.w += n;
            }
            Event::Truncate { object, end } => {
                ends[object] = ends[object].max(end);
                c.m += 1
            }
            Event::Map { end } => {
                map = map.max(end);
                c.m += 4
            }
        }
    }
    c.e = (ends[0] - base[0]) + (ends[1] - base[1]);
    c.s = map - map_base;
    (c, ends, map)
}
fn fits(c: Credits, b: Credits) -> bool {
    c.w <= b.w && c.e <= b.e && c.s <= b.s && c.m <= b.m
}
#[test]
fn deterministic_trace_matches_independent_reduction() {
    let l = Ledger::new().unwrap();
    let o = l.register(tag(1)).unwrap();
    let mut g = l.arm(o, binding(), budget()).unwrap();
    let a = opened(&l, g, binding(), Role::Main, 0);
    let b = opened(&l, g, binding(), Role::Wal, 0);
    settled(&l, g);
    let cap = Credits {
        w: 16384,
        e: 16384,
        s: 65536,
        m: 32,
    };
    let mut base = [0; 2];
    let mut map_base = 0;
    let mut events = Vec::new();
    g = l.arm(o, binding(), cap).unwrap();
    let mut seed = 0x19327834u64;
    let mut accepted = 0;
    let mut denied = 0;
    for step in 0..4096 {
        seed = seed
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        let object = ((seed >> 32) & 1) as usize;
        let handle = if object == 0 { a.handle } else { b.handle };
        let end = ((seed >> 17) % 24 + 1) * 1024;
        let kind = seed % 3;
        let event = match kind {
            0 => Event::Write {
                object,
                end,
                n: 1024,
            },
            1 => Event::Truncate { object, end },
            _ => Event::Map {
                end: if seed & 8 == 0 { 32768 } else { 65536 },
            },
        };
        let mut candidate = events.clone();
        candidate.push(event);
        let (cost, _, _) = reduce(&candidate, base, map_base);
        let expected = fits(cost, cap);
        let actual = match event {
            Event::Write { end, n, .. } => l.write(g, binding(), handle, end - n, n),
            Event::Truncate { end, .. } => l.truncate(g, binding(), handle, end),
            Event::Map { end } => l.map(g, binding(), a.handle, (end / 32768 - 1) as u32),
        };
        assert_eq!(actual.is_ok(), expected, "step={step}");
        let fail = actual.is_ok() && seed.is_multiple_of(19);
        if let Ok(r) = actual {
            events.push(event);
            l.complete(r, if fail { Native::Failed } else { Native::Ok })
                .unwrap();
            accepted += 1
        } else {
            denied += 1;
        }
        let (cost, ends, map) = reduce(&events, base, map_base);
        let v = l.view(o).unwrap();
        assert_eq!(
            v.credits.unwrap(),
            Credits {
                w: cap.w - cost.w,
                e: cap.e - cost.e,
                s: cap.s - cost.s,
                m: cap.m - cost.m
            }
        );
        assert_eq!(l.object_hwm(a.object).unwrap().0, ends[0]);
        assert_eq!(l.object_hwm(b.object).unwrap().0, ends[1]);
        if step % 16 == 15 || fail {
            settled(&l, g);
            base = ends;
            map_base = map;
            events.clear();
            g = l.arm(o, binding(), cap).unwrap();
        }
    }
    eprintln!("reference_trace steps=4096 accepted={accepted} denied={denied}");
}
#[test]
fn three_thread_results_have_a_reference_linearization() {
    let mut observed_masks = [0u64; 8];
    for _ in 0..64 {
        let (l, o, g, h) = fixture(Credits {
            w: 3072,
            e: 4096,
            m: 2,
            s: 0,
        });
        let l = Arc::new(l);
        let b = Arc::new(Barrier::new(3));
        let mut threads = Vec::new();
        for i in 0..3 {
            let l = l.clone();
            let b = b.clone();
            threads.push(std::thread::spawn(move || {
                b.wait();
                let r = l.write(g, binding(), h.handle, i * 1024, 2048);
                b.wait();
                if let Ok(r) = r {
                    l.complete(r, Native::Ok).unwrap();
                    true
                } else {
                    false
                }
            }));
        }
        let got: Vec<_> = threads.into_iter().map(|h| h.join().unwrap()).collect();
        let mask = got
            .iter()
            .enumerate()
            .map(|(i, &yes)| usize::from(yes) << i)
            .sum::<usize>();
        observed_masks[mask] += 1;
        let v = l.view(o).unwrap().credits.unwrap();
        let permutations = [
            [0, 1, 2],
            [0, 2, 1],
            [1, 0, 2],
            [1, 2, 0],
            [2, 0, 1],
            [2, 1, 0],
        ];
        assert!(permutations.iter().any(|order| {
            let mut log = Vec::new();
            let mut decisions = [false; 3];
            for &i in order {
                let e = Event::Write {
                    object: 0,
                    end: (i as u64 + 2) * 1024,
                    n: 2048,
                };
                let mut next = log.clone();
                next.push(e);
                if fits(
                    reduce(&next, [0; 2], 0).0,
                    Credits {
                        w: 3072,
                        e: 4096,
                        m: 0,
                        s: 0,
                    },
                ) {
                    log = next;
                    decisions[i] = true;
                }
            }
            let c = reduce(&log, [0; 2], 0).0;
            decisions == got.as_slice() && v.w == 3072 - c.w && v.e == 4096 - c.e
        }));
    }
    eprintln!("reference_linearization trials=64 accepted_masks={observed_masks:?}");
}
#[test]
fn inline_memory_is_finite() {
    assert!(Ledger::inline_bytes() <= 65536);
    eprintln!(
        "ledger_inline_bytes={} owner_slots={OWNERS} object_slots={OBJECTS} handle_slots={HANDLES} normal_flights={FLIGHTS}",
        Ledger::inline_bytes()
    );
}
#[test]
fn receipt_reuse_cannot_complete_another_flight() {
    let (l, o, g, h) = fixture(budget());
    let old = l.write(g, binding(), h.handle, 0, 1).unwrap();
    l.complete(old, Native::Ok).unwrap();
    let current = l.write(g, binding(), h.handle, 1, 1).unwrap();
    let before = l.view(o).unwrap();
    assert_eq!(l.complete(old, Native::Ok), Err(Error::Stale));
    assert_eq!(l.view(o).unwrap(), before);
    l.complete(current, Native::Ok).unwrap();
    assert_eq!(l.view(o).unwrap().inflight, 0);
}
#[test]
fn parallel_retirement_waits_for_outer_function_return() {
    let (l, o, g, h) = fixture(budget());
    settled(&l, g);
    let l = Arc::new(l);
    let hit = Arc::new(Barrier::new(2));
    let leave = Arc::new(Barrier::new(2));
    let ll = l.clone();
    let hh = hit.clone();
    let ee = leave.clone();
    let thread = std::thread::spawn(move || {
        ll.close_owner(o, |l| {
            let c = l.close_handle(h.handle).unwrap();
            l.complete(c, Native::Ok).unwrap();
            hh.wait();
            ee.wait();
            true
        })
    });
    hit.wait();
    let state = l.view(o).unwrap();
    assert_eq!(state.handles, 0);
    assert!(state.closing && !state.closed);
    assert_eq!(l.retire_owner(o), Err(Error::Busy));
    assert_eq!(l.register(tag(1)), Err(Error::Busy));
    leave.wait();
    thread.join().unwrap().unwrap();
    l.retire_owner(o).unwrap();
}
#[test]
fn slow_outcome_resolution_cannot_settle_a_regranted_operation() {
    let (l, o, g, _) = fixture(budget());
    let l = Arc::new(l);
    let token = l.seal(g, true, true).unwrap().unwrap();
    let hit = Arc::new(Barrier::new(2));
    let leave = Arc::new(Barrier::new(2));
    struct Slow {
        hit: Arc<Barrier>,
        leave: Arc<Barrier>,
    }
    impl SourceVerifier for Slow {
        fn lookup(&self, b: Binding) -> Evidence {
            self.hit.wait();
            self.leave.wait();
            Evidence {
                binding: b,
                outcome: SourceOutcome::NoCommit,
            }
        }
    }
    let ll = l.clone();
    let provider = Slow {
        hit: hit.clone(),
        leave: leave.clone(),
    };
    let task = std::thread::spawn(move || ll.resolve(token, &provider));
    hit.wait();
    l.resolve(
        token,
        &Verifier {
            binding: binding(),
            outcome: SourceOutcome::NoCommit,
        },
    )
    .unwrap();
    l.barrier(g).unwrap();
    let mut next_binding = binding();
    next_binding.key = [8; 16];
    let next = l.arm(o, next_binding, budget()).unwrap();
    let before = l.view(o).unwrap();
    leave.wait();
    assert_eq!(task.join().unwrap(), Err(Error::Stale));
    assert_eq!(l.view(o).unwrap(), before);
    assert_ne!(next, g);
}
#[test]
fn closed_owner_still_holds_uncertain_outcome_until_verified_barrier() {
    let (l, o, g, h) = fixture(budget());
    let token = l.seal(g, true, true).unwrap().unwrap();
    l.close_owner(o, |l| {
        let c = l.close_handle(h.handle).unwrap();
        l.complete(c, Native::Ok).unwrap();
        true
    })
    .unwrap();
    assert!(l.view(o).unwrap().closed);
    assert_eq!(l.retire_owner(o), Err(Error::Busy));
    assert_eq!(
        l.resolve(
            token,
            &Verifier {
                binding: binding(),
                outcome: SourceOutcome::Unknown
            }
        ),
        Err(Error::OutcomeUnknown)
    );
    l.resolve(
        token,
        &Verifier {
            binding: binding(),
            outcome: SourceOutcome::Committed {
                generation: 2,
                revision: [0xB; 32],
            },
        },
    )
    .unwrap();
    l.barrier(g).unwrap();
    l.retire_owner(o).unwrap();
    assert_eq!(l.view(o), Err(Error::Stale));
}
#[test]
fn every_source_binding_component_and_cross_owner_handle_are_immutable() {
    let (l, o, g, h) = fixture(budget());
    let mut variants = Vec::new();
    let b = binding();
    let mut x = b;
    x.store = [99; 16];
    variants.push(x);
    let mut x = b;
    x.project = [99; 16];
    variants.push(x);
    let mut x = b;
    x.base_generation = 2;
    variants.push(x);
    let mut x = b;
    x.base_revision = Some([99; 32]);
    variants.push(x);
    let mut x = b;
    x.key = [99; 16];
    variants.push(x);
    let mut x = b;
    x.target = Some([99; 32]);
    variants.push(x);
    let before = l.view(o).unwrap();
    for bad in variants {
        assert_eq!(l.write(g, bad, h.handle, 0, 1), Err(Error::Binding));
        assert_eq!(l.view(o).unwrap(), before);
    }
    let other = l.register(tag(2)).unwrap();
    let mut b2 = binding();
    b2.store = [2; 16];
    let g2 = l.arm(other, b2, budget()).unwrap();
    let untouched = l.view(other).unwrap();
    assert_eq!(l.write(g2, b2, h.handle, 0, 1), Err(Error::Binding));
    assert_eq!(l.view(other).unwrap(), untouched);
}

#[test]
fn immutable_owner_mapping_policy_cannot_be_chosen_per_request() {
    let c = Credits {
        s: 32768,
        m: 6,
        ..Credits::default()
    };
    let (a, _, ga, ha) = fixture_page(c, 16384);
    let r = a.map(ga, binding(), ha.handle, 0).unwrap();
    a.complete(r, Native::Ok).unwrap();
    let (b, ob, gb, hb) = fixture_page(c, 65536);
    let before = b.view(ob).unwrap();
    assert_eq!(b.map(gb, binding(), hb.handle, 0), Err(Error::Credit));
    assert_eq!(b.view(ob).unwrap(), before);
    for page in [0, 3, 131072] {
        let l = Ledger::new().unwrap();
        assert_eq!(
            l.register(Tag {
                os_page: page,
                ..tag(1)
            }),
            Err(Error::Range)
        );
        assert!(l.register(tag(1)).is_ok());
    }
}
