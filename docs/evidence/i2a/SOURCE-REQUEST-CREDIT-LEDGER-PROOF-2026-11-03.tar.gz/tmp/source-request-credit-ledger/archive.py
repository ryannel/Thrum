#!/usr/bin/env python3
"""Freeze selected text inputs/logs; byte-verify before build-output cleanup."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).resolve().parent
repo=root.parents[1]
report=repo/'docs/evidence/i2a/SOURCE-REQUEST-CREDIT-LEDGER-2026-11-03.md'
archive=repo/'docs/evidence/i2a/SOURCE-REQUEST-CREDIT-LEDGER-PROOF-2026-11-03.tar.gz'
files={str(p.relative_to(repo)):p.read_bytes() for p in root.rglob('*') if p.is_file() and p.relative_to(root).parts[0]!='target' and p.name!='archive-result.json'}
files[str(report.relative_to(repo))]=report.read_bytes()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in sorted(files.items())}
files['EVIDENCE-SHA256.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as z,tarfile.open(fileobj=z,mode='w') as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
 assert set(tar.getnames())==set(files)
 for name,data in files.items():assert tar.extractfile(name).read()==data,name
result={'path':str(archive.relative_to(repo)),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'verified_members':len(files)}
(root/'archive-result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
