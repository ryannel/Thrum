#!/usr/bin/env python3
"""Reproducible checks first, then isolated release workers with wait4 RSS."""
from pathlib import Path
import json,os,subprocess,hashlib,platform
ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw';RAW.mkdir(exist_ok=True)
ENV=os.environ.copy();ENV['RUSTC_WRAPPER']=''
spec=json.loads((ROOT/'inputs.json').read_text());assert f"0x{spec['reference_trace']['seed']:08x}u64" in (ROOT/'tests/proof.rs').read_text(), 'declared seed differs from executable trace'
base=['rustup','run','1.99.1','cargo'];manifest=['--locked','--offline','--manifest-path',str(ROOT/'Cargo.toml')]
for label,command in [('fmt',base+['fmt','--manifest-path',str(ROOT/'Cargo.toml'),'--check']),('clippy',base+['clippy']+manifest+['--all-targets','--','-D','warnings']),('debug-tests',base+['test']+manifest+['--','--nocapture']),('release-tests',base+['test']+manifest+['--release','--','--nocapture']),('build',base+['build']+manifest+['--release'])]:
 with (RAW/(label+'.log')).open('w')as log:
  log.write('RUSTC_WRAPPER= '+' '.join(command)+'\n');log.flush();result=subprocess.run(command,cwd=ROOT,env=ENV,stdout=log,stderr=subprocess.STDOUT);log.write('exit_code='+str(result.returncode)+'\n');assert result.returncode==0,(label,RAW/(label+'.log'))
binary=ROOT/'target/release/source-request-credit-ledger';workers=[]
for mode in ('trace','contended'):
 with (RAW/(mode+'.jsonl')).open('w')as out,(RAW/(mode+'.stderr')).open('w')as err:
  p=subprocess.Popen([str(binary),mode],cwd=ROOT,env=ENV,stdout=out,stderr=err)
  _,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 record={'mode':mode,'command':[str(binary),mode],'returncode':p.returncode,'peak_rss_bytes_macos':usage.ru_maxrss,'user_s':usage.ru_utime,'system_s':usage.ru_stime};workers.append(record);print(json.dumps(record),flush=True);assert p.returncode==0
(RAW/'workers.json').write_text(json.dumps(workers,indent=2)+'\n')
files=[p for p in ROOT.rglob('*')if p.is_file()and p.relative_to(ROOT).parts[0]not in ('target','raw')and p.name!='tool-identity.json']+[binary]
identity={'sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files},'environment':{'platform':platform.platform(),'machine':platform.machine(),'python':platform.python_version()},'commands':{}}
for command in [['rustup','run','1.99.1','rustc','-Vv'],['sw_vers'],['git','rev-parse','HEAD']]:
 result=subprocess.run(command,text=True,capture_output=True);identity['commands'][' '.join(command)]=result.stdout+result.stderr
(ROOT/'tool-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
