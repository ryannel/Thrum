#!/usr/bin/env python3
"""Package only selected source/config/raw inputs; verify every member's bytes."""
from pathlib import Path
import hashlib,json,tarfile
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent.parent
REPORT=REPO/'docs/design/research/SOURCE-REQUESTED-IO-FENCE-2026-11-03.md'
ARCHIVE=REPO/'docs/evidence/i2a/SOURCE-REQUESTED-IO-FENCE-PROOF-2026-11-03.tar.gz'
pairs=[(str(p.relative_to(ROOT)),p)for p in ROOT.rglob('*')if p.is_file()and p.relative_to(ROOT).parts[0]not in ('target','runs')and p.name!='evidence-sha256.json']
pairs.append((REPORT.name,REPORT))
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest()for name,p in pairs}
(ROOT/'evidence-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
pairs.append(('evidence-sha256.json',ROOT/'evidence-sha256.json'))
with tarfile.open(ARCHIVE,'w:gz')as archive:
 for name,p in sorted(pairs):
  info=archive.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb')as data:archive.addfile(info,data)
with tarfile.open(ARCHIVE,'r:gz')as archive:
 for name,digest in manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,name
 assert json.load(archive.extractfile('evidence-sha256.json'))==manifest
print(json.dumps({'archive':str(ARCHIVE),'sha256':hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),'bytes':ARCHIVE.stat().st_size,'verified_members':len(pairs)}))
