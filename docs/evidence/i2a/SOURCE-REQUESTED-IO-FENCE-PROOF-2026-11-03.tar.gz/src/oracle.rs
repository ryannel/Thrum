//! Safe executable dispatch oracle, not a SQLite VFS or physical allocator.
use serde_json::json;
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Mutant {
    None,
    SkipWork,
    DedupOverwrite,
    RefundFailure,
    SkipGrowth,
    SkipTruncate,
    SkipShmRead,
    RoundShmDown,
    ForwardHint,
    AllowTemp,
    SkipDelete,
    RefundLiveDelete,
    IgnoreRecovery,
    FreeRegistration,
    PartialDebit,
}
#[derive(Clone, Copy, Default)]
struct Slot {
    hwm: u64,
    cap: u64,
    open: bool,
}
struct Fence {
    work: u64,
    growth: u64,
    maps: u64,
    ops: u64,
    slots: [Slot; 4],
    map_hwm: u64,
    native_calls: u64,
    blocked: bool,
    mutant: Mutant,
}
impl Fence {
    fn new(work: u64, growth: u64, maps: u64, ops: u64, mutant: Mutant) -> Self {
        Self {
            work,
            growth,
            maps,
            ops,
            slots: [Slot {
                cap: 65536,
                ..Slot::default()
            }; 4],
            map_hwm: 0,
            native_calls: 0,
            blocked: false,
            mutant,
        }
    }
    fn reserve(&mut self, w: u64, g: u64, s: u64, m: u64) -> bool {
        if self.blocked && self.mutant != Mutant::IgnoreRecovery {
            return false;
        }
        if self.mutant == Mutant::PartialDebit && w <= self.work {
            self.work -= w;
            return g <= self.growth && s <= self.maps && m <= self.ops;
        }
        if w > self.work || g > self.growth || s > self.maps || m > self.ops {
            return false;
        }
        self.work -= w;
        self.growth -= g;
        self.maps -= s;
        self.ops -= m;
        true
    }
    fn open(&mut self, id: usize, temp: bool) -> bool {
        if temp && self.mutant != Mutant::AllowTemp {
            return false;
        }
        if self.slots[id].open || !self.reserve(0, 0, 0, 2) {
            return false;
        }
        self.slots[id].open = true;
        self.native_calls += 1;
        true
    }
    fn write(&mut self, id: usize, offset: u64, n: u64, fail_partial: bool) -> bool {
        let Some(end) = offset.checked_add(n) else {
            return false;
        };
        let slot = self.slots[id];
        if end > slot.cap {
            return false;
        }
        let growth = if self.mutant == Mutant::SkipGrowth {
            0
        } else {
            end.saturating_sub(slot.hwm)
        };
        let w = if self.mutant == Mutant::SkipWork
            || (self.mutant == Mutant::DedupOverwrite && end <= slot.hwm)
        {
            0
        } else {
            n
        };
        if !self.reserve(w, growth, 0, 0) {
            return false;
        }
        self.slots[id].hwm = slot.hwm.max(end);
        self.native_calls += 1;
        if fail_partial && self.mutant == Mutant::RefundFailure {
            self.work += w;
            self.growth += growth;
        }
        !fail_partial
    }
    fn truncate(&mut self, id: usize, n: u64) -> bool {
        let slot = self.slots[id];
        if n > slot.cap {
            return false;
        }
        let g = if self.mutant == Mutant::SkipTruncate {
            0
        } else {
            n.saturating_sub(slot.hwm)
        };
        if !self.reserve(0, g, 0, 1) {
            return false;
        }
        self.slots[id].hwm = slot.hwm.max(n);
        self.native_calls += 1;
        true
    }
    fn map(&mut self, index: u64, extend: bool, os_page: u64) -> bool {
        let Some(end) = index.checked_add(1).and_then(|i| i.checked_mul(32768)) else {
            return false;
        };
        let group = os_page.max(32768);
        let rounded = if self.mutant == Mutant::RoundShmDown {
            end
        } else {
            let Some(x) = end.checked_add(group - 1) else {
                return false;
            };
            x / group * group
        };
        if rounded > 131072 {
            return false;
        }
        let growth = if !extend && self.mutant == Mutant::SkipShmRead {
            0
        } else {
            rounded.saturating_sub(self.map_hwm)
        };
        if !self.reserve(0, 0, growth, 4) {
            return false;
        }
        self.map_hwm = self.map_hwm.max(rounded);
        self.native_calls += 1;
        true
    }
    fn hint(&mut self) {
        if self.mutant == Mutant::ForwardHint {
            self.native_calls += 1;
        }
    }
    fn delete(&mut self, id: usize) -> bool {
        let m = u64::from(self.mutant != Mutant::SkipDelete);
        if !self.reserve(0, 0, 0, m) {
            return false;
        }
        self.native_calls += 1;
        if self.slots[id].open && self.mutant == Mutant::RefundLiveDelete {
            self.growth += self.slots[id].hwm;
        }
        true
    }
}
fn case(which: Mutant, m: Mutant) -> bool {
    use Mutant::*;
    match which {
        SkipWork => {
            let mut f = Fence::new(0, 4096, 0, 0, m);
            !f.write(0, 0, 1, false) && f.native_calls == 0
        }
        DedupOverwrite => {
            let mut f = Fence::new(1, 1, 0, 0, m);
            f.write(0, 0, 1, false) && !f.write(0, 0, 1, false) && f.native_calls == 1
        }
        RefundFailure => {
            let mut f = Fence::new(4096, 4096, 0, 0, m);
            !f.write(0, 0, 4096, true) && !f.write(0, 0, 1, false) && f.native_calls == 1
        }
        SkipGrowth => {
            let mut f = Fence::new(1, 4096, 0, 0, m);
            !f.write(0, 65535, 1, false) && f.native_calls == 0
        }
        SkipTruncate => {
            let mut f = Fence::new(0, 0, 0, 1, m);
            !f.truncate(0, 4096) && f.native_calls == 0
        }
        SkipShmRead => {
            let mut f = Fence::new(0, 0, 0, 4, m);
            !f.map(0, false, 16384) && f.native_calls == 0
        }
        RoundShmDown => {
            let mut f = Fence::new(0, 0, 32768, 4, m);
            !f.map(0, true, 65536) && f.native_calls == 0
        }
        ForwardHint => {
            let mut f = Fence::new(0, 0, 0, 0, m);
            f.hint();
            f.native_calls == 0
        }
        AllowTemp => {
            let mut f = Fence::new(0, 0, 0, 2, m);
            !f.open(0, true) && f.native_calls == 0
        }
        SkipDelete => {
            let mut f = Fence::new(0, 0, 0, 0, m);
            !f.delete(0) && f.native_calls == 0
        }
        RefundLiveDelete => {
            let mut f = Fence::new(8192, 4096, 0, 5, m);
            f.open(0, false)
                && f.write(0, 0, 4096, false)
                && f.delete(0)
                && f.open(1, false)
                && !f.write(1, 0, 4096, false)
        }
        IgnoreRecovery => {
            let mut f = Fence::new(4096, 4096, 0, 0, m);
            f.blocked = true;
            !f.write(0, 0, 1, false) && f.native_calls == 0
        }
        FreeRegistration => {
            let active_files = 1;
            let close_in_progress = true;
            let may_free = if m == FreeRegistration {
                true
            } else {
                active_files == 0 && !close_in_progress
            };
            !may_free
        }
        PartialDebit => {
            let mut f = Fence::new(4, 0, 0, 1, m);
            !f.reserve(4, 4, 0, 1) && f.work == 4 && f.ops == 1
        }
        None => unreachable!(),
    }
}
fn main() {
    use Mutant::*;
    let mutants = [
        SkipWork,
        DedupOverwrite,
        RefundFailure,
        SkipGrowth,
        SkipTruncate,
        SkipShmRead,
        RoundShmDown,
        ForwardHint,
        AllowTemp,
        SkipDelete,
        RefundLiveDelete,
        IgnoreRecovery,
        FreeRegistration,
        PartialDebit,
    ];
    let rows: Vec<_> = mutants
        .iter()
        .map(|&m| {
            let good = case(m, None);
            let killed = !case(m, m);
            assert!(good && killed, "{m:?}: reference={good} killed={killed}");
            json!({"case":format!("{m:?}"),"reference_pass":good,"mutant_killed":killed})
        })
        .collect();
    println!(
        "{}",
        json!({"model":"serial requested-API dispatch; no native allocation or crash durability", "ledger_size_bytes":std::mem::size_of::<Fence>(),"cases":rows})
    );
}
