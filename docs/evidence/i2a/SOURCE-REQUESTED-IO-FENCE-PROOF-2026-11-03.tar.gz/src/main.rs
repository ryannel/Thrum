use rusqlite::{Connection, OpenFlags};
use serde_json::{Value, json};
use std::{
    ffi::{CString, c_char},
    fs,
    os::unix::fs::MetadataExt,
    path::{Path, PathBuf},
    time::Instant,
};
use thrum_source::{
    SourcePath, StagedTree,
    provisional_store::{ProvisionalSourceStore, PublicationStatus},
    registry_stage::validate_staged_candidate,
    stage_declared_tree,
};
const PROJECT: &str = "2a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SCENE: &str = "3a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const HISTORY: &str = "4a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SOURCE: &str = "10000000-0000-4000-8000-000000000001";
const LIGHT: &str = "10000000-0000-4000-8000-000000000002";
const SOURCE_PATH: &str = "records/environment.record.json";
// Scratch-only serial C ABI; fixed caller-owned counters, no production linkage.
unsafe extern "C" {
    fn credit_after_open(expected: *const c_char) -> i32;
    fn credit_init(mode: i32, scheduled: i32) -> i32;
    fn credit_bind(expected: *const c_char) -> i32;
    fn credit_reset(grant: u64);
    fn credit_stats(out: *mut u64);
}
fn db(root: &Path) -> PathBuf {
    root.join("store/provisional-source.sqlite")
}
fn fixture(root: &Path, tiny: usize, large: usize) -> Vec<SourcePath> {
    let p = root.join("project");
    for d in ["records", "scenes", "schemas", "notes", "masters"] {
        fs::create_dir_all(p.join(d)).unwrap();
    }
    fs::create_dir_all(root.join("store")).unwrap();
    let records = [
        SOURCE_PATH,
        "records/light.record.json",
        "scenes/main.scene.json",
    ];
    let files = [
        (
            "project.json",
            json!({"id":PROJECT,"type":"core.project","schema":2,"fields":{"project.format":1,"project.records":records,"project.schemas":[],"project.registryHistory":"schemas/history.registry.json","project.entryScenes":[SCENE]}}),
        ),
        (
            SOURCE_PATH,
            json!({"id":SOURCE,"type":"thrum.environment.authored","schema":1,"fields":{"profile":"constant-light-v1","sun":{"light_ref":LIGHT,"toward_source_unit":[0,1,0],"perpendicular_illuminance_lux":100000,"unit_luminance_linear_rec709":[1,1,1],"angular_radius_rad":0.00465,"direction_model":"geometric-straight","applied_attenuation":[]},"ambient_irradiance_lux":[1000,1000,1000],"background_radiance_cd_m2":[0,0,0],"unsupported":["wind","cloud_tau","precipitation","air","thermal","moon","air_quality"],"x.thrum.environment.note":{"retained":true}}}),
        ),
        (
            "records/light.record.json",
            json!({"id":LIGHT,"type":"thrum.light.identity","schema":1,"fields":{"driver_binding":"incoming-environment-sun"}}),
        ),
        (
            "scenes/main.scene.json",
            json!({"id":SCENE,"type":"core.scene","schema":2,"fields":{"environment.source":SOURCE}}),
        ),
        (
            "schemas/history.registry.json",
            json!({"id":HISTORY,"type":"core.registry-history","schema":1,"fields":{"registry.fields":[],"registry.versions":[]}}),
        ),
    ];
    let mut paths = Vec::new();
    for (pth, v) in files {
        fs::write(p.join(pth), serde_json::to_vec(&v).unwrap()).unwrap();
        paths.push(SourcePath::parse(pth).unwrap());
    }
    for n in 0..tiny {
        let path = format!("notes/{n:04}.txt");
        let mut b = vec![b'x'; 4096];
        b[..8].copy_from_slice(&(n as u64).to_le_bytes());
        fs::write(p.join(&path), b).unwrap();
        paths.push(SourcePath::parse(&path).unwrap());
    }
    if large > 0 {
        fs::write(p.join("masters/large.bin"), vec![0x42; large]).unwrap();
        paths.push(SourcePath::parse("masters/large.bin").unwrap());
    }
    paths
}
fn capture(root: &Path, paths: &[SourcePath]) -> StagedTree {
    stage_declared_tree(&root.join("project"), paths).unwrap()
}
fn edit(root: &Path, n: u64, large: bool) {
    let p = root.join("project").join(SOURCE_PATH);
    let mut v: Value = serde_json::from_slice(&fs::read(&p).unwrap()).unwrap();
    v["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(75000 + n);
    fs::write(p, serde_json::to_vec(&v).unwrap()).unwrap();
    if large {
        use std::io::{Seek, Write};
        let mut f = fs::OpenOptions::new()
            .write(true)
            .open(root.join("project/masters/large.bin"))
            .unwrap();
        f.seek(std::io::SeekFrom::Start(0)).unwrap();
        f.write_all(&n.to_le_bytes()).unwrap();
    }
}
fn fstat(p: &Path) -> Value {
    match fs::metadata(p) {
        Ok(m) => json!({"length":m.len(),"allocated":m.blocks()*512}),
        Err(_) => Value::Null,
    }
}
fn snap(root: &Path) -> Value {
    let conn = Connection::open_with_flags(db(root), OpenFlags::SQLITE_OPEN_READ_ONLY).unwrap();
    json!({"main":fstat(&db(root)),"wal":fstat(&root.join("store/provisional-source.sqlite-wal")),"free":fs4::available_space(root.join("store")).unwrap(),"pages":conn.query_row("PRAGMA page_count",[],|r|r.get::<_,i64>(0)).unwrap(),"freelist":conn.query_row("PRAGMA freelist_count",[],|r|r.get::<_,i64>(0)).unwrap()})
}

fn stats() -> [u64; 16] {
    let mut out = [0; 16];
    unsafe { credit_stats(out.as_mut_ptr()) };
    out
}
fn checkpoint(root: &Path, observed: bool) -> Value {
    let c = Connection::open(db(root)).unwrap();
    let n: i64 = c.query_row("PRAGMA page_count", [], |r| r.get(0)).unwrap();
    let (busy, l, k): (i64, i64, i64) = c
        .query_row("PRAGMA wal_checkpoint(NOOP)", [], |r| {
            Ok((r.get(0)?, r.get(1)?, r.get(2)?))
        })
        .unwrap();
    assert_eq!(busy, 0);
    assert!(l >= k && k >= 0);
    let data_bound = n.min(l - k) as u64 * 4096;
    let available = fs4::available_space(root.join("store")).unwrap();
    assert!(
        available >= 8 * 1024 * 1024 * 1024 + data_bound,
        "scratch floor/debt precheck"
    );
    let before = stats();
    let t = Instant::now();
    let result: (i64, i64, i64) = c
        .query_row("PRAGMA wal_checkpoint(TRUNCATE)", [], |r| {
            Ok((r.get(0)?, r.get(1)?, r.get(2)?))
        })
        .unwrap();
    assert_eq!(result.0, 0);
    let after = stats();
    assert!(
        after[8] - before[8] <= data_bound,
        "checkpoint exceeded distinct-page data-write bound"
    );
    json!({"elapsed_ms":t.elapsed().as_secs_f64()*1000.,"frames":l,"backfilled":k,"pages":n,"data_write_bound":data_bound,"observed_main_write_bytes":if observed{Some(after[8]-before[8])}else{None}})
}
fn run(root: &Path, scheduled: bool, observed: bool) {
    let paths = fixture(root, 1000, 12 * 1024 * 1024);
    let stage = capture(root, &paths);
    let a = validate_staged_candidate(&stage, &[]).unwrap();
    let mut fixture_manifest = Vec::new();
    a.provisional_manifest()
        .unwrap()
        .write_jcs(&mut fixture_manifest)
        .unwrap();
    fs::write(root.join("fixture-a.manifest.json"), fixture_manifest).unwrap();
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    if scheduled {
        let expected = CString::new(db(root).to_str().unwrap()).unwrap();
        assert_eq!(unsafe { credit_after_open(expected.as_ptr()) }, 0);
    }
    let empty = store.selection().unwrap();
    let before = snap(root);
    unsafe { credit_reset(u64::MAX) };
    let t = Instant::now();
    let sa = store.publish_candidate(&empty, [1; 16], &a).unwrap();
    let publish_ms = t.elapsed().as_secs_f64() * 1000.;
    let publication_stats = stats();
    if scheduled {
        assert_eq!(
            publication_stats[8], 0,
            "automatic main checkpoint escaped scheduling"
        );
    }
    let cp = if scheduled {
        checkpoint(root, observed)
    } else {
        Value::Null
    };
    let total_counters = stats();
    let after = snap(root);
    println!(
        "{}",
        json!({"phase":"fresh","publish_ms":publish_ms,"checkpoint":cp,"before":before,"after":after,"publication_counters":if observed{Some(publication_stats)}else{None},"total_counters":if observed{Some(total_counters)}else{None}})
    );
    let lease = store.lease_current(&sa).unwrap();
    let old = lease.read_record(SOURCE).unwrap();
    edit(root, 1, false);
    let bs = capture(root, &paths);
    let b = validate_staged_candidate(&bs, &[]).unwrap();
    let mut fixture_manifest = Vec::new();
    b.provisional_manifest()
        .unwrap()
        .write_jcs(&mut fixture_manifest)
        .unwrap();
    fs::write(root.join("fixture-b.manifest.json"), fixture_manifest).unwrap();
    let before = snap(root);
    unsafe { credit_reset(u64::MAX) };
    let t = Instant::now();
    let sb = store.publish_candidate(&sa, [2; 16], &b).unwrap();
    let publish_ms = t.elapsed().as_secs_f64() * 1000.;
    let publication_stats = stats();
    if scheduled {
        assert_eq!(
            publication_stats[8], 0,
            "automatic main checkpoint escaped scheduling"
        );
    }
    let cp = if scheduled {
        checkpoint(root, observed)
    } else {
        Value::Null
    };
    assert_eq!(store.selection().unwrap(), sb);
    assert_eq!(lease.read_record(SOURCE).unwrap(), old);
    let total_counters = stats();
    let after = snap(root);
    println!(
        "{}",
        json!({"phase":"edit","publish_ms":publish_ms,"checkpoint":cp,"before":before,"after":after,"publication_counters":if observed{Some(publication_stats)}else{None},"total_counters":if observed{Some(total_counters)}else{None}})
    );
    lease.close().unwrap();
}
fn fault(root: &Path) {
    let paths = fixture(root, 0, 4 * 1024 * 1024);
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    let st = capture(root, &paths);
    let a = validate_staged_candidate(&st, &[]).unwrap();
    let mut fixture_manifest = Vec::new();
    a.provisional_manifest()
        .unwrap()
        .write_jcs(&mut fixture_manifest)
        .unwrap();
    fs::write(root.join("fixture-a.manifest.json"), fixture_manifest).unwrap();
    let sa = store
        .publish_candidate(&store.selection().unwrap(), [1; 16], &a)
        .unwrap();
    let lease = store.lease_current(&sa).unwrap();
    let old = lease.read_record(SOURCE).unwrap();
    edit(root, 2, true);
    let bs = capture(root, &paths);
    let b = validate_staged_candidate(&bs, &[]).unwrap();
    let mut fixture_manifest = Vec::new();
    b.provisional_manifest()
        .unwrap()
        .write_jcs(&mut fixture_manifest)
        .unwrap();
    fs::write(root.join("fixture-b.manifest.json"), fixture_manifest).unwrap();
    let target = *b.provisional_manifest().unwrap().revision().as_bytes();
    fs::write(root.join("base.token"), sa.to_token_bytes()).unwrap();
    fs::write(root.join("target"), target).unwrap();
    unsafe { credit_reset(65536) };
    let error = store.publish_candidate(&sa, [2; 16], &b).unwrap_err();
    let failed = stats();
    assert!(failed[0] <= 65536 && failed[3] > 0);
    assert_eq!(store.selection().unwrap(), sa);
    assert_eq!(lease.read_record(SOURCE).unwrap(), old);
    println!(
        "{}",
        json!({"phase":"credit_refusal","grant":65536,"counters":failed,"error":error.to_string(),"old_selection":sa.generation()})
    );
    // This new grant is a deliberate test reset, not durable-credit recovery.
    unsafe { credit_reset(u64::MAX) };
    lease.close().unwrap();
    drop(store);
    let reopened = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    assert_eq!(reopened.selection().unwrap(), sa);
    assert_eq!(
        reopened.publication_status(&sa, [2; 16], target).unwrap(),
        PublicationStatus::PendingNeedsRetry
    );
    let sb = reopened.publish_candidate(&sa, [2; 16], &b).unwrap();
    assert_eq!(sb.generation(), 2);
    println!(
        "{}",
        json!({"phase":"reopen_retry","generation":sb.generation(),"durable_credit_recovery":false})
    );
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    if args[1] == "identity" {
        let c = Connection::open_in_memory().unwrap();
        let options: Vec<String> = c
            .prepare("PRAGMA compile_options")
            .unwrap()
            .query_map([], |r| r.get(0))
            .unwrap()
            .map(Result::unwrap)
            .collect();
        println!(
            "{}",
            json!({"version":c.query_row("SELECT sqlite_version()",[],|r|r.get::<_,String>(0)).unwrap(),"source_id":c.query_row("SELECT sqlite_source_id()",[],|r|r.get::<_,String>(0)).unwrap(),"compile_options":options})
        );
        return;
    }
    let mode = match args[1].as_str() {
        "native" => 0,
        "scheduled" => 1,
        "fence" | "fault" => 2,
        _ => panic!("mode"),
    };
    let scheduled = true;
    assert_eq!(unsafe { credit_init(mode, 0) }, 0);
    let root = PathBuf::from(&args[2]);
    fs::create_dir_all(&root).unwrap();
    let root = root.canonicalize().unwrap();
    let expected = CString::new(db(&root).to_str().unwrap()).unwrap();
    assert_eq!(unsafe { credit_bind(expected.as_ptr()) }, 0);
    if args[1] == "fault" {
        fault(&root)
    } else {
        run(&root, scheduled, mode != 0)
    }
}
