// Scratch-only serial requested-I/O adapter. Not physical allocation/recovery.
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <stdio.h>
#include <unistd.h>
typedef struct {sqlite3_file base;sqlite3_file*real;int kind;}File;
static sqlite3_vfs*under;static sqlite3_vfs wrapper;
static int mode;static char expected[4096];
static uint64_t wleft=UINT64_MAX,eleft=UINT64_MAX,sleft=UINT64_MAX,mleft=UINT64_MAX;
static uint64_t used,writes,writebytes,denied,hints,truncs,maps,mainbytes,walbytes,extent_used,map_used,meta_used,deletes,opens;
static uint64_t high[4],map_high;
static const uint64_t caps[]={0,256ULL*1024*1024,64ULL*1024*1024,16ULL*1024*1024};
static int charge(uint64_t w,uint64_t e,uint64_t s,uint64_t m){
 if(mode==2&&(w>wleft||e>eleft||s>sleft||m>mleft)){denied++;return SQLITE_FULL;}
 if(mode==2){wleft-=w;eleft-=e;sleft-=s;mleft-=m;}
 used+=w;extent_used+=e;map_used+=s;meta_used+=m;return SQLITE_OK;}
static int path_role(const char*n){if(!n)return 0;size_t k=strlen(expected);if(!strcmp(n,expected))return 1;if(!strncmp(n,expected,k)&&!strcmp(n+k,"-wal"))return 2;if(!strncmp(n,expected,k)&&!strcmp(n+k,"-journal"))return 3;return 0;}
int credit_bind(const char*n){if(strlen(n)>sizeof(expected)-10)return SQLITE_CANTOPEN;strcpy(expected,n);return SQLITE_OK;}
static int close_f(sqlite3_file*p){File*f=(File*)p;int r=f->real->pMethods->xClose(f->real);p->pMethods=0;return r;} // close operation was prepaid at open
static int read_f(sqlite3_file*p,void*b,int n,sqlite3_int64 o){File*f=(File*)p;return f->real->pMethods->xRead(f->real,b,n,o);}
static int write_f(sqlite3_file*p,const void*b,int n,sqlite3_int64 o){File*f=(File*)p;
 if(o<0||n<=0||o>INT64_MAX-n)return SQLITE_IOERR_WRITE;uint64_t end=(uint64_t)o+(unsigned)n;
 if(mode==2&&end>caps[f->kind]){denied++;return SQLITE_FULL;}
 uint64_t e=end>high[f->kind]?end-high[f->kind]:0;
 if(charge((unsigned)n,e,0,0)!=SQLITE_OK)return SQLITE_FULL;
 if(end>high[f->kind])high[f->kind]=end; // burn before forward, including partial failure
 int r=f->real->pMethods->xWrite(f->real,b,n,o);writes++;if(r==SQLITE_OK){writebytes+=(unsigned)n;if(f->kind==1)mainbytes+=(unsigned)n;if(f->kind==2)walbytes+=(unsigned)n;}return r;}
static int trunc_f(sqlite3_file*p,sqlite3_int64 n){File*f=(File*)p;if(n<0)return SQLITE_IOERR_TRUNCATE;
 if(mode==2&&(uint64_t)n>caps[f->kind]){denied++;return SQLITE_FULL;}
 uint64_t e=(uint64_t)n>high[f->kind]?(uint64_t)n-high[f->kind]:0;
 if(charge(0,e,0,1)!=SQLITE_OK)return SQLITE_FULL;if((uint64_t)n>high[f->kind])high[f->kind]=(uint64_t)n;
 truncs++;return f->real->pMethods->xTruncate(f->real,n);}
static int sync_f(sqlite3_file*p,int x){File*f=(File*)p;if(charge(0,0,0,1)!=SQLITE_OK)return SQLITE_IOERR_FSYNC;return f->real->pMethods->xSync(f->real,x);}
static int size_f(sqlite3_file*p,sqlite3_int64*n){File*f=(File*)p;return f->real->pMethods->xFileSize(f->real,n);}
static int lock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xLock(f->real,x);}
static int unlock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xUnlock(f->real,x);}
static int reserved_f(sqlite3_file*p,int*x){File*f=(File*)p;return f->real->pMethods->xCheckReservedLock(f->real,x);}
static int control_f(sqlite3_file*p,int x,void*a){File*f=(File*)p;
 if(mode==2){
  if(x==SQLITE_FCNTL_SIZE_HINT){hints++;return SQLITE_NOTFOUND;} // never forward advisory allocation
  if(x==SQLITE_FCNTL_CHUNK_SIZE&&*(int*)a!=0)return SQLITE_NOTFOUND;
  if(x==SQLITE_FCNTL_MMAP_SIZE){*(sqlite3_int64*)a=0;}
  if(x==SQLITE_FCNTL_FILE_POINTER){*(sqlite3_file**)a=p;return SQLITE_OK;}
  if(x==SQLITE_FCNTL_VFS_POINTER){*(sqlite3_vfs**)a=&wrapper;return SQLITE_OK;}
  if(x==SQLITE_FCNTL_PERSIST_WAL&&*(int*)a==0)return SQLITE_NOTFOUND;
  switch(x){
   case SQLITE_FCNTL_CHUNK_SIZE:case SQLITE_FCNTL_MMAP_SIZE:case SQLITE_FCNTL_PERSIST_WAL:
   case SQLITE_FCNTL_LOCKSTATE:case SQLITE_FCNTL_LAST_ERRNO:case SQLITE_FCNTL_POWERSAFE_OVERWRITE:
   case SQLITE_FCNTL_VFSNAME:case SQLITE_FCNTL_PRAGMA:case SQLITE_FCNTL_HAS_MOVED:
   case SQLITE_FCNTL_SYNC:case SQLITE_FCNTL_COMMIT_PHASETWO:case SQLITE_FCNTL_CKPT_START:case SQLITE_FCNTL_CKPT_DONE:
   case SQLITE_FCNTL_DATA_VERSION:break;
   default:return SQLITE_NOTFOUND;
  }
 }
 return f->real->pMethods->xFileControl(f->real,x,a);}
static int sector_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xSectorSize(f->real);}
static int device_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xDeviceCharacteristics(f->real);}
static int shmmap_f(sqlite3_file*p,int i,int n,int w,void volatile**v){File*f=(File*)p;
 if(i<0||n!=32768)return SQLITE_IOERR_SHMMAP;
 long page=sysconf(_SC_PAGESIZE);if(page<=0||page>65536)return SQLITE_IOERR_SHMMAP;uint64_t group=(uint64_t)page;if(group<32768)group=32768;
 uint64_t end=((uint64_t)(unsigned)i+1)*(unsigned)n;end=(end+group-1)/group*group;
 if(mode==2&&end>131072){denied++;return SQLITE_FULL;}
 uint64_t extent=end>map_high?end-map_high:0;
 // Read mappings also need capacity; native opens/grows SHM below this hook.
 if(charge(0,0,extent,4)!=SQLITE_OK)return SQLITE_FULL;
 if(end>map_high)map_high=end;maps++;
 return f->real->pMethods->xShmMap(f->real,i,n,w,v);}
static int shmlock_f(sqlite3_file*p,int i,int n,int x){File*f=(File*)p;return f->real->pMethods->xShmLock(f->real,i,n,x);}
static void barrier_f(sqlite3_file*p){File*f=(File*)p;f->real->pMethods->xShmBarrier(f->real);}
static int unmap_f(sqlite3_file*p,int x){File*f=(File*)p;if(mode==2&&x){denied++;int r=f->real->pMethods->xShmUnmap(f->real,0);return r==SQLITE_OK?SQLITE_IOERR_SHMOPEN:r;}return f->real->pMethods->xShmUnmap(f->real,x);}
static int fetch_f(sqlite3_file*p,sqlite3_int64 o,int n,void**v){(void)p;(void)o;(void)n;*v=0;return SQLITE_OK;}
static int unfetch_f(sqlite3_file*p,sqlite3_int64 o,void*v){(void)p;(void)o;(void)v;return SQLITE_OK;}
static const sqlite3_io_methods methods={3,close_f,read_f,write_f,trunc_f,sync_f,size_f,lock_f,unlock_f,reserved_f,control_f,sector_f,device_f,shmmap_f,shmlock_f,barrier_f,unmap_f,fetch_f,unfetch_f};
static int open_f(sqlite3_vfs*v,const char*n,sqlite3_file*p,int flags,int*out){(void)v;File*f=(File*)p;memset(f,0,sizeof(*f));f->real=(sqlite3_file*)(f+1);
 int kind=path_role(n);int wanted=kind==1?SQLITE_OPEN_MAIN_DB:kind==2?SQLITE_OPEN_WAL:SQLITE_OPEN_MAIN_JOURNAL;
 int types=SQLITE_OPEN_MAIN_DB|SQLITE_OPEN_WAL|SQLITE_OPEN_MAIN_JOURNAL|SQLITE_OPEN_TEMP_DB|SQLITE_OPEN_TEMP_JOURNAL|SQLITE_OPEN_TRANSIENT_DB|SQLITE_OPEN_SUBJOURNAL|SQLITE_OPEN_SUPER_JOURNAL;
 if(mode==2&&(!kind||(flags&types)!=wanted||(flags&SQLITE_OPEN_DELETEONCLOSE))){denied++;return SQLITE_CANTOPEN;}
 if(charge(0,0,0,2)!=SQLITE_OK)return SQLITE_CANTOPEN; // native close is prepaid
 opens++;int r=under->xOpen(under,n,f->real,flags,out);
 if(f->real->pMethods)f->base.pMethods=&methods; // includes failed-open native cleanup
 if(r!=SQLITE_OK)return r;if(!f->real->pMethods)return SQLITE_IOERR;
 f->kind=kind;sqlite3_int64 length=0;r=f->real->pMethods->xFileSize(f->real,&length);if(r!=SQLITE_OK)return r;
 if(mode==2&&(length<0||(uint64_t)length>caps[kind]))return SQLITE_FULL;
 if((uint64_t)length>high[kind])high[kind]=(uint64_t)length;
 if(mode==2&&kind==1){int one=1;r=f->real->pMethods->xFileControl(f->real,SQLITE_FCNTL_PERSIST_WAL,&one);if(r!=SQLITE_OK)return r;one=-1;r=f->real->pMethods->xFileControl(f->real,SQLITE_FCNTL_PERSIST_WAL,&one);if(r!=SQLITE_OK||one!=1)return SQLITE_IOERR;}
 return SQLITE_OK;}
static int delete_vfs(sqlite3_vfs*v,const char*n,int sync){(void)v;int kind=path_role(n);if(mode==2&&(kind!=2&&kind!=3)){denied++;return SQLITE_IOERR_DELETE;}if(charge(0,0,0,1)!=SQLITE_OK)return SQLITE_IOERR_DELETE;deletes++;return under->xDelete(under,n,sync);}
int credit_after_open(const char*expected_path){(void)expected_path;return SQLITE_OK;} // current store owns Option A
int credit_init(int m,int scheduled){(void)scheduled;mode=m;under=sqlite3_vfs_find("unix");if(!under||under->iVersion<2)return SQLITE_ERROR;
 if(mode){wrapper=*under;wrapper.pNext=0;wrapper.zName="unix";wrapper.szOsFile=(int)(sizeof(File)+under->szOsFile);wrapper.xOpen=open_f;wrapper.xDelete=delete_vfs;
  // Isolated diagnostic process: replace registration, retain native static
  // object below the wrapper. No duplicate VFS names or production change.
  int r=sqlite3_vfs_unregister(under);if(r!=SQLITE_OK)return r;r=sqlite3_vfs_register(&wrapper,1);if(r!=SQLITE_OK)return r;}
 return SQLITE_OK;}
void credit_reset(uint64_t grant){wleft=grant;eleft=64ULL*1024*1024;sleft=131072;mleft=65536;used=writes=writebytes=denied=hints=truncs=maps=mainbytes=walbytes=extent_used=map_used=meta_used=deletes=opens=0;}
void credit_stats(uint64_t*out){uint64_t a[]={used,writes,writebytes,denied,hints,truncs,maps,wleft,mainbytes,walbytes,extent_used,map_used,meta_used,mleft,deletes,opens};memcpy(out,a,sizeof(a));}
