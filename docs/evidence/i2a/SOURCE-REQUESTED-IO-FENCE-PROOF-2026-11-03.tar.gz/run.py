#!/usr/bin/env python3
"""Isolated workers; retain exact stdout/stderr, per-process RSS and identities."""
import hashlib,json,os,pathlib,platform,shutil,subprocess
TASK=pathlib.Path(__file__).resolve().parent
RAW=TASK/'raw';RAW.mkdir(exist_ok=True)
RUN=TASK/'runs';RUN.mkdir(exist_ok=True)
BIN=TASK/'target/release/source-requested-io-fence'
ORACLE=TASK/'target/release/fence-oracle'
subprocess.run([str(ORACLE)],stdout=open(RAW/'oracle.json','w'),stderr=open(RAW/'oracle.stderr','w'),check=True)
subprocess.run([str(BIN),'identity'],stdout=open(RAW/'sqlite-identity.json','w'),check=True)
workers=[]
for mode in ('native','fence','fault'):
 root=RUN/mode;root.mkdir(exist_ok=False)
 with open(RAW/(mode+'.jsonl'),'w')as out,open(RAW/(mode+'.stderr'),'w')as err:
  p=subprocess.Popen([str(BIN),mode,str(root)],stdout=out,stderr=err)
  pid,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 row={'mode':mode,'command':[str(BIN),mode,str(root)],'returncode':p.returncode,'peak_rss_bytes_macos':usage.ru_maxrss,'user_s':usage.ru_utime,'system_s':usage.ru_stime}
 assert p.returncode==0,(mode,(RAW/(mode+'.stderr')).read_text())
 row['fixture_manifests']=[]
 for source in sorted(root.glob('fixture-*.manifest.json')):
  dest=RAW/((('fresh-edit' if mode in ('native','fence')else'fault')+'.'+source.name))
  data=source.read_bytes()
  if dest.exists():assert dest.read_bytes()==data,'selected/native/fence fixture drift'
  else:dest.write_bytes(data)
  row['fixture_manifests'].append({'file':dest.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 workers.append(row);print(json.dumps(row),flush=True)
 assert p.returncode==0,(mode,(RAW/(mode+'.stderr')).read_text())
 shutil.rmtree(root)
(RAW/'workers.json').write_text(json.dumps(workers,indent=2)+'\n')
(TASK/'environment.json').write_text(json.dumps({'platform':platform.platform(),'machine':platform.machine(),'python':platform.python_version(),'os_page_bytes':os.sysconf('SC_PAGE_SIZE')},indent=2)+'\n')
