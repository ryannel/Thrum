# Requested-I/O fence scratch ownership

Owner: `/root/source_binding_review`, 3 November 2026. Purpose: freeze the next
private request-fence contract before production unsafe code. Expected peak <300 MiB;
initial local APFS available ~83 GiB. Selected inputs: current provisional source
crate, exact bundled SQLite 3.53.2 and a public constant-light capture/publication
fixture with 1000×4 KiB notes and a 12 MiB master. No production/doc-contract edits.

Retain source/config/Cargo lock, safe dispatch oracle and bypass mutants, exact raw
worker output, runtime/tool/source identities and selected research report in a
byte-verified compact archive. Remove owned run databases/target after verification.
No source master assets are created. Ignored scratch is local evidence, not backup;
archive promotion is the explicit closeout artifact, not admission qualification.

`fence-oracle` is a safe executable reference for dispatch/grant rules, not native
SQLite/filesystem proof. The C adapter measures selected request-path costs against
actual public APIs. Its serial static ledger is deliberately not a production owner,
recovery or FFI-lifetime implementation. See the selected report for exclusions.

Frozen `input-source/` contains all 24 exact thrum-source Rust inputs. Original
workspace/crate Cargo manifests are retained; the replay crate adds only an explicit
workspace location and uses a derived minimal workspace with the same package/lints.
The final workers built against that copy, independently of mutable repository HEAD.
`input-source-manifest.json` hashes every replay input; raw canonical A/B manifests
bind every generated workload byte. The frozen replay matches the selected original
live-workspace manifests. No third-party source is vendored; locked offline Cargo
requires its dependencies already cached and the pinned SQLite header path available.

The safe oracle assumes validated file-slot capabilities for byte-accounting cases;
it does not prove native handle binding or FFI memory lifetime.
