use rusqlite::{Connection, OpenFlags};
use serde_json::{Value, json};
use std::{
    ffi::{CString, c_char},
    fs,
    os::unix::fs::MetadataExt,
    path::{Path, PathBuf},
    time::Instant,
};
use thrum_source::{
    SourcePath, StagedTree,
    provisional_store::{ProvisionalSelection, ProvisionalSourceStore, PublicationStatus},
    registry_stage::validate_staged_candidate,
    stage_declared_tree,
};
const PROJECT: &str = "2a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SCENE: &str = "3a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const HISTORY: &str = "4a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SOURCE: &str = "10000000-0000-4000-8000-000000000001";
const LIGHT: &str = "10000000-0000-4000-8000-000000000002";
const SOURCE_PATH: &str = "records/environment.record.json";
// Narrow scratch C boundary: serial process only; VFS forwards every operation;
// fixed caller-owned counter array and CString live across armed writes.
unsafe extern "C" {
    fn probe_init() -> i32;
    fn probe_reset();
    fn probe_fault(after: u64, kill: i32, marker: *const c_char);
    fn probe_stats(out: *mut u64);
}
fn db(root: &Path) -> PathBuf {
    root.join("store/provisional-source.sqlite")
}
fn fixture(root: &Path, tiny: usize, large: usize) -> Vec<SourcePath> {
    let p = root.join("project");
    for d in ["records", "scenes", "schemas", "notes", "masters"] {
        fs::create_dir_all(p.join(d)).unwrap();
    }
    fs::create_dir_all(root.join("store")).unwrap();
    let records = [
        SOURCE_PATH,
        "records/light.record.json",
        "scenes/main.scene.json",
    ];
    let files = [
        (
            "project.json",
            json!({"id":PROJECT,"type":"core.project","schema":2,"fields":{"project.format":1,"project.records":records,"project.schemas":[],"project.registryHistory":"schemas/history.registry.json","project.entryScenes":[SCENE]}}),
        ),
        (
            SOURCE_PATH,
            json!({"id":SOURCE,"type":"thrum.environment.authored","schema":1,"fields":{"profile":"constant-light-v1","sun":{"light_ref":LIGHT,"toward_source_unit":[0,1,0],"perpendicular_illuminance_lux":100000,"unit_luminance_linear_rec709":[1,1,1],"angular_radius_rad":0.00465,"direction_model":"geometric-straight","applied_attenuation":[]},"ambient_irradiance_lux":[1000,1000,1000],"background_radiance_cd_m2":[0,0,0],"unsupported":["wind","cloud_tau","precipitation","air","thermal","moon","air_quality"],"x.thrum.environment.note":{"retained":true}}}),
        ),
        (
            "records/light.record.json",
            json!({"id":LIGHT,"type":"thrum.light.identity","schema":1,"fields":{"driver_binding":"incoming-environment-sun"}}),
        ),
        (
            "scenes/main.scene.json",
            json!({"id":SCENE,"type":"core.scene","schema":2,"fields":{"environment.source":SOURCE}}),
        ),
        (
            "schemas/history.registry.json",
            json!({"id":HISTORY,"type":"core.registry-history","schema":1,"fields":{"registry.fields":[],"registry.versions":[]}}),
        ),
    ];
    let mut paths = Vec::new();
    for (pth, v) in files {
        fs::write(p.join(pth), serde_json::to_vec(&v).unwrap()).unwrap();
        paths.push(SourcePath::parse(pth).unwrap());
    }
    for n in 0..tiny {
        let path = format!("notes/{n:04}.txt");
        let mut b = vec![b'x'; 4096];
        b[..8].copy_from_slice(&(n as u64).to_le_bytes());
        fs::write(p.join(&path), b).unwrap();
        paths.push(SourcePath::parse(&path).unwrap());
    }
    if large > 0 {
        fs::write(p.join("masters/large.bin"), vec![0x42; large]).unwrap();
        paths.push(SourcePath::parse("masters/large.bin").unwrap());
    }
    paths
}
fn capture(root: &Path, paths: &[SourcePath]) -> StagedTree {
    stage_declared_tree(&root.join("project"), paths).unwrap()
}
fn edit(root: &Path, n: u64, large: bool) {
    let p = root.join("project").join(SOURCE_PATH);
    let mut v: Value = serde_json::from_slice(&fs::read(&p).unwrap()).unwrap();
    v["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(75000 + n);
    fs::write(p, serde_json::to_vec(&v).unwrap()).unwrap();
    if large {
        use std::io::{Seek, Write};
        let mut f = fs::OpenOptions::new()
            .write(true)
            .open(root.join("project/masters/large.bin"))
            .unwrap();
        f.seek(std::io::SeekFrom::Start(0)).unwrap();
        f.write_all(&n.to_le_bytes()).unwrap();
    }
}
fn fstat(p: &Path) -> Value {
    match fs::metadata(p) {
        Ok(m) => json!({"length":m.len(),"allocated":m.blocks()*512}),
        Err(_) => Value::Null,
    }
}
fn snap(root: &Path) -> Value {
    let conn = Connection::open_with_flags(db(root), OpenFlags::SQLITE_OPEN_READ_ONLY).unwrap();
    json!({"main":fstat(&db(root)),"wal":fstat(&root.join("store/provisional-source.sqlite-wal")),"free":fs4::available_space(root.join("store")).unwrap(),"pages":conn.query_row("PRAGMA page_count",[],|r|r.get::<_,i64>(0)).unwrap(),"freelist":conn.query_row("PRAGMA freelist_count",[],|r|r.get::<_,i64>(0)).unwrap()})
}
fn reset() {
    unsafe { probe_reset() }
}
fn report(root: &Path, phase: &str, before: Value, ms: f64, result: Value) {
    let mut s = [0; 12];
    unsafe { probe_stats(s.as_mut_ptr()) };
    println!(
        "{}",
        json!({"phase":phase,"before":before,"after":snap(root),"elapsed_ms":ms,"writes":s[0],"write_bytes":s[1],"syncs":s[2],"truncates":s[3],"size_hints":s[4],"commit_statements_profiled":s[5],"main_peak_length":s[6],"wal_peak_length":s[7],"main_peak_allocated":s[8],"wal_peak_allocated":s[9],"minimum_sampled_free":s[10],"main_plus_wal_peak_allocated":s[11],"result":result})
    );
}
fn measure<F: FnOnce() -> Value>(root: &Path, phase: &str, f: F) {
    let before = snap(root);
    reset();
    let t = Instant::now();
    let result = f();
    report(
        root,
        phase,
        before,
        t.elapsed().as_secs_f64() * 1000.,
        result,
    );
}
fn source_bytes(store: &ProvisionalSourceStore, s: &ProvisionalSelection) -> Vec<u8> {
    let lease = store.lease_current(s).unwrap();
    let b = lease.read_record(SOURCE).unwrap();
    lease.close().unwrap();
    b
}
fn run_fresh(root: &Path) {
    let paths = fixture(root, 1000, 12 * 1024 * 1024);
    let stage = capture(root, &paths);
    let a = validate_staged_candidate(&stage, &[]).unwrap();
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    let empty = store.selection().unwrap();
    let mut selected = None;
    measure(root, "fresh_1000tiny_12MiB", || {
        let s = store.publish_candidate(&empty, [1; 16], &a).unwrap();
        selected = Some(s.clone());
        json!({"generation":s.generation()})
    });
    let sa = selected.unwrap();
    let lease = store.lease_current(&sa).unwrap();
    let old = lease.read_record(SOURCE).unwrap();
    edit(root, 1, false);
    let bs = capture(root, &paths);
    let b = validate_staged_candidate(&bs, &[]).unwrap();
    measure(root, "one_record_edit_reused_master_and_1000tiny", || {
        let sb = store.publish_candidate(&sa, [2; 16], &b).unwrap();
        assert_eq!(lease.read_record(SOURCE).unwrap(), old);
        json!({"generation":sb.generation()})
    });
    lease.close().unwrap();
}
fn run_blocked(root: &Path) {
    let paths = fixture(root, 0, 4 * 1024 * 1024);
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    let st = capture(root, &paths);
    let a = validate_staged_candidate(&st, &[]).unwrap();
    let mut selected = store
        .publish_candidate(&store.selection().unwrap(), [1; 16], &a)
        .unwrap();
    drop(a);
    drop(st);
    let reader = Connection::open(db(root)).unwrap();
    reader.execute_batch("BEGIN").unwrap();
    let _: i64 = reader
        .query_row("SELECT generation FROM selection", [], |r| r.get(0))
        .unwrap();
    let mut saw_busy = false;
    for n in 2..14u64 {
        edit(root, n, true);
        let stage = capture(root, &paths);
        let c = validate_staged_candidate(&stage, &[]).unwrap();
        let before = snap(root);
        reset();
        let t = Instant::now();
        match store.publish_candidate(&selected, [n as u8; 16], &c) {
            Ok(s) => {
                selected = s;
                report(
                    root,
                    &format!("reader_held_edit_{n}"),
                    before,
                    t.elapsed().as_secs_f64() * 1000.,
                    json!({"generation":selected.generation()}),
                );
            }
            Err(e) => {
                assert_eq!(store.selection().unwrap(), selected);
                report(
                    root,
                    "blocked_checkpoint_refusal",
                    before,
                    t.elapsed().as_secs_f64() * 1000.,
                    json!({"error":e.to_string(),"old_generation":selected.generation()}),
                );
                reader.execute_batch("COMMIT").unwrap();
                if let Ok(marker) = std::env::var("THRUM_SPACE_MARKER") {
                    fs::write(&marker, []).unwrap();
                    assert_eq!(fs4::available_space(root.join("store")).unwrap(), 0);
                    measure(root, "zero_available_with_checkpoint_debt", || {
                        let e = store
                            .publish_candidate(&selected, [n as u8; 16], &c)
                            .unwrap_err();
                        assert_eq!(store.selection().unwrap(), selected);
                        json!({"error":e.to_string(),"old_generation":selected.generation()})
                    });
                    fs::remove_file(marker).unwrap();
                }
                measure(root, "reader_drained_retry_after_checkpoint", || {
                    selected = store
                        .publish_candidate(&selected, [n as u8; 16], &c)
                        .unwrap();
                    json!({"generation":selected.generation()})
                });
                saw_busy = true;
                break;
            }
        }
    }
    assert!(saw_busy, "profile did not reach backpressure");
}
fn run_fault(root: &Path, kill: bool) {
    let paths = fixture(root, 0, 4 * 1024 * 1024);
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    let st = capture(root, &paths);
    let a = validate_staged_candidate(&st, &[]).unwrap();
    let sa = store
        .publish_candidate(&store.selection().unwrap(), [1; 16], &a)
        .unwrap();
    let old = source_bytes(&store, &sa);
    edit(root, 2, true);
    let bs = capture(root, &paths);
    let b = validate_staged_candidate(&bs, &[]).unwrap();
    let target = *b.provisional_manifest().unwrap().revision().as_bytes();
    fs::write(root.join("base.token"), sa.to_token_bytes()).unwrap();
    fs::write(root.join("target"), target).unwrap();
    fs::write(root.join("old-source"), &old).unwrap();
    let marker = CString::new(root.join("paused").to_str().unwrap()).unwrap();
    let before = snap(root);
    reset();
    unsafe { probe_fault(64 * 1024, kill as i32, marker.as_ptr()) };
    let t = Instant::now();
    let error = store.publish_candidate(&sa, [2; 16], &b).unwrap_err();
    assert_eq!(store.selection().unwrap(), sa);
    assert_eq!(source_bytes(&store, &sa), old);
    report(
        root,
        "injected_vfs_ENOSPC",
        before,
        t.elapsed().as_secs_f64() * 1000.,
        json!({"error":error.to_string(),"old_generation":sa.generation()}),
    );
    drop(store);
    recover(root);
}
fn recover(root: &Path) {
    let token = ProvisionalSelection::from_token_bytes(&fs::read(root.join("base.token")).unwrap())
        .unwrap();
    let target: [u8; 32] = fs::read(root.join("target")).unwrap().try_into().unwrap();
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    assert_eq!(store.selection().unwrap(), token);
    assert_eq!(
        source_bytes(&store, &token),
        fs::read(root.join("old-source")).unwrap()
    );
    assert_eq!(
        store.publication_status(&token, [2; 16], target).unwrap(),
        PublicationStatus::PendingNeedsRetry
    );
    let paths = [
        "project.json",
        SOURCE_PATH,
        "records/light.record.json",
        "scenes/main.scene.json",
        "schemas/history.registry.json",
        "masters/large.bin",
    ]
    .map(|s| SourcePath::parse(s).unwrap());
    let st = capture(root, &paths);
    let b = validate_staged_candidate(&st, &[]).unwrap();
    measure(root, "reopen_exact_pending_retry", || {
        let sb = store.publish_candidate(&token, [2; 16], &b).unwrap();
        assert_eq!(store.selection().unwrap(), sb);
        json!({"generation":sb.generation(),"prior_root_preserved_until_retry":true})
    });
}
fn lowspace(root: &Path) {
    let paths = fixture(root, 0, 0);
    let store = ProvisionalSourceStore::open(&root.join("store"), PROJECT).unwrap();
    let st = capture(root, &paths);
    let a = validate_staged_candidate(&st, &[]).unwrap();
    let empty = store.selection().unwrap();
    let marker = PathBuf::from(std::env::var("THRUM_SPACE_MARKER").unwrap());
    fs::write(&marker, []).unwrap();
    assert_eq!(
        fs4::available_space(root.join("store")).unwrap(),
        0,
        "availability oracle not loaded"
    );
    let before = snap(root);
    reset();
    let t = Instant::now();
    let e = store.publish_candidate(&empty, [1; 16], &a).unwrap_err();
    assert_eq!(store.selection().unwrap(), empty);
    report(
        root,
        "injected_zero_available_before_intent",
        before,
        t.elapsed().as_secs_f64() * 1000.,
        json!({"error":e.to_string()}),
    );
    fs::remove_file(marker).unwrap();
    measure(
        root,
        "lowspace_oracle_removed_retry",
        || json!({"generation":store.publish_candidate(&empty,[1;16],&a).unwrap().generation()}),
    );
}
fn main() {
    assert_eq!(unsafe { probe_init() }, 0);
    let args: Vec<_> = std::env::args().collect();
    if args[1] == "identity" {
        let c = Connection::open_in_memory().unwrap();
        let options: Vec<String> = c
            .prepare("PRAGMA compile_options")
            .unwrap()
            .query_map([], |r| r.get(0))
            .unwrap()
            .map(Result::unwrap)
            .collect();
        println!(
            "{}",
            json!({"version":c.query_row("SELECT sqlite_version()",[],|r|r.get::<_,String>(0)).unwrap(),"source_id":c.query_row("SELECT sqlite_source_id()",[],|r|r.get::<_,String>(0)).unwrap(),"compile_options":options})
        );
        return;
    }
    let root = PathBuf::from(&args[2]);
    fs::create_dir_all(&root).unwrap();
    match args[1].as_str() {
        "fresh" => run_fresh(&root),
        "blocked" => run_blocked(&root),
        "fault" => run_fault(&root, false),
        "kill" => run_fault(&root, true),
        "recover" => recover(&root),
        "lowspace" => lowspace(&root),
        _ => panic!("unknown mode"),
    }
}
