#!/usr/bin/env python3
"""Summarize successful profile boundaries; values include auto-checkpoint I/O."""
import json,pathlib
TASK=pathlib.Path(__file__).resolve().parent
out={}
for version in ('pre-fix','post-fix'):
 records=[]
 limits=[json.loads(s)['write_bytes']for s in (TASK/'raw'/version/'fresh.jsonl').read_text().splitlines()]
 rows=[json.loads(s)for s in (TASK/'raw'/version/'fresh.trace.jsonl').read_text().splitlines()]
 segment=-1;group=None;last=0;phases={}
 for r in rows:
  if 'reset'in r:segment+=1;group=None;last=0;continue
  if segment<0 or segment>=len(limits) or r['write_bytes']>limits[segment]:continue
  p=phases.setdefault(segment,{'explicit':[],'autocommit_write_statements':[]})
  kind=r['statement'];n=r['write_bytes']
  if kind=='begin':group={'start':n,'mutations':0,'begin_main':r['main_length'],'begin_wal':r['wal_length']}
  elif kind=='commit'and group is not None:
   p['explicit'].append({'write_bytes':n-group['start'],'mutations':group['mutations'],'main_length_delta':r['main_length']-group['begin_main'],'wal_length_delta':r['wal_length']-group['begin_wal']});group=None
  elif kind in ('insert','update','delete'):
   if group is not None:group['mutations']+=1
   elif n>last:p['autocommit_write_statements'].append({'kind':kind,'write_bytes':n-last,'main_length':r['main_length'],'wal_length':r['wal_length']})
  last=n
 out[version]=phases
(TASK/'trace-summary.json').write_text(json.dumps(out,indent=2)+'\n')
for version,phases in out.items():
 for phase,p in phases.items():
  print(version,phase,'explicit',p['explicit'],'autocommit',p['autocommit_write_statements'])
