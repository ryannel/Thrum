# Provisional source physical envelope: measured counterexample and ordering fix

3 November 2026. Owner: `/root/source_binding_review`, bounded native F3 physical-space commission.
Scope: `tmp/source-physical-envelope/` and the availability ordering/regression in
`crates/thrum-source/src/provisional_store.rs`. No public API/schema/canonical-doc changes.
Selected inputs: actual public v2 capture → validation → publication/lease/status APIs;
constant-light project fixture, 1,000 distinct 4 KiB notes, a 12 MiB master, and repeated
4 MiB master edits. Expected scratch peak <300 MiB; observed pre-cleanup peak <300 MiB.
Retain source/config/lockfile, exact tool identities, ordering patch and compact raw logs.
Owned databases/stages and build cache are reproducible and were removed after successful
assertions/hash capture. No promoted archive. Closeout: deliver this report to the coordinator;
these ignored files are local evidence, not a durable backup or capability promotion.

## Decision and actual fix

No physical reservation envelope was proved for SQLite 3.53.2's native Unix VFS on this
APFS volume. The store remains provisional. The measured input/transaction allowances
cannot become admission bounds. Only the demonstrated ordering bug was fixed:
`prepare_write` now checks availability before checkpoint work and again after checkpoint.
The new source test creates >32 MiB WAL debt, verifies zero availability leaves main/WAL
length and the selected root unchanged, then verifies a post-checkpoint low-space refusal.
The public-API oracle independently confirms zero SQLite writes in that scenario.

Source SHA256 before: `f020c580204611c5c855477ff420ccffb373bbf52150cb19cbb5ab724a9e2a53`.
After: `b6da4d3f9b335d3f4037c8cdb494d5dd6bf34eef7b47f8807842cac0b551d0ec`.
`provisional-space-ordering.patch` was derived from a byte-verified reconstruction of
that exact pre-fix source, not from the repository's older tracked base.

## Instrument and boundaries

An isolated Rust scratch executable links actual `thrum-source`, pinned rusqlite and its
bundled SQLite. A narrow C wrapper forwards the default VFS and samples after xWrite,
xTruncate, xSync and xFileControl (including SIZE_HINT). Counters record successful
write bytes/calls, main/WAL logical lengths, `st_blocks*512`, sampled `statvfs` availability,
and SQLite PROFILE statement boundaries. It leaves normal automatic checkpointing enabled.
Separate fresh processes use `wait4` for whole-worker peak RSS; this includes fixture,
capture, validation and publication, excludes compilation, and is not publication-only RSS.
No allocator or whole-volume peak is claimed. SHM, staged trees and other processes are
not in the main+WAL allocation sum. Availability samples are volume-wide and noisy.

The C wrapper is scratch-only unsafe instrumentation: serial process, caller-owned fixed
counter array, forwarded file/VFS lifetimes and no production linkage. The macOS dyld
oracle overrides `statvfs` only for the exact store directory while a marker exists; it
never fills the real volume. The VFS disk-full injection returns SQLITE_FULL with
`errno=ENOSPC` before a selected WAL write. It exercises SQLite full/error rollback, not
an actual kernel-full volume or every OS I/O error. A separate worker pauses before a
partial chunk WAL write; the parent sends SIGKILL, waits, and starts a fresh recovery process
using only persisted public selection-token bytes/key/target. Power-loss flush honesty
is outside this proof.

Every write sample performs filesystem queries; trace logging adds work. These one-run
instrumented timings are diagnostics, not uninstrumented edit latency or a speedup claim.

## Selected measurements

`raw/pre-fix/` preserves the counterexample. `raw/post-fix/` is the final run.
All figures below are post-fix except the explicitly marked old guard.

| Work | Observation |
| --- | --- |
| Fresh 1,000 ×4 KiB notes +12 MiB master +5 project records | 245.394 ms instrumented; 35,380,752 B SQLite writes; peak main+WAL allocation 21,712,896 B; main 4,096→16,932,864 B; WAL 61,832→4,779,232 B; sampled available 88,084,942,848→88,062,590,976 B |
| One environment-record edit, same notes/master | 31.814 ms instrumented; 251,320 B writes; unchanged main/WAL lengths and allocation; available delta −4,096 B (not a unique attribution); A lease still returned exact A bytes after B |
| Fresh worker whole-process peak RSS | 48,316,416 B (46.1 MiB) |
| Blocked-reader worker whole-process peak RSS | 26,509,312 B (25.3 MiB) |
| Full 128-file tiny batches, 512 KiB input | 659,200–716,880 B observed writes per commit; these are observations, not maxima over all store states |
| A 4 MiB chunk insertion | Up to 8,507,568 B observed writes including automatic checkpoint; one completion-marker update wrote 4,223,032 B including checkpoint |
| Final atomic selected/outcome/intent metadata commit | 20,600 B observed writes in this fixture; other index states are unproved |
| Reader held at A while 4 MiB edits accumulate | Generation 8 remains selected when next attempt refuses Busy; WAL 34,640,992 B; main 4,263,936 B; tentative data/intent survive for exact retry |
| Old guard with availability oracle=0 after reader drain | Before refusal, main grew 4,263,936→37,916,672 B; 33,705,984 B writes; WAL truncated; peak main+WAL allocation 72,560,640 B from 38,907,904 B. Old selection remained generation 8 |
| Fixed guard, same oracle/debt | 0 writes, 0 syncs, 0 truncates; main/WAL unchanged; generation 8 remains selected |
| Restore availability and retry after drain | Main+WAL reaches the same 72,560,640-B peak during checkpoint; exact target commits generation 9 |
| Synthetic SQLITE_FULL and SIGKILL during tentative chunk | Old generation 1 and exact A record survive reopen; persisted token status=PendingNeedsRetry; exact retry commits generation 2 |

Explicit COMMIT-profile counts exclude autocommit INSERT/UPDATE transactions. Do not use
those raw counters as total transaction counts. `trace-summary.json` separates explicit
transaction writes and observed autocommit statements, clipping samples at each timed
phase's write counter to exclude later lease pin/release writes.

## What can be bounded, and what remains unproved

For page size P=4096 and a known appended frame count F, WAL append bytes are at most
32+(P+24)F, excluding any already allocated tail. That is an accounting identity, not an
input-to-F bound. Page splits, indexes, pointer-map pages, cache spill/repeated page
frames and incomplete-blob reset must be charged. Normal SQLite auto-checkpointing can
also run *inside* an apparently small INSERT/UPDATE return boundary. A 4 MiB chunk or
metadata-only final transaction therefore does not imply 4 MiB or metadata-only I/O.
SQLite documents page-frame WALs, reader-blocked checkpoint progress and automatic
checkpointing in [WAL](https://sqlite.org/wal.html).

A conservative *logical extent* debt at a serialized checkpoint boundary is
`max(0, logical_page_count*4096 - main_length)` while retaining the WAL. In the measured
blocked case it is 33,652,736 B. It is not a physical allocation bound: rewriting existing
main pages can allocate storage even without length growth. A bound must also include
all current main-page bytes potentially copied, retained WAL, managed temporary/staging
work and filesystem allocation metadata. The verified 256 MiB main page cap constrains
logical SQLite pages; the 64 MiB WAL heuristic does not enforce a per-write WAL quota.
No finite per-operation physical constant was established by this study.

SQLite's SIZE_HINT explicitly need not be accurate and permits the VFS to preallocate:
[SQLite file controls](https://sqlite.org/c3ref/c_fcntl_begin_atomic_write.html).
APFS supports copy-on-write, snapshots and shared container space; allocated block sums
and sparse logical lengths are not an exclusive physical reservation. Apple's archived
[APFS features](https://developer.apple.com/library/archive/documentation/FileManagement/Conceptual/APFS_Guide/Features/Features.html)
provide background, not a current quantitative allocation guarantee. Neither a sparse
file nor successful allocation hint proves reserved rewrite/metadata capacity.

Next proof queue, before accepted-source authority:

1. Select an enforceable resource/VFS/filesystem model. Either derive conservative
   version-pinned pager/index/reset envelopes for every permitted SQL operation plus
   checkpoint/auto-checkpoint, or enforce credits before every allocating VFS operation.
   An arbitrary multiplier from this fixture is insufficient. Decide whether to disable
   automatic checkpointing and schedule fully charged checkpoints explicitly.
2. Under the single cooperating writer/reservation lock, persist/check unique missing
   blobs, old retained closure, staging/temporary allocations, checkpoint debt, reserved
   WAL growth and unallocated floor before starting work. Recheck before every bounded
   allocating write/checkpoint; blocked checkpoint gives no reclaimed credit. Prove
   how reservation/recovery survives death and how credits are reconciled on reopen.
3. Qualify actual APFS/Unix VFS allocation/preallocation semantics (including sparse,
   snapshots/CoW, incomplete reset, cache spill, full main cap and blocked readers).
   `F_PREALLOCATE`/ALLOCATEALL would require checking its actual allocated result and
   still does not, from this evidence, establish overwrite/metadata or snapshot bounds.
4. Fault at each write/truncate/checkpoint/sync/commit boundary with persistent ENOSPC,
   actual constrained-volume ENOSPC and process interruption; verify exact status and
   old-root/lease bytes. Current one-shot SQLITE_FULL and one SIGKILL boundary are scoped
   probes, not exhaustive fault qualification.

The application can serialize its own writers, refuse before exceeding proved credits,
check actual available space, keep old roots/pins, and resolve an uncertain result by
exact durable request. It cannot stop unrelated volume consumers between checks, control
APFS snapshots owned elsewhere, or guarantee hardware honors flush. Those assumptions
must remain explicit even after a production reservation exists. GC stays disabled here;
this task changes neither pin-owner recovery nor the canonical RecoveryRoot envelope.

## Runtime/tools and validation

Actual runtime: SQLite **3.53.2**, source ID
`2026-06-03 19:12:13 d6e03d8c777cfa2d35e3b60d8ec3e0187f3e9f99d8e2ee9cac695fd6fcdf1a24`.
Full compile options are in both raw SQLite identity JSON files. Important options include
4096-byte default pages, FULL/WAL FULL defaults, WAL_AUTOCHECKPOINT=1000, TEMP_STORE=1,
DEFAULT_CACHE_SIZE=-2000 and THREADSAFE=1. The store separately sets/reads its own limits.
Target: macOS 26.6.2 arm64, local APFS; Rust 1.99.1; compiler/tool details and every source,
archive and executed-tool SHA256 are retained in `tool-identity.json`.
Final executable SHA256: `8ee47bbdb2bb6a163e5d8dcfcd9070753f89d370b4a5a12bce2f92d9921ba276`.
Pre-fix executable: `eec589a6335d5e933054e3a9d015b2882f12f472e2dbc4f59e3e05e0b11bea4a`.
Bundled release SQLite archive: `76e590fcb1046bc80636c9e52b9cb6664dbbcc9695a9c1225dd8c5e3cf6f9126`.

Passed: targeted source regression; all source tests (144 passed/34 ignored); all-target
source Clippy with `-D warnings`; source rustfmt, scratch fmt/Clippy; `git diff --check`;
repository-wide `RUSTC_WRAPPER= ./dev check`; every final public-API probe and both fresh
recovery processes. This is no accepted-source, physical-reservation or F4-ready claim.

Reproduce after restoring the scratch target (ordinary Cargo build output, not retained):

```sh
cc -Wall -Wextra -Werror -dynamiclib tmp/source-physical-envelope/space_oracle.c -o tmp/source-physical-envelope/space_oracle.dylib
RUSTC_WRAPPER= rustup run 1.99.1 cargo build --locked --offline --release --manifest-path tmp/source-physical-envelope/Cargo.toml
python3 tmp/source-physical-envelope/run.py
python3 tmp/source-physical-envelope/analyze.py
```

`build.rs` deliberately points to the exact locally cached bundled SQLite header; adjust
only that header location on another machine, then record a new tool identity. `run.py`
removes only its own per-case databases after assertions, preserving raw logs.
