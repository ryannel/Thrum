// macOS scratch-only availability oracle; never fills the user's volume.
#include <sys/statvfs.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int fake_statvfs(const char *p,struct statvfs *s){
 int r=statvfs(p,s);const char*m=getenv("THRUM_SPACE_MARKER"),*d=getenv("THRUM_SPACE_DIRECTORY");
 if(r==0 && m && d && !strcmp(p,d) && access(m,F_OK)==0)s->f_bavail=0;
 return r;
}
__attribute__((used)) static struct {const void *replacement,*replacee;} entry __attribute__((section("__DATA,__interpose")))={(void*)fake_statvfs,(void*)statvfs};
