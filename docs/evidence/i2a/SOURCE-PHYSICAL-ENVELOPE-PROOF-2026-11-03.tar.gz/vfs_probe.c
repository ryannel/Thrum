// Scratch instrumentation only: transparent forwarding of the default SQLite VFS.
// No production code. Counters/faults are single-threaded for this serial probe.
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <unistd.h>
typedef struct {sqlite3_file base; sqlite3_file *real; int kind; char name[4096];} File;
static sqlite3_vfs *under; static sqlite3_vfs wrapper;
static unsigned long long writes,writebytes,syncs,truncs,hints,commits,mainpeak,walpeak,mainblocks,walblocks,minfree,failafter,killafter,totalpeak;
static int armed; static const char *marker; static FILE *tracefile; static char mainname[4096],walname[4096];
static void sample(File *f){
 struct stat s; struct statvfs v;
 if(f->kind && stat(f->name,&s)==0){
  unsigned long long n=(unsigned long long)s.st_size,b=(unsigned long long)s.st_blocks*512;
  unsigned long long *peak=f->kind==1?&mainpeak:&walpeak,*blocks=f->kind==1?&mainblocks:&walblocks;
  if(n>*peak)*peak=n; if(b>*blocks)*blocks=b;
 }
 struct stat sm={0},sw={0};stat(mainname,&sm);stat(walname,&sw);unsigned long long total=(unsigned long long)(sm.st_blocks+sw.st_blocks)*512;if(total>totalpeak)totalpeak=total;
 if(f->kind && statvfs(f->name,&v)==0){unsigned long long n=(unsigned long long)v.f_bavail*v.f_frsize;if(n<minfree)minfree=n;}
}
static int close_f(sqlite3_file *p){File*f=(File*)p;int r=f->real->pMethods->xClose(f->real);p->pMethods=0;return r;}
static int read_f(sqlite3_file*p,void*b,int n,sqlite3_int64 o){File*f=(File*)p;return f->real->pMethods->xRead(f->real,b,n,o);}
static int write_f(sqlite3_file*p,const void*b,int n,sqlite3_int64 o){File*f=(File*)p;
 if(armed && f->kind==2){
  if(killafter && writebytes+(unsigned)n>=killafter){FILE*m=fopen(marker,"w");if(m){fputs("paused-before-wal-write\n",m);fclose(m);}for(;;)sleep(1);}
  if(failafter && writebytes+(unsigned)n>=failafter){armed=0;errno=ENOSPC;return SQLITE_FULL;}
 }
 int r=f->real->pMethods->xWrite(f->real,b,n,o);writes++;if(r==SQLITE_OK)writebytes+=(unsigned)n;sample(f);return r;
}
static int trunc_f(sqlite3_file*p,sqlite3_int64 n){File*f=(File*)p;truncs++;int r=f->real->pMethods->xTruncate(f->real,n);sample(f);return r;}
static int sync_f(sqlite3_file*p,int x){File*f=(File*)p;syncs++;int r=f->real->pMethods->xSync(f->real,x);sample(f);return r;}
static int size_f(sqlite3_file*p,sqlite3_int64*n){File*f=(File*)p;return f->real->pMethods->xFileSize(f->real,n);}
static int lock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xLock(f->real,x);}
static int unlock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xUnlock(f->real,x);}
static int reserved_f(sqlite3_file*p,int*x){File*f=(File*)p;return f->real->pMethods->xCheckReservedLock(f->real,x);}
static int control_f(sqlite3_file*p,int x,void*a){File*f=(File*)p;if(x==SQLITE_FCNTL_SIZE_HINT)hints++;int r=f->real->pMethods->xFileControl(f->real,x,a);sample(f);return r;}
static int sector_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xSectorSize(f->real);}
static int device_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xDeviceCharacteristics(f->real);}
static int shmmap_f(sqlite3_file*p,int i,int n,int w,void volatile**v){File*f=(File*)p;return f->real->pMethods->xShmMap(f->real,i,n,w,v);}
static int shmlock_f(sqlite3_file*p,int i,int n,int x){File*f=(File*)p;return f->real->pMethods->xShmLock(f->real,i,n,x);}
static void barrier_f(sqlite3_file*p){File*f=(File*)p;f->real->pMethods->xShmBarrier(f->real);}
static int unmap_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xShmUnmap(f->real,x);}
static int fetch_f(sqlite3_file*p,sqlite3_int64 o,int n,void**v){File*f=(File*)p;if(f->real->pMethods->iVersion<3||!f->real->pMethods->xFetch){*v=0;return SQLITE_OK;}return f->real->pMethods->xFetch(f->real,o,n,v);}
static int unfetch_f(sqlite3_file*p,sqlite3_int64 o,void*v){File*f=(File*)p;if(f->real->pMethods->iVersion<3||!f->real->pMethods->xUnfetch)return SQLITE_OK;return f->real->pMethods->xUnfetch(f->real,o,v);}
static const sqlite3_io_methods methods={3,close_f,read_f,write_f,trunc_f,sync_f,size_f,lock_f,unlock_f,reserved_f,control_f,sector_f,device_f,shmmap_f,shmlock_f,barrier_f,unmap_f,fetch_f,unfetch_f};
static int open_f(sqlite3_vfs*v,const char*n,sqlite3_file*p,int flags,int*out){(void)v;File*f=(File*)p;memset(f,0,sizeof(*f));f->real=(sqlite3_file*)(f+1);int r=under->xOpen(under,n,f->real,flags,out);if(r!=SQLITE_OK)return r;
 if(n){snprintf(f->name,sizeof(f->name),"%s",n);if(flags&SQLITE_OPEN_MAIN_DB)f->kind=1;else if(flags&SQLITE_OPEN_WAL)f->kind=2;}if(f->kind==1)snprintf(mainname,sizeof(mainname),"%s",f->name);if(f->kind==2)snprintf(walname,sizeof(walname),"%s",f->name);f->base.pMethods=&methods;sample(f);return r;
}
static int trace(unsigned flag,void*ctx,void*p,void*x){(void)ctx;(void)x;
 if(flag==SQLITE_TRACE_PROFILE){const char*s=sqlite3_sql((sqlite3_stmt*)p);if(!s)return 0;
 const char*kind=0;if(!strncmp(s,"COMMIT",6)||!strncmp(s,"END",3)){commits++;kind="commit";}
 else if(!strncmp(s,"BEGIN",5))kind="begin";
 else if(!strncmp(s,"INSERT",6))kind="insert";
 else if(!strncmp(s,"UPDATE",6))kind="update";
 else if(!strncmp(s,"DELETE",6))kind="delete";
 if(kind&&tracefile){struct stat m={0},w={0};stat(mainname,&m);stat(walname,&w);
 fprintf(tracefile,"{\"statement\":\"%s\",\"write_bytes\":%llu,\"main_length\":%lld,\"wal_length\":%lld,\"main_allocated\":%lld,\"wal_allocated\":%lld}\n",kind,writebytes,(long long)m.st_size,(long long)w.st_size,(long long)m.st_blocks*512,(long long)w.st_blocks*512);fflush(tracefile);}
 }return 0;}
static int extension(sqlite3*d,char**e,const sqlite3_api_routines*a){(void)e;(void)a;sqlite3_trace_v2(d,SQLITE_TRACE_PROFILE,trace,0);return SQLITE_OK;}
int probe_init(void){const char*t=getenv("THRUM_SQL_TRACE");if(t)tracefile=fopen(t,"a");under=sqlite3_vfs_find(0);if(!under||under->iVersion<2)return SQLITE_ERROR;wrapper=*under;wrapper.zName="thrum-physical-probe";wrapper.szOsFile=(int)(sizeof(File)+under->szOsFile);wrapper.xOpen=open_f;minfree=~0ULL;int r=sqlite3_vfs_register(&wrapper,1);if(r!=SQLITE_OK)return r;return sqlite3_auto_extension((void(*)(void))extension);}
void probe_reset(void){if(tracefile){fputs("{\"reset\":true}\n",tracefile);fflush(tracefile);}writes=writebytes=syncs=truncs=hints=commits=mainpeak=walpeak=mainblocks=walblocks=totalpeak=0;minfree=~0ULL;armed=0;}
void probe_fault(unsigned long long after,int kill,const char*m){failafter=kill?0:after;killafter=kill?after:0;marker=m;armed=1;}
void probe_stats(unsigned long long*out){unsigned long long a[]={writes,writebytes,syncs,truncs,hints,commits,mainpeak,walpeak,mainblocks,walblocks,minfree,totalpeak};memcpy(out,a,sizeof(a));}
