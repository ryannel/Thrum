#!/usr/bin/env python3
"""Serial scratch workers; wait4 reports per-process peak RSS (bytes on macOS)."""
import json,os,platform,subprocess,time,pathlib,hashlib,shutil
TASK=pathlib.Path(__file__).resolve().parent
BIN=TASK/'target/release/source-physical-envelope'
RAW=TASK/'raw/post-fix';RAW.mkdir(parents=True,exist_ok=True)
RUN=TASK/'runs';RUN.mkdir(exist_ok=True)
def worker(mode,case=None,kill=False,oracle=False):
 case=case or mode;root=RUN/case;root.mkdir(exist_ok=True)
 trace=RAW/(mode+'.trace.jsonl');trace.unlink(missing_ok=True)
 env=os.environ.copy();env['THRUM_SQL_TRACE']=str(trace)
 if oracle:
  env['DYLD_INSERT_LIBRARIES']=str(TASK/'space_oracle.dylib')
  env['THRUM_SPACE_MARKER']=str(root/'low-space')
  env['THRUM_SPACE_DIRECTORY']=str(root/'store')
 with open(RAW/(mode+'.jsonl'),'w') as out,open(RAW/(mode+'.stderr'),'w') as err:
  p=subprocess.Popen([str(BIN),mode,str(root)],stdout=out,stderr=err,env=env)
  if kill:
   deadline=time.monotonic()+30
   while not(root/'paused').exists():
    if time.monotonic()>deadline:p.kill();raise RuntimeError('pause not reached')
    time.sleep(.01)
   p.kill()
  pid,status,rusage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 record={'worker':mode,'returncode':p.returncode,'peak_rss_bytes_macos':rusage.ru_maxrss,'user_s':rusage.ru_utime,'system_s':rusage.ru_stime}
 print(json.dumps(record),flush=True)
 with open(RAW/'workers.jsonl','a')as f:f.write(json.dumps(record)+'\n')
 assert p.returncode==(-9 if kill else 0),(mode,(RAW/(mode+'.stderr')).read_text())
 if not kill:shutil.rmtree(root)
(RAW/'workers.jsonl').write_text('')
subprocess.run([str(BIN),'identity'],stdout=open(RAW/'sqlite-identity.json','w'),check=True)
for mode in ['fresh','blocked','fault']:worker(mode,oracle=(mode=='blocked'))
worker('lowspace',oracle=True)
worker('kill',case='interruption',kill=True)
worker('recover',case='interruption')
(TASK/'environment.json').write_text(json.dumps({'platform':platform.platform(),'machine':platform.machine(),'python':platform.python_version()},indent=2)+'\n')
