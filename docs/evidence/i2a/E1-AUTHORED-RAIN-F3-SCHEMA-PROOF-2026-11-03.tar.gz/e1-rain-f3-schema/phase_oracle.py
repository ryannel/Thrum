#!/usr/bin/env python3
"""Independent Fraction comparison against bounded native phase arithmetic."""
import math,random,struct,subprocess,sys
from fractions import Fraction
from pathlib import Path

def bits(x):return struct.pack('>d',x).hex()
def main():
    binary=Path(sys.argv[1]).resolve();random.seed(180031);cases=[]
    for initial in [-float.fromhex('0x1.fffffffffffffp1023'),-1.0,-math.ulp(0.0),-0.0,0.0,math.ulp(0.0),1.0,float.fromhex('0x1.fffffffffffffp1023')]:
        for weight in [0,1,3840,3317760000]:
            for last in [initial,math.nextafter(initial,-math.inf),math.nextafter(initial,math.inf)]:
                if math.isfinite(last):cases.append((initial,last,weight))
    for _ in range(256):
        initial=struct.unpack('>d',random.getrandbits(64).to_bytes(8,'big'))[0]
        if not math.isfinite(initial):continue
        weight=random.randrange(3317760001);last=initial+weight/3840
        if math.isfinite(last):cases.extend([(initial,last,weight),(initial,math.nextafter(last,-math.inf),weight),(initial,math.nextafter(last,math.inf),weight)])
    for initial,last,weight in cases:
        expected=Fraction.from_float(last)>=Fraction.from_float(initial)+Fraction(weight,3840)
        p=subprocess.run([str(binary),'--phase',bits(initial),bits(last),str(weight)],capture_output=True,text=True,check=True)
        assert(p.stdout.strip()=='true')==expected,(initial,last,weight,expected,p.stdout)
    print(f'EXACT PHASE PASS {len(cases)} Fraction/native comparisons; source-duration rational limit and subnormal/extreme/fence cases')
if __name__=='__main__':main()
