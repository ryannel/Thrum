//! Proposed grammar proof only. No staged admission, products, runtime or views.
#![forbid(unsafe_code)]
use serde::de::{DeserializeSeed, Error as _, MapAccess, SeqAccess, Visitor};
use serde::{Deserialize, Deserializer};
use serde_json::value::RawValue;
use sha2::{Digest, Sha256};
use std::{
    cell::Cell,
    collections::{BTreeMap, BTreeSet},
    fmt, fs,
    path::Path,
    time::Instant,
};

const MAX_BYTES: usize = 16 * 1024 * 1024;
const MAX_NODES: usize = 1_000_000;
const BASE_UNSUPPORTED: [&str; 6] = [
    "moon",
    "thermal_irradiance",
    "air_quality",
    "cloud_density_volume",
    "optical_air",
    "terminal_sky",
];
type R<T> = Result<T, String>;
fn need(ok: bool, message: &str) -> R<()> {
    if ok { Ok(()) } else { Err(message.into()) }
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
struct Uuid(String);
impl<'de> Deserialize<'de> for Uuid {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let s = Text::deserialize(d)?.0;
        let b = s.as_bytes();
        let valid = b.len() == 36
            && b.iter().enumerate().all(|(i, c)| {
                if matches!(i, 8 | 13 | 18 | 23) {
                    *c == b'-'
                } else {
                    matches!(c,b'0'..=b'9'|b'a'..=b'f')
                }
            })
            && matches!(b[14], b'1'..=b'8')
            && matches!(b[19], b'8' | b'9' | b'a' | b'b');
        if valid {
            Ok(Self(s))
        } else {
            Err(D::Error::custom("canonical UUID"))
        }
    }
}
#[derive(Clone, Debug)]
struct Text(String);
impl<'de> Deserialize<'de> for Text {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V;
        impl Visitor<'_> for V {
            type Value = Text;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                f.write_str("UTF8 string <=4096 bytes")
            }
            fn visit_str<E: serde::de::Error>(self, s: &str) -> Result<Text, E> {
                if s.len() > 4096 {
                    Err(E::custom("text limit"))
                } else {
                    Ok(Text(s.into()))
                }
            }
        }
        d.deserialize_str(V)
    }
}
#[derive(Clone, Copy, Debug)]
struct F(f64);
impl<'de> Deserialize<'de> for F {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let x = f64::deserialize(d)?;
        if x.is_finite() {
            Ok(F(x))
        } else {
            Err(D::Error::custom("finite number"))
        }
    }
}
#[derive(Clone, Debug)]
struct B<T, const N: usize>(Vec<T>);
impl<'de, T: Deserialize<'de>, const N: usize> Deserialize<'de> for B<T, N> {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V<T, const N: usize>(std::marker::PhantomData<T>);
        impl<'de, T: Deserialize<'de>, const N: usize> Visitor<'de> for V<T, N> {
            type Value = B<T, N>;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                write!(f, "array <={N}")
            }
            fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Self::Value, A::Error> {
                let mut v = Vec::new();
                loop {
                    if v.len() == N {
                        a.next_element_seed(Reject)?;
                        break;
                    }
                    match a.next_element()? {
                        Some(x) => v.push(x),
                        None => break,
                    }
                }
                Ok(B(v))
            }
        }
        d.deserialize_seq(V(std::marker::PhantomData))
    }
}
struct Reject;
impl<'de> DeserializeSeed<'de> for Reject {
    type Value = ();
    fn deserialize<D: Deserializer<'de>>(self, _: D) -> Result<(), D::Error> {
        Err(D::Error::custom(
            "bounded array refuses excess before traversal",
        ))
    }
}
#[derive(Clone, Debug)]
struct Empty;
impl<'de> Deserialize<'de> for Empty {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V;
        impl<'de> Visitor<'de> for V {
            type Value = Empty;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                f.write_str("empty array")
            }
            fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<Empty, A::Error> {
                a.next_element_seed(Reject)?;
                Ok(Empty)
            }
        }
        d.deserialize_seq(V)
    }
}
fn optional<'de, D: Deserializer<'de>, T: Deserialize<'de>>(d: D) -> Result<Option<T>, D::Error> {
    T::deserialize(d).map(Some)
}

// Strict no-tree whole-record/opaque traversal. Keys are retained only in opaque
// objects to reject duplicates; all known field duplicates use typed visitors.
struct Skip<'a> {
    depth: usize,
    nodes: &'a Cell<usize>,
    limit: usize,
    max_depth: usize,
    strings: usize,
    duplicates: bool,
}
impl<'de> DeserializeSeed<'de> for Skip<'_> {
    type Value = ();
    fn deserialize<D: Deserializer<'de>>(self, d: D) -> Result<(), D::Error> {
        if self.nodes.get() >= self.limit {
            return Err(D::Error::custom("JSON nodes limit"));
        }
        self.nodes.set(self.nodes.get() + 1);
        d.deserialize_any(SkipV(self))
    }
}
struct SkipV<'a>(Skip<'a>);
impl<'de> Visitor<'de> for SkipV<'_> {
    type Value = ();
    fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("bounded strict finite JSON")
    }
    fn visit_unit<E: serde::de::Error>(self) -> Result<(), E> {
        Ok(())
    }
    fn visit_bool<E: serde::de::Error>(self, _: bool) -> Result<(), E> {
        Ok(())
    }
    fn visit_i64<E: serde::de::Error>(self, _: i64) -> Result<(), E> {
        Ok(())
    }
    fn visit_u64<E: serde::de::Error>(self, _: u64) -> Result<(), E> {
        Ok(())
    }
    fn visit_f64<E: serde::de::Error>(self, x: f64) -> Result<(), E> {
        if x.is_finite() {
            Ok(())
        } else {
            Err(E::custom("finite JSON"))
        }
    }
    fn visit_str<E: serde::de::Error>(self, s: &str) -> Result<(), E> {
        if s.len() <= self.0.strings {
            Ok(())
        } else {
            Err(E::custom("JSON string limit"))
        }
    }
    fn visit_seq<A: SeqAccess<'de>>(self, mut a: A) -> Result<(), A::Error> {
        if self.0.depth >= self.0.max_depth {
            return Err(A::Error::custom("JSON depth limit"));
        }
        while a
            .next_element_seed(Skip {
                depth: self.0.depth + 1,
                ..self.0.reborrow()
            })?
            .is_some()
        {}
        Ok(())
    }
    fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<(), A::Error> {
        if self.0.depth >= self.0.max_depth {
            return Err(A::Error::custom("JSON depth limit"));
        }
        let mut keys = BTreeSet::new();
        while let Some(key) = a.next_key::<String>()? {
            if key.len() > self.0.strings {
                return Err(A::Error::custom("JSON key limit"));
            }
            if self.0.duplicates && !keys.insert(key) {
                return Err(A::Error::custom("opaque duplicate key"));
            }
            a.next_value_seed(Skip {
                depth: self.0.depth + 1,
                ..self.0.reborrow()
            })?;
        }
        Ok(())
    }
}
impl Skip<'_> {
    fn reborrow(&self) -> Skip<'_> {
        Skip {
            depth: self.depth,
            nodes: self.nodes,
            limit: self.limit,
            max_depth: self.max_depth,
            strings: self.strings,
            duplicates: self.duplicates,
        }
    }
}
fn check_json(bytes: &[u8]) -> R<()> {
    need(bytes.len() <= MAX_BYTES, "record bytes limit")?;
    let nodes = Cell::new(0);
    let mut d = serde_json::Deserializer::from_slice(bytes);
    Skip {
        depth: 0,
        nodes: &nodes,
        limit: MAX_NODES,
        max_depth: 64,
        strings: MAX_BYTES,
        duplicates: false,
    }
    .deserialize(&mut d)
    .map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())
}
fn strict<'de, T: Deserialize<'de>>(bytes: &'de [u8]) -> R<T> {
    let mut d = serde_json::Deserializer::from_slice(bytes);
    let x = T::deserialize(&mut d).map_err(|e| e.to_string())?;
    d.end().map_err(|e| e.to_string())?;
    Ok(x)
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Envelope<T> {
    id: Uuid,
    #[serde(rename = "type")]
    kind: Text,
    schema: u32,
    fields: T,
    #[serde(default, deserialize_with = "optional")]
    documentation: Option<Text>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Header<'a> {
    id: Uuid,
    #[serde(rename = "type")]
    kind: Text,
    schema: u32,
    #[serde(borrow)]
    fields: &'a RawValue,
    #[serde(default, deserialize_with = "optional")]
    documentation: Option<Text>,
}

#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Box3 {
    min: [F; 3],
    max: [F; 3],
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Rate {
    from_tick: u32,
    num: u16,
    den: u8,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Phase {
    initial_seconds: F,
    rates: B<Rate, 16>,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Sun {
    light_ref: Uuid,
    initial_toward_source_unit: [F; 3],
    rotation_axis_unit: [F; 3],
    period_phase_seconds: F,
    peak_perpendicular_illuminance_lux: F,
    intensity_envelope: Text,
    unit_luminance_linear_rec709: [F; 3],
    angular_radius_rad: F,
    direction_model: Text,
    applied_attenuation: Empty,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Wind {
    reference_height_m: F,
    vertical_multiplier: B<(F, F), 8>,
    weather_phase_vector_knots_mps: B<(F, [F; 3]), 256>,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Cloud {
    plane_height_m: F,
    map_origin_xz_m: [F; 2],
    spacing_xz_m: [F; 2],
    periodic_node_dimensions: [u32; 2],
    vertical_tau_nodes_x_fastest: B<F, 4096>,
    advection_wind_height_m: F,
    low_sun_policy: Text,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Precip {
    origin_xz_m: [F; 2],
    cell_size_xz_m: [F; 2],
    dimensions: [u32; 2],
    cell_multiplier_x_fastest: B<F, 16384>,
    weather_phase_liquid_flux_knots_kg_m2_s: B<(F, F), 256>,
    weather_phase_solid_flux_knots_kg_m2_s: B<(F, F), 256>,
    exposure_ref: Uuid,
    input_reservoir_ref: Uuid,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Air {
    temperature_k: F,
    local_absolute_pressure_pa: F,
    vapour_gas_mass_fraction: F,
    saturation_law: Text,
}
#[derive(Debug)]
struct Source {
    label: Option<Text>,
    profile: Text,
    world_support_m: Box3,
    valid_ticks: [u32; 2],
    day_phase: Phase,
    weather_phase: Phase,
    sun: Sun,
    wind: Wind,
    cloud: Cloud,
    precipitation: Precip,
    air: Option<Air>,
    unsupported: B<Text, 7>,
    opaque: Vec<(String, String)>,
}
impl<'de> Deserialize<'de> for Source {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        struct V;
        impl<'de> Visitor<'de> for V {
            type Value = Source;
            fn expecting(&self, f: &mut fmt::Formatter) -> fmt::Result {
                f.write_str("schema2 authored vertical rain fields")
            }
            fn visit_map<A: MapAccess<'de>>(self, mut a: A) -> Result<Source, A::Error> {
                let (
                    mut label,
                    mut profile,
                    mut world_support_m,
                    mut valid_ticks,
                    mut day_phase,
                    mut weather_phase,
                    mut sun,
                    mut wind,
                    mut cloud,
                    mut precipitation,
                    mut air,
                    mut unsupported,
                ) = (
                    None, None, None, None, None, None, None, None, None, None, None, None,
                );
                let mut opaque: Vec<(String, String)> = Vec::new();
                let nodes = Cell::new(0);
                let mut bytes = 0;
                while let Some(key) = a.next_key::<Text>()? {
                    match key.0.as_str() {
                        "label" if label.is_none() => label = Some(a.next_value()?),
                        "profile" if profile.is_none() => profile = Some(a.next_value()?),
                        "world_support_m" if world_support_m.is_none() => {
                            world_support_m = Some(a.next_value()?)
                        }
                        "valid_ticks" if valid_ticks.is_none() => {
                            valid_ticks = Some(a.next_value()?)
                        }
                        "day_phase" if day_phase.is_none() => day_phase = Some(a.next_value()?),
                        "weather_phase" if weather_phase.is_none() => {
                            weather_phase = Some(a.next_value()?)
                        }
                        "sun" if sun.is_none() => sun = Some(a.next_value()?),
                        "wind" if wind.is_none() => wind = Some(a.next_value()?),
                        "cloud" if cloud.is_none() => cloud = Some(a.next_value()?),
                        "precipitation" if precipitation.is_none() => {
                            precipitation = Some(a.next_value()?)
                        }
                        "air" if air.is_none() => air = Some(a.next_value()?),
                        "unsupported" if unsupported.is_none() => {
                            unsupported = Some(a.next_value()?)
                        }
                        k if k.starts_with("x.thrum.environment.") && k.is_ascii() => {
                            if opaque.len() == 16 || opaque.iter().any(|(old, _)| old == k) {
                                return Err(A::Error::custom("opaque count/duplicate"));
                            }
                            let raw: &RawValue = a.next_value()?;
                            bytes += raw.get().len();
                            if raw.get().len() > 16384 || bytes > 262144 {
                                return Err(A::Error::custom("opaque bytes limit"));
                            }
                            let mut rd = serde_json::Deserializer::from_str(raw.get());
                            Skip {
                                depth: 0,
                                nodes: &nodes,
                                limit: 4096,
                                max_depth: 16,
                                strings: 4096,
                                duplicates: true,
                            }
                            .deserialize(&mut rd)
                            .map_err(A::Error::custom)?;
                            rd.end().map_err(A::Error::custom)?;
                            opaque.push((key.0, raw.get().into()));
                        }
                        _ => return Err(A::Error::custom("duplicate/unknown source field")),
                    }
                }
                fn req<T, E: serde::de::Error>(x: Option<T>) -> Result<T, E> {
                    x.ok_or_else(|| E::custom("missing source field"))
                }
                Ok(Source {
                    label,
                    profile: req(profile)?,
                    world_support_m: req(world_support_m)?,
                    valid_ticks: req(valid_ticks)?,
                    day_phase: req(day_phase)?,
                    weather_phase: req(weather_phase)?,
                    sun: req(sun)?,
                    wind: req(wind)?,
                    cloud: req(cloud)?,
                    precipitation: req(precipitation)?,
                    air,
                    unsupported: req(unsupported)?,
                    opaque,
                })
            }
        }
        d.deserialize_map(V)
    }
}

#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Light {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    driver_binding: Text,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Reservoir {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    material: Text,
    inventory: Text,
    momentum_policy: Text,
    energy_policy: Text,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Sink {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    material: Text,
    boundary: Text,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Exposure {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    source_ref: Uuid,
    entry_world_y_m: F,
    receiver_refs: B<Uuid, 1024>,
    uncovered_sink_ref: Uuid,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Surface {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    xz_rectangle_m: [F; 4],
    world_y_m: F,
    response_patch_id: Uuid,
    response_cell_id: Uuid,
    initial_liquid_kg: F,
    initial_solid_kg: F,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Pond {
    #[serde(default, deserialize_with = "optional")]
    label: Option<Text>,
    xz_rectangle_m: [F; 4],
    flat_bed_world_y_m: F,
    initial_depth_m: F,
    grid_dimensions: [u32; 2],
    water_domain_id: Uuid,
    bed_patch_id: Uuid,
    wall_crest_world_y_m: F,
    stage_valid_m: [F; 2],
    edges: Text,
    liquid_density_kg_m3: F,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Scene {
    #[serde(rename = "scene.label", default, deserialize_with = "optional")]
    label: Option<Text>,
    #[serde(rename = "environment.source", default, deserialize_with = "optional")]
    source: Option<Uuid>,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct Project {
    #[serde(rename = "project.format")]
    format: u32,
    #[serde(rename = "project.records")]
    records: B<Text, 4096>,
    #[serde(rename = "project.schemas")]
    schemas: Empty,
    #[serde(rename = "project.registryHistory")]
    history: Text,
    #[serde(rename = "project.entryScenes")]
    entries: B<Uuid, 4096>,
}
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
struct History {
    #[serde(rename = "registry.fields")]
    fields: Empty,
    #[serde(rename = "registry.versions")]
    versions: Empty,
}
#[derive(Debug)]
enum Record {
    Source(Box<Envelope<Source>>),
    Light(Envelope<Light>),
    Reservoir(Envelope<Reservoir>),
    Sink(Envelope<Sink>),
    Exposure(Envelope<Exposure>),
    Surface(Envelope<Surface>),
    Pond(Envelope<Pond>),
    Scene(Envelope<Scene>),
    Project(Envelope<Project>),
    History(Envelope<History>),
}
impl Record {
    fn id(&self) -> &Uuid {
        match self {
            Self::Source(x) => &x.id,
            Self::Light(x) => &x.id,
            Self::Reservoir(x) => &x.id,
            Self::Sink(x) => &x.id,
            Self::Exposure(x) => &x.id,
            Self::Surface(x) => &x.id,
            Self::Pond(x) => &x.id,
            Self::Scene(x) => &x.id,
            Self::Project(x) => &x.id,
            Self::History(x) => &x.id,
        }
    }
    fn kind(&self) -> &str {
        match self {
            Self::Source(_) => "thrum.environment.authored",
            Self::Light(_) => "thrum.light.identity",
            Self::Reservoir(_) => "thrum.environment.external_reservoir",
            Self::Sink(_) => "thrum.environment.export_sink",
            Self::Exposure(_) => "thrum.environment.vertical_exposure_recipe",
            Self::Surface(_) => "thrum.fixture.static_surface_receiver",
            Self::Pond(_) => "thrum.fixture.closed_shallow_receiver",
            Self::Scene(_) => "core.scene",
            Self::Project(_) => "core.project",
            Self::History(_) => "core.registry-history",
        }
    }
}
fn parse(bytes: &[u8]) -> R<Record> {
    check_json(bytes)?;
    let h: Header<'_> = strict(bytes)?;
    let _ = (&h.id, &h.fields, &h.documentation);
    let r = match (h.kind.0.as_str(), h.schema) {
        ("thrum.environment.authored", 2) => Record::Source(Box::new(strict(bytes)?)),
        ("thrum.light.identity", 1) => Record::Light(strict(bytes)?),
        ("thrum.environment.external_reservoir", 1) => Record::Reservoir(strict(bytes)?),
        ("thrum.environment.export_sink", 1) => Record::Sink(strict(bytes)?),
        ("thrum.environment.vertical_exposure_recipe", 1) => Record::Exposure(strict(bytes)?),
        ("thrum.fixture.static_surface_receiver", 1) => Record::Surface(strict(bytes)?),
        ("thrum.fixture.closed_shallow_receiver", 1) => Record::Pond(strict(bytes)?),
        ("core.scene", 2) => Record::Scene(strict(bytes)?),
        ("core.project", 2) => Record::Project(strict(bytes)?),
        ("core.registry-history", 1) => Record::History(strict(bytes)?),
        _ => return Err("unsupported type/version in this isolated storm prototype".into()),
    };
    Ok(r)
}

// Exact comparison of phase=decoded-f64(initial)+weighted_ticks/3840 against a
// decoded-f64 knot. Finite binary64 *3840*2^1074 fits2176 bits. No bigint heap.
#[derive(Clone)]
struct Wide {
    negative: bool,
    words: [u64; 34],
}
impl Wide {
    fn placed(value: u128, shift: usize, negative: bool) -> Self {
        let mut words = [0; 34];
        for bit in 0..128 {
            if value & (1_u128 << bit) != 0 {
                let i = shift + bit;
                words[i / 64] |= 1_u64 << (i % 64);
            }
        }
        Self {
            negative: negative && words.iter().any(|x| *x != 0),
            words,
        }
    }
    fn scaled(x: f64) -> Self {
        let bits = x.to_bits();
        let exponent = ((bits >> 52) & 0x7ff) as usize;
        let mantissa = (bits & ((1_u64 << 52) - 1)) | if exponent == 0 { 0 } else { 1_u64 << 52 };
        Self::placed(
            u128::from(mantissa) * 3840,
            exponent.saturating_sub(1),
            bits >> 63 != 0,
        )
    }
    fn abs_cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.words.iter().rev().cmp(other.words.iter().rev())
    }
    fn minus(mut a: [u64; 34], b: [u64; 34]) -> [u64; 34] {
        let mut borrow = false;
        for i in 0..34 {
            let (x, b1) = a[i].overflowing_sub(b[i]);
            let (y, b2) = x.overflowing_sub(u64::from(borrow));
            a[i] = y;
            borrow = b1 || b2;
        }
        assert!(!borrow);
        a
    }
    fn plus_weight(self, weight: u64) -> Self {
        let other = Self::placed(u128::from(weight), 1074, false);
        if self.negative {
            match self.abs_cmp(&other) {
                std::cmp::Ordering::Greater => Self {
                    negative: true,
                    words: Self::minus(self.words, other.words),
                },
                _ => Self {
                    negative: false,
                    words: Self::minus(other.words, self.words),
                },
            }
        } else {
            let mut words = [0; 34];
            let mut carry = 0_u128;
            for (i, out) in words.iter_mut().enumerate() {
                let sum = u128::from(self.words[i]) + u128::from(other.words[i]) + carry;
                *out = sum as u64;
                carry = sum >> 64;
            }
            assert_eq!(carry, 0);
            Self {
                negative: false,
                words,
            }
        }
    }
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        match (self.negative, other.negative) {
            (true, false) => std::cmp::Ordering::Less,
            (false, true) => std::cmp::Ordering::Greater,
            (true, true) => self.abs_cmp(other).reverse(),
            _ => self.abs_cmp(other),
        }
    }
}
fn covers(last: f64, initial: f64, weight: u64) -> bool {
    Wide::scaled(last).cmp(&Wide::scaled(initial).plus_weight(weight)) != std::cmp::Ordering::Less
}
fn phase_weight(phase: &Phase, end: u32) -> R<u64> {
    need(
        !phase.rates.0.is_empty() && phase.rates.0[0].from_tick == 0,
        "phase first rate anchor",
    )?;
    let mut weight = 0_u64;
    for (i, rate) in phase.rates.0.iter().enumerate() {
        need(
            rate.num <= 240 && [1, 2, 4, 8, 16, 32, 64].contains(&rate.den) && rate.from_tick < end,
            "phase rational rate bounds",
        )?;
        let next = phase.rates.0.get(i + 1).map_or(end, |x| x.from_tick);
        need(
            next > rate.from_tick && next <= end,
            "phase start order/coverage",
        )?;
        weight +=
            u64::from(next - rate.from_tick) * u64::from(rate.num) * (64 / u64::from(rate.den));
    }
    Ok(weight)
}
fn norm(v: [F; 3]) -> f64 {
    (((v[0].0 * v[0].0) + (v[1].0 * v[1].0)) + (v[2].0 * v[2].0)).sqrt()
}
fn luminance(c: [F; 3]) -> f64 {
    ((0.2126 * c[0].0) + (0.7152 * c[1].0)) + (0.0722 * c[2].0)
}
fn nonnegative(xs: impl IntoIterator<Item = f64>) -> bool {
    xs.into_iter().all(|x| x >= 0.0)
}
fn rect(r: [F; 4]) -> R<()> {
    need(
        r[0].0 < r[2].0
            && r[1].0 < r[3].0
            && (r[2].0 - r[0].0).is_finite()
            && (r[3].0 - r[1].0).is_finite(),
        "positive finite rectangle",
    )
}
fn ordered(xs: impl IntoIterator<Item = f64>) -> bool {
    let mut last = None;
    for x in xs {
        if last.is_some_and(|old| x <= old) {
            return false;
        }
        last = Some(x);
    }
    true
}
fn track<T>(rows: &[(F, T)], initial: f64, weight: u64) -> R<()> {
    need(
        rows.len() >= 2
            && ordered(rows.iter().map(|x| x.0.0))
            && rows[0].0.0 <= initial
            && covers(rows.last().unwrap().0.0, initial, weight),
        "track phase order/exact coverage",
    )
}

fn source_check(s: &Source) -> R<()> {
    let _ = (&s.label, &s.opaque, &s.sun.applied_attenuation);
    need(s.profile.0 == "authored-vertical-rain-v1", "source profile")?;
    need(
        s.valid_ticks[0] == 0 && (1..=216000).contains(&s.valid_ticks[1]),
        "valid_ticks anchor/duration",
    )?;
    for i in 0..3 {
        need(
            s.world_support_m.min[i].0 < s.world_support_m.max[i].0,
            "support min/max",
        )?;
    }
    for i in [0, 2] {
        let d = s.world_support_m.max[i].0 - s.world_support_m.min[i].0;
        need(d.is_finite() && d <= 512.0, "world horizontal extent")?;
    }
    need(
        s.world_support_m.min[1].0 >= -10.0 && s.world_support_m.max[1].0 <= 1000.0,
        "world height limits",
    )?;
    phase_weight(&s.day_phase, s.valid_ticks[1])?;
    let weight = phase_weight(&s.weather_phase, s.valid_ticks[1])?;
    need(
        (norm(s.sun.initial_toward_source_unit) - 1.0).abs() <= 1e-6
            && (norm(s.sun.rotation_axis_unit) - 1.0).abs() <= 1e-6,
        "schema2 vector normalization",
    )?;
    need(
        nonnegative(s.sun.unit_luminance_linear_rec709.map(|x| x.0))
            && (luminance(s.sun.unit_luminance_linear_rec709) - 1.0).abs() <= 1e-6,
        "schema2 colour normalization",
    )?;
    need(
        s.sun.period_phase_seconds.0 > 0.0
            && s.sun.peak_perpendicular_illuminance_lux.0 >= 0.0
            && s.sun.angular_radius_rad.0 >= 0.0
            && s.sun.intensity_envelope.0 == "positive-world-y-squared"
            && s.sun.direction_model.0 == "geometric-straight",
        "Sun raw descriptor",
    )?;
    let heights = &s.wind.vertical_multiplier.0;
    need(
        heights.len() >= 2
            && ordered(heights.iter().map(|x| x.0.0))
            && heights.iter().all(|(h, a)| {
                h.0 >= 0.0
                    && h.0 <= 1000.0
                    && a.0 >= 0.0
                    && h.0 >= s.world_support_m.min[1].0
                    && h.0 <= s.world_support_m.max[1].0
            }),
        "wind height knots",
    )?;
    let hmin = heights[0].0.0;
    let hmax = heights.last().unwrap().0.0;
    need(
        (hmin..=hmax).contains(&s.wind.reference_height_m.0)
            && (hmin..=hmax).contains(&s.cloud.advection_wind_height_m.0),
        "wind reference/advection heights",
    )?;
    let wind = &s.wind.weather_phase_vector_knots_mps.0;
    need(wind.iter().all(|(_, v)| v[1].0 == 0.0), "horizontal wind")?;
    track(wind, s.weather_phase.initial_seconds.0, weight)?;
    for track_values in [
        &s.precipitation.weather_phase_liquid_flux_knots_kg_m2_s.0,
        &s.precipitation.weather_phase_solid_flux_knots_kg_m2_s.0,
    ] {
        need(
            nonnegative(track_values.iter().map(|x| x.1.0)),
            "nonnegative flux",
        )?;
        track(track_values, s.weather_phase.initial_seconds.0, weight)?;
    }
    need(
        wind.len()
            + s.precipitation
                .weather_phase_liquid_flux_knots_kg_m2_s
                .0
                .len()
            + s.precipitation
                .weather_phase_solid_flux_knots_kg_m2_s
                .0
                .len()
            <= 256,
        "aggregate temporal knot limit",
    )?;
    let c = &s.cloud;
    need(
        c.periodic_node_dimensions
            .iter()
            .all(|n| (1..=64).contains(n))
            && c.vertical_tau_nodes_x_fastest.0.len()
                == (c.periodic_node_dimensions[0] * c.periodic_node_dimensions[1]) as usize
            && c.spacing_xz_m.iter().all(|x| x.0 > 0.0)
            && c.vertical_tau_nodes_x_fastest
                .0
                .iter()
                .all(|x| (0.0..=8.0).contains(&x.0))
            && c.low_sun_policy.0 == "authored-fade-to-clear-0.2-to-0.1",
        "cloud grid/meaning",
    )?;
    need(
        c.plane_height_m.0 >= s.world_support_m.min[1].0
            && c.plane_height_m.0 <= s.world_support_m.max[1].0,
        "cloud plane support",
    )?;
    for i in 0..2 {
        need(
            (f64::from(c.periodic_node_dimensions[i]) * c.spacing_xz_m[i].0).is_finite(),
            "finite cloud period",
        )?;
    }
    let _ = c.map_origin_xz_m;
    let p = &s.precipitation;
    need(
        p.dimensions.iter().all(|n| (1..=128).contains(n))
            && p.cell_multiplier_x_fastest.0.len() == (p.dimensions[0] * p.dimensions[1]) as usize
            && p.cell_size_xz_m.iter().all(|x| x.0 > 0.0)
            && p.cell_multiplier_x_fastest.0.iter().all(|x| x.0 >= 0.0),
        "rain grid/meaning",
    )?;
    for (i, world_i) in [(0, 0), (1, 2)] {
        let end = p.origin_xz_m[i].0 + p.cell_size_xz_m[i].0 * f64::from(p.dimensions[i]);
        need(
            end.is_finite()
                && p.origin_xz_m[i].0 >= s.world_support_m.min[world_i].0
                && end <= s.world_support_m.max[world_i].0,
            "rain support within source",
        )?;
    }
    let mut unsupported: BTreeSet<&str> = BTreeSet::new();
    for value in &s.unsupported.0 {
        need(unsupported.insert(&value.0), "duplicate unsupported")?;
    }
    let mut expected: BTreeSet<&str> = BASE_UNSUPPORTED.into_iter().collect();
    if s.air.is_none() {
        expected.insert("air");
    }
    need(unsupported == expected, "unsupported exact set/air absence")?;
    if let Some(a) = &s.air {
        need(
            (273.15..=313.15).contains(&a.temperature_k.0)
                && a.local_absolute_pressure_pa.0 > 0.0
                && (0.0..1.0).contains(&a.vapour_gas_mass_fraction.0)
                && a.saturation_law.0 == "nws-liquid-magnus-bounded-v1",
            "air constants/model",
        )?;
    }
    Ok(())
}
#[derive(Debug)]
struct Summary {
    records: usize,
    namespace: usize,
    edges: usize,
    receivers: usize,
    expanded: usize,
    logical_payload_bytes: usize,
}
fn closure(records: &[(String, Record)]) -> R<Summary> {
    need(records.len() <= 4096, "record count")?;
    let mut namespace = BTreeSet::new();
    let mut map = BTreeMap::new();
    let mut logical = 0;
    for (_, record) in records {
        need(
            namespace.insert(record.id().clone()),
            "duplicate global record UUID",
        )?;
        map.insert(record.id(), record);
        match record {
            Record::Surface(x) => {
                for id in [&x.fields.response_patch_id, &x.fields.response_cell_id] {
                    need(namespace.insert(id.clone()), "duplicate embedded UUID")?;
                }
            }
            Record::Pond(x) => {
                for id in [&x.fields.water_domain_id, &x.fields.bed_patch_id] {
                    need(namespace.insert(id.clone()), "duplicate embedded UUID")?;
                }
            }
            _ => {}
        }
    }
    let mut edges = 0;
    let mut receivers = 0;
    let mut expanded = 0;
    let mut target = |id: &Uuid, kinds: &[&str]| -> R<&Record> {
        edges += 1;
        need(edges <= 65536, "required edge cap")?;
        let r = map.get(id).ok_or("missing reference")?;
        need(kinds.contains(&r.kind()), "wrong reference type")?;
        Ok(r)
    };
    let projects: Vec<_> = records
        .iter()
        .filter_map(|(_, r)| {
            if let Record::Project(x) = r {
                Some(x)
            } else {
                None
            }
        })
        .collect();
    need(projects.len() == 1, "exactly one project")?;
    let project = projects[0];
    let pf = &project.fields;
    let _ = (
        &project.kind,
        &project.schema,
        &project.documentation,
        &pf.schemas,
    );
    need(
        pf.format == 1
            && pf.history.0 == "schemas/history.registry.json"
            && !pf.entries.0.is_empty()
            && ordered_text(pf.entries.0.iter().map(|x| x.0.as_str())),
        "project declaration",
    )?;
    let mut declared: Vec<_> = records
        .iter()
        .filter(|(_, r)| !matches!(r, Record::Project(_) | Record::History(_)))
        .map(|(path, _)| path.as_str())
        .collect();
    declared.sort_unstable();
    let declared_fields: Vec<_> = pf.records.0.iter().map(|x| x.0.as_str()).collect();
    need(
        declared_fields == declared,
        "project.records exact sorted membership",
    )?;
    need(
        records
            .iter()
            .filter(|(path, r)| path == &pf.history.0 && matches!(r, Record::History(_)))
            .count()
            == 1,
        "history membership",
    )?;
    let mut selected = false;
    for id in &pf.entries.0 {
        let scene = map.get(id).ok_or("entry scene missing")?;
        if let Record::Scene(s) = scene {
            selected |= s.fields.source.is_some();
        } else {
            return Err("entry scene wrong type".into());
        }
    }
    need(
        !selected || pf.entries.0.len() == 1,
        "single selected entry scene",
    )?;
    for (_, record) in records {
        match record {
            Record::Source(x) => {
                source_check(&x.fields)?;
                let s = &x.fields;
                target(&s.sun.light_ref, &["thrum.light.identity"])?;
                target(
                    &s.precipitation.input_reservoir_ref,
                    &["thrum.environment.external_reservoir"],
                )?;
                let r = target(
                    &s.precipitation.exposure_ref,
                    &["thrum.environment.vertical_exposure_recipe"],
                )?;
                if let Record::Exposure(e) = r {
                    need(e.fields.source_ref == x.id, "source/exposure reciprocal")?;
                }
                logical += s.wind.vertical_multiplier.0.capacity() * std::mem::size_of::<(F, F)>()
                    + s.wind.weather_phase_vector_knots_mps.0.capacity()
                        * std::mem::size_of::<(F, [F; 3])>()
                    + s.cloud.vertical_tau_nodes_x_fastest.0.capacity() * 8
                    + s.precipitation.cell_multiplier_x_fastest.0.capacity() * 8;
            }
            Record::Scene(x) => {
                let _ = &x.fields.label;
                if let Some(id) = &x.fields.source {
                    target(id, &["thrum.environment.authored"])?;
                }
            }
            Record::Light(x) => {
                let _ = &x.fields.label;
                need(
                    x.fields.driver_binding.0 == "incoming-environment-sun",
                    "light incoming driver",
                )?;
            }
            Record::Reservoir(x) => {
                let f = &x.fields;
                let _ = &f.label;
                need(
                    f.material.0 == "water"
                        && f.inventory.0 == "unbounded-external"
                        && f.momentum_policy.0 == "zero-horizontal-no-impact-force"
                        && f.energy_policy.0 == "unrepresented",
                    "external reservoir policy",
                )?;
            }
            Record::Sink(x) => {
                let _ = &x.fields.label;
                need(
                    x.fields.material.0 == "water" && x.fields.boundary.0 == "exported",
                    "export sink policy",
                )?;
            }
            Record::Exposure(x) => {
                let f = &x.fields;
                let _ = &f.label;
                let source = target(&f.source_ref, &["thrum.environment.authored"])?;
                let Record::Source(source) = source else {
                    unreachable!()
                };
                need(
                    source.fields.precipitation.exposure_ref == x.id,
                    "exposure/source reciprocal",
                )?;
                target(&f.uncovered_sink_ref, &["thrum.environment.export_sink"])?;
                need(!f.receiver_refs.0.is_empty(), "receiver refs nonempty")?;
                let mut unique = BTreeSet::new();
                let mut pond_count = 0;
                let mut expanded_here = 0;
                for id in &f.receiver_refs.0 {
                    need(unique.insert(id), "duplicate receiver ref")?;
                    let r = target(
                        id,
                        &[
                            "thrum.fixture.static_surface_receiver",
                            "thrum.fixture.closed_shallow_receiver",
                        ],
                    )?;
                    let (rectangle, low, high) = match r {
                        Record::Surface(r) => {
                            expanded_here += 1;
                            (
                                r.fields.xz_rectangle_m,
                                r.fields.world_y_m.0,
                                r.fields.world_y_m.0,
                            )
                        }
                        Record::Pond(r) => {
                            pond_count += 1;
                            expanded_here += 16;
                            need(
                                source
                                    .fields
                                    .precipitation
                                    .weather_phase_solid_flux_knots_kg_m2_s
                                    .0
                                    .iter()
                                    .all(|(_, v)| v.0 == 0.0),
                                "liquid-only fixed pond rejects solid rain",
                            )?;
                            (
                                r.fields.xz_rectangle_m,
                                r.fields.flat_bed_world_y_m.0,
                                r.fields.wall_crest_world_y_m.0,
                            )
                        }
                        _ => unreachable!(),
                    };
                    let p = &source.fields.precipitation;
                    for (i, lo, hi) in [
                        (0, rectangle[0].0, rectangle[2].0),
                        (1, rectangle[1].0, rectangle[3].0),
                    ] {
                        need(
                            lo >= p.origin_xz_m[i].0
                                && hi
                                    <= p.origin_xz_m[i].0
                                        + p.cell_size_xz_m[i].0 * f64::from(p.dimensions[i]),
                            "receiver outside rain support",
                        )?;
                    }
                    need(
                        low >= -10.0
                            && high <= 500.0
                            && low >= source.fields.world_support_m.min[1].0
                            && high <= source.fields.world_support_m.max[1].0
                            && high < f.entry_world_y_m.0
                            && high < source.fields.cloud.plane_height_m.0,
                        "receiver/entry/cloud height support",
                    )?;
                    receivers += 1;
                }
                need(
                    pond_count <= 1 && expanded_here <= 1024,
                    "fixed pond/expanded receiver limit",
                )?;
                expanded += expanded_here;
                need(
                    f.entry_world_y_m.0 >= source.fields.world_support_m.min[1].0
                        && f.entry_world_y_m.0 <= source.fields.world_support_m.max[1].0,
                    "entry plane in support",
                )?;
            }
            Record::Surface(x) => {
                let f = &x.fields;
                let _ = &f.label;
                rect(f.xz_rectangle_m)?;
                need(
                    (-10.0..=500.0).contains(&f.world_y_m.0),
                    "surface height profile",
                )?;
                need(
                    nonnegative([f.initial_liquid_kg.0, f.initial_solid_kg.0]),
                    "surface initial stores",
                )?;
            }
            Record::Pond(x) => {
                let f = &x.fields;
                let _ = &f.label;
                rect(f.xz_rectangle_m)?;
                need(
                    (-10.0..=500.0).contains(&f.flat_bed_world_y_m.0)
                        && (-10.0..=500.0).contains(&f.wall_crest_world_y_m.0),
                    "pond height profile",
                )?;
                let initial = f.flat_bed_world_y_m.0 + f.initial_depth_m.0;
                need(
                    f.initial_depth_m.0 > 0.0
                        && f.liquid_density_kg_m3.0 > 0.0
                        && f.grid_dimensions == [4, 4]
                        && f.edges.0 == "closed-reflective"
                        && initial.is_finite()
                        && f.flat_bed_world_y_m.0 < f.stage_valid_m[0].0
                        && f.stage_valid_m[0].0 <= initial
                        && initial <= f.stage_valid_m[1].0
                        && f.stage_valid_m[1].0 < f.wall_crest_world_y_m.0,
                    "fixed wet pond stage/geometry",
                )?;
            }
            Record::History(x) => {
                let _ = (&x.fields.fields, &x.fields.versions);
            }
            Record::Project(_) => {}
        }
    }
    Ok(Summary {
        records: records.len(),
        namespace: namespace.len(),
        edges,
        receivers,
        expanded,
        logical_payload_bytes: logical,
    })
}
fn ordered_text<'a>(xs: impl IntoIterator<Item = &'a str>) -> bool {
    let mut last = None;
    for x in xs {
        if last.is_some_and(|old| old >= x) {
            return false;
        }
        last = Some(x);
    }
    true
}
fn files(root: &Path) -> R<Vec<(String, Vec<u8>)>> {
    fn walk(root: &Path, current: &Path, out: &mut Vec<(String, Vec<u8>)>) -> R<()> {
        for entry in fs::read_dir(current).map_err(|e| e.to_string())? {
            let entry = entry.map_err(|e| e.to_string())?;
            if entry.file_type().map_err(|e| e.to_string())?.is_dir() {
                walk(root, &entry.path(), out)?;
            } else {
                need(
                    entry.file_type().map_err(|e| e.to_string())?.is_file(),
                    "prototype fixture requires regular files",
                )?;
                need(out.len() < 4096, "record count before decode")?;
                need(
                    entry.metadata().map_err(|e| e.to_string())?.len() <= MAX_BYTES as u64,
                    "record bytes before read",
                )?;
                let path = entry
                    .path()
                    .strip_prefix(root)
                    .unwrap()
                    .to_str()
                    .unwrap()
                    .replace('\\', "/");
                out.push((path, fs::read(entry.path()).map_err(|e| e.to_string())?));
            }
        }
        Ok(())
    }
    let mut out = Vec::new();
    walk(root, root, &mut out)?;
    out.sort_by(|a, b| a.0.cmp(&b.0));
    Ok(out)
}
#[cfg(test)]
fn validate(input: &[(String, Vec<u8>)]) -> R<Summary> {
    let mut records = Vec::with_capacity(input.len());
    for (path, bytes) in input {
        records.push((
            path.clone(),
            parse(bytes).map_err(|e| format!("{path}: {e}"))?,
        ));
    }
    closure(&records)
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    if args.get(1).map(String::as_str) == Some("--phase") {
        let initial = f64::from_bits(u64::from_str_radix(&args[2], 16).unwrap());
        let last = f64::from_bits(u64::from_str_radix(&args[3], 16).unwrap());
        let weight = args[4].parse().unwrap();
        assert!(initial.is_finite() && last.is_finite());
        println!("{}", covers(last, initial, weight));
        return;
    }
    if args.get(1).map(String::as_str) == Some("--baseline") {
        println!("baseline process; no parse");
        return;
    }
    if args.get(1).map(String::as_str) == Some("--definitions") {
        let mut paths: Vec<_> = fs::read_dir(&args[2])
            .unwrap()
            .map(|e| e.unwrap().path())
            .collect();
        paths.sort();
        for p in paths {
            let bytes = fs::read(&p).unwrap();
            let mut digest = Sha256::new();
            digest.update(b"thrum-f3-builtin-schema-v1\0");
            digest.update(bytes);
            println!(
                "{} {}",
                p.file_name().unwrap().to_str().unwrap(),
                digest
                    .finalize()
                    .iter()
                    .map(|b| format!("{b:02x}"))
                    .collect::<String>()
            );
        }
        return;
    }
    let input = match files(Path::new(args.get(1).expect("fixture root"))) {
        Ok(input) => input,
        Err(e) => {
            eprintln!("REFUSED {e}");
            std::process::exit(2)
        }
    };
    let repetitions: usize = args.get(2).map(|x| x.parse().unwrap()).unwrap_or(1);
    let start = Instant::now();
    let mut parse_ns = 0_u128;
    let mut closure_ns = 0_u128;
    let mut summary = None;
    for _ in 0..repetitions {
        let decoded_at = Instant::now();
        let decoded: R<Vec<_>> = std::hint::black_box(&input)
            .iter()
            .map(|(path, bytes)| parse(bytes).map(|record| (path.clone(), record)))
            .collect();
        parse_ns += decoded_at.elapsed().as_nanos();
        let closed_at = Instant::now();
        let result = decoded.and_then(|records| closure(&records));
        closure_ns += closed_at.elapsed().as_nanos();
        match result {
            Ok(x) => summary = Some(x),
            Err(e) => {
                eprintln!("REFUSED {e}");
                std::process::exit(2)
            }
        }
    }
    let s = summary.unwrap();
    println!(
        "PASS records={} namespace={} required_edges={} receiver_records={} expanded_receivers={} input_bytes={} scoped_grid_wind_capacity_bytes={} repetitions={} parse_us={} closure_us={} elapsed_us={}",
        s.records,
        s.namespace,
        s.edges,
        s.receivers,
        s.expanded,
        input.iter().map(|x| x.1.len()).sum::<usize>(),
        s.logical_payload_bytes,
        repetitions,
        parse_ns / 1000,
        closure_ns / 1000,
        start.elapsed().as_micros()
    );
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_phase_edges() {
        assert!(covers(1.0, 0.0, 3840));
        assert!(!covers(f64::from_bits(1.0_f64.to_bits() - 1), 0.0, 3840));
        assert!(covers(0.0, -1.0, 3840));
        assert!(!covers(-f64::from_bits(1), -1.0, 3840));
        assert!(covers(f64::MAX, f64::MAX, 0));
        assert!(!covers(f64::MAX, f64::MAX, 1));
        assert!(covers(-f64::MAX, -f64::MAX, 0));
        assert!(!covers(-f64::MAX, -f64::MAX, 1));
        assert!(covers(f64::from_bits(1), 0.0, 0));
    }
    #[test]
    fn opaque_value_spelling_survives_a_known_neighbor_proposal() {
        let base = fs::read_to_string(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/fixture/records/environment.record.json"
        ))
        .unwrap();
        let raw = r#"{ "decimal":1.00,"escaped":"\u0061","list":[-0,null,true] }"#;
        let original = base.replace(
            "\"profile\":",
            &format!("\"x.thrum.environment.note\":{raw},\"profile\":"),
        );
        let edited = original.replace(
            "\"peak_perpendicular_illuminance_lux\":100000",
            "\"peak_perpendicular_illuminance_lux\":75000",
        );
        assert_ne!(original, edited);
        let Record::Source(a) = parse(original.as_bytes()).unwrap() else {
            panic!()
        };
        let Record::Source(b) = parse(edited.as_bytes()).unwrap() else {
            panic!()
        };
        assert_eq!(a.fields.opaque, b.fields.opaque);
        assert_eq!(
            b.fields.opaque,
            [("x.thrum.environment.note".to_owned(), raw.to_owned())]
        );
        assert_eq!(b.fields.sun.peak_perpendicular_illuminance_lux.0, 75000.0);
    }
    #[test]
    fn positive() {
        let input = files(Path::new(concat!(env!("CARGO_MANIFEST_DIR"), "/fixture"))).unwrap();
        let s = validate(&input).unwrap();
        assert_eq!(
            (s.records, s.namespace, s.edges, s.receivers, s.expanded),
            (12, 20, 10, 4, 19)
        );
    }
}
