# Proposed E1 rain F3 grammar proof

This scratch package freezes a proposed `thrum.environment.authored` schema2
`authored-vertical-rain-v1` grammar and six type/version definition records before
production dispatch. Nothing here admits a source, creates an F4 product,
executes F1 or qualifies a renderer. The owner decisions remain unadopted until
C09/F3/F4 review. Read the repository research document for the five decisions
and the explicit failure to supply R0's required ambient/background closure.

Reproduce from the repository root with:

```sh
python3 tmp/e1-rain-f3-schema/run.py
```

The runner regenerates the known fixture and definition bytes, verifies the
unchanged SDK schema1/scene/light hashes, checks fmt and Clippy, runs native
debug/release tests, independently compares all definition hashes, executes the
Python/Rust adversarial matrix and Fraction/native phase comparisons, and runs
serial native RSS/cost probes. It requires Rust1.99.1 and the pinned cached
Cargo dependencies, offline. Cargo builds only inside this scratch directory.
The archived source is intended to be extracted back at this path in a Thrum
checkout. `prepare.py` checks the current paper fixture against the pinned raw
input instead of silently accepting a changed source recipe.

The selected batch records3 native debug and3 release tests,104 adversarial
cases (15 positive variants,89 refusals), and856 independent exact phase
comparisons. Global required edges are tested at65536 accepted and65537
refused, using otherwise valid reciprocal graphs, not malformed references.
The opaque retention unit test verifies raw value spelling across a manually
constructed neighboring numeric edit; it is not a production editor test.

`definitions/` contains the exact proposed meaning bytes and
`definition-hashes.json` their hashes. Hashing uses the existing SDK domain
`thrum-f3-builtin-schema-v1` plus NUL followed by exact definition bytes.
`table.hash` is a proof-local aggregate hash, not a source or build revision.
`fixture/` is the selected12-record source closure, with8 embedded IDs and10
required references. `fixture.tree-manifest.jcs.json` is outside that source
root. It is metadata, not an admitted-source lease.

The native parser has no generic JSON Value tree. It performs a bounded whole
JSON walk, a borrowed header read, and fixed typed decoding. Serde derives are
used for the experiment; production can reuse its existing bounded header and
hand-written visitors, avoiding this prototype's extra walk and without adding
a new source-carried schema framework. Arbitrary game schemas/history are not
reimplemented here; the genesis project/scene/history mirror only closes this
fixture. Global namespace/ref checks are separate from decoding. The boxed
large source avoids reserving832 bytes for every non-source enum record.
Exact phase coverage uses a2176-bit stack integer comparator; Python Fraction
is its independent oracle. No unsafe allocator observer was added.

The selected RSS values include process startup, immutable input buffers,
typed decoding and temporary closure structures; they do not measure a whole
source admission or maximum engine profile. Closure timings include source
cross-field checks and releasing decoded records. The tracked grid/wind Vec
capacity is a partial logical count, not peak heap. Native process RSS is
obtained by a fresh Python wrapper's RUSAGE_CHILDREN ru_maxrss; on Darwin it is
bytes. Compiler/case/binary identities and raw samples are retained. CPU model,
other host activity, allocator request counts and production maxima are not
qualified. The native parser measurements exclude source-file reads from the
timed parse/closure loop, while RSS includes those input buffers.

`cook_boundaries.py` only diagnoses the selected fixture's source/F4/F2 boundary:
a source cloud gradient0.01 becomes0.010000000149011612 after f32 quantization,
so F4 must recheck; a finite1e308 multiplier must refuse f32 conversion. It does
not cook geometry, products or forcing. Its global wind derivative bound is
conservative and is not a prescribed production acceptance algorithm.

The large dense fixture, per-case mutations, Python caches and Cargo target are
regenerable and removed at closeout. Keep only sources/lock, exact definitions,
the small selected fixture, compact correctness/measurement output and their
SHA-256 inventory. A small proof archive is selected research evidence; it does
not promote these choices into the SDK or canonical contracts.
