#!/usr/bin/env python3
"""Fixture-only derived gate diagnostics; does not produce an F4 product."""
from pathlib import Path
import json,math,struct
HERE=Path(__file__).resolve().parent

def f32(x):return struct.unpack('<f',struct.pack('<f',x))[0]
def gradient(c,quantize):
    nx,nz=c['periodic_node_dimensions'];dx,dz=c['spacing_xz_m'];nodes=[f32(x)if quantize else float(x)for x in c['vertical_tau_nodes_x_fastest']]
    maximum=0.0
    for z in range(nz):
        for x in range(nx):
            a=nodes[z*nx+x];b=nodes[z*nx+(x+1)%nx];cc=nodes[((z+1)%nz)*nx+x];d=nodes[((z+1)%nz)*nx+(x+1)%nx]
            maximum=max(maximum,*(math.hypot(gx,gz)for gx in((b-a)/dx,(d-cc)/dx)for gz in((cc-a)/dz,(d-b)/dz)))
    return maximum

def main():
    s=json.loads((HERE/'fixture/records/environment.record.json').read_bytes())['fields']
    amax=max(row[1]for row in s['wind']['vertical_multiplier']);knots=s['wind']['weather_phase_vector_knots_mps']
    speed=amax*max(math.hypot(*row[1])for row in knots)
    rate=max(row['num']/row['den']for row in s['weather_phase']['rates'])
    derivative=amax*rate*max(math.hypot(*(b-a for a,b in zip(left[1],right[1])))/(right[0]-left[0])for left,right in zip(knots,knots[1:]))
    air=s['air'];epsilon=287.05/461.5;q=air['vapour_gas_mass_fraction'];vapour=q*air['local_absolute_pressure_pa']/(epsilon+(1-epsilon)*q);tc=air['temperature_k']-273.15;rh=vapour/(611.2*math.exp(17.67*tc/(tc+243.5)))
    g=gradient(s['cloud'],True);assert g<=.01 and speed<=40 and derivative<=.5 and 0<=rh<=1
    boundary=dict(s['cloud']);boundary['vertical_tau_nodes_x_fastest']=[0,.4,0,.4];boundary['spacing_xz_m']=[40,64]
    before=gradient(boundary,False);after=gradient(boundary,True)
    assert before<=.01 and after>.01
    try:f32(1e308)
    except OverflowError:overflow_refused=True
    else:raise AssertionError('f32 overflow not detected')
    result={'fixture_f32_cloud_gradient_per_m':g,'fixture_conservative_speed_bound_m_s':speed,'fixture_conservative_world_time_derivative_m_s2':derivative,'fixture_tick_hold_bound_m_s':derivative/60,'fixture_RH':rh,'source_boundary_gradient':before,'cooked_boundary_gradient':after,'boundary_requires_F4_refusal':True,'f64_multiplier_overflow_requires_F4_refusal':overflow_refused,'scope':'fixture-only F4/F2 diagnostics; global wind bounds may reject extra candidates; no geometry or forcing product'}
    (HERE/'cook-boundaries.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,sort_keys=True))
if __name__=='__main__':main()
