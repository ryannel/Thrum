# Scratch ownership

Owner: e1_source_parser, bounded schema design/proof commission, 3 November 2026.
Purpose: proposed schema-2 rain grammar, strict parser/closure prototype and independent oracle before production dispatch.
Inputs: canonical Foundation/Environment/C08/C09 and the 2 November dogfood fixture; baseline schema1/scene/light definition hashes.
Expected peak: below512 MiB of owned build outputs; source/evidence retained below1 MiB.
Retain: selected fixture, exact definitions/hashes, Rust/Python/lock sources and compact correctness/cost results. Remove regenerable build/cache/adversarial bulk at closeout after verification.
No production source, canonical contracts, Build Plan or maturity edits are authorized. Scratch fixtures are local-only, not admitted source or a backup.
