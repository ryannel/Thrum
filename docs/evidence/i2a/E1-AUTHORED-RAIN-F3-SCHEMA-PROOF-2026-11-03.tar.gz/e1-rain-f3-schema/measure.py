#!/usr/bin/env python3
"""Isolated Darwin child RSS and native parse/closure timing; no unsafe hooks."""
from pathlib import Path
import importlib.util,json,os,resource,statistics,subprocess,sys,time,shutil
HERE=Path(__file__).resolve().parent

def one(binary,fixture,repetitions):
    command=[str(binary),'--baseline']if fixture=='--baseline'else[str(binary),str(fixture),str(repetitions)]
    start=time.perf_counter_ns();p=subprocess.run(command,text=True,capture_output=True,check=True);wall=time.perf_counter_ns()-start
    rss=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    values={}
    if p.stdout.startswith('PASS '):
        for token in p.stdout.split()[1:]:
            k,v=token.split('=');values[k]=int(v)
    return {'command':command,'stdout':p.stdout.strip(),'process_wall_ns':wall,'ru_maxrss':rss,'rss_units':'bytes on Darwin'if sys.platform=='darwin'else'OS-reported units',**values}

def main():
    if len(sys.argv)>1 and sys.argv[1]=='--one':
        print(json.dumps(one(Path(sys.argv[2]),sys.argv[3],int(sys.argv[4]))));return
    binary=Path(sys.argv[1]).resolve()
    spec=importlib.util.spec_from_file_location('prep',HERE/'prepare.py');p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
    dense=p.dense_fixture()
    rows=[]
    try:
        for name,fixture,reps in [('baseline','--baseline',1),('fixture-once',HERE/'fixture',1),('fixture-warm',HERE/'fixture',2000),('dense-once',dense,1),('dense-warm',dense,100)]:
            samples=[]
            for _ in range(3):
                result=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--one',str(binary),str(fixture),str(reps)],capture_output=True,text=True,check=True)
                samples.append(json.loads(result.stdout))
            row={'case':name,'samples':samples,'peak_rss_bytes':max(x['ru_maxrss']for x in samples)}
            if'parse_us'in samples[0]:
                row['median_parse_us_per_iteration']=statistics.median(x['parse_us']/reps for x in samples)
                row['median_closure_us_per_iteration']=statistics.median(x['closure_us']/reps for x in samples)
                row['median_total_us_per_iteration']=statistics.median(x['elapsed_us']/reps for x in samples)
            rows.append(row)
            print(name,json.dumps({k:v for k,v in row.items()if k!='samples'},sort_keys=True))
        (HERE/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
    finally:shutil.rmtree(dense)

if __name__=='__main__':main()
