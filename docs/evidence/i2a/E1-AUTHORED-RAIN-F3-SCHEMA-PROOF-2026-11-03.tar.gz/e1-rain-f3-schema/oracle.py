#!/usr/bin/env python3
"""Independent bounded syntax/semantic oracle. Not an engine source admission API."""
import json
import math
from fractions import Fraction
from pathlib import Path
import re

MAX_BYTES=16*1024*1024
BASE={'moon','thermal_irradiance','air_quality','cloud_density_volume','optical_air','terminal_sky'}
UUID=re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\Z')
class Refusal(ValueError):pass

def require(condition,reason):
    if not condition:raise Refusal(reason)

def bounded_syntax(raw):
    require(len(raw)<=MAX_BYTES,'record bytes')
    text=raw.decode('utf8','strict');i=0;depth=0;nodes=0
    while i<len(text):
        c=text[i]
        if c.isspace() or c in ',:':i+=1;continue
        if c in '[{':
            depth+=1;nodes+=1;require(depth<=64,'whole depth');i+=1
        elif c in ']}':depth-=1;i+=1
        elif c=='"':
            i+=1
            while i<len(text):
                if text[i]=='\\':i+=2
                elif text[i]=='"':i+=1;break
                else:i+=1
            j=i
            while j<len(text) and text[j].isspace():j+=1
            if j>=len(text) or text[j]!=':':nodes+=1
        else:
            nodes+=1
            while i<len(text) and text[i] not in ',]} \t\r\n':i+=1
        require(nodes<=1_000_000,'whole nodes')
    return text

def unique(pairs):
    out={}
    for k,v in pairs:
        k.encode('utf8','strict');require(k not in out,'duplicate key');out[k]=v
    return out

def parse(raw):
    text=bounded_syntax(raw)
    def finite(value):
        x=float(value);require(math.isfinite(x),'finite JSON');return x
    def constant(value):raise Refusal('non-I-JSON constant '+value)
    def bounded_integer(token):
        value=int(token)
        try: finite_value=float(value)
        except OverflowError: raise Refusal('integer cannot decode as finite f64')
        require(math.isfinite(finite_value),'integer cannot decode as finite f64')
        return -0.0 if token=='-0' else value
    obj=json.loads(text,object_pairs_hook=unique,parse_float=finite,parse_int=bounded_integer,parse_constant=constant)
    def unicode_check(x):
        if isinstance(x,str):x.encode('utf8','strict')
        elif isinstance(x,list):
            for v in x:unicode_check(v)
        elif isinstance(x,dict):
            for k,v in x.items():k.encode('utf8','strict');unicode_check(v)
    unicode_check(obj)
    return obj,text

def keys(o,required,optional=()):
    require(isinstance(o,dict),'object type')
    require(set(required)<=set(o)<=set(required)|set(optional),'unknown/missing fields')

def text(x):require(isinstance(x,str) and len(x.encode('utf8'))<=4096,'bounded string')
def uid(x):text(x);require(bool(UUID.fullmatch(x)),'canonical UUID')
def num(x):require(type(x) in (int,float) and math.isfinite(float(x)),'finite number');return float(x)
def integer(x,max_value=2**32-1):require(type(x) is int and 0<=x<=max_value,'integer range');return x
def vector(x,n):require(isinstance(x,list) and len(x)==n,'fixed vector');return [num(v) for v in x]
def array(x,low,high):require(isinstance(x,list) and low<=len(x)<=high,'bounded array');return x

def object_members(text,start=0):
    decoder=json.JSONDecoder()
    while text[start].isspace():start+=1
    require(text[start]=='{','object raw span');start+=1
    while True:
        while text[start].isspace():start+=1
        if text[start]=='}':return
        key,end=decoder.raw_decode(text,start);start=end
        while text[start].isspace():start+=1
        require(text[start]==':','member colon');start+=1
        while text[start].isspace():start+=1
        first=start;value,end=decoder.raw_decode(text,start)
        yield key,value,first,end
        start=end
        while text[start].isspace():start+=1
        if text[start]=='}':return
        require(text[start]==',','member comma');start+=1

def opaque(raw,value):
    require(len(raw.encode('utf8'))<=16384,'opaque bytes')
    count=0
    def walk(v,depth):
        nonlocal count
        count+=1
        if isinstance(v,(list,dict)):
            require(depth<16,'opaque depth')
            if isinstance(v,dict):
                for k,x in v.items():text(k);walk(x,depth+1)
            else:
                for x in v:walk(x,depth+1)
        elif isinstance(v,str):text(v)
    walk(value,0)
    return count

def phase(p,end):
    keys(p,('initial_seconds','rates'));initial=num(p['initial_seconds']);rates=array(p['rates'],1,16)
    require(rates[0]['from_tick']==0,'phase anchor');weight=0
    for i,r in enumerate(rates):
        keys(r,('from_tick','num','den'));start=integer(r['from_tick']);n=integer(r['num'],240);d=integer(r['den'],64)
        require(d in (1,2,4,8,16,32,64) and start<end,'phase rate')
        stop=integer(rates[i+1]['from_tick']) if i+1<len(rates) else end
        require(start<stop<=end,'phase order');weight+=(stop-start)*n*(64//d)
    return Fraction.from_float(initial),Fraction.from_float(initial)+Fraction(weight,3840)

def track(rows,dimensions,phase_range):
    array(rows,2,256);times=[]
    for row in rows:
        require(isinstance(row,list) and len(row)==2,'track tuple');times.append(num(row[0]))
        value=vector(row[1],3) if dimensions==3 else [num(row[1])]
        if dimensions==3:require(value[1]==0,'horizontal wind')
        else:require(value[0]>=0,'nonnegative flux')
    require(all(a<b for a,b in zip(times,times[1:])),'strict track order')
    require(Fraction.from_float(times[0])<=phase_range[0] and Fraction.from_float(times[-1])>=phase_range[1],'exact phase coverage')

def ordered_norm(v):return math.sqrt(((v[0]*v[0])+(v[1]*v[1]))+(v[2]*v[2]))

def source(f,raw):
    required={'profile','world_support_m','valid_ticks','day_phase','weather_phase','sun','wind','cloud','precipitation','unsupported'}
    ext=[k for k in f if k.startswith('x.thrum.environment.') and k.isascii()]
    keys(f,required,{'label','air',*ext});require(len(ext)<=16,'opaque count')
    if 'label'in f:text(f['label'])
    for k in ext:text(k)
    fields_start=next(first for k,_,first,_ in object_members(raw) if k=='fields')
    spans={k:raw[first:end] for k,_,first,end in object_members(raw,fields_start) if k in ext}
    require(sum(len(s.encode('utf8')) for s in spans.values())<=262144,'opaque total bytes')
    require(sum(opaque(spans[k],f[k]) for k in ext)<=4096,'opaque aggregate nodes')
    require(f['profile']=='authored-vertical-rain-v1','profile')
    b=f['world_support_m'];keys(b,('min','max'));lo=vector(b['min'],3);hi=vector(b['max'],3)
    require(all(a<b for a,b in zip(lo,hi)) and hi[0]-lo[0]<=512 and hi[2]-lo[2]<=512 and lo[1]>=-10 and hi[1]<=1000,'source support')
    ticks=vector(f['valid_ticks'],2);[integer(t) for t in f['valid_ticks']];require(ticks[0]==0 and 1<=ticks[1]<=216000,'valid time')
    phase(f['day_phase'],int(ticks[1]));weather=phase(f['weather_phase'],int(ticks[1]))
    s=f['sun'];keys(s,('light_ref','initial_toward_source_unit','rotation_axis_unit','period_phase_seconds','peak_perpendicular_illuminance_lux','intensity_envelope','unit_luminance_linear_rec709','angular_radius_rad','direction_model','applied_attenuation'))
    uid(s['light_ref'])
    for k in ('initial_toward_source_unit','rotation_axis_unit'):require(abs(ordered_norm(vector(s[k],3))-1)<=1e-6,'source unit vector')
    c=vector(s['unit_luminance_linear_rec709'],3);require(min(c)>=0 and abs(((.2126*c[0])+.7152*c[1])+.0722*c[2]-1)<=1e-6,'source unit colour')
    require(num(s['period_phase_seconds'])>0 and num(s['peak_perpendicular_illuminance_lux'])>=0 and num(s['angular_radius_rad'])>=0 and s['intensity_envelope']=='positive-world-y-squared' and s['direction_model']=='geometric-straight' and s['applied_attenuation']==[],'Sun semantics')
    w=f['wind'];keys(w,('reference_height_m','vertical_multiplier','weather_phase_vector_knots_mps'));h=array(w['vertical_multiplier'],2,8)
    for row in h:require(len(row)==2 and 0<=num(row[0])<=1000 and lo[1]<=row[0]<=hi[1] and num(row[1])>=0,'height knot')
    require(all(a[0]<b[0] for a,b in zip(h,h[1:])) and h[0][0]<=num(w['reference_height_m'])<=h[-1][0],'height order/reference')
    track(w['weather_phase_vector_knots_mps'],3,weather)
    c=f['cloud'];keys(c,('plane_height_m','map_origin_xz_m','spacing_xz_m','periodic_node_dimensions','vertical_tau_nodes_x_fastest','advection_wind_height_m','low_sun_policy'))
    vector(c['map_origin_xz_m'],2);spacing=vector(c['spacing_xz_m'],2);dims=c['periodic_node_dimensions'];require(isinstance(dims,list) and len(dims)==2,'cloud dimensions');[require(1<=integer(d,64)<=64,'cloud dims') for d in dims]
    nodes=array(c['vertical_tau_nodes_x_fastest'],0,4096);require(len(nodes)==dims[0]*dims[1] and min(spacing)>0 and all(0<=num(x)<=8 for x in nodes),'cloud values')
    require(lo[1]<=num(c['plane_height_m'])<=hi[1] and h[0][0]<=num(c['advection_wind_height_m'])<=h[-1][0] and c['low_sun_policy']=='authored-fade-to-clear-0.2-to-0.1' and all(math.isfinite(n*d) for n,d in zip(dims,spacing)),'cloud semantics')
    p=f['precipitation'];keys(p,('origin_xz_m','cell_size_xz_m','dimensions','cell_multiplier_x_fastest','weather_phase_liquid_flux_knots_kg_m2_s','weather_phase_solid_flux_knots_kg_m2_s','exposure_ref','input_reservoir_ref'))
    origin=vector(p['origin_xz_m'],2);size=vector(p['cell_size_xz_m'],2);dims=p['dimensions'];require(isinstance(dims,list)and len(dims)==2,'rain dimensions');[require(1<=integer(d,128)<=128,'rain dims')for d in dims]
    mult=array(p['cell_multiplier_x_fastest'],0,16384);require(len(mult)==dims[0]*dims[1] and min(size)>0 and all(num(x)>=0 for x in mult),'rain values')
    for i,j in ((0,0),(1,2)):require(lo[j]<=origin[i]and math.isfinite(origin[i]+size[i]*dims[i])and origin[i]+size[i]*dims[i]<=hi[j],'rain support')
    for k in ('exposure_ref','input_reservoir_ref'):uid(p[k])
    for k in ('weather_phase_liquid_flux_knots_kg_m2_s','weather_phase_solid_flux_knots_kg_m2_s'):track(p[k],1,weather)
    require(sum(len(x)for x in [w['weather_phase_vector_knots_mps'],p['weather_phase_liquid_flux_knots_kg_m2_s'],p['weather_phase_solid_flux_knots_kg_m2_s']])<=256,'temporal knot total')
    unsupported=array(f['unsupported'],0,7);require(all(isinstance(x,str)for x in unsupported)and len(set(unsupported))==len(unsupported),'unsupported uniqueness')
    require(set(unsupported)==BASE|({'air'}if'air'not in f else set()),'unsupported set/air absence')
    if'air'in f:
        a=f['air'];keys(a,('temperature_k','local_absolute_pressure_pa','vapour_gas_mass_fraction','saturation_law'))
        require(273.15<=num(a['temperature_k'])<=313.15 and num(a['local_absolute_pressure_pa'])>0 and 0<=num(a['vapour_gas_mass_fraction'])<1 and a['saturation_law']=='nws-liquid-magnus-bounded-v1','air meaning')

FIELDS={
 'thrum.light.identity':{'driver_binding'},
 'thrum.environment.external_reservoir':{'material','inventory','momentum_policy','energy_policy'},
 'thrum.environment.export_sink':{'material','boundary'},
 'thrum.environment.vertical_exposure_recipe':{'source_ref','entry_world_y_m','receiver_refs','uncovered_sink_ref'},
 'thrum.fixture.static_surface_receiver':{'xz_rectangle_m','world_y_m','response_patch_id','response_cell_id','initial_liquid_kg','initial_solid_kg'},
 'thrum.fixture.closed_shallow_receiver':{'xz_rectangle_m','flat_bed_world_y_m','initial_depth_m','grid_dimensions','water_domain_id','bed_patch_id','wall_crest_world_y_m','stage_valid_m','edges','liquid_density_kg_m3'},
 'core.scene':set(), 'core.project':{'project.format','project.records','project.schemas','project.registryHistory','project.entryScenes'},
 'core.registry-history':{'registry.fields','registry.versions'},
}

def f64_quantities(value):
    if type(value)in(int,float):return num(value)
    if isinstance(value,list):return[f64_quantities(x)for x in value]
    if isinstance(value,dict):return{k:f64_quantities(v)for k,v in value.items()}
    return value

def normalize_known(kind,f):
    # Match the typed native decoder. Strict integer fields are deliberately
    # excluded; opaque extension values are never interpreted or normalized.
    if kind=='thrum.environment.authored':
        for key in('world_support_m','sun','wind','air'):
            if key in f:f[key]=f64_quantities(f[key])
        for key in('day_phase','weather_phase'):
            if isinstance(f.get(key),dict)and'initial_seconds'in f[key]:f[key]['initial_seconds']=num(f[key]['initial_seconds'])
        for key,excluded in(('cloud',{'periodic_node_dimensions'}),('precipitation',{'dimensions'})):
            if isinstance(f.get(key),dict):
                f[key]={k:(v if k in excluded else f64_quantities(v))for k,v in f[key].items()}
    else:
        floats={
          'thrum.environment.vertical_exposure_recipe':('entry_world_y_m',),
          'thrum.fixture.static_surface_receiver':('xz_rectangle_m','world_y_m','initial_liquid_kg','initial_solid_kg'),
          'thrum.fixture.closed_shallow_receiver':('xz_rectangle_m','flat_bed_world_y_m','initial_depth_m','wall_crest_world_y_m','stage_valid_m','liquid_density_kg_m3'),
        }
        for key in floats.get(kind,()):
            if key in f:f[key]=f64_quantities(f[key])

def validate(files):
    records={};by_path={};namespace=set();source_raw={}
    for path,raw in files:
        r,text_raw=parse(raw);keys(r,('id','type','schema','fields'),('documentation',));uid(r['id'])
        if'documentation'in r:text(r['documentation'])
        kind=r['type'];text(kind);require(type(r['schema'])is int,'schema integer')
        expected=2 if kind in ('thrum.environment.authored','core.scene','core.project')else 1
        require(r['schema']==expected,'schema version')
        require(r['id']not in namespace,'duplicate global UUID');namespace.add(r['id']);records[r['id']]=r;by_path[path]=r
        f=r['fields'];require(isinstance(f,dict),'fields object');normalize_known(kind,f)
        if kind=='thrum.environment.authored':source(f,text_raw);source_raw[r['id']]=text_raw
        else:
            require(kind in FIELDS,'unknown type');keys(f,FIELDS[kind],('scene.label','environment.source')if kind=='core.scene'else (()if kind in('core.project','core.registry-history')else('label',)))
            if 'label'in f:text(f['label'])
            if kind=='core.scene':
                if'scene.label'in f:text(f['scene.label'])
                if'environment.source'in f:uid(f['environment.source'])
        for k in ('response_patch_id','response_cell_id','water_domain_id','bed_patch_id'):
            if k in f:uid(f[k]);require(f[k]not in namespace,'embedded UUID collision');namespace.add(f[k])
    require(len(records)<=4096,'record cap');edges=0
    def ref(ident,kinds):
        nonlocal edges
        uid(ident);edges+=1;require(edges<=65536,'edge cap');require(ident in records and records[ident]['type']in kinds,'required typed reference');return records[ident]
    projects=[r for r in records.values()if r['type']=='core.project'];require(len(projects)==1,'project count');pf=projects[0]['fields']
    declared=sorted(path for path,r in by_path.items()if r['type']not in('core.project','core.registry-history'))
    require(integer(pf['project.format'])==1 and pf['project.records']==declared and pf['project.schemas']==[]and pf['project.registryHistory']=='schemas/history.registry.json','project membership')
    require('schemas/history.registry.json'in by_path and by_path['schemas/history.registry.json']['type']=='core.registry-history','history membership')
    entries=pf['project.entryScenes'];require(isinstance(entries,list)and 1<=len(entries)<=4096 and entries==sorted(set(entries)),'entries')
    selected=False
    for entry in entries:
        uid(entry);require(entry in records and records[entry]['type']=='core.scene','entry target');selected|='environment.source'in records[entry]['fields']
    require(not selected or len(entries)==1,'one selected entry')
    receivers=expanded=0
    for r in records.values():
        k=r['type'];f=r['fields']
        if k=='thrum.environment.authored':
            ref(f['sun']['light_ref'],['thrum.light.identity']);ref(f['precipitation']['input_reservoir_ref'],['thrum.environment.external_reservoir']);e=ref(f['precipitation']['exposure_ref'],['thrum.environment.vertical_exposure_recipe']);require(e['fields']['source_ref']==r['id'],'source reciprocal')
        elif k=='core.scene'and'environment.source'in f:ref(f['environment.source'],['thrum.environment.authored'])
        elif k=='thrum.light.identity':require(f['driver_binding']=='incoming-environment-sun','light driver')
        elif k=='thrum.environment.external_reservoir':require((f['material'],f['inventory'],f['momentum_policy'],f['energy_policy'])==('water','unbounded-external','zero-horizontal-no-impact-force','unrepresented'),'reservoir policy')
        elif k=='thrum.environment.export_sink':require((f['material'],f['boundary'])==('water','exported'),'sink policy')
        elif k=='thrum.environment.vertical_exposure_recipe':
            s=ref(f['source_ref'],['thrum.environment.authored']);sf=s['fields'];require(sf['precipitation']['exposure_ref']==r['id'],'recipe reciprocal');ref(f['uncovered_sink_ref'],['thrum.environment.export_sink']);entry=num(f['entry_world_y_m']);refs=array(f['receiver_refs'],1,1024);require(len(refs)==len(set(refs)),'receiver duplicate');count=ponds=0
            for ident in refs:
                receiver=ref(ident,['thrum.fixture.static_surface_receiver','thrum.fixture.closed_shallow_receiver']);rf=receiver['fields'];rectangle=vector(rf['xz_rectangle_m'],4)
                if receiver['type']=='thrum.fixture.static_surface_receiver':count+=1;lo=hi=num(rf['world_y_m'])
                else:
                    count+=16;ponds+=1;lo=num(rf['flat_bed_world_y_m']);hi=num(rf['wall_crest_world_y_m']);require(all(num(row[1])==0 for row in sf['precipitation']['weather_phase_solid_flux_knots_kg_m2_s']),'liquid-only pond')
                p=sf['precipitation']
                for i,a,b in ((0,rectangle[0],rectangle[2]),(1,rectangle[1],rectangle[3])):require(p['origin_xz_m'][i]<=a and b<=p['origin_xz_m'][i]+p['cell_size_xz_m'][i]*p['dimensions'][i],'receiver rain support')
                require(-10<=lo and hi<=500 and sf['world_support_m']['min'][1]<=lo and hi<=sf['world_support_m']['max'][1]and hi<entry and hi<sf['cloud']['plane_height_m'],'receiver height support');receivers+=1
            require(ponds<=1 and count<=1024,'receiver expanded limit');require(sf['world_support_m']['min'][1]<=entry<=sf['world_support_m']['max'][1],'entry support');expanded+=count
        elif k=='thrum.fixture.static_surface_receiver':
            rectangle=vector(f['xz_rectangle_m'],4);require(rectangle[0]<rectangle[2]and rectangle[1]<rectangle[3]and math.isfinite(rectangle[2]-rectangle[0])and math.isfinite(rectangle[3]-rectangle[1]),'rectangle order');require(-10<=num(f['world_y_m'])<=500 and num(f['initial_liquid_kg'])>=0 and num(f['initial_solid_kg'])>=0,'initial stores/height')
        elif k=='thrum.fixture.closed_shallow_receiver':
            rectangle=vector(f['xz_rectangle_m'],4);require(rectangle[0]<rectangle[2]and rectangle[1]<rectangle[3]and math.isfinite(rectangle[2]-rectangle[0])and math.isfinite(rectangle[3]-rectangle[1]),'rectangle order');stage=vector(f['stage_valid_m'],2);bed=num(f['flat_bed_world_y_m']);depth=num(f['initial_depth_m']);crest=num(f['wall_crest_world_y_m'])
            require(isinstance(f['grid_dimensions'],list)and len(f['grid_dimensions'])==2,'pond dimensions');[integer(d)for d in f['grid_dimensions']];require(-10<=bed<=500 and -10<=crest<=500 and depth>0 and num(f['liquid_density_kg_m3'])>0 and f['grid_dimensions']==[4,4]and f['edges']=='closed-reflective'and bed<stage[0]<=bed+depth<=stage[1]<crest,'fixed pond geometry/stage')
        elif k=='core.registry-history':require(f['registry.fields']==[]and f['registry.versions']==[],'empty proof history')
    return {'records':len(records),'namespace':len(namespace),'required_edges':edges,'receivers':receivers,'expanded':expanded}


def read_fixture(root):return [(p.relative_to(root).as_posix(),p.read_bytes())for p in sorted(Path(root).rglob('*.json'))]
if __name__=='__main__':
    import sys
    print(validate(read_fixture(Path(sys.argv[1]))))
