#!/usr/bin/env python3
"""Prepare known paper fixture and immutable proposed definition bytes, no admission."""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1]
SOURCE_ID = "10000000-0000-4000-8000-000000000010"
PROJECT_ID = "40000000-0000-4000-8000-000000000001"
SCENE_ID = "40000000-0000-4000-8000-000000000002"
HISTORY_ID = "40000000-0000-4000-8000-000000000003"
BASELINES = {
    "thrum.environment.authored@1":"8f3d060dcd716a40ebfeddcdae58cc7285d281b6bba24fa9a38ebf2000ab5cfb",
    "core.scene@2":"75c09153b459c576f89ad3328dc6e3bac82379368cd7e3ac9317f058a2ea8aa7",
    "thrum.light.identity@1":"9376fbe1d51794e5cae447c41ae0d02a71cd3f652830c9b650375144ac97b166",
}


def dump(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def ident(suffix):
    return f"10000000-0000-4000-8000-{suffix:012x}"


def fixture():
    paper = (REPO/"docs/design/research/ENVIRONMENT-IMPLEMENTOR-DOGFOOD-2026-11-02.md").read_text()
    paper_source = next(json.loads(block) for block in re.findall(r"```json\n(.*?)\n```", paper, re.S)
                  if '"profile": "authored-vertical-rain-v1"' in block)
    source = json.loads((HERE/"inputs/paper-storm-source.json").read_bytes())
    assert source == paper_source, "paper source changed; review the frozen proposed grammar before replacing its fixture"
    assert source["schema"] == 2 and source["id"] == SOURCE_ID
    records = [("records/environment.record.json", source)]
    def add(name, number, kind, fields):
        records.append((f"records/{name}.record.json", {"id":ident(number),"type":kind,"schema":1,"fields":fields}))
    add("light",0x11,"thrum.light.identity",{"label":"Shared Sun","driver_binding":"incoming-environment-sun"})
    add("reservoir",0x13,"thrum.environment.external_reservoir",{"label":"Prescribed rain","material":"water","inventory":"unbounded-external","momentum_policy":"zero-horizontal-no-impact-force","energy_policy":"unrepresented"})
    add("exposure",0x12,"thrum.environment.vertical_exposure_recipe",{"label":"Static roof and enclosed pond","source_ref":SOURCE_ID,"entry_world_y_m":10,"receiver_refs":[ident(i) for i in (0x20,0x21,0x22,0x23)],"uncovered_sink_ref":ident(0x14)})
    add("sink",0x14,"thrum.environment.export_sink",{"label":"Outside represented catchment","material":"water","boundary":"exported"})
    for number,label,rectangle,y in [(0x20,"Ground west",[0,0,32,64],0),(0x21,"Ground north-east",[32,32,64,64],0),(0x22,"Roof",[0,0,16,32],3)]:
        add(f"surface-{number:x}",number,"thrum.fixture.static_surface_receiver",{"label":label,"xz_rectangle_m":rectangle,"world_y_m":y,"response_patch_id":f"20000000-0000-4000-8000-{number:012x}","response_cell_id":f"30000000-0000-4000-8000-{number:012x}","initial_liquid_kg":0,"initial_solid_kg":0})
    add("pond",0x23,"thrum.fixture.closed_shallow_receiver",{"label":"Finite enclosed pond","xz_rectangle_m":[32,0,64,32],"flat_bed_world_y_m":-1,"initial_depth_m":1,"grid_dimensions":[4,4],"water_domain_id":"20000000-0000-4000-8000-000000000023","bed_patch_id":"20000000-0000-4000-8000-000000000024","wall_crest_world_y_m":1,"stage_valid_m":[-0.25,0.25],"edges":"closed-reflective","liquid_density_kg_m3":1000})
    records.append(("scenes/main.scene.json",{"id":SCENE_ID,"type":"core.scene","schema":2,"fields":{"scene.label":"bounded rain proof","environment.source":SOURCE_ID}}))
    records.sort()
    records += [("project.json",{"id":PROJECT_ID,"type":"core.project","schema":2,"fields":{"project.format":1,"project.records":[path for path,_ in records],"project.schemas":[],"project.registryHistory":"schemas/history.registry.json","project.entryScenes":[SCENE_ID]}}),
                ("schemas/history.registry.json",{"id":HISTORY_ID,"type":"core.registry-history","schema":1,"fields":{"registry.fields":[],"registry.versions":[]}})]
    records.sort()
    output=HERE/"fixture"
    for path,record in records:
        target=output/path; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(dump(record))
    manifest={"format":1,"projectId":PROJECT_ID,"dependencyRoots":[],"files":[{"path":path,"kind":"file","length":len(dump(record)),"hash":hashlib.sha256(dump(record)).hexdigest(),"recordId":record["id"],"recordType":record["type"]} for path,record in records]}
    (HERE/"fixture.tree-manifest.jcs.json").write_bytes(dump(manifest))
    return records


COMMON = "envelope=id:lowercase-rfc4122-uuid,type:exact,schema:exact-positive-integer,fields:strict-object,documentation?:utf8<=4096;label?:utf8<=4096;duplicate=refuse;unknown=refuse;finite-f64;signed-zero-source-accepted;record-bytes<=16777216;whole-nodes<=1000000;whole-container-depth<=64;source-predicates-use-ordered-binary64-except-exact-rational-phase-coverage;global-record-and-declared-embedded-UUID-namespace-unique;required-refs-resolve-typed-supported-version;all-required-edges-including-unselected-content<=65536;activation=entry-scene-binding-only;unselected-content-valid;selected-environment-requires-one-entry\n"
DEFINITIONS = {
"thrum.environment.authored@2": """profile=authored-vertical-rain-v1;no-other-profile
world_support_m={min:f64[3],max:f64[3]};C01-world-metres;min<max;XZ-width<=512;Y-within[-10,1000];XZ-half-open;Y-closed
valid_ticks=u32[2];[0,N];1<=N<=216000;inclusive-endpoints;F1-tick-seconds=n/60;interval-needs-both-endpoints
day_phase-and-weather_phase={initial_seconds:finite-f64,rates:1..16[{from_tick:u32,num:u16,den:u8}]};anchor=tick0;first-from_tick=0;strict-start-order;later-start<N;num=0..240;den-in[1,2,4,8,16,32,64];phase=initial+weighted_ticks/3840;weighted_ticks=sum(delta_ticks*num*(64/den));coverage-exact-real-decoded-f64-plus-rational
sun={light_ref:required-ref<thrum.light.identity@1>,initial_toward_source_unit:f64[3],rotation_axis_unit:f64[3],period_phase_seconds:positive-f64,peak_perpendicular_illuminance_lux:nonnegative-f64,unit_luminance_linear_rec709:nonnegative-f64[3],angular_radius_rad:nonnegative-f64,intensity_envelope:positive-world-y-squared,direction_model:geometric-straight,applied_attenuation:[]};direction-and-axis-nonzero;length=sqrt(((x*x)+(y*y))+(z*z))-ordered-binary64-no-contraction;abs(length-1)<=1e-6;abs(Y-1)<=1e-6;Y=(0.2126R+0.7152G)+0.0722B;raw-unattenuated-lux;geometric-radians;no-ambient-or-background-field
wind={reference_height_m:f64,vertical_multiplier:2..8[[worldY_m,nonnegative-f64]],weather_phase_vector_knots_mps:2..256[[phase_seconds,f64[3]]]};height-in[0,1000];every-height-within-world_support_m.Y;strict-height-order;reference-within-height-domain;linear-vector-and-height-interpolation;horizontal-Uy=0;temporal-knots-strict;no-track-extrapolation
cloud={plane_height_m:f64,map_origin_xz_m:f64[2],spacing_xz_m:positive-f64[2],periodic_node_dimensions:u32[2],vertical_tau_nodes_x_fastest:0..4096[f64-in[0,8]],advection_wind_height_m:f64,low_sun_policy:authored-fade-to-clear-0.2-to-0.1};dimensions-each1..64;node-count=Nx*Nz;x-fastest;period=Nx*dx,Nz*dz;derived-periods-finite-positive;plane-height-within-world_support_m.Y;receiver-domain-world-support-and-Y<plane;advection-height-within-wind-domain;low-Sun-fade0-at-sy<=0.1-to1-at-sy>=0.2;optical-depth-not-transmittance
precipitation={origin_xz_m:f64[2],cell_size_xz_m:positive-f64[2],dimensions:u32[2],cell_multiplier_x_fastest:0..16384[nonnegative-f64],weather_phase_liquid_flux_knots_kg_m2_s:2..256[[phase_seconds,nonnegative-f64]],weather_phase_solid_flux_knots_kg_m2_s:2..256[[phase_seconds,nonnegative-f64]],exposure_ref:required-ref<thrum.environment.vertical_exposure_recipe@1>,input_reservoir_ref:required-ref<thrum.environment.external_reservoir@1>};dimensions-each1..128;count=Nx*Nz;x-fastest;static-footprints;cell-mean-horizontal-kg-per-m2-per-world-second;linear-temporal-flux;no-track-extrapolation;outside-rain-support=OutsideSupport-not-zero
all-temporal-wind-liquid-solid-knots-total<=256;phase-min=initial;phase-max=initial+weighted_ticks/3840;all-weather-tracks-bracket-entire-valid-phase-range;all-knots-finite-strict;rain-grid-within-world-XZ
air?={temperature_k:f64-in[273.15,313.15],local_absolute_pressure_pa:positive-f64,vapour_gas_mass_fraction:f64-in[0,1),saturation_law:nws-liquid-magnus-bounded-v1};constant-gas-facts;no-condensate;RH-derived-not-authored;F2-requires-derived-RH-in[0,1];no-energy-authority
unsupported=exact-unique-set[moon,thermal_irradiance,air_quality,cloud_density_volume,optical_air,terminal_sky]+air-IFF-air-field-absent;known-positive-capabilities=Sun,wind,cloud_tau,precipitation,and-air-IFF-present;ambient/background-unavailable;no-fog-field
opaque=only-direct-fields-prefix-x.thrum.environment.;ASCII-keys<=4096bytes;keys<=16;raw-bytes-each<=16384;raw-total<=262144;aggregate-value-nodes<=4096;per-value-container-depth<=16;decoded-strings-and-keys<=4096bytes;exact-untouched-value-bytes-preserved;never-runtime-controls
semantic-phase=theta(t)=theta0+sum_over_rates((num/den)*world_seconds_in_rate_segment_before_t);world_time=tick/60;zero-rate-holds-controls-not-world-time
semantic-Sun=d=normalize(initial_toward_source_unit),k=normalize(rotation_axis_unit),a=2*pi*((theta_day(t) mod period_phase_seconds)/period_phase_seconds),s=d*cos(a)+(k cross d)*sin(a)+k*dot(k,d)*(1-cos(a));mod=Euclidean[0,period);E_perp=peak_perpendicular_illuminance_lux*max(s_y,0)^2;colour=raw_colour/Y(raw_colour);angular-radius-unchanged;no-air/cloud/terrain-attenuation-in-E_perp
semantic-wind=a(y)=linear-height-multiplier,v(theta)=linear-vector-track,u(y,t)=a(y)*v(theta_weather(t));uniform-horizontal-position;reference_height_m-reports-sample-height-not-renormalization;u(reference,t)=a(reference)*v(theta_weather(t));outside-height-or-world/time-support=OutsideSupport
semantic-cloud=D(t)=integral_0^t u(advection_wind_height_m,s)ds-world-metres;D(0)=0;integrate-world-time-not-phase;frozen-nonzero-wind-still-advects;for-receiver-p-below-plane-and-s_y>0.1,q=p+(plane_height_m-p_y)*s/s_y;UV=(q_XZ-D(t)-map_origin_xz_m)/spacing_xz_m;sample-four-periodic-node-neighbours-with-Euclidean-floor/mod-and-bilinear-weights;f32-canonical-spatial-node-values-decoded-for-CPU;fade=0-if-s_y<=0.1,(s_y-0.1)/0.1-if-0.1<s_y<0.2,1-if-s_y>=0.2;tau_cloud=fade*tau_vertical/s_y-for-s_y>0.1;at-s_y<=0.1-exact-tau0-and-transmittance1-with-no-division-and-AuthoredLowSunClear-tag;T_cloud=exp(-tau_cloud)-applied-once-by-transport;no-terminal-sky-or-visible-density
semantic-rain=cell_i=floor((XZ-origin_XZ)/cell_size_XZ)-inside-half-open-grid;P_liquid_i(t)=w_i*L(theta_weather(t));P_solid_i(t)=w_i*S(theta_weather(t));w_i=decoded-canonical-f32-multiplier;piecewise-constant-spatial-cell-mean;linear-phase-flux;DeltaM_receiver=sum_i(projected_first_hit_area_i_receiver*integral_world_interval(P_i(t)dt));split-at-phase-rate-and-track-boundaries;output-kg-not-depth-or-true-area-density;phase-freeze-does-not-freeze-held-nonzero-flux
semantic-air=epsilon=287.05/461.5,e=q*p/(epsilon+(1-epsilon)*q),T_C=T_K-273.15,e_sat=611.2*exp(17.67*T_C/(T_C+243.5)),RH=e/e_sat;F2-requires-finite-RH-in[0,1];at-q0-RH0-and-NoFiniteDewPoint;for-positive-e,A=ln(e/611.2),dew_point_K=273.15+243.5*A/(17.67-A);no-derived-quantity-authored-independently
F4-normalizes-vectors-colour-once;F4-quantizes-cloud-nodes-and-rain-multipliers-to-canonical-f32-and-rechecks-finite/support/maximum-corner-Euclidean-bilinear-gradient<=0.01-per-metre;F2-checks-speed<=40m/s-and-world-time-wind-derivative<=0.5m/s2-for-retained-tick-start-consumers;no-view-clock;no-weather-mass-store
""",
"thrum.environment.external_reservoir@1": "material=water;inventory=unbounded-external;momentum_policy=zero-horizontal-no-impact-force;energy_policy=unrepresented;authoritative-external-exchange-source-not-second-world-mass-store\n",
"thrum.environment.export_sink@1": "material=water;boundary=exported;identified-ledger-destination-not-silent-discard\n",
"thrum.environment.vertical_exposure_recipe@1": "source_ref:required-ref<thrum.environment.authored@2>;entry_world_y_m:finite-worldY-metres;receiver_refs:1..1024[required-ref<thrum.fixture.static_surface_receiver@1|thrum.fixture.closed_shallow_receiver@1>];unique-receivers;uncovered_sink_ref:required-ref<thrum.environment.export_sink@1>;reciprocal-source.precipitation.exposure_ref=this;one-source-per-recipe;downward-direction=(0,-1,0);expanded-receiving-elements<=1024;at-most-one-fixed-pond;F4-row-cap32768;entry-within-source-world_support_m.Y;surface-height-bounds=[world_y_m,world_y_m];pond-height-bounds=[flat_bed_world_y_m,wall_crest_world_y_m];all-receiver-height-bounds-within-source-world_support_m.Y-and[-10,500];all-receiver-closed-XZ-bounds-within-rain-rectangle-and-source-world-XZ;receiver-high<entry_world_y_m;receiver-high<source.cloud.plane_height_m;F4-static-first-hit-not-cell-centre-height\n",
"thrum.fixture.static_surface_receiver@1": "fixture-only;xz_rectangle_m:f64[4]=[x0,z0,x1,z1];finite-positive-extents;world_y_m:finite-worldY-metres-in[-10,500];response_patch_id:declared-embedded-uuid;response_cell_id:declared-embedded-uuid;initial_liquid_kg:nonnegative-f64;initial_solid_kg:nonnegative-f64;record-id=geometry-id;one-response-cell;corners=(x0,y,z0),(x0,y,z1),(x1,y,z1),(x1,y,z0);triangles=(0,1,2),(0,2,3);upward-winding;area=(x1-x0)*(z1-z0);receiver-overlap-not-automatically-invalid;no-general-material-model\n",
"thrum.fixture.closed_shallow_receiver@1": "fixture-only;xz_rectangle_m:f64[4]=[x0,z0,x1,z1];finite-positive-extents;flat_bed_world_y_m:finite-worldY-metres-in[-10,500];initial_depth_m:positive-f64;grid_dimensions=[4,4];water_domain_id:declared-embedded-uuid;bed_patch_id:distinct-declared-embedded-uuid;wall_crest_world_y_m:finite-worldY-metres-in[-10,500];stage_valid_m:f64[2]=[min,max];min<=initial-bed-plus-depth<=max;bed<min<=max<wall-crest<entry;edges=closed-reflective;liquid_density_kg_m3:positive-f64;four-vertical-walls-bed-to-crest;bed-is-not-independent-rain-receiver;16-product-local-cells-not-durable-uuids;fixed-footprint;any-authored-nonzero-solid-track-knot-refuses-this-liquid-only-pond-profile-even-if-unreached-or-zero-multiplier;no-moving-shore-or-body-model\n",
}


def baseline_invariants():
    import ast
    sdk=(REPO/"crates/thrum-source/src/environment_json.rs").read_text()
    pairs={"thrum.environment.authored@1":"ENVIRONMENT_DEFINITION","core.scene@2":"SCENE_DEFINITION","thrum.light.identity@1":"LIGHT_DEFINITION"}
    actual={}
    for key,name in pairs.items():
        body=re.search(r"const "+name+r": &str = concat!\((.*?)\n\);",sdk,re.S).group(1)
        value="".join(ast.literal_eval(token) for token in re.findall(r'"(?:[^"\\]|\\.)*"',body))
        actual[key]=hashlib.sha256(b"thrum-f3-builtin-schema-v1\0"+value.encode()).hexdigest()
        assert actual[key]==BASELINES[key],(key,actual[key],BASELINES[key])
    (HERE/"baseline-hashes.json").write_bytes(dump(actual))
    print("SDK baseline definitions unchanged:",actual)
    return actual


def dense_fixture():
    import copy,shutil
    records=dict(fixture())
    for path in list(records):
        if path.startswith("records/surface-"):del records[path]
    s=records["records/environment.record.json"]["fields"]
    s["cloud"]["periodic_node_dimensions"]=[64,64]
    s["cloud"]["spacing_xz_m"]=[2,2]
    s["cloud"]["vertical_tau_nodes_x_fastest"]=[0]*4096
    s["precipitation"]["dimensions"]=[128,128]
    s["precipitation"]["cell_size_xz_m"]=[.5,.5]
    s["precipitation"]["cell_multiplier_x_fastest"]=[1]*16384
    s["wind"]["vertical_multiplier"]=[[i*1000/7,2]for i in range(8)]
    s["wind"]["weather_phase_vector_knots_mps"]=[[i*3600/127,[6,0,0]]for i in range(128)]
    s["precipitation"]["weather_phase_liquid_flux_knots_kg_m2_s"]=[[i*3600/63,.002777777777777778]for i in range(64)]
    s["precipitation"]["weather_phase_solid_flux_knots_kg_m2_s"]=[[i*3600/63,0]for i in range(64)]
    for key in ("day_phase","weather_phase"):s[key]["rates"]=[{"from_tick":i*100,"num":1,"den":1}for i in range(16)]
    receiver_ids=[]
    for i in range(1008):
        number=0x1000+i;x=(i%64)*.5;z=(i//64)*4
        ident_r=ident(number);receiver_ids.append(ident_r)
        records[f"records/surface-{number:x}.record.json"]={"id":ident_r,"type":"thrum.fixture.static_surface_receiver","schema":1,"fields":{"xz_rectangle_m":[x,z,x+.5,z+4],"world_y_m":0,"response_patch_id":f"20000000-0000-4000-8000-{number:012x}","response_cell_id":f"30000000-0000-4000-8000-{number:012x}","initial_liquid_kg":0,"initial_solid_kg":0}}
    records["records/exposure.record.json"]["fields"]["receiver_refs"]=receiver_ids+[ident(0x23)]
    records["project.json"]["fields"]["project.records"]=sorted(path for path in records if path not in ("project.json","schemas/history.registry.json"))
    output=HERE/"dense"
    if output.exists():shutil.rmtree(output)
    for path,record in records.items():
        target=output/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(dump(record))
    return output


def definitions():
    table=dict(BASELINES)
    for key,body in DEFINITIONS.items():
        encoded=("thrum-builtin-definition-v1\n"+key+"\n"+COMMON+body).encode()
        name=key.replace("@","-")+".txt"
        (HERE/"definitions"/name).write_bytes(encoded)
        table[key]=hashlib.sha256(b"thrum-f3-builtin-schema-v1\0"+encoded).hexdigest()
    (HERE/"definition-hashes.json").write_bytes(dump(table))
    bundle=hashlib.sha256(b"thrum-proof-e1-rain-schema-table-v1\0"+dump(table)).hexdigest()
    print("source schema2 definition hash:",table["thrum.environment.authored@2"])
    print("complete proposed table hash:",bundle)
    (HERE/"table.hash").write_text(bundle+"\n")
    return table


if __name__=="__main__":
    baseline_invariants();records=fixture();definitions()
    print("fixture:",len(records),"records",sum(len(dump(record)) for _,record in records),"bytes")
