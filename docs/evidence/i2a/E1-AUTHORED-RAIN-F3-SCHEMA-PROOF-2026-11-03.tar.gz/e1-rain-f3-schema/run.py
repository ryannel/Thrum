#!/usr/bin/env python3
"""Reproduce this proposed grammar proof serially; never admits a source root."""
from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys
HERE=Path(__file__).resolve().parent
ENV=dict(os.environ,RUSTC_WRAPPER='')
LOG=['All Rust commands use pinned Rust1.99.1, locked offline dependencies and empty RUSTC_WRAPPER. No production dispatch is changed.']

def run(command,compact=False):
    LOG.append('$ '+shlex.join(map(str,command)))
    p=subprocess.run(list(map(str,command)),cwd=HERE,env=ENV,text=True,capture_output=True,check=True)
    output=p.stdout+p.stderr
    if compact:output='\n'.join(line for line in output.splitlines()if line.startswith(('running ','test ','    Finished')))+'\n'
    LOG.append(output.rstrip());print(output,end='',flush=True)
    return p.stdout

def main():
    run(['rustup','run','1.99.1','rustc','--version','--verbose']);run([sys.executable,'--version'])
    run([sys.executable,HERE/'prepare.py'])
    cargo=['rustup','run','1.99.1','cargo'];manifest=['--manifest-path',HERE/'Cargo.toml'];locked=['--locked','--offline']
    run(cargo+['fmt']+manifest+['--','--check'])
    run(cargo+['test']+locked+manifest,True)
    run(cargo+['test','--release']+locked+manifest,True)
    run(cargo+['clippy']+locked+manifest+['--all-targets','--','-D','warnings'],True)
    run(cargo+['build','--release']+locked+manifest,True)
    binary=HERE/'target/release/e1-rain-f3-schema-proof'
    output=run([binary,'--definitions',HERE/'definitions'])
    expected=json.loads((HERE/'definition-hashes.json').read_bytes())
    for line in output.splitlines():
        name,value=line.split();key=name.removesuffix('.txt').rsplit('-',1);key=key[0]+'@'+key[1]
        assert expected[key]==value,(key,value,expected[key])
    run([sys.executable,HERE/'oracle.py',HERE/'fixture'])
    run([sys.executable,HERE/'check.py',binary])
    run([sys.executable,HERE/'phase_oracle.py',binary])
    run([sys.executable,HERE/'cook_boundaries.py'])
    # Measure only after compilation/checks, in new native processes, serially.
    run([sys.executable,HERE/'measure.py',binary])
    LOG.append('Selected SHA-256 identities:')
    for name in ['src/main.rs','Cargo.toml','Cargo.lock','prepare.py','oracle.py','check.py','phase_oracle.py','measure.py','cook_boundaries.py','run.py','fixture.tree-manifest.jcs.json','definition-hashes.json','baseline-hashes.json','adversarial.tsv','measurements.json','cook-boundaries.json','target/release/e1-rain-f3-schema-proof']:
        LOG.append(hashlib.sha256((HERE/name).read_bytes()).hexdigest()+'  '+name)
    LOG.append('Result: proposed schema only;3 native debug+3 release unit tests,104 adversarial agreement cases,856 exact phase comparisons; no accepted source, F4 product, F1 forcing or renderer claim. RSS is native process high-water including startup/input/decode/closure; tracked Vec bytes are partial logical payload, not a heap cap.')
    (HERE/'verification.txt').write_text('\n\n'.join(LOG)+'\n')

if __name__=='__main__':main()
