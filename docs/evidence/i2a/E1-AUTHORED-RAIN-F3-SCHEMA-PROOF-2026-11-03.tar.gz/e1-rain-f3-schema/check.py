#!/usr/bin/env python3
"""Serial adversarial replay; writes one temporary candidate at a time."""
from pathlib import Path
import copy, importlib.util, json, os, shutil, subprocess, sys
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rain_oracle',HERE/'oracle.py');o=importlib.util.module_from_spec(spec);spec.loader.exec_module(o)
SOURCE='records/environment.record.json';EXPOSURE='records/exposure.record.json';POND='records/pond.record.json';SCENE='scenes/main.scene.json';PROJECT='project.json'
BASE=dict(o.read_fixture(HERE/'fixture'))
ENV='10000000-0000-4000-8000-000000000010'
LIGHT='10000000-0000-4000-8000-000000000011'

def encoded(obj):return json.dumps(obj,separators=(',',':'),ensure_ascii=True).encode()
def changed(path,fn):
    files=dict(BASE);record=json.loads(files[path]);fn(record);files[path]=encoded(record);return files

def source(fn):return changed(SOURCE,lambda r:fn(r['fields']))
def opaque(raws):
    files=dict(BASE);addition=','.join(json.dumps('x.thrum.environment.'+str(i))+':'+raw for i,raw in enumerate(raws))
    files[SOURCE]=BASE[SOURCE].replace(b'"profile":',addition.encode()+b',"profile":')
    return files

def with_records(extra,modify=lambda files:None):
    files=dict(BASE)
    for path,record in extra:files[path]=encoded(record)
    modify(files)
    p=json.loads(files[PROJECT]);p['fields']['project.records']=sorted(path for path in files if path not in (PROJECT,'schemas/history.registry.json'));files[PROJECT]=encoded(p)
    return files

def edge_graph(selected):
    files=dict(BASE)
    for path in list(files):
        if path.startswith("records/surface-"):del files[path]
    receiver_ids=[]
    for i in range(1019):
        number=0x1000+i;rid=f"10000000-0000-4000-8000-{number:012x}";receiver_ids.append(rid)
        x=i%64;z=(i//64)*4
        record={"id":rid,"type":"thrum.fixture.static_surface_receiver","schema":1,"fields":{"xz_rectangle_m":[x,z,x+1,z+4],"world_y_m":0,"response_patch_id":f"20000000-0000-4000-8000-{number:012x}","response_cell_id":f"30000000-0000-4000-8000-{number:012x}","initial_liquid_kg":0,"initial_solid_kg":0}}
        files[f"records/surface-{number:x}.record.json"]=encoded(record)
    recipe=json.loads(files[EXPOSURE]);recipe['fields']['receiver_refs']=receiver_ids;files[EXPOSURE]=encoded(recipe)
    for i in range(63):
        src=json.loads(BASE[SOURCE]);src['id']=f"10000000-0000-4000-8000-{0x5000+i:012x}"
        exp=copy.deepcopy(recipe);exp['id']=f"10000000-0000-4000-8000-{0x6000+i:012x}"
        src['fields']['precipitation']['exposure_ref']=exp['id'];exp['fields']['source_ref']=src['id']
        files[f"records/source-extra-{i:03}.record.json"]=encoded(src)
        files[f"records/exposure-extra-{i:03}.record.json"]=encoded(exp)
    scene=json.loads(files[SCENE]);
    if not selected:scene['fields'].pop('environment.source')
    files[SCENE]=encoded(scene)
    p=json.loads(files[PROJECT]);p['fields']['project.records']=sorted(path for path in files if path not in (PROJECT,'schemas/history.registry.json'));files[PROJECT]=encoded(p)
    return files

def shifted_integer_X():
    files=dict(BASE);offset=2**53
    s=json.loads(files[SOURCE]);f=s['fields']
    for key in('min','max'):f['world_support_m'][key][0]+=offset
    f['cloud']['map_origin_xz_m'][0]+=offset
    f['precipitation']['origin_xz_m'][0]=offset+1
    files[SOURCE]=encoded(s)
    for path in list(files):
        if path.startswith('records/surface-')or path==POND:
            r=json.loads(files[path]);rect=r['fields']['xz_rectangle_m']
            for i in(0,2):rect[i]+=offset
            files[path]=encoded(r)
    return files

def cases():
    yield 'positive/base',True,dict(BASE)
    yield 'positive/order-fields-first',True,changed(SOURCE,lambda r:None)
    yield 'positive/source-schema2-tolerance1e-6',True,source(lambda f:f['sun'].__setitem__('initial_toward_source_unit',[0,1.0000005,0]))
    yield 'negative/source-schema2-unit-outside',False,source(lambda f:f['sun'].__setitem__('initial_toward_source_unit',[0,1.0000011,0]))
    yield 'positive/large-integer-quantity-spelling-rounded-f64',True,shifted_integer_X()
    yield 'negative/project-label-unknown',False,changed(PROJECT,lambda r:r['fields'].__setitem__('label','not allowed'))
    yield 'negative/history-label-unknown',False,changed('schemas/history.registry.json',lambda r:r['fields'].__setitem__('label','not allowed'))
    yield 'negative/huge-integer-opaque',False,opaque(['9'*1000])
    files=dict(BASE);files[SOURCE]=BASE[SOURCE].replace(b'"valid_ticks":[0,216000]',b'"valid_ticks":[-0,216000]');yield 'negative/negative-zero-integer-literal',False,files
    yield 'negative/negative-zero-integer-spelling',False,changed(SOURCE,lambda r:r['fields']['valid_ticks'].__setitem__(0,-0.0))
    def bad_wind_support(f):
        f['world_support_m']['max'][1]=900;f['cloud']['plane_height_m']=900
    yield 'negative/wind-height-outside-source-Y',False,source(bad_wind_support)
    yield 'negative/cloud-plane-outside-source-Y',False,source(lambda f:f['cloud'].__setitem__('plane_height_m',1001))
    yield 'negative/cloud-derived-period-overflow',False,source(lambda f:f['cloud'].__setitem__('spacing_xz_m',[float.fromhex('0x1.fffffffffffffp1023'),64]))
    yield 'negative/entry-plane-outside-source-Y',False,changed(EXPOSURE,lambda r:r['fields'].__setitem__('entry_world_y_m',1001))
    def receiver_Y_outside(f):
        f['world_support_m']['min'][1]=0;f['wind']['vertical_multiplier'][0][0]=0
    yield 'negative/receiver-bed-outside-source-Y',False,source(receiver_Y_outside)
    yield 'negative/receiver-above-cloud-plane',False,source(lambda f:f['cloud'].__setitem__('plane_height_m',2))
    yield 'negative/unknown-envelope-field',False,changed(SOURCE,lambda r:r.__setitem__('note',0))
    yield 'negative/required-wind-field-missing',False,source(lambda f:f.pop('wind'))
    yield 'positive/UTF8-label4096',True,source(lambda f:f.__setitem__('label','é'*2048))
    yield 'negative/UTF8-label4098',False,source(lambda f:f.__setitem__('label','é'*2049))
    yield 'negative/source-wrong-schema1',False,changed(SOURCE,lambda r:r.__setitem__('schema',1))
    yield 'negative/source-fractional-schema',False,changed(SOURCE,lambda r:r.__setitem__('schema',2.0))
    yield 'negative/source-unknown-type',False,changed(SOURCE,lambda r:r.__setitem__('type','thrum.environment.future'))
    yield 'negative/source-wrong-profile',False,source(lambda f:f.__setitem__('profile','constant-light-v1'))
    files=dict(BASE);files[SOURCE]=BASE[SOURCE].replace(b'"schema":2',b'"schema":2,"schema":2');yield 'negative/duplicate-envelope',False,files
    files=dict(BASE);files[SOURCE]=BASE[SOURCE].replace(b'"profile":',b'"profile":"authored-vertical-rain-v1","profile":');yield 'negative/duplicate-source-field',False,files
    files=dict(BASE);files[SOURCE]=BASE[SOURCE].replace(b'"plane_height_m":',b'"plane_height_m":1000,"plane_height_m":');yield 'negative/duplicate-nested',False,files
    yield 'negative/duplicate-opaque-escaped-alias',False,opaque([r'{"a":0,"\u0061":1}'])
    yield 'negative/unknown-source-field',False,source(lambda f:f.__setitem__('humidity',0.5))
    yield 'negative/unknown-fog-field',False,source(lambda f:f.__setitem__('fog',{}))
    yield 'negative/unknown-nested-field',False,source(lambda f:f['wind'].__setitem__('gusts',0))
    yield 'negative/unknown-fixture-field',False,changed(POND,lambda r:r['fields'].__setitem__('roughness',.2))
    yield 'negative/rival-light-descriptor',False,changed('records/light.record.json',lambda r:r['fields'].__setitem__('illuminance_lux',1))
    yield 'negative/uppercase-UUID',False,changed(SOURCE,lambda r:r.__setitem__('id','10000000-0000-4000-8000-0000000000AB'))
    yield 'negative/version-zero-UUID',False,changed(SOURCE,lambda r:r.__setitem__('id','10000000-0000-0000-8000-000000000010'))
    yield 'negative/variant-UUID',False,changed(SOURCE,lambda r:r.__setitem__('id','10000000-0000-4000-1000-000000000010'))
    yield 'negative/duplicate-global-record-ID',False,changed(POND,lambda r:r.__setitem__('id',ENV))
    yield 'negative/embedded-record-collision',False,changed(POND,lambda r:r['fields'].__setitem__('water_domain_id',ENV))
    yield 'negative/duplicate-embedded-ID',False,changed(POND,lambda r:r['fields'].__setitem__('bed_patch_id',r['fields']['water_domain_id']))
    yield 'negative/missing-required-light',False,source(lambda f:f['sun'].__setitem__('light_ref','10000000-0000-4000-8000-0000000000ab'))
    yield 'negative/wrong-type-light',False,source(lambda f:f['sun'].__setitem__('light_ref',ENV))
    yield 'negative/wrong-type-source-binding',False,changed(SCENE,lambda r:r['fields'].__setitem__('environment.source',LIGHT))
    yield 'negative/wrong-type-reservoir',False,source(lambda f:f['precipitation'].__setitem__('input_reservoir_ref',LIGHT))
    yield 'negative/duplicate-receiver-reference',False,changed(EXPOSURE,lambda r:r['fields']['receiver_refs'].append(r['fields']['receiver_refs'][0]))
    second=json.loads(BASE[SOURCE]);second['id']='10000000-0000-4000-8000-000000000015'
    def mismatch(files):
        e=json.loads(files[EXPOSURE]);e['fields']['source_ref']=second['id'];files[EXPOSURE]=encoded(e)
    yield 'negative/source-recipe-nonreciprocal',False,with_records([('records/other-source.record.json',second)],mismatch)
    other=json.loads(BASE[EXPOSURE]);other['id']='10000000-0000-4000-8000-000000000016'
    def mismatch2(files):
        s=json.loads(files[SOURCE]);s['fields']['precipitation']['exposure_ref']=other['id'];files[SOURCE]=encoded(s)
    yield 'negative/recipe-source-nonreciprocal',False,with_records([('records/other-exposure.record.json',other)],mismatch2)
    yield 'negative/negative-flux',False,source(lambda f:f['precipitation']['weather_phase_liquid_flux_knots_kg_m2_s'][0].__setitem__(1,-1))
    yield 'negative/nonhorizontal-wind',False,source(lambda f:f['wind']['weather_phase_vector_knots_mps'][0][1].__setitem__(1,1))
    yield 'negative/unknown-direction-model',False,source(lambda f:f['sun'].__setitem__('direction_model','apparent'))
    yield 'negative/nonempty-attenuation',False,source(lambda f:f['sun'].__setitem__('applied_attenuation',['cloud']))
    yield 'negative/null-air-not-absence',False,source(lambda f:f.__setitem__('air',None))
    yield 'negative/null-label-not-absence',False,source(lambda f:f.__setitem__('label',None))
    yield 'negative/air-missing-without-unsupported',False,source(lambda f:f.pop('air'))
    def absent(f):f.pop('air');f['unsupported'].append('air')
    yield 'positive/absent-air-explicit',True,source(absent)
    yield 'negative/contradictory-air-unsupported',False,source(lambda f:f['unsupported'].append('air'))
    yield 'negative/duplicate-unsupported',False,source(lambda f:f['unsupported'].__setitem__(1,f['unsupported'][0]))
    yield 'negative/missing-unsupported',False,source(lambda f:f['unsupported'].pop())
    yield 'negative/phase-tick-anchor',False,source(lambda f:f['weather_phase']['rates'][0].__setitem__('from_tick',1))
    yield 'negative/nonzero-validity-anchor',False,source(lambda f:f['valid_ticks'].__setitem__(0,1))
    yield 'negative/phase-denominator',False,source(lambda f:f['weather_phase']['rates'][0].__setitem__('den',3))
    yield 'negative/phase-numerator-limit',False,source(lambda f:f['weather_phase']['rates'][0].__setitem__('num',241))
    yield 'negative/phase-duplicate-start',False,source(lambda f:f['weather_phase']['rates'][1].__setitem__('from_tick',0))
    yield 'negative/phase-rate-at-last-endpoint',False,source(lambda f:f['weather_phase']['rates'][1].__setitem__('from_tick',216000))
    yield 'negative/phase-rate-limit',False,source(lambda f:f['weather_phase'].__setitem__('rates',[{'from_tick':i,'num':1,'den':1}for i in range(17)]))
    yield 'negative/track-duplicate-phase',False,source(lambda f:f['wind']['weather_phase_vector_knots_mps'][1].__setitem__(0,0))
    yield 'negative/track-short-coverage',False,source(lambda f:f['wind']['weather_phase_vector_knots_mps'][-1].__setitem__(0,1814))
    yield 'negative/track-negative-phase-coverage',False,source(lambda f:f['weather_phase'].__setitem__('initial_seconds',-1))
    def frozen(f):
        f['weather_phase']['rates']=[{'from_tick':0,'num':0,'den':64}]
    yield 'positive/frozen-weather-nonzero-world-wind',True,source(frozen)
    yield 'negative/wind-height-limit',False,source(lambda f:f['wind'].__setitem__('vertical_multiplier',[[i*100,1]for i in range(9)]))
    yield 'negative/aggregate-temporal-limit',False,source(lambda f:f['wind'].__setitem__('weather_phase_vector_knots_mps',[[i*3600/252,[6,0,0]]for i in range(253)]))
    yield 'negative/cloud-dimension-limit',False,source(lambda f:f['cloud'].__setitem__('periodic_node_dimensions',[65,2]))
    yield 'negative/cloud-sample-count',False,source(lambda f:f['cloud']['vertical_tau_nodes_x_fastest'].pop())
    yield 'negative/cloud-tau-limit',False,source(lambda f:f['cloud']['vertical_tau_nodes_x_fastest'].__setitem__(0,8.1))
    yield 'negative/rain-dimension-limit',False,source(lambda f:f['precipitation'].__setitem__('dimensions',[129,1]))
    yield 'negative/rain-sample-count',False,source(lambda f:f['precipitation']['cell_multiplier_x_fastest'].pop())
    yield 'negative/rain-outside-support',False,source(lambda f:f['precipitation'].__setitem__('origin_xz_m',[250,0]))
    yield 'negative/rain-nonpositive-cell-size',False,source(lambda f:f['precipitation'].__setitem__('cell_size_xz_m',[0,32]))
    yield 'negative/pond-grid-unsupported',False,changed(POND,lambda r:r['fields'].__setitem__('grid_dimensions',[8,8]))
    yield 'negative/pond-stage-crosses-wall',False,changed(POND,lambda r:r['fields'].__setitem__('stage_valid_m',[-.25,1]))
    yield 'negative/pond-stage-crosses-bed',False,changed(POND,lambda r:r['fields'].__setitem__('stage_valid_m',[-1,.25]))
    yield 'negative/pond-solid-rain',False,source(lambda f:f['precipitation']['weather_phase_solid_flux_knots_kg_m2_s'][0].__setitem__(1,1))
    yield 'negative/exposure-entry-below-roof',False,changed(EXPOSURE,lambda r:r['fields'].__setitem__('entry_world_y_m',2))
    yield 'negative/receiver-footprint-outside-rain',False,changed(POND,lambda r:r['fields'].__setitem__('xz_rectangle_m',[32,0,65,32]))
    yield 'positive/opaque-raw-byte-limit',True,opaque(['['+' '*(16384-3)+'0]'])
    yield 'negative/opaque-raw-byte-excess',False,opaque(['['+' '*(16385-3)+'0]'])
    yield 'positive/opaque-16-and-total-byte-limits',True,opaque(['['+' '*(16384-3)+'0]']*16)
    yield 'negative/opaque-17-fields',False,opaque(['0']*17)
    yield 'positive/opaque-4096-aggregate-nodes',True,opaque(['['+'0,'*2046+'0]']*2)
    yield 'negative/opaque-4097-aggregate-nodes',False,opaque(['['+'0,'*2046+'0]','['+'0,'*2047+'0]'])
    yield 'positive/opaque-depth16',True,opaque(['['*16+'0'+']'*16])
    yield 'negative/opaque-depth17',False,opaque(['['*17+'0'+']'*17])
    yield 'positive/opaque-decoded-string4096',True,opaque([json.dumps('a'*4096)] )
    yield 'negative/opaque-decoded-string4097',False,opaque([json.dumps('a'*4097)] )
    yield 'negative/opaque-decoded-key4097',False,opaque(['{'+json.dumps('a'*4097)+':0}'])
    yield 'negative/opaque-invalid-unicode',False,opaque([r'"\ud800"'])
    yield 'negative/nonfinite-number',False,opaque(['1e999'])
    files=dict(BASE);files[SOURCE]=b'{"fields":' + b'['*65+b'{"never-read":';yield 'negative/whole-depth-malformed-tail',False,files
    files=dict(BASE);files[SOURCE]=b'{"fields":['+b'0,'*(1_000_000-2)+b'{"never-read":';yield 'negative/whole-node-malformed-tail',False,files
    files=dict(BASE);files[SOURCE]=b' '*(16*1024*1024+1);yield 'negative/whole-byte-limit',False,files
    yield 'positive/declared-unselected',True,changed(SCENE,lambda r:r['fields'].pop('environment.source'))
    second_scene={'id':'40000000-0000-4000-8000-000000000004','type':'core.scene','schema':2,'fields':{}}
    def two_entries(files):
        p=json.loads(files[PROJECT]);p['fields']['project.entryScenes'].append(second_scene['id']);files[PROJECT]=encoded(p)
    yield 'negative/two-selected-entry-closure',False,with_records([('scenes/second.scene.json',second_scene)],two_entries)
    def unselected(files):
        two_entries(files);s=json.loads(files[SCENE]);s['fields'].pop('environment.source');files[SCENE]=encoded(s)
    yield 'positive/two-baseline-entry-unselected',True,with_records([('scenes/second.scene.json',second_scene)],unselected)

    yield 'positive/global-required-edges65536',True,edge_graph(False)
    yield 'negative/global-required-edges65537',False,edge_graph(True)


def main():
    binary=Path(sys.argv[1]).resolve();candidate=HERE/'candidate';candidate.mkdir(exist_ok=True)
    results=[]
    try:
        for name,expected,files in cases():
            for old in candidate.rglob('*.json'):old.unlink()
            for path,raw in files.items():
                p=candidate/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
            try:summary=o.validate(sorted(files.items()));oracle_ok=True;reason='accepted'
            except (ValueError,TypeError,KeyError,OverflowError,UnicodeError,StopIteration,IndexError)as e:oracle_ok=False;reason=str(e).splitlines()[0]
            p=subprocess.run([str(binary),str(candidate)],text=True,capture_output=True)
            rust_ok=p.returncode==0
            require=expected==oracle_ok==rust_ok
            results.append((name,'accept'if expected else'refuse','pass'if require else'FAIL',reason[:100],p.stderr.strip()[:120]))
            if not require:raise AssertionError((name,expected,oracle_ok,p.returncode,reason,p.stdout,p.stderr))
        (HERE/'adversarial.tsv').write_text('case\texpected\tresult\toracle\trust\n'+'\n'.join('\t'.join(row)for row in results)+'\n')
        print(f'ADVERSARIAL PASS {len(results)} cases; {sum(row[1]=="accept"for row in results)} positive variants; independent Rust/Python agreement')
    finally:shutil.rmtree(candidate)

if __name__=='__main__':main()
