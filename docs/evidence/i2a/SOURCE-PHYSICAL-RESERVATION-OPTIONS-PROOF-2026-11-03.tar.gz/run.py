#!/usr/bin/env python3
"""One matched fresh/edit worker per option and one bounded quota refusal."""
import json,os,pathlib,platform,subprocess,hashlib,shutil
TASK=pathlib.Path(__file__).resolve().parent
BIN=TASK/'target/release/source-vfs-credit-proof'
RAW=TASK/'raw';RAW.mkdir(exist_ok=True)
RUN=TASK/'runs';RUN.mkdir(exist_ok=True)
subprocess.run([str(BIN),'identity'],stdout=open(RAW/'sqlite-identity.json','w'),check=True)
workers=[]
for mode in ('native','scheduled','credit','fault'):
 root=RUN/mode;root.mkdir(exist_ok=False)
 with open(RAW/(mode+'.jsonl'),'w')as out,open(RAW/(mode+'.stderr'),'w')as err:
  p=subprocess.Popen([str(BIN),mode,str(root)],stdout=out,stderr=err)
  pid,status,usage=os.wait4(p.pid,0);p.returncode=os.waitstatus_to_exitcode(status)
 item={'mode':mode,'returncode':p.returncode,'peak_rss_bytes_macos':usage.ru_maxrss,'user_s':usage.ru_utime,'system_s':usage.ru_stime}
 print(json.dumps(item),flush=True);workers.append(item)
 assert p.returncode==0,(mode,(RAW/(mode+'.stderr')).read_text())
 shutil.rmtree(root)
(RAW/'workers.json').write_text(json.dumps(workers,indent=2)+'\n')
(TASK/'environment.json').write_text(json.dumps({'platform':platform.platform(),'machine':platform.machine(),'python':platform.python_version()},indent=2)+'\n')
