# Source VFS credit proof — bounded scratch

Owner: `/root/source_binding_review`, 3 November 2026. Purpose: compare current
public provisional source fresh/edit with explicit checkpoint scheduling and a
requested-page credit fence; one quota refusal/reopen. Expected peak <300 MiB;
local APFS had >80 GiB available. No production code/schema/public API edits.

Selected report: `docs/design/research/SOURCE-PHYSICAL-RESERVATION-OPTIONS-2026-11-03.md`.
Retain this recipe, exact sources/Cargo lock, raw measurements, rejected initial A
proxy and tool identities in a byte-verified compact archive. Remove owned databases
and target after verification. No master asset, runtime readiness or physical-space
reservation is produced. Ignored scratch is local evidence, not a durable backup.

The C wrapper is scratch-only unsafe code, serial one-store lifetime. It forwards
the default native VFS and refuses requested-page work before forwarding. It does
not account all filesystem metadata/control paths or persist credit grants. A uses
an actual live private SQLite handle recorded by an auto-extension and path-checked
/configured after public store open, between completed serial operations. This test
hook is not a proposed public API. The initial open-hook-only A proxy was overwritten
by SQLite's later default initialization; its raw log is retained as rejected.

Run after restoring the owned target:

```sh
RUSTC_WRAPPER= rustup run 1.99.1 cargo build --locked --offline --release --manifest-path tmp/source-vfs-credit-proof/Cargo.toml
python3 tmp/source-vfs-credit-proof/run.py
```

`build.rs` names the exact local bundled 3.53.2 header. A different header path,
compiler or dependency build requires a new identity record. `run.py` removes only
its own per-case stores after assertions. It records one matched sample per option,
not a speedup or percentile campaign.

Raw counter order: requested-page debit, successful forwarded write calls,
successful requested write bytes, quota denials, suppressed size hints, truncates,
SHM extension calls, remaining credit, main write bytes, WAL write bytes.
Mode native has no wrapper counters. Failed/partial writes retain their charge.
The fault worker deliberately grants new unlimited test credit after refusal; it
proves old-root/status/retry behavior, not durable-credit recovery.
