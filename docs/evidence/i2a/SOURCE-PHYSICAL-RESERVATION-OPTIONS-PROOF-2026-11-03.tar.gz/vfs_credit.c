// Scratch only: one serial owner and one store. Not a physical allocator.
#include <sqlite3.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
typedef struct {sqlite3_file base; sqlite3_file *real; int kind; sqlite3_int64 eof; uint64_t shm;} File;
static sqlite3_vfs *under;static sqlite3_vfs wrapper;
static int mode,schedule;static sqlite3* active[16];static uint64_t remaining=UINT64_MAX,used,writes,writebytes,denied,hints,truncs,maps,mainbytes,walbytes;
static uint64_t round_page(uint64_t n){return (n+4095)&~(uint64_t)4095;}
static int debit(uint64_t n){if(mode==2&&n>remaining){denied++;return SQLITE_FULL;}if(mode==2)remaining-=n;used+=n;return SQLITE_OK;}
static int close_f(sqlite3_file *p){File*f=(File*)p;int r=f->real->pMethods->xClose(f->real);p->pMethods=0;return r;}
static int read_f(sqlite3_file*p,void*b,int n,sqlite3_int64 o){File*f=(File*)p;return f->real->pMethods->xRead(f->real,b,n,o);}
static int write_f(sqlite3_file*p,const void*b,int n,sqlite3_int64 o){File*f=(File*)p;
 if(o<0||n<0||o>INT64_MAX-n)return SQLITE_IOERR_WRITE;
 uint64_t amount=round_page((uint64_t)(o&4095)+(unsigned)n);
 if(mode==2&&debit(amount)!=SQLITE_OK)return SQLITE_FULL;
 int r=f->real->pMethods->xWrite(f->real,b,n,o);writes++;if(r==SQLITE_OK){writebytes+=(unsigned)n;if(f->kind==1)mainbytes+=(unsigned)n;if(f->kind==2)walbytes+=(unsigned)n;if(o+n>f->eof)f->eof=o+n;}return r;}
static int trunc_f(sqlite3_file*p,sqlite3_int64 n){File*f=(File*)p;if(n<0)return SQLITE_IOERR_TRUNCATE;
 if(mode==2&&debit(n>f->eof?round_page((uint64_t)(n-f->eof)):4096)!=SQLITE_OK)return SQLITE_FULL;
 truncs++;int r=f->real->pMethods->xTruncate(f->real,n);if(r==SQLITE_OK)f->eof=n;return r;}
static int sync_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xSync(f->real,x);}
static int size_f(sqlite3_file*p,sqlite3_int64*n){File*f=(File*)p;return f->real->pMethods->xFileSize(f->real,n);}
static int lock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xLock(f->real,x);}
static int unlock_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xUnlock(f->real,x);}
static int reserved_f(sqlite3_file*p,int*x){File*f=(File*)p;return f->real->pMethods->xCheckReservedLock(f->real,x);}
static int control_f(sqlite3_file*p,int x,void*a){File*f=(File*)p;
 if(mode==2){
  if(x==SQLITE_FCNTL_SIZE_HINT){hints++;return SQLITE_OK;} // suppress advisory underlying allocations
  if(x==SQLITE_FCNTL_CHUNK_SIZE&&*(int*)a!=0)return SQLITE_NOTFOUND;
  if(x==SQLITE_FCNTL_MMAP_SIZE){*(sqlite3_int64*)a=0;}
  if(x==SQLITE_FCNTL_FILE_POINTER){*(sqlite3_file**)a=p;return SQLITE_OK;}
  if(x==SQLITE_FCNTL_VFS_POINTER){*(sqlite3_vfs**)a=&wrapper;return SQLITE_OK;}
 }
 return f->real->pMethods->xFileControl(f->real,x,a);}
static int sector_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xSectorSize(f->real);}
static int device_f(sqlite3_file*p){File*f=(File*)p;return f->real->pMethods->xDeviceCharacteristics(f->real);}
static int shmmap_f(sqlite3_file*p,int i,int n,int w,void volatile**v){File*f=(File*)p;
 if(i<0||n<=0)return SQLITE_IOERR_SHMMAP;
 uint64_t end=((uint64_t)(unsigned)i+1)*(unsigned)n;
 if(w&&end>f->shm){if(mode==2&&debit(round_page(end-f->shm))!=SQLITE_OK)return SQLITE_FULL;f->shm=end;maps++;}
 return f->real->pMethods->xShmMap(f->real,i,n,w,v);}
static int shmlock_f(sqlite3_file*p,int i,int n,int x){File*f=(File*)p;return f->real->pMethods->xShmLock(f->real,i,n,x);}
static void barrier_f(sqlite3_file*p){File*f=(File*)p;f->real->pMethods->xShmBarrier(f->real);}
static int unmap_f(sqlite3_file*p,int x){File*f=(File*)p;return f->real->pMethods->xShmUnmap(f->real,x);}
static int fetch_f(sqlite3_file*p,sqlite3_int64 o,int n,void**v){File*f=(File*)p;if(f->real->pMethods->iVersion<3||!f->real->pMethods->xFetch){*v=0;return SQLITE_OK;}return f->real->pMethods->xFetch(f->real,o,n,v);}
static int unfetch_f(sqlite3_file*p,sqlite3_int64 o,void*v){File*f=(File*)p;if(f->real->pMethods->iVersion<3||!f->real->pMethods->xUnfetch)return SQLITE_OK;return f->real->pMethods->xUnfetch(f->real,o,v);}
static const sqlite3_io_methods methods={3,close_f,read_f,write_f,trunc_f,sync_f,size_f,lock_f,unlock_f,reserved_f,control_f,sector_f,device_f,shmmap_f,shmlock_f,barrier_f,unmap_f,fetch_f,unfetch_f};
static int open_f(sqlite3_vfs*v,const char*n,sqlite3_file*p,int flags,int*out){(void)v;File*f=(File*)p;memset(f,0,sizeof(*f));f->real=(sqlite3_file*)(f+1);int r=under->xOpen(under,n,f->real,flags,out);if(r!=SQLITE_OK)return r;
 f->kind=(flags&SQLITE_OPEN_MAIN_DB)?1:(flags&SQLITE_OPEN_WAL)?2:3;f->base.pMethods=&methods;r=f->real->pMethods->xFileSize(f->real,&f->eof);if(r!=SQLITE_OK){close_f(p);return r;}return SQLITE_OK;}
static int closed(unsigned event,void*ctx,void*p,void*x){(void)event;(void)p;(void)x;for(int i=0;i<16;i++)if(active[i]==(sqlite3*)ctx)active[i]=0;return 0;}
static int extension(sqlite3*d,char**e,const sqlite3_api_routines*a){(void)e;(void)a;
 if(schedule){for(int i=0;i<16;i++)if(!active[i]){active[i]=d;return sqlite3_trace_v2(d,SQLITE_TRACE_CLOSE,closed,d);}return SQLITE_ERROR;}
 return SQLITE_OK;}
// Called only between completed public API operations, serial probe only.
int credit_after_open(const char*expected){if(!schedule)return SQLITE_OK;int found=0;
 for(int i=0;i<16;i++){sqlite3*d=active[i];if(!d)continue;const char*n=sqlite3_db_filename(d,"main");if(!n||strcmp(n,expected))continue;
 if(!sqlite3_get_autocommit(d))return SQLITE_BUSY;found++;
 int actual=0,r=sqlite3_wal_autocheckpoint(d,0);if(r!=SQLITE_OK)return r;
 r=sqlite3_db_config(d,SQLITE_DBCONFIG_NO_CKPT_ON_CLOSE,1,&actual);if(r!=SQLITE_OK||actual!=1)return SQLITE_ERROR;
 sqlite3_stmt*s=0;r=sqlite3_prepare_v2(d,"PRAGMA wal_autocheckpoint",-1,&s,0);if(r!=SQLITE_OK)return r;
 r=sqlite3_step(s);int okay=r==SQLITE_ROW&&sqlite3_column_int(s,0)==0;sqlite3_finalize(s);if(!okay)return SQLITE_ERROR;
 }return found==1?SQLITE_OK:SQLITE_ERROR;}
int credit_init(int m,int scheduled){mode=m;schedule=scheduled;under=sqlite3_vfs_find(0);if(!under||under->iVersion<2)return SQLITE_ERROR;
 if(mode){wrapper=*under;wrapper.zName="thrum-credit-research";wrapper.szOsFile=(int)(sizeof(File)+under->szOsFile);wrapper.xOpen=open_f;int r=sqlite3_vfs_register(&wrapper,1);if(r!=SQLITE_OK)return r;}
 return sqlite3_auto_extension((void(*)(void))extension);}
void credit_reset(uint64_t grant){remaining=grant;used=writes=writebytes=denied=hints=truncs=maps=mainbytes=walbytes=0;}
void credit_stats(uint64_t*out){uint64_t a[]={used,writes,writebytes,denied,hints,truncs,maps,remaining,mainbytes,walbytes};memcpy(out,a,sizeof(a));}
