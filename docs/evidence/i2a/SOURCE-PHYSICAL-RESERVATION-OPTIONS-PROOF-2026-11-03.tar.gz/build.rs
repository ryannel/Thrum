use std::{env, path::PathBuf, process::Command};
fn main() {
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());
    assert!(Command::new("cc").args(["-std=c11","-I/Users/ryannel/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.38.2/sqlite3","-O2","-Wall","-Wextra","-Werror","-c","vfs_credit.c","-o"]).arg(out.join("probe.o")).status().unwrap().success());
    assert!(
        Command::new("ar")
            .arg("crs")
            .arg(out.join("libprobe.a"))
            .arg(out.join("probe.o"))
            .status()
            .unwrap()
            .success()
    );
    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=probe");
    println!("cargo:rerun-if-changed=vfs_credit.c");
}
