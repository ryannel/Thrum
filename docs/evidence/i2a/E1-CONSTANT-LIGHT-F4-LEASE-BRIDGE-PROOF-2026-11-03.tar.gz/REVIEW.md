# Selected proof review — 3 November 2026

The parent reviewed the bridge, oracle, report and measurement scope, requiring
explicit disclosure of out-of-band staged SelectionRecipe, cfg(test)-only numeric
projections, local cache verification/reuse and the absence of a build orchestrator.
These boundaries are retained in README and the selected evidence report.

A separate read-only adversarial agent found source drift behind the committed
COMMIT-quarantine/marker fix, and a replay verifier that checked the lib.rs prefix
without proving its exact suffix. The source snapshot was refreshed to HEAD
`1c35b5300ba0714ce6346dc94d66bc7978441c25`, and correctness, independent oracle and
both release workload measurements were rerun. The verifier now checks the exact
suffix, original prefix and complete source file membership; negative suffix and
extra-file mutation probes refuse, with restoration checked afterward.

Final independent read-only review found no remaining actionable findings. It
verified the refreshed snapshot hashes against committed files, the mutation
refusals, report/results agreement, 17 actual leased source cases and the
4,096-file profile arithmetic. It cleared archive freeze while retaining the
production API/cache/admission limitations. This review qualifies only the
bounded scratch proof and its stated evidence, without production readiness or
user visual acceptance.
