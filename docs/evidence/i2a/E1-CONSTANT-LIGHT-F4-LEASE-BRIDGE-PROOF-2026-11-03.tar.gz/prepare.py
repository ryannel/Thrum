#!/usr/bin/env python3
"""Create only this task's exact-source scratch workspace."""
from pathlib import Path
import hashlib, json, shutil
root=Path(__file__).resolve().parent
repo=root.parents[1]
source=root/'source'
source.mkdir(exist_ok=True)
shutil.copytree(repo/'crates/thrum-source/src', source/'src', dirs_exist_ok=True)
shutil.copy2(repo/'crates/thrum-source/Cargo.toml',source/'Cargo.toml')
config=(repo/'Cargo.toml').read_text()
config=config[config.index('[workspace.package]'):]
(root/'Cargo.toml').write_text('[workspace]\nmembers = ["source"]\nresolver = "3"\n\n'+config)
shutil.copy2(repo/'Cargo.lock',root/'Cargo.lock')
codec=(repo/'tmp/f4-constant-light-proof/src/main.rs').read_text()
(root/'codec-original.rs').write_text(codec)
codec=codec[:codec.index('fn main()')] + codec[codec.index('#[cfg(test)]\nmod tests'):]
codec=codec.replace('include_str!("../oracle.golden")','include_str!("oracle.golden")')
(root/'bridge_proof.rs').write_text(codec+'\ninclude!("bridge_join.rs");\n')
with (source/'src/lib.rs').open('a') as f:
    f.write('\n// Proof-only access to unchanged crate-private F3 typed projections.\n#[cfg(test)]\n#[path = "../../bridge_proof.rs"]\nmod bridge_proof;\n')
for name in ['oracle.py','oracle.golden']:
    shutil.copy2(repo/'tmp/f4-constant-light-proof'/name,root/name)
files=[repo/'Cargo.toml',repo/'Cargo.lock']+sorted((repo/'crates/thrum-source').rglob('*.rs'))+[repo/'crates/thrum-source/Cargo.toml']
identity={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(root/'source-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(root/'OWNERSHIP.md').write_text('Owner: delegated F4 constant-light bridge proof. Scope: this directory only. Expected peak <1 GiB including isolated build cache. Exact current thrum-source, prior codec, original fixtures; no external assets. Retain reproducible source and compact results after root review. Discard only owned rebuildable target and generated temporary store trees after selected archive verification.\n')
print('Prepared exact-source scratch crate; only lib.rs has appended proof test module.')
