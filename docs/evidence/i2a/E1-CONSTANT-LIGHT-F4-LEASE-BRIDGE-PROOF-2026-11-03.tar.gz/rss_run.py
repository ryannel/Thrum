#!/usr/bin/env python3
"""Run exactly one Rust child and report that child's getrusage high-water RSS."""
import json,resource,subprocess,sys,time
start=time.perf_counter()
r=subprocess.run(sys.argv[1:])
u=resource.getrusage(resource.RUSAGE_CHILDREN)
print('CHILD_RUSAGE '+json.dumps({'max_rss_bytes':u.ru_maxrss,'user_seconds':u.ru_utime,'system_seconds':u.ru_stime,'wall_seconds':time.perf_counter()-start,'scope':'one Rust test process; macOS ru_maxrss bytes; fixture/setup/both revisions/test harness included; Python parent excluded'}),flush=True)
raise SystemExit(r.returncode)
