# Provisional F3 → F4 constant-light lease bridge proof

Package `thrum.e1.constant-light.f3-f4-lease-bridge-proof.v1`, 3 November 2026.
This is an internal scratch proof over the actual current `ProvisionalSourceStore`,
`VerifiedSourceLease`, staged candidate and F3 typed parsers. It is neither an
admitted-source API nor an F4 ready build, persistent product cache or renderer.
No production crate, canonical contract or maturity claim was changed.

`source/` is an exact snapshot of `crates/thrum-source/`; its original files are
hashed in `source-identity.json`. Only `source/src/lib.rs` has an appended
`#[cfg(test)]` module declaration. `run_proof.py` checks the exact appended suffix, original prefix, complete source file membership
and all original source hashes before replay. Negative suffix/membership mutation
probes are recorded in `logs/snapshot-verifier-hardening.log`. Its scratch lock contains exactly the
42 matching package identities/checksums from the repository lock subset.
`codec-original.rs` is the complete prior standalone codec source. The derived
`bridge_proof.rs` removes only its unused executable entry point, adjusts the
golden include path, and includes `bridge_join.rs`; its nine existing tests remain.
All proof code is original project code; no outside engine source/assets were used.

Three boundaries are deliberate:

- `SelectionRecipe` comes from the validated staged candidate **before** provisional
  publication. It carries the candidate's exact revision, project/entry ID and
  built-in definition hashes. It is out of band from the lease: today's public
  lease exposes a selection and per-ID reads, without a manifest/typed-selection
  accessor. The adapter checks revision/project equality before any record reads.
- Today's F3 environment numeric projections exist only under `cfg(test)`. This
  internal test module consumes the unchanged F3 decoder's projections. A real
  F4 consumer requires a narrow production F3 API that retains validated values
  and selects scene/source/light with stable IDs from one verified build lease.
  Its manifest/index must be acquired once and shared across the build's products.
- `cached_product` locally verifies/reuses A's payload/manifest under B's computed
  key. There is no persistent cache lookup, product publication or build authority.

`join` reads exactly three hash-verified records by stable ID from one lease:
entry scene → schema-1 authored environment → schema-1 light identity. It uses
F3's fixed typed decoders, applies the selected ordered normalization and codec,
verifies the product and binds exact provisional SourceRevision/project/entry/
source/light/scene definition/profile lock. Every mutable candidate source file is
poisoned after publication and before the B cook; A's original candidate/stage and
checkout are dropped/deleted while its lease reader remains valid. The 17 retained
cases also contain a lower-ID, earlier-path unselected environment/light and a
non-entry bound scene; these do not change the selected product.

The inherited identity grammar is **proof-local**, not a persistent F4 choice.
CookKey hashes the NUL-terminated `thrum-proof-f4-constant-light-cook-key-v1`
domain, LE u16 product version, source/light UUID octets, 14 source f64 values
with positive-zero canonicalization, LE u32 mask, length-prefixed UTF-8 profile/
direction-model/driver strings, environment/light definition hashes, three LE u32
implementation revisions and length-prefixed compiler/target/FP-class strings.
The product revision hashes the NUL-terminated
`thrum-proof-f4-constant-light-manifest-v1` domain, LE u16 version, LE u32 size,
CookKey and BlobHash. Binding hashes the NUL-terminated
`thrum-proof-f4-constant-light-build-binding-v1` domain, exact SourceRevision,
project/entry/environment/light UUID octets, scene definition hash, profile lock
hash and product revision. `bridge_proof.rs` and both Python oracles provide the
complete executable grammar. The 160-byte payload follows the selected ENVIRONMENT
contract; source revisions remain actual F3 canonical manifest SHA-256 values.

Replay from any owned `tmp/<task>/` inside this repository with cached locked
dependencies and pinned Rust 1.99.1:

```sh
python3 run_proof.py
python3 run_proof.py --measure
```

The second command runs two isolated release child processes, for 3 records/5
files and the provisional store's maximum 4,094 records/4,096 files. Measurements
are sequential, with first-use acquisition/decode after publication (filesystem
caches are **not** evicted), 31 repeated acquire/join pairs, 101 shared-index joins
and 101 decode-only samples. `rss_run.py` obtains the one Rust child's high-water
RSS using macOS `getrusage`; it excludes the Python parent but includes fixture
creation, F3, store publication, test harness, both stages, both leases and both
products. It does not identify when the process peak occurred. No allocation
counter, target device or whole-engine qualification is claimed.

The initial 4,096-record attempt correctly exceeded MAX_FILES because project and
history add two files; `logs/profile-refusal-4096-records.log` records the refusal.
The initial `/usr/bin/time -l` RSS wrapper failed its sandboxed clockrate sysctl;
`logs/preliminary-time-probe.log` retains that trial. Direct child `getrusage`
works without that sysctl. These preliminary timings are not improvement evidence.

`results/cases/` contains exact staged manifests/trees and the three actual leased
records, product bytes and hashes. `joined_oracle.py` independently rehashes every
file and manifest, follows the selected links, and reconstructs full payload,
recipe, manifest and binding from those actual bytes. The manifest fixture's
alphabet/metadata are deliberately bounded, so stdlib sorted compact JSON is JCS
for these files; this is not a general JCS implementation. `oracle.py` and
`oracle.golden` retain the earlier three codec goldens and cosmetic binding vectors.
Independent review found the original scratch snapshot had drifted behind the
committed COMMIT-quarantine/marker correction; it was refreshed to HEAD
`1c35b5300ba0714ce6346dc94d66bc7978441c25`, store source SHA-256
`f9355227dc36ce39b5b6ae6e56d14115fbc3ab41dc12e234f6cff8b06430cd44`.
The selected correctness/oracle and measurements were rerun; `logs/*pre-refresh*`
records superseded source identities/results without a performance comparison.
`host-and-build.json`, results, logs and `verification.txt` identify tools, source,
loaded release binary, workload and actual checks. `prepare.py` is historical
capture provenance requiring the original repository/codec scratch inputs;
replay consumes the retained exact snapshot and does not run that capture script.
