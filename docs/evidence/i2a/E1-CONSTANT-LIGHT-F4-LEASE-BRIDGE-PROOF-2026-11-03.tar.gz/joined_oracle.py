#!/usr/bin/env python3
"""Independent stdlib reconstruction from the actual leased source snapshots."""
import hashlib,json,math,struct,uuid
from pathlib import Path
import oracle as base
ROOT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).digest()
def check(folder):
    result=json.loads((folder/'result.json').read_bytes())
    encoded=(folder/'manifest.json').read_bytes()
    manifest=json.loads(encoded)
    # Deliberately bounded alphabet and integer-only metadata makes this JCS.
    assert encoded==json.dumps(manifest,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    revision=sha(encoded)
    assert revision.hex()==result['source_revision']
    indexed={}
    for entry in manifest['files']:
        b=(folder/'source'/entry['path']).read_bytes()
        assert len(b)==entry['length'] and sha(b).hex()==entry['hash']
        if entry['recordId']:
            record=json.loads(b)
            assert record['id']==entry['recordId'] and record['type']==entry['recordType']
            assert record['id'] not in indexed
            indexed[record['id']]=(record,b)
    project=indexed[manifest['projectId']][0]
    scene_id,=project['fields']['project.entryScenes']
    scene,scene_b=indexed[scene_id]
    assert scene['type']=='core.scene' and scene['schema']==2
    env_id=scene['fields']['environment.source']
    env,env_b=indexed[env_id]
    light_id=env['fields']['sun']['light_ref']
    light,light_b=indexed[light_id]
    assert env['type']=='thrum.environment.authored' and env['schema']==1
    assert light['type']=='thrum.light.identity' and light['schema']==1
    assert light['fields']['driver_binding']=='incoming-environment-sun'
    for name,b in [('scene',scene_b),('environment',env_b),('light',light_b)]:
        assert (folder/f'leased-{name}.json').read_bytes()==b
    f=env['fields']; sun=f['sun']
    assert f['profile']=='constant-light-v1'
    assert sun['direction_model']=='geometric-straight' and sun['applied_attenuation']==[]
    assert sorted(f['unsupported'])==sorted(base.UNSUPPORTED)
    values=sun['toward_source_unit']+sun['unit_luminance_linear_rec709']+[sun['perpendicular_illuminance_lux'],sun['angular_radius_rad']]+f['ambient_irradiance_lux']+f['background_radiance_cd_m2']
    dx,dy,dz,r,g,b=values[:6]
    length=math.sqrt(((dx*dx)+(dy*dy))+(dz*dz))
    luminance=((0.2126*r)+(0.7152*g))+(0.0722*b)
    assert abs(length-1)<=1e-9 and abs(luminance-1)<=1e-9
    cooked=[base.positive_zero(x/length) for x in (dx,dy,dz)]+[base.positive_zero(x/luminance) for x in (r,g,b)]+[base.positive_zero(x) for x in values[6:]]
    product=b'THRME1C\0'+struct.pack('<HHI',1,0,0x7f)+uuid.UUID(env_id).bytes+uuid.UUID(light_id).bytes+struct.pack('<14d',*cooked)
    assert product==(folder/'product.bin').read_bytes()
    blob=sha(product)
    recipe=base.COOK_DOMAIN+struct.pack('<H',1)+uuid.UUID(env_id).bytes+uuid.UUID(light_id).bytes
    recipe+=struct.pack('<14d',*(base.positive_zero(x) for x in values))+struct.pack('<I',0x7f)
    recipe+=b''.join(base.text(x) for x in ['constant-light-v1','geometric-straight','incoming-environment-sun'])
    recipe+=base.ENV_DEF+base.LIGHT_DEF+struct.pack('<III',1,1,1)+b''.join(base.text(x) for x in base.CLASS)
    key=sha(recipe)
    product_revision=sha(base.PRODUCT_DOMAIN+struct.pack('<HI',1,160)+key+blob)
    binding=base.BINDING_DOMAIN+revision+b''.join(uuid.UUID(i).bytes for i in [manifest['projectId'],scene_id,env_id,light_id])+base.SCENE_DEF+sha(b'proof-profile-r0-target-lock-v1')+product_revision
    for name,b in [('blob_hash',blob),('cook_key',key),('product_revision',product_revision),('binding',sha(binding))]:
        assert result[name]==b.hex(),(folder.name,name)
    assert result['record_reads']==3
    print(folder.name, '160 bytes, exact source closure/revision, recipe, manifest and binding independently match')
    return result

def main():
    cases=sorted((ROOT/'results/cases').iterdir())
    result={p.name:check(p) for p in cases}
    assert len(result)==17
    a=result['A']
    for name in ['formatting','label','documentation','opaque','signed_zero','light_label','path','unrelated','scene_rebind','unselected']:
        assert result[name]['cook_key']==a['cook_key'] and result[name]['product_revision']==a['product_revision']
        assert result[name]['source_revision']!=a['source_revision'] and result[name]['binding']!=a['binding']
    for name in ['direction','colour','lux','radius','ambient','background']:
        assert result[name]['cook_key']!=a['cook_key']
    print('PASS: independent joined oracle verified all 17 actual leased source closures and complete bytes/digests.')
if __name__=='__main__':main()
