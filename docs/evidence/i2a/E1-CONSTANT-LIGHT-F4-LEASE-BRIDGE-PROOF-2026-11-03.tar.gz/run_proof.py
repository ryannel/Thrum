#!/usr/bin/env python3
"""Replay retained scratch source without touching the repository's source crate."""
import argparse,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def command(args,env=None,quiet=False):
    print('+',' '.join(map(str,args)),flush=True)
    r=subprocess.run(list(map(str,args)),cwd=ROOT,env=env,text=True,capture_output=True)
    if not quiet: print(r.stdout,end='')
    print(r.stderr,end='',file=sys.stderr)
    if r.returncode:raise SystemExit(r.returncode)
    return r

def verify_snapshot():
    recorded=json.loads((ROOT/'source-identity.json').read_text())
    for rel,digest in recorded.items():
        if rel.startswith('crates/thrum-source/'):
            p=ROOT/'source'/rel.removeprefix('crates/thrum-source/')
            b=p.read_bytes()
            if rel.endswith('/lib.rs'):
                suffix=b'\n// Proof-only access to unchanged crate-private F3 typed projections.\n#[cfg(test)]\n#[path = "../../bridge_proof.rs"]\nmod bridge_proof;\n'
                assert b.endswith(suffix), 'lib.rs proof suffix differs'
                b=b[:-len(suffix)]
            assert hashlib.sha256(b).hexdigest()==digest,rel
    expected={str(Path(rel).relative_to('crates/thrum-source')) for rel in recorded if rel.startswith('crates/thrum-source/')}
    actual={str(p.relative_to(ROOT/'source')) for p in (ROOT/'source').rglob('*') if p.is_file()}
    assert actual==expected, 'source snapshot file membership differs'
    print('Exact original source snapshot hashes and file membership match; lib.rs has only the exact test-module append.')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--measure',action='store_true');a=ap.parse_args()
    verify_snapshot()
    env=os.environ.copy();env['RUSTC_WRAPPER']='';env['CARGO_TARGET_DIR']=str(ROOT/'target')
    cargo=['rustup','run','1.99.1','cargo']
    logs=ROOT/'logs';logs.mkdir(exist_ok=True)
    command(cargo+['fmt','--all','--check'],env)
    command(['rustup','run','1.99.1','rustfmt','--edition','2024','--check',ROOT/'bridge_proof.rs',ROOT/'bridge_join.rs'],env)
    command(cargo+['clippy','--locked','--offline','--all-targets','--','-D','warnings'],env)
    for mode in ['debug','release']:
        flags=[] if mode=='debug' else ['--release']
        r=command(cargo+['test','--locked','--offline']+flags+['bridge_proof','--','--nocapture','--test-threads=1'],env)
        (logs/f'{mode}-tests.log').write_text(r.stdout+r.stderr)
    r=command([sys.executable,ROOT/'joined_oracle.py'],env);(logs/'joined-oracle.log').write_text(r.stdout)
    if a.measure:
        r=command(cargo+['test','--locked','--offline','--release','--no-run','--message-format=json'],env,quiet=True)
        executable=[json.loads(s)['executable'] for s in r.stdout.splitlines() if s.startswith('{') and json.loads(s).get('executable')][-1]
        for records in [3,4094]:
            e=env.copy();e['BRIDGE_RECORDS']=str(records)
            r=command([sys.executable,ROOT/'rss_run.py',executable,'bridge_proof::bridge_joined_measurement','--exact','--ignored','--nocapture','--test-threads=1'],e)
            (logs/f'measurement-{records}.log').write_text(r.stdout+r.stderr)
            usage=json.loads([line.removeprefix('CHILD_RUSAGE ') for line in r.stdout.splitlines() if line.startswith('CHILD_RUSAGE ')][0])
            (ROOT/f'results/rss-{records}.json').write_text(json.dumps(usage,indent=2)+'\n')
    print('PASS: retained proof replay; scoped internal provisional evidence only.')
if __name__=='__main__':main()
