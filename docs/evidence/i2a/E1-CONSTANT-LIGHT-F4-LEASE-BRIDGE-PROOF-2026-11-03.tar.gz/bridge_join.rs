use crate::environment_json::{parse_environment, parse_light, parse_scene};
use crate::provisional_store::{ProvisionalSourceStore, VerifiedSourceLease};
use crate::registry_stage::{StagedCandidate, validate_staged_candidate};
use crate::{SourcePath, StagedTree, stage_declared_tree};
use serde_json::{Value, json};
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};

const PROJECT_ID: &str = "20000000-0000-4000-8000-000000000001";
const SCENE_ID: &str = "20000000-0000-4000-8000-000000000002";
const ENV_ID: &str = "10000000-0000-4000-8000-000000000001";

#[derive(Clone)]
struct SelectionRecipe {
    revision: [u8; 32],
    entry: String,
    project: String,
    scene_definition: [u8; 32],
    class: CacheClass<'static>,
}
// Proof-local adapter: F3 selection is bound to the candidate's exact revision.
// No public production interface is introduced by this test module.
fn selection_recipe(candidate: &StagedCandidate<'_>) -> SelectionRecipe {
    let project = candidate.registry().project();
    assert_eq!(project.entry_scenes().len(), 1);
    let entry = project.entry_scenes()[0].clone();
    let scene = candidate
        .records()
        .scenes()
        .iter()
        .find(|s| s.id() == entry)
        .unwrap();
    let env_id = scene.environment_source().unwrap();
    let env = candidate
        .records()
        .builtins()
        .iter()
        .find(|b| b.id() == env_id)
        .unwrap();
    let light_id = env.required_light().unwrap();
    let light = candidate
        .records()
        .builtins()
        .iter()
        .find(|b| b.id() == light_id)
        .unwrap();
    let mut class = cache_class();
    class.environment_definition = *env.definition().definition_hash();
    class.light_definition = *light.definition().definition_hash();
    SelectionRecipe {
        revision: *candidate
            .provisional_manifest()
            .unwrap()
            .revision()
            .as_bytes(),
        project: project.id().to_owned(),
        entry,
        scene_definition: *scene.definition().unwrap().definition_hash(),
        class,
    }
}
fn uuid_bytes(id: &str) -> [u8; 16] {
    from_hex(&id.replace('-', ""))
}
struct Joined {
    lease: VerifiedSourceLease,
    source: TypedSource,
    raw: [Vec<u8>; 3],
    bytes: [u8; SIZE],
    manifest: ProductManifest,
    binding: BuildBinding,
}
impl Joined {
    fn close(self) {
        self.lease.close().unwrap();
    }
}
fn join(lease: VerifiedSourceLease, selected: &SelectionRecipe) -> Result<Joined, String> {
    if lease.selection().revision() != Some(&selected.revision)
        || lease.selection().project_id() != selected.project
    {
        return Err("stale F3 selection".to_owned());
    }
    let scene_bytes = lease
        .read_record(&selected.entry)
        .map_err(|e| format!("{e:?}"))?;
    let scene = parse_scene(&scene_bytes).map_err(|e| e.to_string())?;
    let env_id = scene.environment_source.ok_or("inactive entry scene")?;
    let env_bytes = lease.read_record(&env_id).map_err(|e| format!("{e:?}"))?;
    let env = parse_environment(&env_bytes).map_err(|e| e.to_string())?;
    let light_bytes = lease
        .read_record(&env.sun.light_ref)
        .map_err(|e| format!("{e:?}"))?;
    let light = parse_light(&light_bytes).map_err(|e| e.to_string())?;
    if scene.id != selected.entry || env.id != env_id || light.id != env.sun.light_ref {
        return Err("typed identity mismatch".to_owned());
    }
    assert_eq!(env.unsupported.len(), 7); // F3 has checked the exact unique set.
    let mut values = [0.; 14];
    values[..3].copy_from_slice(&env.sun.toward_source_unit);
    values[3..6].copy_from_slice(&env.sun.unit_luminance_linear_rec709);
    values[6] = env.sun.perpendicular_illuminance_lux;
    values[7] = env.sun.angular_radius_rad;
    values[8..11].copy_from_slice(&env.ambient_irradiance_lux);
    values[11..].copy_from_slice(&env.background_radiance_cd_m2);
    let source = TypedSource {
        environment: uuid_bytes(&env.id),
        light: uuid_bytes(&light.id),
        values,
        unsupported: MASK,
    };
    let bytes =
        encode(&cook(&source).map_err(|e| format!("{e:?}"))?).map_err(|e| format!("{e:?}"))?;
    let manifest = ProductManifest {
        key: cook_key(&source, &selected.class).map_err(|e| format!("{e:?}"))?,
        blob: blob_hash(&bytes),
    };
    cached_product(manifest.key, manifest.revision(), manifest, &bytes)
        .map_err(|e| format!("{e:?}"))?;
    let binding = BuildBinding {
        context: BindingContext {
            source_revision: SourceRevision(selected.revision),
            project: uuid_bytes(&selected.project),
            entry_scene: uuid_bytes(&selected.entry),
            environment: source.environment,
            light: source.light,
            scene_definition: selected.scene_definition,
            profile_target_lock: hash(b"proof-profile-r0-target-lock-v1"),
        },
        product_revision: manifest.revision(),
    };
    Ok(Joined {
        lease,
        source,
        raw: [scene_bytes, env_bytes, light_bytes],
        bytes,
        manifest,
        binding,
    })
}
fn task_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .to_owned()
}
fn write_value(path: &Path, value: &Value) {
    fs::write(path, serde_json::to_vec(value).unwrap()).unwrap();
}
fn edit(path: &Path, change: impl FnOnce(&mut Value)) {
    let mut value: Value = serde_json::from_slice(&fs::read(path).unwrap()).unwrap();
    change(&mut value);
    write_value(path, &value);
}
fn fixture(root: &Path, case: &str, records: usize) -> Vec<SourcePath> {
    fs::create_dir_all(root).unwrap();
    let mut paths = vec![];
    for p in [
        "project.json",
        "schemas/history.registry.json",
        "scenes/main.scene.json",
        "records/environment.record.json",
        "records/light.record.json",
    ] {
        let target = root.join(p);
        fs::create_dir_all(target.parent().unwrap()).unwrap();
        fs::copy(task_root().join("fixtures/cardinal-base").join(p), target).unwrap();
        paths.push(p.to_owned());
    }
    let env = root.join("records/environment.record.json");
    let light = root.join("records/light.record.json");
    match case {
        "A" => (),
        "formatting" => {
            let mut b = fs::read(&env).unwrap();
            b.extend_from_slice(b"\n  ");
            fs::write(&env, b).unwrap();
        }
        "label" => edit(&env, |v| v["fields"]["label"] = json!("renamed")),
        "documentation" => edit(&env, |v| v["documentation"] = json!("authoring note")),
        "opaque" => edit(&env, |v| {
            v["fields"]["x.thrum.environment.note"] = json!({"changed":[true,3]})
        }),
        "signed_zero" => edit(&env, |v| {
            v["fields"]["sun"]["toward_source_unit"][0] = json!(-0.0);
            v["fields"]["background_radiance_cd_m2"][0] = json!(-0.0);
        }),
        "light_label" => edit(&light, |v| v["fields"]["label"] = json!("Sun label")),
        "direction" => edit(&env, |v| {
            v["fields"]["sun"]["toward_source_unit"] = json!([0.36, 0.48, -0.8000000001])
        }),
        "colour" => edit(&env, |v| {
            v["fields"]["sun"]["unit_luminance_linear_rec709"] = json!([0.5, 1., 2.47229917])
        }),
        "lux" => edit(&env, |v| {
            v["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(123456.)
        }),
        "radius" => edit(&env, |v| {
            v["fields"]["sun"]["angular_radius_rad"] = json!(0.005)
        }),
        "ambient" => edit(&env, |v| {
            v["fields"]["ambient_irradiance_lux"][1] = json!(4321.)
        }),
        "background" => edit(&env, |v| {
            v["fields"]["background_radiance_cd_m2"][2] = json!(65.)
        }),
        "unselected" => {
            let eid = "00000000-0000-4000-8000-000000000001";
            let lid = "00000000-0000-4000-8000-000000000002";
            let mut e: Value = serde_json::from_slice(&fs::read(&env).unwrap()).unwrap();
            e["id"] = json!(eid);
            e["fields"]["sun"]["light_ref"] = json!(lid);
            e["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(987.);
            let mut l: Value = serde_json::from_slice(&fs::read(&light).unwrap()).unwrap();
            l["id"] = json!(lid);
            for (p, v) in [
                ("records/a-unselected-environment.record.json", e),
                ("records/a-unselected-light.record.json", l),
                (
                    "scenes/unselected-bound.scene.json",
                    json!({"id":"00000000-0000-4000-8000-000000000003","type":"core.scene","schema":2,"fields":{"environment.source":eid}}),
                ),
            ] {
                write_value(&root.join(p), &v);
                paths.push(p.to_owned());
            }
        }
        "invalid" => edit(&env, |v| {
            v["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(-1.)
        }),
        "wrong_type" => edit(&env, |v| v["fields"]["sun"]["light_ref"] = json!(SCENE_ID)),
        "unknown_schema" => edit(&env, |v| v["schema"] = json!(2)),
        "path" => {
            fs::rename(&env, root.join("records/renamed.record.json")).unwrap();
            *paths
                .iter_mut()
                .find(|p| **p == "records/environment.record.json")
                .unwrap() = "records/renamed.record.json".to_owned();
            edit(&root.join("project.json"), |v| {
                v["fields"]["project.records"][0] = json!("records/renamed.record.json")
            });
        }
        "unrelated" => {
            fs::write(root.join("notes.txt"), b"unrelated exact bytes\n").unwrap();
            paths.push("notes.txt".to_owned());
        }
        "scene_rebind" => {
            let new_id = "20000000-0000-4000-8000-000000000004";
            edit(&root.join("scenes/main.scene.json"), |v| {
                v["id"] = json!(new_id)
            });
            edit(&root.join("project.json"), |v| {
                v["fields"]["project.entryScenes"][0] = json!(new_id)
            });
        }
        _ => panic!("unknown case"),
    }
    for i in 3..records {
        let p = format!("scenes/unselected-{i:04}.scene.json");
        write_value(
            &root.join(&p),
            &json!({"id":format!("30000000-0000-4000-8000-{i:012x}"),"type":"core.scene","schema":1,"fields":{}}),
        );
        paths.push(p.clone());
    }
    let mut declared_records: Vec<_> = paths
        .iter()
        .filter(|p| p.starts_with("records/") || p.starts_with("scenes/"))
        .cloned()
        .collect();
    declared_records.sort();
    edit(&root.join("project.json"), |v| {
        v["fields"]["project.records"] = json!(declared_records)
    });
    paths
        .iter()
        .map(|p| SourcePath::parse(p).unwrap())
        .collect()
}
fn retain_case(
    output: &Path,
    stage: &StagedTree,
    candidate: &StagedCandidate<'_>,
    joined: &Joined,
) {
    fs::create_dir_all(output).unwrap();
    let mut manifest = vec![];
    candidate
        .provisional_manifest()
        .unwrap()
        .write_jcs(&mut manifest)
        .unwrap();
    fs::write(output.join("manifest.json"), &manifest).unwrap();
    for file in stage.files() {
        let p = output.join("source").join(file.path().as_str());
        fs::create_dir_all(p.parent().unwrap()).unwrap();
        let mut bytes = vec![];
        stage
            .open(file.path())
            .unwrap()
            .read_to_end(&mut bytes)
            .unwrap();
        fs::write(p, bytes).unwrap();
    }
    for (name, bytes) in ["scene", "environment", "light"].iter().zip(&joined.raw) {
        fs::write(output.join(format!("leased-{name}.json")), bytes).unwrap();
    }
    fs::write(output.join("product.bin"), joined.bytes).unwrap();
    fs::write(output.join("result.json"), serde_json::to_vec_pretty(&json!({
        "source_revision":hex(&joined.binding.context.source_revision.0), "blob_hash":hex(&joined.manifest.blob.0),
        "cook_key":hex(&joined.manifest.key.0), "product_revision":hex(&joined.manifest.revision().0), "binding":hex(&joined.binding.digest()),
        "project":hex(&joined.binding.context.project),"entry_scene":hex(&joined.binding.context.entry_scene),
        "environment":hex(&joined.source.environment),"light":hex(&joined.source.light),"record_reads":3,
    })).unwrap()).unwrap();
}
fn fresh_dir(name: &str) -> PathBuf {
    let p = task_root().join("work").join(name);
    if p.exists() {
        fs::remove_dir_all(&p).unwrap();
    }
    fs::create_dir_all(&p).unwrap();
    p
}
#[test]
fn bridge_joined_correctness() {
    let work = fresh_dir("correctness");
    let store_path = work.join("store");
    fs::create_dir_all(&store_path).unwrap();
    let store = ProvisionalSourceStore::open(&store_path, PROJECT_ID).unwrap();
    let base = store.selection().unwrap();
    let a_paths = fixture(&work.join("checkout"), "A", 3);
    let a_stage = stage_declared_tree(&work.join("checkout"), &a_paths).unwrap();
    let a_candidate = validate_staged_candidate(&a_stage, &[]).unwrap();
    let a_recipe = selection_recipe(&a_candidate);
    let a_selection = store
        .publish_candidate(&base, [1; 16], &a_candidate)
        .unwrap();
    let a_lease = store.lease_current(&a_selection).unwrap();
    // Shared-reader clones keep one durable pin, not one pin/index per product.
    let pin_count = || {
        rusqlite::Connection::open(store_path.join("provisional-source.sqlite"))
            .unwrap()
            .query_row("SELECT count(*) FROM pin", [], |r| r.get::<_, i64>(0))
            .unwrap()
    };
    assert_eq!(pin_count(), 1);
    let old_clone = a_lease.clone();
    assert_eq!(pin_count(), 1);
    let a = join(a_lease, &a_recipe).unwrap();
    retain_case(
        &task_root().join("results/cases/A"),
        &a_stage,
        &a_candidate,
        &a,
    );
    // Failed new candidates never displace the selected A or its pinned reader.
    for case in ["invalid", "wrong_type", "unknown_schema"] {
        let root = work.join(format!("failed-before-B-{case}"));
        let paths = fixture(&root, case, 3);
        let stage = stage_declared_tree(&root, &paths).unwrap();
        assert!(validate_staged_candidate(&stage, &[]).is_err());
        assert_eq!(store.selection().unwrap(), a_selection);
        assert_eq!(join(old_clone.clone(), &a_recipe).unwrap().bytes, a.bytes);
    }
    drop(a_candidate);
    drop(a_stage);
    fs::remove_dir_all(work.join("checkout")).unwrap();
    assert_eq!(join(old_clone.clone(), &a_recipe).unwrap().bytes, a.bytes);
    let mut current = a_selection.clone();
    for (index, case) in [
        "formatting",
        "label",
        "documentation",
        "opaque",
        "signed_zero",
        "light_label",
        "path",
        "unrelated",
        "scene_rebind",
        "unselected",
        "direction",
        "colour",
        "lux",
        "radius",
        "ambient",
        "background",
    ]
    .iter()
    .enumerate()
    {
        let root = work.join(format!("candidate-{case}"));
        let paths = fixture(&root, case, 3);
        let stage = stage_declared_tree(&root, &paths).unwrap();
        let candidate = validate_staged_candidate(&stage, &[]).unwrap();
        let recipe = selection_recipe(&candidate);
        let selected = store
            .publish_candidate(&current, [(index + 2) as u8; 16], &candidate)
            .unwrap();
        // Poison every mutable source file after capture/publication. Cook must not read them.
        for path in &paths {
            fs::write(
                root.join(path.as_str()),
                b"mutable checkout is deliberately invalid",
            )
            .unwrap();
        }
        let b = join(store.lease_current(&selected).unwrap(), &recipe).unwrap();
        assert_ne!(
            b.binding.context.source_revision, a.binding.context.source_revision,
            "{case}"
        );
        assert_ne!(b.binding.digest(), a.binding.digest(), "{case}");
        if index < 10 {
            assert_eq!(b.manifest, a.manifest, "{case}");
            assert_eq!(b.bytes, a.bytes, "{case}");
            let reused =
                cached_product(b.manifest.key, a.manifest.revision(), a.manifest, &a.bytes)
                    .unwrap();
            assert_eq!(encode(&reused).unwrap(), b.bytes);
        } else {
            assert_ne!(b.manifest.key, a.manifest.key, "{case}");
            assert_ne!(b.bytes, a.bytes, "{case}");
        }
        assert!(
            a.binding
                .check_current(b.binding.context, b.manifest.revision())
                .is_err()
        );
        assert!(join(old_clone.clone(), &recipe).is_err());
        retain_case(
            &task_root().join("results/cases").join(case),
            &stage,
            &candidate,
            &b,
        );
        let old_again = join(old_clone.clone(), &a_recipe).unwrap();
        assert_eq!(old_again.bytes, a.bytes);
        assert_eq!(old_again.binding, a.binding);
        old_again.close();
        if index == 0 {
            assert!(
                store
                    .publish_candidate(&a_selection, [90; 16], &candidate)
                    .is_err()
            );
            assert!(store.lease_current(&a_selection).is_err());
            assert_eq!(store.selection().unwrap(), selected);
        }
        current = selected;
        b.close();
    }
    for case in ["invalid", "wrong_type", "unknown_schema"] {
        let root = work.join(case);
        let paths = fixture(&root, case, 3);
        let stage = stage_declared_tree(&root, &paths).unwrap();
        assert!(validate_staged_candidate(&stage, &[]).is_err());
        assert_eq!(store.selection().unwrap(), current);
        assert_eq!(join(old_clone.clone(), &a_recipe).unwrap().bytes, a.bytes);
    }
    // Corrupt A alone after B advanced; exact leased reads refuse same-length mutation.
    let old_hash = hash(&a.raw[1]);
    let mut corrupt = a.raw[1].clone();
    corrupt[0] ^= 1;
    let conn = rusqlite::Connection::open(store_path.join("provisional-source.sqlite")).unwrap();
    assert_eq!(
        conn.execute(
            "UPDATE chunk SET bytes=?1 WHERE hash=?2 AND ix=0",
            rusqlite::params![corrupt, old_hash.as_slice()]
        )
        .unwrap(),
        1
    );
    assert!(old_clone.read_record(ENV_ID).is_err());
    assert!(join(old_clone.clone(), &a_recipe).is_err());
    assert_eq!(store.selection().unwrap(), current);
    // Latest B is still readable because it has different exact bytes.
    let latest = store.lease_current(&current).unwrap();
    assert!(latest.read_record(ENV_ID).is_ok());
    latest.close().unwrap();
    old_clone.close().unwrap();
    a.close();
    assert_eq!(pin_count(), 0);
    println!(
        "BRIDGE correctness: 17 exact leased closures; 10 cosmetic reuse and 6 semantic invalidations; A reader across B; stale selection/recipe/binding, failed candidate and hash-corruption refusal; shared final-owner pin release"
    );
}

#[test]
#[ignore = "isolated release process RSS and phase timing probe"]
fn bridge_joined_measurement() {
    let records: usize = std::env::var("BRIDGE_RECORDS")
        .unwrap_or("3".to_owned())
        .parse()
        .unwrap();
    let work = fresh_dir(&format!("measurement-{records}"));
    let store_path = work.join("store");
    fs::create_dir(&store_path).unwrap();
    let store = ProvisionalSourceStore::open(&store_path, PROJECT_ID).unwrap();
    let paths = fixture(&work.join("checkout"), "direction", records);
    let start = Instant::now();
    let stage = stage_declared_tree(&work.join("checkout"), &paths).unwrap();
    let stage_ms = start.elapsed().as_secs_f64() * 1000.;
    let start = Instant::now();
    let candidate = validate_staged_candidate(&stage, &[]).unwrap();
    let recipe = selection_recipe(&candidate);
    let f3_ms = start.elapsed().as_secs_f64() * 1000.;
    let start = Instant::now();
    let selected = store
        .publish_candidate(&store.selection().unwrap(), [1; 16], &candidate)
        .unwrap();
    let publish_ms = start.elapsed().as_secs_f64() * 1000.;
    let start = Instant::now();
    let lease = store.lease_current(&selected).unwrap();
    let first_acquire_ms = start.elapsed().as_secs_f64() * 1000.;
    let start = Instant::now();
    let old = join(lease, &recipe).unwrap();
    let first_join_us = start.elapsed().as_secs_f64() * 1e6;
    let mut acquire = vec![];
    let mut joined = vec![];
    for _ in 0..31 {
        let start = Instant::now();
        let l = store.lease_current(&selected).unwrap();
        acquire.push(start.elapsed().as_secs_f64() * 1e6);
        let start = Instant::now();
        let j = join(l, &recipe).unwrap();
        joined.push(start.elapsed().as_secs_f64() * 1e6);
        j.close();
    }
    let mut shared = vec![];
    for _ in 0..101 {
        let start = Instant::now();
        let j = join(old.lease.clone(), &recipe).unwrap();
        shared.push(start.elapsed().as_secs_f64() * 1e6);
        j.close();
    }
    let mut decode_source = vec![];
    for _ in 0..101 {
        let start = Instant::now();
        black_box(parse_scene(black_box(&old.raw[0])).unwrap());
        black_box(parse_environment(black_box(&old.raw[1])).unwrap());
        black_box(parse_light(black_box(&old.raw[2])).unwrap());
        decode_source.push(start.elapsed().as_secs_f64() * 1e6);
    }
    // B reuses all unmodified source blobs but retains a distinct active source/product.
    edit(
        &work.join("checkout/records/environment.record.json"),
        |v| v["fields"]["sun"]["perpendicular_illuminance_lux"] = json!(234567.),
    );
    let b_stage = stage_declared_tree(&work.join("checkout"), &paths).unwrap();
    let b_candidate = validate_staged_candidate(&b_stage, &[]).unwrap();
    let b_recipe = selection_recipe(&b_candidate);
    let b_selected = store
        .publish_candidate(&selected, [2; 16], &b_candidate)
        .unwrap();
    let new = join(store.lease_current(&b_selected).unwrap(), &b_recipe).unwrap();
    assert_ne!(new.manifest, old.manifest);
    assert_eq!(join(old.lease.clone(), &recipe).unwrap().bytes, old.bytes);
    let mut source_unique = std::collections::BTreeMap::new();
    for s in [&stage, &b_stage] {
        for f in s.files() {
            source_unique.insert(*f.sha256(), f.length());
        }
    }
    let source_closure_unique: u64 = source_unique.values().sum();
    let raw_retained: usize = old.raw.iter().chain(&new.raw).map(Vec::capacity).sum();
    let conn = rusqlite::Connection::open(store_path.join("provisional-source.sqlite")).unwrap();
    let stored_chunk_bytes: i64 = conn
        .query_row("SELECT sum(length(bytes)) FROM chunk", [], |r| r.get(0))
        .unwrap();
    let manifest_bytes: i64 = conn
        .query_row(
            "SELECT sum(length(bytes)) FROM chunk WHERE hash IN (SELECT revision FROM pin)",
            [],
            |r| r.get(0),
        )
        .unwrap();
    let mut disk = 0u64;
    for entry in fs::read_dir(&store_path).unwrap() {
        let e = entry.unwrap();
        if e.file_type().unwrap().is_file() {
            disk += e.metadata().unwrap().len();
        }
    }
    fn summary(mut values: Vec<f64>) -> Value {
        values.sort_by(f64::total_cmp);
        json!({"samples":values.len(),"median":values[values.len()/2],"p95":values[(values.len()*95).div_ceil(100)-1],"max":values[values.len()-1]})
    }
    let result = json!({"records":records,"files":stage.files().len(),"stage_ms":stage_ms,"f3_validate_revision_select_ms":f3_ms,"publish_ms":publish_ms,
        "first_acquire_verify_manifest_index_ms":first_acquire_ms,"first_join_read_decode_cook_hash_bind_us":first_join_us,
        "warm_acquire_us":summary(acquire),"warm_join_us":summary(joined),"shared_lease_join_us":summary(shared),"typed_decode_3_retained_records_us":summary(decode_source),"reads_per_join":3,
        "source_bytes_each":[stage.copied_bytes(),b_stage.copied_bytes()],"source_unique_old_new_bytes":source_closure_unique,
        "retained_leased_records_capacity_bytes":raw_retained,"retained_payload_bytes":320,"retained_product_manifest_binding_layout_bytes":2*(std::mem::size_of::<ProductManifest>()+std::mem::size_of::<BuildBinding>()),
        "source_manifests_old_new_bytes":manifest_bytes,"store_chunk_bytes":stored_chunk_bytes,"store_files_bytes":disk,
        "old_source_revision":hex(&recipe.revision),"new_source_revision":hex(&b_recipe.revision),
        "index_scope":"one acquisition per build; shared lease clones share manifest/index/pin; each join performs 3 binary-search indexed record reads; no manifest iteration"});
    fs::create_dir_all(task_root().join("results")).unwrap();
    fs::write(
        task_root().join(format!("results/measurement-{records}.json")),
        serde_json::to_vec_pretty(&result).unwrap(),
    )
    .unwrap();
    println!("BRIDGE_MEASUREMENT {result}");
    new.close();
    old.close();
    benchmark();
}
