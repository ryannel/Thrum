//! Standalone typed-input experiment; these identity encodings are proof-local.
#![forbid(unsafe_code)]

use sha2::{Digest, Sha256};
use std::hint::black_box;
use std::time::Instant;

const MAGIC: &[u8; 8] = b"THRME1C\0";
const FORMAT: u16 = 1;
const MASK: u32 = 0x7f;
const SIZE: usize = 160;
const COOK_DOMAIN: &[u8] = b"thrum-proof-f4-constant-light-cook-key-v1\0";
const PRODUCT_DOMAIN: &[u8] = b"thrum-proof-f4-constant-light-manifest-v1\0";
const BINDING_DOMAIN: &[u8] = b"thrum-proof-f4-constant-light-build-binding-v1\0";
const ENVIRONMENT: [u8; 16] = [0x10, 0, 0, 0, 0, 0, 0x40, 0, 0x80, 0, 0, 0, 0, 0, 0, 1];
const LIGHT: [u8; 16] = [0x10, 0, 0, 0, 0, 0, 0x40, 0, 0x80, 0, 0, 0, 0, 0, 0, 2];
const PROJECT: [u8; 16] = [0x20, 0, 0, 0, 0, 0, 0x40, 0, 0x80, 0, 0, 0, 0, 0, 0, 1];
const SCENE: [u8; 16] = [0x20, 0, 0, 0, 0, 0, 0x40, 0, 0x80, 0, 0, 0, 0, 0, 0, 2];
const SCENE_HASH: &str = "75c09153b459c576f89ad3328dc6e3bac82379368cd7e3ac9317f058a2ea8aa7";
const ENV_HASH: &str = "8f3d060dcd716a40ebfeddcdae58cc7285d281b6bba24fa9a38ebf2000ab5cfb";
const LIGHT_HASH: &str = "9376fbe1d51794e5cae447c41ae0d02a71cd3f652830c9b650375144ac97b166";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct BlobHash([u8; 32]);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct CookKey([u8; 32]);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ProductRevision([u8; 32]);
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct SourceRevision([u8; 32]);

#[derive(Clone, Copy, Debug)]
struct TypedSource {
    environment: [u8; 16],
    light: [u8; 16],
    // X/Y/Z, R/G/B, lux, radius, ambient R/G/B, background R/G/B.
    values: [f64; 14],
    unsupported: u32,
}

#[derive(Clone, Copy, Debug)]
struct Product {
    environment: [u8; 16],
    light: [u8; 16],
    values: [f64; 14],
}

#[derive(Clone, Debug)]
struct CacheClass<'a> {
    environment_definition: [u8; 32],
    light_definition: [u8; 32],
    cooker: u32,
    normalizer: u32,
    evaluator: u32,
    compiler: &'a str,
    target: &'a str,
    floating_point: &'a str,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct ProductManifest {
    key: CookKey,
    blob: BlobHash,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct BindingContext {
    source_revision: SourceRevision,
    project: [u8; 16],
    entry_scene: [u8; 16],
    environment: [u8; 16],
    light: [u8; 16],
    scene_definition: [u8; 32],
    profile_target_lock: [u8; 32],
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct BuildBinding {
    context: BindingContext,
    product_revision: ProductRevision,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Refusal {
    Source,
    Length,
    Magic,
    Version,
    Flags,
    Mask,
    Uuid,
    IdentityCollision,
    Nonfinite,
    NegativeQuantity,
    NegativeZero,
    Normalization,
    CacheKey,
    ManifestRevision,
    BlobHash,
    StaleBinding,
}

fn uuid_valid(bytes: [u8; 16]) -> bool {
    (1..=8).contains(&(bytes[6] >> 4)) && bytes[8] & 0xc0 == 0x80
}
fn zero(value: f64) -> f64 {
    if value == 0.0 { 0.0 } else { value }
}
fn ordered_length(values: &[f64]) -> f64 {
    (((values[0] * values[0]) + (values[1] * values[1])) + (values[2] * values[2])).sqrt()
}
fn ordered_luminance(values: &[f64]) -> f64 {
    ((0.2126 * values[0]) + (0.7152 * values[1])) + (0.0722 * values[2])
}
fn source_valid(source: &TypedSource) -> bool {
    uuid_valid(source.environment)
        && uuid_valid(source.light)
        && source.environment != source.light
        && source.unsupported == MASK
        && source.values.iter().all(|value| value.is_finite())
        && source.values[3..].iter().all(|value| *value >= 0.0)
        && (source.values[0]
            .hypot(source.values[1])
            .hypot(source.values[2])
            - 1.0)
            .abs()
            <= 1e-9
        && (ordered_luminance(&source.values[3..6]) - 1.0).abs() <= 1e-9
}
fn cooked_valid(product: &Product) -> Result<(), Refusal> {
    if !uuid_valid(product.environment) || !uuid_valid(product.light) {
        return Err(Refusal::Uuid);
    }
    if product.environment == product.light {
        return Err(Refusal::IdentityCollision);
    }
    if product.values.iter().any(|value| !value.is_finite()) {
        return Err(Refusal::Nonfinite);
    }
    if product.values[3..].iter().any(|value| *value < 0.0) {
        return Err(Refusal::NegativeQuantity);
    }
    if product
        .values
        .iter()
        .any(|value| value.to_bits() == (-0.0_f64).to_bits())
    {
        return Err(Refusal::NegativeZero);
    }
    if (ordered_length(&product.values[..3]) - 1.0).abs() > 1e-12
        || (ordered_luminance(&product.values[3..6]) - 1.0).abs() > 1e-12
    {
        return Err(Refusal::Normalization);
    }
    Ok(())
}
fn cook(source: &TypedSource) -> Result<Product, Refusal> {
    if !source_valid(source) {
        return Err(Refusal::Source);
    }
    let mut values = source.values;
    let length = ordered_length(&values[..3]);
    let luminance = ordered_luminance(&values[3..6]);
    for value in &mut values[..3] {
        *value /= length;
    }
    for value in &mut values[3..6] {
        *value /= luminance;
    }
    for value in &mut values {
        *value = zero(*value);
    }
    let product = Product {
        environment: source.environment,
        light: source.light,
        values,
    };
    cooked_valid(&product)?;
    Ok(product)
}
fn encode(product: &Product) -> Result<[u8; SIZE], Refusal> {
    cooked_valid(product)?;
    let mut bytes = [0_u8; SIZE];
    bytes[..8].copy_from_slice(MAGIC);
    bytes[8..10].copy_from_slice(&FORMAT.to_le_bytes());
    bytes[12..16].copy_from_slice(&MASK.to_le_bytes());
    bytes[16..32].copy_from_slice(&product.environment);
    bytes[32..48].copy_from_slice(&product.light);
    for (slot, value) in bytes[48..]
        .as_chunks_mut::<8>()
        .0
        .iter_mut()
        .zip(product.values)
    {
        slot.copy_from_slice(&value.to_le_bytes());
    }
    Ok(bytes)
}
fn decode(bytes: &[u8]) -> Result<Product, Refusal> {
    if bytes.len() != SIZE {
        return Err(Refusal::Length);
    }
    if &bytes[..8] != MAGIC {
        return Err(Refusal::Magic);
    }
    if u16::from_le_bytes(bytes[8..10].try_into().unwrap()) != FORMAT {
        return Err(Refusal::Version);
    }
    if u16::from_le_bytes(bytes[10..12].try_into().unwrap()) != 0 {
        return Err(Refusal::Flags);
    }
    if u32::from_le_bytes(bytes[12..16].try_into().unwrap()) != MASK {
        return Err(Refusal::Mask);
    }
    let mut values = [0.0; 14];
    for (value, slot) in values.iter_mut().zip(bytes[48..].as_chunks::<8>().0.iter()) {
        *value = f64::from_le_bytes(*slot);
    }
    let product = Product {
        environment: bytes[16..32].try_into().unwrap(),
        light: bytes[32..48].try_into().unwrap(),
        values,
    };
    cooked_valid(&product)?;
    Ok(product)
}
fn hash(bytes: &[u8]) -> [u8; 32] {
    Sha256::digest(bytes).into()
}
fn blob_hash(bytes: &[u8; SIZE]) -> BlobHash {
    BlobHash(hash(bytes))
}
fn recipe_text(hash: &mut Sha256, value: &str) {
    hash.update(
        u32::try_from(value.len())
            .expect("bounded proof cache-class string")
            .to_le_bytes(),
    );
    hash.update(value.as_bytes());
}
fn cook_key(source: &TypedSource, class: &CacheClass<'_>) -> Result<CookKey, Refusal> {
    if !source_valid(source) {
        return Err(Refusal::Source);
    }
    let mut digest = Sha256::new();
    digest.update(COOK_DOMAIN);
    digest.update(FORMAT.to_le_bytes());
    digest.update(source.environment);
    digest.update(source.light);
    for value in source.values {
        digest.update(zero(value).to_le_bytes());
    }
    digest.update(MASK.to_le_bytes());
    for value in [
        "constant-light-v1",
        "geometric-straight",
        "incoming-environment-sun",
    ] {
        recipe_text(&mut digest, value);
    }
    digest.update(class.environment_definition);
    digest.update(class.light_definition);
    for value in [class.cooker, class.normalizer, class.evaluator] {
        digest.update(value.to_le_bytes());
    }
    for value in [class.compiler, class.target, class.floating_point] {
        recipe_text(&mut digest, value);
    }
    Ok(CookKey(digest.finalize().into()))
}
impl ProductManifest {
    fn revision(self) -> ProductRevision {
        let mut digest = Sha256::new();
        digest.update(PRODUCT_DOMAIN);
        digest.update(FORMAT.to_le_bytes());
        digest.update((SIZE as u32).to_le_bytes());
        digest.update(self.key.0);
        digest.update(self.blob.0);
        ProductRevision(digest.finalize().into())
    }
}
impl BuildBinding {
    fn digest(self) -> [u8; 32] {
        let mut digest = Sha256::new();
        digest.update(BINDING_DOMAIN);
        digest.update(self.context.source_revision.0);
        for id in [
            self.context.project,
            self.context.entry_scene,
            self.context.environment,
            self.context.light,
        ] {
            digest.update(id);
        }
        digest.update(self.context.scene_definition);
        digest.update(self.context.profile_target_lock);
        digest.update(self.product_revision.0);
        digest.finalize().into()
    }
    fn check_current(
        self,
        context: BindingContext,
        product: ProductRevision,
    ) -> Result<(), Refusal> {
        if self.context != context || self.product_revision != product {
            return Err(Refusal::StaleBinding);
        }
        Ok(())
    }
}
fn cached_product(
    expected_key: CookKey,
    expected_revision: ProductRevision,
    manifest: ProductManifest,
    bytes: &[u8; SIZE],
) -> Result<Product, Refusal> {
    if manifest.key != expected_key {
        return Err(Refusal::CacheKey);
    }
    if manifest.revision() != expected_revision {
        return Err(Refusal::ManifestRevision);
    }
    if blob_hash(bytes) != manifest.blob {
        return Err(Refusal::BlobHash);
    }
    decode(bytes)
}

fn from_hex<const N: usize>(value: &str) -> [u8; N] {
    assert_eq!(value.len(), N * 2);
    let mut bytes = [0_u8; N];
    for (index, byte) in bytes.iter_mut().enumerate() {
        *byte = u8::from_str_radix(&value[index * 2..index * 2 + 2], 16).unwrap();
    }
    bytes
}
fn hex(bytes: &[u8]) -> String {
    use std::fmt::Write;
    let mut result = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        write!(&mut result, "{byte:02x}").unwrap();
    }
    result
}
fn source(noncardinal: bool) -> TypedSource {
    let mut values = [
        0.0, 1.0, 0.0, 1.0, 1.0, 1.0, 100000.0, 0.00465, 1000.0, 1000.0, 1000.0, 0.0, 0.0, 0.0,
    ];
    if noncardinal {
        values[..6].copy_from_slice(&[-0.6, 0.8000000001, -0.0, 0.5, 1.0, 2.47229917]);
    }
    TypedSource {
        environment: ENVIRONMENT,
        light: LIGHT,
        values,
        unsupported: MASK,
    }
}
fn golden_source(name: &str) -> TypedSource {
    match name {
        "cardinal" => source(false),
        "noncardinal" => source(true),
        "allnonzero" => {
            let mut input = source(true);
            input.values[..3].copy_from_slice(&[0.36, 0.48, -0.8000000001]);
            input
        }
        _ => panic!("unknown golden fixture {name}"),
    }
}
fn cache_class() -> CacheClass<'static> {
    CacheClass {
        environment_definition: from_hex(ENV_HASH),
        light_definition: from_hex(LIGHT_HASH),
        cooker: 1,
        normalizer: 1,
        evaluator: 1,
        compiler: "rustc 1.99.1 (58cf8f9c3 2026-10-13)",
        target: "aarch64-apple-darwin",
        floating_point: "strict-ieee754-binary64-nearest-even-no-fast-math-no-contraction",
    }
}
fn context(source_revision: SourceRevision) -> BindingContext {
    BindingContext {
        source_revision,
        project: PROJECT,
        entry_scene: SCENE,
        environment: ENVIRONMENT,
        light: LIGHT,
        scene_definition: from_hex(SCENE_HASH),
        profile_target_lock: hash(b"proof-profile-r0-target-lock-v1"),
    }
}
fn oracle_rows() -> Vec<Vec<&'static str>> {
    include_str!("oracle.golden")
        .lines()
        .map(|line| line.split_whitespace().collect())
        .collect()
}
fn golden_check() {
    for row in oracle_rows().iter().filter(|row| row[0] != "cosmetic") {
        let source = golden_source(row[0]);
        let product = cook(&source).unwrap();
        if row[0] == "allnonzero" {
            assert!(source.values[..3].iter().all(|value| *value != 0.0));
            assert!(product.values[2] < 0.0);
        }
        let bytes = encode(&product).unwrap();
        assert_eq!(hex(&bytes), row[1]);
        let blob = blob_hash(&bytes);
        let key = cook_key(&source, &cache_class()).unwrap();
        let manifest = ProductManifest { key, blob };
        assert_eq!(hex(&blob.0), row[2]);
        assert_eq!(hex(&key.0), row[3]);
        assert_eq!(hex(&manifest.revision().0), row[4]);
        let binding = BuildBinding {
            context: context(SourceRevision(from_hex(row[5]))),
            product_revision: manifest.revision(),
        };
        assert_eq!(hex(&binding.digest()), row[6]);
        binding
            .check_current(binding.context, manifest.revision())
            .unwrap();
        cached_product(key, manifest.revision(), manifest, &bytes).unwrap();
        assert_eq!(encode(&decode(&bytes).unwrap()).unwrap(), bytes);
        println!(
            "{}: full 160-byte golden, BlobHash, CookKey, ProductRevision, exact-source BuildBinding match independent Python",
            row[0]
        );
    }
}
fn benchmark() {
    let source = source(true);
    let product = cook(&source).unwrap();
    let bytes = encode(&product).unwrap();
    let iterations = 500_000_u32;
    println!(
        "release local microprobe: compiler={} target={} iterations={iterations}; each sample includes validation; no recipe/binding/IO timing",
        cache_class().compiler,
        cache_class().target
    );
    let start = Instant::now();
    for _ in 0..iterations {
        black_box(cook(black_box(&source)).unwrap());
    }
    println!(
        "cook ns/op={:.3}",
        start.elapsed().as_nanos() as f64 / f64::from(iterations)
    );
    let start = Instant::now();
    for _ in 0..iterations {
        black_box(encode(black_box(&product)).unwrap());
    }
    println!(
        "encode ns/op={:.3}",
        start.elapsed().as_nanos() as f64 / f64::from(iterations)
    );
    let start = Instant::now();
    for _ in 0..iterations {
        black_box(decode(black_box(&bytes)).unwrap());
    }
    println!(
        "decode ns/op={:.3}",
        start.elapsed().as_nanos() as f64 / f64::from(iterations)
    );
    let start = Instant::now();
    for _ in 0..iterations {
        black_box(blob_hash(black_box(&bytes)));
    }
    println!(
        "SHA-256(160 bytes) ns/op={:.3}",
        start.elapsed().as_nanos() as f64 / f64::from(iterations)
    );
    println!(
        "payload=160 bytes; typed Product={} bytes; ProductManifest={} bytes; BuildBinding={} bytes; old/new payload+manifest+binding={} bytes excluding allocator, runtime, cache, and source",
        std::mem::size_of::<Product>(),
        std::mem::size_of::<ProductManifest>(),
        std::mem::size_of::<BuildBinding>(),
        2 * (SIZE + std::mem::size_of::<ProductManifest>() + std::mem::size_of::<BuildBinding>())
    );
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn independent_python_full_golden_bytes_hashes_and_bindings() {
        golden_check();
    }
    #[test]
    fn negative_direction_and_all_signed_zeros_are_valid_and_canonical() {
        let cardinal = source(false);
        let expected = encode(&cook(&cardinal).unwrap()).unwrap();
        let key = cook_key(&cardinal, &cache_class()).unwrap();
        let zero_indices = [0, 2, 11, 12, 13];
        for mask in 0..(1 << zero_indices.len()) {
            let mut signed = cardinal;
            for (bit, index) in zero_indices.iter().enumerate() {
                if mask & (1 << bit) != 0 {
                    signed.values[*index] = -0.0;
                }
            }
            assert_eq!(encode(&cook(&signed).unwrap()).unwrap(), expected);
            assert_eq!(cook_key(&signed, &cache_class()).unwrap(), key);
        }
        let mut dark = cardinal;
        dark.values[3..6].copy_from_slice(&[0.0, 1.0 / 0.7152, 0.0]);
        dark.values[6..].fill(0.0);
        let expected_dark = encode(&cook(&dark).unwrap()).unwrap();
        let dark_key = cook_key(&dark, &cache_class()).unwrap();
        let all_zero_indices: Vec<_> = dark
            .values
            .iter()
            .enumerate()
            .filter_map(|(index, value)| (*value == 0.0).then_some(index))
            .collect();
        assert_eq!(all_zero_indices.len(), 12);
        for mask in 0..(1 << all_zero_indices.len()) {
            let mut signed = dark;
            for (bit, index) in all_zero_indices.iter().enumerate() {
                if mask & (1 << bit) != 0 {
                    signed.values[*index] = -0.0;
                }
            }
            assert_eq!(encode(&cook(&signed).unwrap()).unwrap(), expected_dark);
            assert_eq!(cook_key(&signed, &cache_class()).unwrap(), dark_key);
        }
        let negative = cook(&source(true)).unwrap();
        assert!(negative.values[0] < 0.0);
        assert_eq!(negative.values[2].to_bits(), 0);
        assert!(decode(&encode(&negative).unwrap()).is_ok());
    }
    #[test]
    fn refuses_unknown_layout_invalid_uuid_bad_quantities_residuals_and_negative_zero() {
        let base = encode(&cook(&source(false)).unwrap()).unwrap();
        assert_eq!(decode(&base[..159]).unwrap_err(), Refusal::Length);
        let mut too_long = base.to_vec();
        too_long.push(0);
        assert_eq!(decode(&too_long).unwrap_err(), Refusal::Length);
        for (offset, value, reason) in [
            (0, b'X', Refusal::Magic),
            (8, 2, Refusal::Version),
            (10, 1, Refusal::Flags),
            (12, 0x7e, Refusal::Mask),
            (15, 0x80, Refusal::Mask),
            (22, 0, Refusal::Uuid),
            (40, 0, Refusal::Uuid),
        ] {
            let mut bytes = base;
            bytes[offset] = value;
            assert_eq!(decode(&bytes).unwrap_err(), reason);
        }
        for (index, value, reason) in [
            (0, f64::NAN, Refusal::Nonfinite),
            (0, f64::INFINITY, Refusal::Nonfinite),
            (1, 1.01, Refusal::Normalization),
            (3, -1.0, Refusal::NegativeQuantity),
            (3, 1.01, Refusal::Normalization),
            (6, -1.0, Refusal::NegativeQuantity),
            (7, -1.0, Refusal::NegativeQuantity),
            (8, -1.0, Refusal::NegativeQuantity),
            (11, -1.0, Refusal::NegativeQuantity),
        ] {
            let mut bytes = base;
            bytes[48 + index * 8..56 + index * 8].copy_from_slice(&value.to_le_bytes());
            assert_eq!(decode(&bytes).unwrap_err(), reason);
        }
        for index in 0..14 {
            let mut bytes = base;
            bytes[48 + index * 8..56 + index * 8].copy_from_slice(&(-0.0_f64).to_le_bytes());
            assert_eq!(decode(&bytes).unwrap_err(), Refusal::NegativeZero);
        }
    }
    #[test]
    fn equal_environment_and_light_ids_refuse_at_every_boundary() {
        let mut authored = source(false);
        authored.light = authored.environment;
        assert_eq!(cook(&authored).unwrap_err(), Refusal::Source);
        assert_eq!(
            cook_key(&authored, &cache_class()).unwrap_err(),
            Refusal::Source
        );
        let mut product = cook(&source(false)).unwrap();
        product.light = product.environment;
        assert_eq!(encode(&product).unwrap_err(), Refusal::IdentityCollision);
        let mut forged = encode(&cook(&source(false)).unwrap()).unwrap();
        forged[32..48].copy_from_slice(&ENVIRONMENT);
        assert_eq!(decode(&forged).unwrap_err(), Refusal::IdentityCollision);
    }
    #[test]
    fn cooked_residual_boundary_and_full_f64_quantities_are_explicit() {
        let base = encode(&cook(&source(false)).unwrap()).unwrap();
        for (delta, accepted) in [(0.9e-12, true), (1.1e-12, false)] {
            let mut bytes = base;
            bytes[56..64].copy_from_slice(&(1.0_f64 + delta).to_le_bytes());
            assert_eq!(decode(&bytes).is_ok(), accepted);
            let mut bytes = base;
            for index in 3..6 {
                bytes[48 + index * 8..56 + index * 8]
                    .copy_from_slice(&(1.0_f64 + delta).to_le_bytes());
            }
            assert_eq!(decode(&bytes).is_ok(), accepted);
        }
        let mut large = source(false);
        for index in [6, 7, 8, 11] {
            large.values[index] = f64::MAX;
        }
        let bytes = encode(&cook(&large).unwrap()).unwrap();
        let recovered = decode(&bytes).unwrap();
        for index in [6, 7, 8, 11] {
            assert_eq!(recovered.values[index].to_bits(), f64::MAX.to_bits());
        }
    }
    #[test]
    fn invalid_typed_sources_refuse_without_clamping_or_weather_fabrication() {
        for (index, value) in [
            (0, 2.0),
            (1, 0.0),
            (3, -1.0),
            (3, 1.1),
            (6, -1.0),
            (7, f64::INFINITY),
            (8, -1.0),
            (11, -1.0),
        ] {
            let mut bad = source(false);
            bad.values[index] = value;
            assert_eq!(cook(&bad).unwrap_err(), Refusal::Source);
            assert_eq!(cook_key(&bad, &cache_class()).unwrap_err(), Refusal::Source);
        }
        let mut bad = source(false);
        bad.unsupported = 0;
        assert_eq!(cook(&bad).unwrap_err(), Refusal::Source);
        let mut bad = source(false);
        bad.environment[6] = 0;
        assert_eq!(cook(&bad).unwrap_err(), Refusal::Source);
    }
    #[test]
    fn cache_reuse_matrix_cosmetic_and_binding_changes_do_not_change_product_identity() {
        let source = source(false);
        let bytes = encode(&cook(&source).unwrap()).unwrap();
        let key = cook_key(&source, &cache_class()).unwrap();
        let manifest = ProductManifest {
            key,
            blob: blob_hash(&bytes),
        };
        let rows = oracle_rows();
        let base_context = context(SourceRevision(from_hex(rows[0][5])));
        let base_binding = BuildBinding {
            context: base_context,
            product_revision: manifest.revision(),
        };
        for row in rows.iter().filter(|row| row[0] == "cosmetic") {
            let mut changed_context = context(SourceRevision(from_hex(row[2])));
            changed_context.entry_scene = from_hex(row[3]);
            assert_ne!(
                changed_context.source_revision, base_context.source_revision,
                "{}",
                row[1]
            );
            let reused = cached_product(key, manifest.revision(), manifest, &bytes).unwrap();
            assert_eq!(encode(&reused).unwrap(), bytes);
            let changed_binding = BuildBinding {
                context: changed_context,
                product_revision: manifest.revision(),
            };
            assert_ne!(
                changed_binding.digest(),
                base_binding.digest(),
                "{}",
                row[1]
            );
            assert_eq!(hex(&changed_binding.digest()), row[4], "{}", row[1]);
            assert_eq!(
                changed_binding.context.source_revision.0,
                from_hex::<32>(row[2])
            );
        }
        let mut rebind = base_binding;
        rebind.context.entry_scene[15] += 1;
        assert_ne!(rebind.digest(), base_binding.digest());
        let mut redefine_scene = base_binding;
        redefine_scene.context.scene_definition[0] ^= 1;
        assert_ne!(redefine_scene.digest(), base_binding.digest());
        let mut relock = base_binding;
        relock.context.profile_target_lock[0] ^= 1;
        assert_ne!(relock.digest(), base_binding.digest());
    }
    #[test]
    fn cache_invalidation_matrix_tracks_known_values_identity_definitions_and_cooker_class() {
        let base = source(false);
        let class = cache_class();
        let key = cook_key(&base, &class).unwrap();
        // Direction, colour, illuminance, radius, ambient, background, source ID, light ID.
        for row in 0..8 {
            let mut changed = base;
            match row {
                0 => changed.values[..3].copy_from_slice(&[-1.0, 0.0, 0.0]),
                1 => changed.values[3..6].copy_from_slice(&source(true).values[3..6]),
                2 => changed.values[6] += 1.0,
                3 => changed.values[7] += 0.001,
                4 => changed.values[8] += 1.0,
                5 => changed.values[11] += 1.0,
                6 => changed.environment[15] += 2,
                _ => changed.light[15] += 2,
            }
            assert_ne!(
                cook_key(&changed, &class).unwrap(),
                key,
                "semantic row {row}"
            );
        }
        for row in 0..8 {
            let mut changed = class.clone();
            match row {
                0 => changed.environment_definition[0] ^= 1,
                1 => changed.light_definition[0] ^= 1,
                2 => changed.cooker += 1,
                3 => changed.normalizer += 1,
                4 => changed.evaluator += 1,
                5 => changed.compiler = "another compiler",
                6 => changed.target = "another target",
                _ => changed.floating_point = "another floating-point mode",
            }
            assert_ne!(cook_key(&base, &changed).unwrap(), key, "class row {row}");
        }
        // Source normalization accepts close authored vectors but never merges
        // their pre-normalization semantic inputs in the cook recipe.
        let mut close = base;
        close.values[1] += 1e-10;
        assert_eq!(
            encode(&cook(&close).unwrap()).unwrap(),
            encode(&cook(&base).unwrap()).unwrap()
        );
        assert_ne!(cook_key(&close, &class).unwrap(), key);
    }
    #[test]
    fn corrupted_cache_and_stale_results_refuse_before_binding_publication() {
        let source = source(false);
        let bytes = encode(&cook(&source).unwrap()).unwrap();
        let key = cook_key(&source, &cache_class()).unwrap();
        let manifest = ProductManifest {
            key,
            blob: blob_hash(&bytes),
        };
        let revision = manifest.revision();
        let mut changed = bytes;
        changed[96..104].copy_from_slice(&99999.0_f64.to_le_bytes());
        assert!(decode(&changed).is_ok()); // A valid but different product still corrupts this cache entry.
        assert_eq!(
            cached_product(key, revision, manifest, &changed).unwrap_err(),
            Refusal::BlobHash
        );
        let changed_manifest = ProductManifest {
            key,
            blob: blob_hash(&changed),
        };
        assert_eq!(
            cached_product(key, revision, changed_manifest, &changed).unwrap_err(),
            Refusal::ManifestRevision
        );
        let mut wrong_key = key;
        wrong_key.0[0] ^= 1;
        assert_eq!(
            cached_product(wrong_key, revision, manifest, &bytes).unwrap_err(),
            Refusal::CacheKey
        );
        let original = context(SourceRevision([1; 32]));
        let binding = BuildBinding {
            context: original,
            product_revision: revision,
        };
        assert!(binding.check_current(original, revision).is_ok());
        let mut updated = original;
        updated.source_revision = SourceRevision([2; 32]);
        assert_eq!(
            binding.check_current(updated, revision),
            Err(Refusal::StaleBinding)
        );
        let mut updated = original;
        updated.entry_scene[15] += 1;
        assert_eq!(
            binding.check_current(updated, revision),
            Err(Refusal::StaleBinding)
        );
        assert_eq!(
            binding.check_current(original, ProductRevision([9; 32])),
            Err(Refusal::StaleBinding)
        );
    }
}

include!("bridge_join.rs");
