use std::{fs, path::Path, time::Instant, hint::black_box};
use serde_json::{json,Value};
use thrum_source::{NativeSourceStore,SourceSpacePlan,SourcePath,registry_stage::validate_staged_candidate,stage_declared_tree_with_plan};
use thrum_cook::cook_pinned_constant_light;
const PROJECT:&str="10000000-0000-4000-8000-000000000001";
const SCENE:&str="10000000-0000-4000-8000-000000000002";
const ENV:&str="10000000-0000-4000-8000-000000000003";
const LIGHT:&str="10000000-0000-4000-8000-000000000004";
const HISTORY:&str="10000000-0000-4000-8000-000000000005";
fn plan()->SourceSpacePlan{SourceSpacePlan{main_target_bytes:1024*1024*1024,wal_stop_bytes:64*1024*1024,temporary_target_bytes:64*1024*1024,free_headroom_bytes:0}}
fn write(root:&Path,path:&str,value:Value){fs::write(root.join(path),serde_json::to_vec(&value).unwrap()).unwrap();}
fn env(lux:u64)->Value {json!({"id":ENV,"type":"thrum.environment.authored","schema":1,"fields":{"profile":"constant-light-v1","sun":{"light_ref":LIGHT,"toward_source_unit":[-0.6,0.8000000001,-0.0],"perpendicular_illuminance_lux":lux,"unit_luminance_linear_rec709":[0.5,1.0,2.47229917],"angular_radius_rad":0.00465,"direction_model":"geometric-straight","applied_attenuation":[]},"ambient_irradiance_lux":[1,2,3],"background_radiance_cd_m2":[4,5,6],"unsupported":["wind","cloud_tau","precipitation","air","thermal","moon","air_quality"],"x.thrum.environment.note":{"opaque":true}}})}
fn init(root:&Path,records:usize){
    fs::create_dir_all(root).unwrap();
    for d in ["records","scenes","schemas",".engine"] {fs::create_dir_all(root.join(d)).unwrap();}
    let mut rp=vec!["records/environment.record.json".to_owned(),"records/light.record.json".to_owned(),"scenes/main.scene.json".to_owned()];
    for i in 0..records-3 {let p=format!("records/a{i:04}.record.json");write(root,&p,json!({"id":format!("7a5ef644-7225-4770-9f4d-{i:012x}"),"type":"thrum.light.identity","schema":1,"fields":{"driver_binding":"incoming-environment-sun","label":"Unselected"}}));rp.push(p);}
    rp.sort();
    write(root,"project.json",json!({"id":PROJECT,"type":"core.project","schema":2,"fields":{"project.format":1,"project.records":rp,"project.schemas":[],"project.registryHistory":"schemas/history.registry.json","project.entryScenes":[SCENE]}}));
    write(root,"scenes/main.scene.json",json!({"id":SCENE,"type":"core.scene","schema":2,"fields":{"scene.label":"A","environment.source":ENV}}));
    write(root,"records/environment.record.json",env(100000));
    write(root,"records/light.record.json",json!({"id":LIGHT,"type":"thrum.light.identity","schema":1,"fields":{"driver_binding":"incoming-environment-sun","label":"Sun"}}));
    write(root,"schemas/history.registry.json",json!({"id":HISTORY,"type":"core.registry-history","schema":1,"fields":{"registry.fields":[],"registry.versions":[]}}));
    fs::write(root.join("note.txt"),"A").unwrap();
    let mut paths:Vec<_>=rp.iter().map(|p|SourcePath::parse(p).unwrap()).collect();
    paths.extend(["project.json","schemas/history.registry.json","note.txt"].map(|p|SourcePath::parse(p).unwrap()));
    let store=NativeSourceStore::open(&root.join(".engine/source.sqlite"),plan()).unwrap();
    for key in 1..=2 {if key==2 {write(root,"records/environment.record.json",env(200000));fs::write(root.join("note.txt"),"B").unwrap();}
        let stage=stage_declared_tree_with_plan(root,&paths,plan()).unwrap();
        let c=validate_staged_candidate(&stage,&[]).unwrap();let accepted=store.admit(key-1,1,key,[key as u8;32],&c).unwrap();
        println!("{}",json!({"init":records,"key":key,"root":format!("{:?}",accepted)}));}
}
#[derive(Clone,Copy)] struct Usage {user:f64,sys:f64,rss:i64}
fn usage()->Usage {unsafe {let mut r:libc::rusage=std::mem::zeroed();assert_eq!(libc::getrusage(libc::RUSAGE_SELF,&mut r),0);Usage{user:r.ru_utime.tv_sec as f64+r.ru_utime.tv_usec as f64/1e6,sys:r.ru_stime.tv_sec as f64+r.ru_stime.tv_usec as f64/1e6,rss:r.ru_maxrss}}}
fn measure<T>(label:&str,n:usize,f:impl FnOnce()->T)->T{let before=usage();let t=Instant::now();let out=f();let wall=t.elapsed().as_secs_f64();let after=usage();println!("{}",json!({"phase":label,"n":n,"wall_s":wall,"user_s":after.user-before.user,"sys_s":after.sys-before.sys,"peak_rss_bytes":after.rss}));out}
fn run(root:&Path,iters:usize){
    let store=measure("store_open",1,||NativeSourceStore::open(&root.join(".engine/source.sqlite"),plan()).unwrap());
    let a=store.outcome(1,1,[1;32]).unwrap().unwrap();let b=store.outcome(1,2,[2;32]).unwrap().unwrap();
    let mut ap=measure("pin_a_first",1,||store.pin_accepted(a).unwrap());
    let ac=measure("cook_a_first",1,||cook_pinned_constant_light(&mut ap).unwrap());
    assert_eq!(ac.input().perpendicular_illuminance_lux,100000.0);
    let mut bp=measure("pin_b_overlap_first",1,||store.pin_accepted(b).unwrap());
    let bc=measure("cook_b_overlap_first",1,||cook_pinned_constant_light(&mut bp).unwrap());
    assert_eq!(bc.input().perpendicular_illuminance_lux,200000.0);
    let scans:Vec<_>=[SCENE,ENV,LIGHT].map(|id|ap.manifest().files().iter().position(|f|f.record_identity().map(|(fid,_)|fid)==Some(id)).unwrap()+1).into();
    let mut manifest_bytes=Vec::new();ap.manifest().write_jcs(&mut manifest_bytes).unwrap();
    println!("{}",json!({"fixture":root.file_name().unwrap().to_string_lossy(),"manifest_entries":ap.manifest().files().len(),"manifest_bytes":manifest_bytes.len(),"selected_copy_bytes_a":ac.records().iter().map(|r|r.content_identity().0).sum::<u64>(),"selected_record_bytes":ac.records().iter().map(|r|r.content_identity().0).collect::<Vec<_>>(),"scan_visits":scans,"scan_visits_total":scans.iter().sum::<usize>(),"root_a":format!("{:?}",a),"root_b":format!("{:?}",b)}));
    measure("cook_a_overlap_repeat",iters,||for _ in 0..iters {black_box(cook_pinned_constant_light(&mut ap).unwrap());});
    measure("cook_b_overlap_repeat",iters,||for _ in 0..iters {black_box(cook_pinned_constant_light(&mut bp).unwrap());});
    bp.close().unwrap();
    measure("pin_b_overlap_repeat",iters,|| {let mut totals=(0.0,0.0,0.0); for _ in 0..iters {let u=usage();let t=Instant::now();let p=store.pin_accepted(b).unwrap();let d=t.elapsed().as_secs_f64();let v=usage();totals.0+=d;totals.1+=v.user-u.user;totals.2+=v.sys-u.sys;p.close().unwrap();}println!("{}",json!({"phase":"pin_b_calls_excluding_close","n":iters,"wall_s":totals.0,"user_s":totals.1,"sys_s":totals.2,"peak_rss_bytes":usage().rss}));});
    measure("full_b_overlap_pin_cook_close",iters,|| for _ in 0..iters {let mut p=store.pin_accepted(b).unwrap();black_box(cook_pinned_constant_light(&mut p).unwrap());p.close().unwrap();});
    assert_eq!(cook_pinned_constant_light(&mut ap).unwrap().input().perpendicular_illuminance_lux,100000.0);
    ap.close().unwrap();
}
fn main(){let args:Vec<_>=std::env::args().collect();let root=Path::new(&args[2]);if args[1]=="init"{init(root,args[3].parse().unwrap());}else{run(root,args[3].parse().unwrap());}}
