from pathlib import Path
import json, statistics
root=Path(__file__).resolve().parent
rows=[json.loads(s) for s in (root/'raw.jsonl').read_text().splitlines()]
for fixture in ['small','large']:
 print('\n'+fixture)
 phases=dict.fromkeys(r['phase'] for r in rows if r['fixture_name']==fixture and 'n' in r)
 for phase in phases:
  rr=[r for r in rows if r['fixture_name']==fixture and r.get('phase')==phase]
  wall=[r['wall_s']*1e6/r['n'] for r in rr];cpu=[(r['user_s']+r['sys_s'])*1e6/r['n'] for r in rr]
  print(f'{phase}: elapsed median/range {statistics.median(wall):.1f} [{min(wall):.1f}, {max(wall):.1f}] us; CPU {statistics.median(cpu):.1f} [{min(cpu):.1f}, {max(cpu):.1f}] us; RSS {[round(r["peak_rss_bytes"]/1048576,3) for r in rr]} MiB')
