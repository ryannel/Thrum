from pathlib import Path
import json, subprocess, time, resource
root=Path(__file__).resolve().parent
binary=root/'target/release/e1-pinned-cook-perf'
with (root/'raw.jsonl').open('w') as out:
    for sample in range(1,6):
        for fixture,iters in [('small',1000),('large',100)]:
            before=resource.getrusage(resource.RUSAGE_CHILDREN)
            start=time.perf_counter()
            p=subprocess.run([str(binary),'run',str(root/fixture),str(iters)],capture_output=True,text=True,check=True)
            wall=time.perf_counter()-start
            after=resource.getrusage(resource.RUSAGE_CHILDREN)
            for line in p.stdout.splitlines():
                row=json.loads(line); row.update(sample=sample,fixture_name=fixture)
                out.write(json.dumps(row)+'\n')
            out.write(json.dumps(dict(phase='process_total',sample=sample,fixture_name=fixture,wall_s=wall,user_s=after.ru_utime-before.ru_utime,sys_s=after.ru_stime-before.ru_stime))+'\n')
            out.flush()
            print(f'{sample} {fixture} {wall:.3f}s',flush=True)
