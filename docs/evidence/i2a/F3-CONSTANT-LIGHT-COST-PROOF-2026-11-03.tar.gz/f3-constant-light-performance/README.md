# F3 constant-light cost experiment

Owner: F3 performance review commission. Purpose: matched 4,096-record provisional candidate CPU/RSS measurements; selected result may be promoted to docs/evidence/i2a. Expected peak disk <1 GiB including isolated release build. Inputs: snapshot of current thrum-source and Cargo.lock. Retain compact harness, results and source identity; reconstructible target/ and per-run fixture trees expire at experiment closeout. No production edits or device/edit-to-ready claims.
