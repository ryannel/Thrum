#!/usr/bin/env python3
"""Fresh processes, serial rotating mode order, macOS wait4 RSS in bytes."""
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
binary = root / "target/release/f3-constant-light-performance"
modes = ["baseline", "selected", "unselected", "selected-opaque"]
results = []
for iteration in range(7):
    for mode in modes[iteration % 4:] + modes[:iteration % 4]:
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            start = time.perf_counter()
            child = subprocess.Popen([str(binary), mode], stdout=stdout, stderr=stderr)
            _, status, usage = os.wait4(child.pid, 0)
            child.returncode = os.waitstatus_to_exitcode(status)
            wall_ms = (time.perf_counter() - start) * 1000
            stdout.seek(0)
            stderr.seek(0)
            if child.returncode:
                raise RuntimeError(stderr.read().decode())
            sample = json.loads(stdout.read())
            sample.update(iteration=iteration, wall_ms=wall_ms,
                process_cpu_ms=(usage.ru_utime+usage.ru_stime)*1000,
                process_rss_bytes=usage.ru_maxrss)
            results.append(sample)
            print(json.dumps(sample), flush=True)
summary = {}
for mode in modes:
    samples = [r for r in results if r["mode"] == mode]
    assert len({s["revision"] for s in samples}) == 1
    summary[mode] = {
        k: dict(min=min(values := [s[k] for s in samples]),
            median=statistics.median(values), max=max(values))
        for k in ["candidate_ms", "validate_ms", "stage_ms", "wall_ms", "process_cpu_ms", "process_rss_bytes"]}
    summary[mode]["identity"] = {k: samples[0][k] for k in ["revision","records","files","copied_bytes","max_file_bytes","max_environment_bytes","pairs","required_edges"]}
identity = dict(platform=platform.platform(),
    compiler=subprocess.check_output(["rustup","run","1.99.1","rustc","-Vv"],text=True),
    git_head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),
    hashes={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [root/"src/main.rs",root/"run.py",root/"Cargo.toml",root/"Cargo.lock",binary]},
    source_hashes={str(p.relative_to(root/"source")):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((root/"source").rglob("*")) if p.is_file()})
(root/"results.json").write_text(json.dumps(dict(identity=identity,summary=summary,samples=results),indent=2)+"\n")
print(json.dumps(summary,indent=2))
