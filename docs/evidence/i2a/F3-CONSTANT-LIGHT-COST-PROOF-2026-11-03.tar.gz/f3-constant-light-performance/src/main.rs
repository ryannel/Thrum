use serde_json::{Value, json};
use std::{fs, path::PathBuf, time::Instant};
use thrum_source::registry_stage::validate_staged_candidate;
use thrum_source::schema_json::parse_schema_descriptor;
use thrum_source::{SourcePath, stage_declared_tree};

const PROJECT: &str = "2a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SCENE: &str = "3a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const GAME: &str = "4a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const SCHEMA: &str = "5a5ef644-7225-4770-9f4d-e1d9c0a7d515";
const HISTORY: &str = "6a5ef644-7225-4770-9f4d-e1d9c0a7d515";
fn hex(bytes: &[u8]) -> String {
    bytes.iter().map(|x| format!("{x:02x}")).collect()
}
fn id(i: usize) -> String {
    format!("10000000-0000-4000-8000-{i:012x}")
}
fn environment(i: usize, opaque: bool) -> Value {
    let mut v = json!({"id":id(i*2+1),"type":"thrum.environment.authored","schema":1,
        "fields":{"label":"fixture light source","profile":"constant-light-v1",
        "sun":{"light_ref":id(i*2+2),"toward_source_unit":[0,1,0],
            "perpendicular_illuminance_lux":100000,"unit_luminance_linear_rec709":[1,1,1],
            "angular_radius_rad":0.00465,"direction_model":"geometric-straight","applied_attenuation":[]},
        "ambient_irradiance_lux":[1000,1000,1000],"background_radiance_cd_m2":[0,0,0],
        "unsupported":["wind","cloud_tau","precipitation","air","thermal","moon","air_quality"]}});
    if opaque {
        for k in 0..16 {
            v["fields"][format!("x.thrum.environment.data{k:02}")] =
                json!(vec!["x".repeat(4092); 4]);
        }
    }
    v
}
fn main() {
    let mode = std::env::args().nth(1).unwrap();
    assert!(["baseline", "selected", "unselected", "selected-opaque"].contains(&mode.as_str()));
    let selected = mode.starts_with("selected");
    let pairs = if mode == "unselected" {
        2047
    } else if selected {
        1
    } else {
        0
    };
    let root =
        PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(format!("fixture-{}", std::process::id()));
    fs::create_dir(&root).unwrap();
    let mut paths: Vec<String> = vec![];
    let mut max_file = 0;
    let mut write = |path: &str, value: Value| -> Vec<u8> {
        let bytes = serde_json::to_vec(&value).unwrap();
        max_file = max_file.max(bytes.len());
        let full = root.join(path);
        fs::create_dir_all(full.parent().unwrap()).unwrap();
        fs::write(full, &bytes).unwrap();
        paths.push(path.to_owned());
        bytes
    };
    let schema = write(
        "schemas/marker.schema.json",
        json!({"id":SCHEMA,"type":"core.schema","schema":1,
        "fields":{"schema.targetType":"game.marker","schema.targetVersion":1,
            "schema.fields":[{"id":"marker.caption","kind":"text","presence":"optional","maxUtf8Bytes":1024},
                {"id":"marker.scene","kind":"record-ref","presence":"required","targetType":"core.scene","resolution":"required"}],
            "schema.optionalExtensionPrefix":"x.game.marker."}}),
    );
    let descriptor = parse_schema_descriptor(&schema).unwrap();
    write(
        "schemas/history.registry.json",
        json!({"id":HISTORY,"type":"core.registry-history","schema":1,
        "fields":{"registry.fields":[
            {"typeId":"game.marker","fieldId":"marker.caption","signature":hex(descriptor.fields()[0].signature()),"retired":false},
            {"typeId":"game.marker","fieldId":"marker.scene","signature":hex(descriptor.fields()[1].signature()),"retired":false}],
            "registry.versions":[{"typeId":"game.marker","targetVersion":1,"definitionHash":hex(descriptor.definition_hash())}]}}),
    );
    let mut records = vec![
        "records/marker.record.json".to_owned(),
        "scenes/main.scene.json".to_owned(),
    ];
    write(
        "records/marker.record.json",
        json!({"id":GAME,"type":"game.marker","schema":1,
        "fields":{"marker.caption":"first marker","marker.scene":SCENE,"x.game.marker.notes":{"nested":[true,null,{"n":3}]}}}),
    );
    let fields = if selected {
        json!({"environment.source":id(1)})
    } else {
        json!({})
    };
    write(
        "scenes/main.scene.json",
        json!({"id":SCENE,"type":"core.scene","schema":if selected {2} else {1},"fields":fields}),
    );
    for i in 1..(4095 - pairs * 2) {
        let p = format!("scenes/scene-{i:04}.scene.json");
        write(
            &p,
            json!({"id":format!("7a5ef644-7225-4770-9f4d-{i:012x}"),"type":"core.scene","schema":1,"fields":{}}),
        );
        records.push(p);
    }
    let mut max_environment = 0;
    for i in 0..pairs {
        let p = format!("records/environment-{i:04}.record.json");
        let b = write(&p, environment(i, mode == "selected-opaque"));
        max_environment = max_environment.max(b.len());
        records.push(p);
        let p = format!("records/light-{i:04}.record.json");
        write(
            &p,
            json!({"id":id(i*2+2),"type":"thrum.light.identity","schema":1,
            "fields":{"label":"shared Sun","driver_binding":"incoming-environment-sun"}}),
        );
        records.push(p);
    }
    records.sort_unstable();
    assert_eq!(records.len(), 4096);
    write(
        "project.json",
        json!({"id":PROJECT,"type":"core.project","schema":2,"fields":{
        "project.format":1,"project.records":records,"project.schemas":["schemas/marker.schema.json"],
        "project.registryHistory":"schemas/history.registry.json","project.entryScenes":[SCENE]}}),
    );
    drop(write);
    let declared: Vec<_> = paths
        .iter()
        .map(|p| SourcePath::parse(p).unwrap())
        .collect();
    let stage_start = Instant::now();
    let stage = stage_declared_tree(&root, &declared).unwrap();
    let stage_ms = stage_start.elapsed().as_secs_f64() * 1000.;
    let start = Instant::now();
    let candidate = validate_staged_candidate(&stage, &[]).unwrap();
    let validate_ms = start.elapsed().as_secs_f64() * 1000.;
    let manifest = candidate.provisional_manifest().unwrap();
    let revision = manifest.revision();
    std::hint::black_box(revision);
    let candidate_ms = start.elapsed().as_secs_f64() * 1000.;
    assert_eq!(candidate.records().builtins().len(), pairs * 2);
    assert_eq!(candidate.records().games().len(), 1);
    assert_eq!(candidate.records().scenes().len(), 4095 - pairs * 2);
    assert_eq!(
        candidate.records().required_edges(),
        1 + pairs + usize::from(selected)
    );
    println!(
        "{}",
        json!({"mode":mode,"records":4096,"files":stage.files().len(),"copied_bytes":stage.copied_bytes(),
        "max_file_bytes":max_file,"max_environment_bytes":max_environment,"stage_ms":stage_ms,
        "validate_ms":validate_ms,"candidate_ms":candidate_ms,"revision":hex(revision.as_bytes()),
        "required_edges":candidate.records().required_edges(),"pairs":pairs})
    );
    drop(manifest);
    drop(candidate);
    drop(stage);
    fs::remove_dir_all(root).unwrap();
}
