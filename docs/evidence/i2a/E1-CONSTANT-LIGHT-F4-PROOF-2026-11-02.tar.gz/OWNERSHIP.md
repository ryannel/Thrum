# Scratch ownership

Owner: e1_source_parser commission, 2 November 2026.
Purpose: standalone typed-input proof of the selected constant-light payload and identity separation.
Inputs: ENVIRONMENT.md selected first F4 constant-light product; F3 built-in hashes read from current registry_stage.rs.
Expected peak disk: below 100 MiB including an isolated Cargo target cache.
Retain: Rust/Python sources, Cargo manifest/lock, compact results and hashes. No production consumers.
Expiry: close after root review; remove owned reconstructible target artifacts after the final verification record is saved. Scratch files are ignored, local-only, and not a durable backup.
