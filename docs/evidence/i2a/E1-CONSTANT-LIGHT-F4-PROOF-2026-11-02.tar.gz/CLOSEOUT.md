# Scratch closeout

Selected Rust/Python/lock/golden sources and three tiny source snapshots were
verified against retained SHA-256 identities after the final successful replay.
The three 160-byte product payloads and exact-source manifests were independently
verified. All selected source-file lengths/hashes matched their manifests.

The owned reconstructible Cargo target tree (65 MiB at final inspection after the audit replay) was
removed. Earlier cosmetic fixture trees were also removed; their exact-source
vectors are retained in oracle.golden and regenerated in memory by oracle.py.
The retained source snapshots are fixtures, not admitted-source leases. No files
were promoted. No crates, design documents or runtime assets were edited.

Reproduction rebuilds the isolated target cache using run_proof.py. Final source
and artifact SHA-256 inventory is in inventory.txt; exact successful commands,
compiler/Python versions, test results and selected local microprobe output are
in verification.txt. These ignored scratch files remain a local-only record,
not durable backup or shipping evidence.

Audit follow-up: the cosmetic cache matrix now compares every binding digest
exactly with its independent Python golden. A third all-nonzero direction with
negative Z has a full independent payload/key/revision/binding golden. All
original cardinal/noncardinal/cosmetic goldens remain unchanged. The nine debug
and nine release tests, fmt and Clippy passed again; verification.txt records
the exact replay and new source/binary hashes. No production files were edited.
