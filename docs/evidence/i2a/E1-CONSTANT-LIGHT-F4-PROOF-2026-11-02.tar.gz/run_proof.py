#!/usr/bin/env python3
"""Reproduce this bounded scratch proof and save compact, command-exact output."""
import hashlib
import os
from pathlib import Path
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
LOG = ["All Cargo commands use RUSTC_WRAPPER= (empty), the pinned Rust1.99.1 toolchain, and locked offline dependencies."]
ENV = dict(os.environ, RUSTC_WRAPPER="")


def run(command, keep=None):
    LOG.append("$ " + shlex.join(map(str, command)))
    result = subprocess.run(list(map(str, command)), cwd=HERE, env=ENV, text=True, capture_output=True, check=True)
    output = result.stdout + result.stderr
    if keep:
        output = "\n".join(line for line in output.splitlines() if keep(line)) + "\n"
    LOG.append(output.rstrip())
    print(output, end="", flush=True)


def main():
    run(["rustup", "run", "1.99.1", "rustc", "--version", "--verbose"])
    run([sys.executable, "--version"])
    try:
        run(["sysctl", "-n", "machdep.cpu.brand_string", "hw.memsize", "hw.ncpu"])
    except subprocess.CalledProcessError as error:
        LOG.append("CPU/memory sysctl unavailable in sandbox: " + error.stderr.strip())
    run([sys.executable, HERE / "oracle.py"])
    cargo = ["rustup", "run", "1.99.1", "cargo"]
    manifest = ["--manifest-path", HERE / "Cargo.toml"]
    common = ["--locked", "--offline"]
    run(cargo + ["fmt"] + manifest + ["--", "--check"])
    run(cargo + ["test"] + common + manifest, lambda line: line.startswith(("test ", "running ")))
    run(cargo + ["test", "--release"] + common + manifest, lambda line: line.startswith(("test ", "running ")))
    run(cargo + ["clippy"] + common + manifest + ["--all-targets", "--", "-D", "warnings"], lambda line: "Finished" in line)
    run(cargo + ["build", "--release"] + common + manifest, lambda line: "Finished" in line)
    # One warm, fixed-iteration local microprobe; RSS is process-wide, not an
    # allocation count and not the immutable product's residency.
    try:
        run(["/usr/bin/time", "-l", HERE / "target/release/f4-constant-light-proof", "--bench"],
            lambda line: not line.startswith(" ") or "maximum resident set size" in line or " real " in line)
    except subprocess.CalledProcessError as error:
        LOG.append("External RSS probe unavailable: " + error.stderr.strip())
        run([HERE / "target/release/f4-constant-light-proof", "--bench"])
    files = ["Cargo.toml", "Cargo.lock", "src/main.rs", "oracle.py", "oracle.golden", "run_proof.py",
             "cardinal.product.bin", "noncardinal.product.bin", "allnonzero.product.bin", "cardinal.tree-manifest.jcs.json", "noncardinal.tree-manifest.jcs.json", "allnonzero.tree-manifest.jcs.json", "target/release/f4-constant-light-proof"]
    LOG.append("Selected reproducible input/output SHA-256 identities:")
    for path in files:
        digest = hashlib.sha256((HERE / path).read_bytes()).hexdigest()
        LOG.append(f"{digest}  {path}")
    LOG.append("Result:9 debug tests+9 release tests passed; fmt+Clippy warnings denied passed. No production engine, authenticated lease, F4 publication, allocation instrumentation or renderer claim.")
    (HERE / "verification.txt").write_text("\n\n".join(LOG) + "\n")


if __name__ == "__main__":
    main()
