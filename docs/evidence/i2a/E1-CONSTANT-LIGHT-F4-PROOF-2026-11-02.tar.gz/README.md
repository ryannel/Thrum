# Constant-light F4 scratch proof

Owner: e1_source_parser bounded commission, 2 November 2026. Scope is the selected
160-byte `ConstantLightProductV1` in `docs/design/modules/ENVIRONMENT.md`.
Only this ignored scratch directory was changed. There is no engine crate,
production F4 product, admitted-source lease, F4 publication, renderer or GPU
readiness claim.

Reproduce from the repository root:

```sh
python3 tmp/f4-constant-light-proof/run_proof.py
```

The runner saves exact commands, tool versions, selected SHA-256 identities and
compact output in `verification.txt`. Dependencies are locked, offline and match
Thrum's `sha2 =0.11.1, default-features=false` profile. It runs Rust debug/release
tests, fmt, Clippy with warnings denied, the independent Python standard-library
oracle, and one selected release microprobe of 500000 operations per function.
Build artifacts are isolated under this directory's `target/`, which can be
reconstructed and is removed at closeout.

## Representation and verification

`src/main.rs` consumes already-typed numeric/UUID inputs. It implements the exact
160-byte little-endian payload, displayed-hex-order UUID octets, ordered f64
normalization, canonical positive zeros and strict decoding. The reader requires
exact length/magic/version/flags/mask, canonical UUID variant/version bits,
distinct environment/light identities, finite signed direction, finite nonnegative other quantities, positive zeros
and cooked unit-length/luminance residuals <=1e-12. Source input validation uses
the existing 1e-9 source normalization tolerance before the selected ordered
normalizer. No JSON parser exists in the Rust experiment.

`oracle.py` independently uses `struct.pack`, `math.sqrt`, explicit ordered
Python binary64 arithmetic and `hashlib.sha256`. It checks complete cardinal, negative/noncardinal and
all-nonzero negative-Z payload bytes, payload hashes, recipe keys, product
revisions and exact-source bindings. Every cosmetic matrix row also asserts the exact independent
Python binding digest, including scene rebinding. `oracle.golden` is retained and a changed
oracle result refuses rather than silently replacing it.

Nine Rust tests pass in both debug and release. They include 32 ordinary and
4096 dark/pure-green signed-zero combinations, negative direction, residual
boundaries, f64::MAX preservation, invalid quantities, unknown version/flags/mask,
invalid/colliding UUIDs, NaN/infinity, noncanonical zeros, corrupted cache data and manifest,
and stale binding refusal. Cache tests cover eight exact-source edits that reuse
the same product (formatting, label, documentation, opaque value, path, unrelated
content, signed-zero spelling, entry-scene rebinding); eight known-value/identity
invalidations; eight definition/revision/compiler/target/floating-point-class
invalidations; and distinct raw directions that normalize to identical product
bytes but retain distinct semantic cook keys. Scene definition and profile lock
changes affect the binding rather than the product.

The three selected source trees under `fixtures/` and their separate
`*.tree-manifest.jcs.json` files only supply exact `SourceRevision` test vectors.
The manifests contain JCS-safe strings, small integer lengths and nulls; their
SHA-256 values are passed opaquely to Rust's `SourceRevision` type. Python creates
these known fixtures; it does not validate arbitrary source, resolve source
schemas or admit a source root. Cosmetic variants are computed in memory and
have no retained source trees. No inferred semantic cook key substitutes for an
exact source revision.

## Explicit proof-local identity choices

The design selects the identity contents but has not selected their canonical
byte grammar or domain literals. These choices belong only to this experiment;
they are not persistent F4 compatibility commitments:

- Cook key domain: ASCII `thrum-proof-f4-constant-light-cook-key-v1` then NUL.
  Then LE u16 product format; environment/light UUID octets; 14 pre-cook decoded
  f64 values in payload field order after positive-zero normalization; LE u32
  exact unsupported mask; profile/direction-model/driver-binding strings;
  environment/light built-in hashes; LE u32 cooker/normalizer/evaluator revisions;
  compiler/target/floating-point-class strings. Every string is UTF-8 preceded
  by a LE u32 byte length. Known values are not normalized before hashing except
  for signed zero. Each three fixed revision numbers is 1.
- Product manifest domain: ASCII `thrum-proof-f4-constant-light-manifest-v1` then
  NUL; LE u16 format 1; LE u32 payload length 160; CookKey32; BlobHash32.
  SHA-256 of those canonical bytes is ProductRevision.
- Binding domain: ASCII `thrum-proof-f4-constant-light-build-binding-v1` then NUL;
  exact SourceRevision32; project/entry-scene/environment/light UUIDs; scene
  definition hash32; profile/target-lock hash32; ProductRevision32. SHA-256 is
  only this scratch binding's digest. The profile lock is SHA-256 of ASCII
  `proof-profile-r0-target-lock-v1`.

The SDK definition hashes are pinned literals in the independent implementations
and recorded in source. Compiler class is
`rustc 1.99.1 (58cf8f9c3 2026-10-13)`, target `aarch64-apple-darwin`, and strict
IEEE754 binary64 nearest-even arithmetic without fast-math or contraction.
Cross-target bit identity has not been proved. The blob hash is exactly SHA-256
of the 160 payload bytes and has no extra domain prefix.

## Cost and limits

The selected timings in `verification.txt` cover only warm in-process cook,
encode, decode and SHA-256 of 160 bytes; validation is included. They exclude
recipe/binding work, filesystem access, source parsing, source admission,
publication, scheduling, consumers and renderer work. CPU model and process RSS
queries were blocked by the sandbox; the exact failure is recorded. Allocation
counts were not instrumented. No unsafe allocator instrumentation was added.

The payload is 160 bytes; this target's typed Product is 144 bytes, ProductManifest
64 and BuildBinding 192. Two serialized payloads plus two manifests and bindings
account for 832 bytes, excluding source, typed copies, allocator and runtime
storage. This is layout accounting, not a residency measurement or engine cost
budget. No general performance or zero-allocation qualification follows from
this microprobe. The experiment contains no per-tick loop, weather state or GPU
resources, but does not establish engine-level disabled-cost counters.

Cache verification assumes an expected product revision from a trusted lookup;
this experiment does not authenticate a production cache index. Type-safe binding
checks model stale-result refusal; no asynchronous runtime or authenticated
source-lease lifecycle is implemented. These remain separate production work.
