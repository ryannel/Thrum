#!/usr/bin/env python3
"""Independent stdlib oracle; generates exact source fixtures and LE goldens."""
import hashlib
import json
import math
from pathlib import Path
import struct
import uuid

ROOT = Path(__file__).resolve().parent
ENV = "10000000-0000-4000-8000-000000000001"
LIGHT = "10000000-0000-4000-8000-000000000002"
PROJECT = "20000000-0000-4000-8000-000000000001"
SCENE = "20000000-0000-4000-8000-000000000002"
HISTORY = "20000000-0000-4000-8000-000000000003"
SCENE_DEF = bytes.fromhex("75c09153b459c576f89ad3328dc6e3bac82379368cd7e3ac9317f058a2ea8aa7")
ENV_DEF = bytes.fromhex("8f3d060dcd716a40ebfeddcdae58cc7285d281b6bba24fa9a38ebf2000ab5cfb")
LIGHT_DEF = bytes.fromhex("9376fbe1d51794e5cae447c41ae0d02a71cd3f652830c9b650375144ac97b166")
CLASS = ("rustc 1.99.1 (58cf8f9c3 2026-10-13)", "aarch64-apple-darwin", "strict-ieee754-binary64-nearest-even-no-fast-math-no-contraction")
UNSUPPORTED = ["wind", "cloud_tau", "precipitation", "air", "thermal", "moon", "air_quality"]
COOK_DOMAIN = b"thrum-proof-f4-constant-light-cook-key-v1\0"
PRODUCT_DOMAIN = b"thrum-proof-f4-constant-light-manifest-v1\0"
BINDING_DOMAIN = b"thrum-proof-f4-constant-light-build-binding-v1\0"


def sha(data):
    return hashlib.sha256(data).digest()


def text(value):
    data = value.encode("utf-8")
    return struct.pack("<I", len(data)) + data


def positive_zero(value):
    return 0.0 if value == 0.0 else value


def known(case):
    directions = {
        "cardinal": [0.0, 1.0, 0.0],
        "noncardinal": [-0.6, 0.8000000001, -0.0],
        "allnonzero": [0.36, 0.48, -0.8000000001],
    }
    direction = directions[case]
    colour = [1.0, 1.0, 1.0] if case == "cardinal" else [0.5, 1.0, 2.47229917]
    return direction + colour + [100000.0, 0.00465] + [1000.0] * 3 + [0.0] * 3


def product_and_recipe(case):
    values = known(case)
    dx, dy, dz, r, g, b = values[:6]
    length = math.sqrt(((dx * dx) + (dy * dy)) + (dz * dz))
    luminance = ((0.2126 * r) + (0.7152 * g)) + (0.0722 * b)
    assert abs(length - 1.0) <= 1e-9 and abs(luminance - 1.0) <= 1e-9
    cooked = [positive_zero(x / length) for x in (dx, dy, dz)]
    cooked += [positive_zero(x / luminance) for x in (r, g, b)]
    cooked += [positive_zero(x) for x in values[6:]]
    blob = b"THRME1C\0" + struct.pack("<HHI", 1, 0, 0x7f)
    blob += uuid.UUID(ENV).bytes + uuid.UUID(LIGHT).bytes
    blob += struct.pack("<14d", *cooked)
    assert len(blob) == 160
    recipe = COOK_DOMAIN + struct.pack("<H", 1)
    recipe += uuid.UUID(ENV).bytes + uuid.UUID(LIGHT).bytes
    recipe += struct.pack("<14d", *(positive_zero(x) for x in values))
    recipe += struct.pack("<I", 0x7f)
    for value in ("constant-light-v1", "geometric-straight", "incoming-environment-sun"):
        recipe += text(value)
    recipe += ENV_DEF + LIGHT_DEF + struct.pack("<III", 1, 1, 1)
    for value in CLASS:
        recipe += text(value)
    return blob, recipe


def exact_source_fixture(case, edit="base"):
    values = known(case)
    if edit == "signed_zero":
        values[0] = -0.0
        values[11] = -0.0
    scene_id = "20000000-0000-4000-8000-000000000004" if edit == "scene_rebind" else SCENE
    source = {"id": ENV, "type": "thrum.environment.authored", "schema": 1, "fields": {
        "profile": "constant-light-v1", "label": "Source" if edit != "label" else "Renamed Source",
        "sun": {"light_ref": LIGHT, "toward_source_unit": values[:3], "unit_luminance_linear_rec709": values[3:6],
                "perpendicular_illuminance_lux": values[6], "angular_radius_rad": values[7],
                "direction_model": "geometric-straight", "applied_attenuation": []},
        "ambient_irradiance_lux": values[8:11], "background_radiance_cd_m2": values[11:14],
        "unsupported": UNSUPPORTED, "x.thrum.environment.note": {"hint": "edited" if edit == "opaque" else "base"}}}
    if edit == "documentation":
        source["documentation"] = "Another authoring note"
    environment_path = "records/renamed.record.json" if edit == "path" else "records/environment.record.json"
    records = [environment_path, "records/light.record.json", "scenes/main.scene.json"]
    tree = {
        "project.json": {"id": PROJECT, "type": "core.project", "schema": 2, "fields": {
            "project.format": 1, "project.records": sorted(records), "project.schemas": [],
            "project.registryHistory": "schemas/history.registry.json", "project.entryScenes": [scene_id]}},
        environment_path: source,
        "records/light.record.json": {"id": LIGHT, "type": "thrum.light.identity", "schema": 1,
                                       "fields": {"driver_binding": "incoming-environment-sun"}},
        "scenes/main.scene.json": {"id": scene_id, "type": "core.scene", "schema": 2, "fields": {"environment.source": ENV}},
        "schemas/history.registry.json": {"id": HISTORY, "type": "core.registry-history", "schema": 1,
                                           "fields": {"registry.fields": [], "registry.versions": []}},
    }
    fixture = ROOT / "fixtures" / f"{case}-{edit}"
    keep_snapshot = edit == "base"
    entries = []
    for path, record in sorted(tree.items()):
        data = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
        if edit == "formatting" and path == environment_path:
            data += b"\n"
        if keep_snapshot:
            target = fixture / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        entries.append({"path": path, "kind": "file", "length": len(data), "hash": sha(data).hex(),
                        "recordId": record["id"], "recordType": record["type"]})
    if edit == "unrelated":
        data = b"unrelated content\n"
        entries.append({"path": "notes.txt", "kind": "file", "length": len(data), "hash": sha(data).hex(),
                        "recordId": None, "recordType": None})
        entries.sort(key=lambda entry: entry["path"])
    manifest = {"format": 1, "projectId": PROJECT, "dependencyRoots": [], "files": entries}
    # Manifest contains only strings, exact small integers, arrays, objects, null;
    # this stdlib spelling is JCS for this deliberately bounded alphabet.
    encoded = json.dumps(manifest, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    if keep_snapshot:
        (ROOT / f"{case}.tree-manifest.jcs.json").write_bytes(encoded)
    return sha(encoded)


def main():
    rows = []
    for case in ("cardinal", "noncardinal", "allnonzero"):
        blob, recipe = product_and_recipe(case)
        blob_hash = sha(blob)
        cook_key = sha(recipe)
        product_manifest = PRODUCT_DOMAIN + struct.pack("<HI", 1, 160) + cook_key + blob_hash
        revision = sha(product_manifest)
        source_revision = exact_source_fixture(case)
        binding = BINDING_DOMAIN + source_revision
        binding += b"".join(uuid.UUID(value).bytes for value in (PROJECT, SCENE, ENV, LIGHT))
        binding += SCENE_DEF + sha(b"proof-profile-r0-target-lock-v1") + revision
        rows.append(" ".join((case, blob.hex(), blob_hash.hex(), cook_key.hex(), revision.hex(), source_revision.hex(), sha(binding).hex())))
        (ROOT / f"{case}.product.bin").write_bytes(blob)
    for edit in ("formatting", "label", "documentation", "opaque", "path", "unrelated", "signed_zero", "scene_rebind"):
        source_revision = exact_source_fixture("cardinal", edit)
        scene_id = "20000000-0000-4000-8000-000000000004" if edit == "scene_rebind" else SCENE
        cardinal_revision = bytes.fromhex(rows[0].split()[4])
        binding = BINDING_DOMAIN + source_revision
        binding += b"".join(uuid.UUID(value).bytes for value in (PROJECT, scene_id, ENV, LIGHT))
        binding += SCENE_DEF + sha(b"proof-profile-r0-target-lock-v1") + cardinal_revision
        rows.append(f"cosmetic {edit} {source_revision.hex()} {uuid.UUID(scene_id).bytes.hex()} {sha(binding).hex()}")
    golden = "\n".join(rows) + "\n"
    target = ROOT / "oracle.golden"
    if target.exists() and target.read_text() != golden:
        raise RuntimeError("oracle differs from retained golden; inspect the changed contract before explicitly replacing it")
    target.write_text(golden)
    print("independent Python stdlib oracle: 3 payload/hash/recipe/manifest/binding goldens; 8 exact-source edit/binding vectors (computed in memory)")
    for row in rows[:3]:
        fields = row.split()
        print(f"{fields[0]} BlobHash={fields[2]} CookKey={fields[3]} ProductRevision={fields[4]} SourceRevision={fields[5]} BuildBindingHash={fields[6]}")


if __name__ == "__main__":
    main()
