# Moving-shore material chronology proof

Owner: `/root/environment_research`, commissioned 2 November 2026. Owned scope is this directory and the linked research report only. Purpose: discriminate spatially fixed chronological material histories from uniform wet/dry-subset mixing. Expected peak disk below 1 MiB; Python standard library only, no external code/assets or build cache.

Run `python3 -B tmp/moving-shore-material-proof/proof.py`. Retain editable fixtures/code, deterministic results and manifest; these ignored scratch files are not a durable evidence backup. Root owns any later promotion. No Thrum runtime, finite-water solver, full constitutive law or device qualification is claimed. Remove only owned reproducible caches at closeout; none are generated with `-B`.

The five hand-balance cases include roof/sheltered-floor/export with explicit authored direct-rain eligibility; their geometric extraction is not implemented. A separate exact-affine counterexample distinguishes representative-versus-footprint mismatch from Taylor geometry ambiguity. The wave proves only point sign-changing roots. Toy state and exchange payloads are separate; all six exercised exchange kinds reject changed mass/destination without mutation. Generic spatial certificates, tangencies, finite-water donors and P7 publication remain unproved.
