# Height-density cohort feasibility proof

Owner `/root/environment_research`, 3 November 2026. Scope: this directory and the new density-cohort research report. Original Fraction-only tide/material experiment, Python stdlib, expected retained disk below 1 MiB. Run `python3 -B tmp/moving-shore-cohort-proof/proof.py`.

The test law authors cap/refill density per projected square metre. It is not the canonical true-area law. Retain source/fixtures/results/manifest; ignored scratch is not a durable evidence backup. Root owns later promotion. No waves, finite-water coupling, nonlinear absorption, f64 product or engine publication qualification. No caches are generated with `-B`.
