# Moving-shore first-hit rain proof

Owner: `/root/moving_shore_rain`, commissioned by the root design programme on 2 November 2026.
Purpose: exact offline first-hit rain mass/identity oracle for a planar changing shore; not finite-water, film, C09 or engine-runtime qualification.
Scope/peak: this directory only; dependency-free Python stdlib, expected peak disk below 2 MiB. No bulk artifacts, third-party code or build cache.
Selected retained roots: `proof.py`, `fixtures.json`, deterministic `results.json`, `SUMMARY.md`, `manifest.json` and this record. Root owns any later promotion.
Closeout: run and independently inspect results; retain editable source/fixtures/results/hashes. Remove only this task's reconstructible cache, if any. These ignored scratch files are not a durable evidence backup until the root promotes them.

Reproduce with the exact Python executable/version/digest recorded in `manifest.json`:

```sh
python3 -B tmp/moving-shore-rain-proof/proof.py
```

The candidate prepares triangle atoms and exact-rational affine clips. The oracle independently integrates strip-length area laws directly from authored roof/bridge/export intervals and the separately derived triangular-footprint law `A_wet=20H−100H²`; it does not consume prepared atoms or polygon clipping. Every numeric fixture input is a rational string. Results retain rational receipts and errors as well as readable decimal approximations.

Audit fixes: admitted covers must be strictly above the bank at both footprint endpoints and above all admitted stages; two falsifying inputs are retained and rejected. The triangular response case asserts nonzero quadratic/cubic terms and rejects a zero-quadratic mutant. Toy commits now enforce the same numerical/slice admission as reported runs. Candidate source-work counters include cached reporting-window integrals; oracle/validation/I/O work is outside those counter scopes. No physical material/water state updates are executed by the exact-receipt calculations.

Cross-partition identity fix: deliveries key source revision, stream and physical interval, independent of N/tolerance. Canonical aggregated exact receiver masses deduplicate equivalent N/tolerance retries and reject changed aggregate receipts before mutation; the source-only offline regression retains one committed interval.
