# Offline moving-shore first-hit proof result

Exact rational first-hit/identity proof only; no finite-water, film exchange or C09 runtime qualification.

Candidate: prepared triangle atoms + affine spatial clipping + frozen-start temporal assignment. Oracle: independent analytic interval-length/area-time integration. All comparisons use fractions.

Admission requires the conservative bound, not merely the observed signed error, to fit `1e-5 kg + 0.001 × local reference mass` for each receiver and each stage/source reporting window. The design cap stays 16 slices per tick: all N>16 runs are diagnostic and reject that profile, even if their mass error meets the request.

| Fixture | First tested N whose bound meets every local request | Actual slices | Clips at that N |
| --- | ---: | ---: | ---: |
| planar-rise-constant | 512 | 512 | 1026 |
| planar-fall-constant | 512 | 512 | 1026 |
| rise-fall-identical-endpoints | 2048 | 2048 | 2050 |
| piecewise-rate-then-off | 512 | 512 | 1030 |
| roof-bridge-export | 1024 | 1024 | 5130 |
| zero-area-bank-tie | 1 | 1 | 2 |
| source-off-entire-interval | 1 | 2 | 4 |
| one-tick-slow-shore | 1 | 1 | 4 |
| one-tick-fast-heavy-rain | 128 | 128 | 258 |
| triangular-response-cubic | 2048 | 2048 | 1027 |

The 1s/2s full-shore sweeps are deliberately large proof windows, not ordinary 60 Hz motion. The one-tick slow-shore case advances stage by 0.1 mm over 1/60 s (0.006 m/s stage speed) and certifies N=1. The fast-heavy case sweeps 0.1 m over 1/60 s (6 m/s stage speed) at 100 mm/h: it requires N=128 and therefore **fails the 16-slice profile**. This does not authorize increasing that cap.

The precomputed-polynomial variant explicitly verifies quadratic area laws on every sorted triangle-vertex height interval using 8 non-fit probes (exact fractions), and integrates the resulting coefficient×linear-flux product analytically. It also matches every oracle receiver/local window exactly, with 0 runtime triangle clips or point samples; preparation/verification and runtime coefficient counts are separate in results. This removes repeated clipping for the covered affine source regime, but no f64 product/error certificate is tested.

The exact-affine-time alternative agrees exactly with the independent oracle for every receiver and every reporting window in all fixtures. It prepares the same triangle atoms, splits only integration algebra at source/stage/triangle-vertex crossing events, and uses an exact cubic3/8 rule. It computes one source receipt batch with bounded internal algebraic integration pieces, without requiring more physical updates for that calculation. It executes no physical material/water update and does not establish that one such update suffices across crossings. For planar affine stage this is the preferred source-integration direction rather than brute-force frozen-start slices. Results retain its operation counts and receipts.

All tested runs conserve the complete source mass exactly and preserve roof/bridge/export identities. This does not imply local allocation accuracy: admitted N varies by fixture. Identical-endpoint rise/fall without interior stage knots gives water receipt 0 versus oracle 1/180 kg; its naive endpoint-only bound is incorrectly 0, while the certified interior envelope bound is 1/90 kg.

Source-knot/off integration, zero-area strict point tie, exact partition coverage and numerically gated reject/retry/duplicate model checks pass. Equivalent cross-N/tolerance deliveries deduplicate, while numerically admitted changed aggregate receipts conflict before mutation; arbitrary wire-payload handling is not tested. Roof/bridge undersides and roof-covered floor receive zero direct rain. Their inundation/film behavior is outside this proof.

Operation counts are scoped candidate counters, not full-program or runtime benchmarks. Source segment tests/integrals include cached reporting-window requests; validation/oracle, admission recomputation, formatting and I/O are excluded. Results include local window receipts so opposite rising/falling errors cannot cancel into a misleading full-interval success. A rejected error budget leaves the toy ledger untouched; successful retry commits once. This is not concurrency, persistence or engine-transaction validation.

Reproduce with `python3 -B tmp/moving-shore-rain-proof/proof.py`. Manifest records exact editable source/fixture/result hashes and Python binary/version. No dependency downloads or cache output.

Audit follow-ups: two falsifying cover-below/intersects-bank fixtures are rejected before candidate/oracle preparation by checking the bank height at both cover endpoints. The admitted roof/bridge profile also remains above every stage, so this proof does not establish arbitrary overlapping/overtopped solids.

The separately identified triangular response footprint has independently derived wet area `20H−100H²` on 0<H<0.1 m, total area 1 m², and linear varying rain. It crosses both vertex levels and source/stage knots. Two nonzero quadratic receiver coefficients and nonzero cubic integrand terms are asserted; deleting the quadratic coefficients is rejected by local oracle receipts. This corrects the earlier strip-only proof, whose aggregate quadratic coefficients were all zero.

Triangle exact receipts: water 189737/23040000 kg; triangular solid 66263/23040000 kg. Its zero-quadratic mutant errors are in results. All other cases remain controls.

The public toy commit function now executes the same numerical/slice gate used in results. A dependency-ready over-budget candidate and an over-cap candidate reject without advancing state; a numerically valid missing-dependency candidate then retries/duplicates with exactly one commit. Zero-input commit likewise advances once. Delivery identity is source revision + stream + physical interval, excluding N/tolerance; canonical aggregated per-receiver masses define the payload digest. The constant-mask N=1→N=2/tolerance retry retains total 1/180 kg and one commit. A slow-shore N=1→N=2 retry has two numerically admissible but different aggregate payloads and returns ReceiptIdentityConflict without mutation. This does not validate a concurrent/persistent engine transaction.

| Fixture | Frozen N=16 clips | Frozen N=16 admission | Exact polynomial pieces / coefficient integrations |
| --- | ---: | --- | ---: |
| planar-rise-constant | 34 | RejectedErrorBudgetBeforeCommit | 1 / 4 |
| planar-fall-constant | 34 | RejectedErrorBudgetBeforeCommit | 1 / 4 |
| rise-fall-identical-endpoints | 18 | RejectedErrorBudgetBeforeCommit | 2 / 8 |
| piecewise-rate-then-off | 38 | RejectedErrorBudgetBeforeCommit | 3 / 12 |
| roof-bridge-export | 90 | RejectedErrorBudgetBeforeCommit | 12 / 84 |
| zero-area-bank-tie | 2 | Accepted | 1 / 4 |
| source-off-entire-interval | 18 | Accepted | 2 / 8 |
| one-tick-slow-shore | 34 | Accepted | 1 / 4 |
| one-tick-fast-heavy-rain | 34 | RejectedErrorBudgetBeforeCommit | 1 / 4 |
| triangular-response-cubic | 11 | RejectedErrorBudgetBeforeCommit | 8 / 32 |

Polynomial preparation and its non-fit verification use clipping offline; those counts are retained separately and are not hidden in runtime 0-clips claims. A future floating-point implementation must certify coefficient reconstruction and integration arithmetic before inheriting these exact-rational results.
