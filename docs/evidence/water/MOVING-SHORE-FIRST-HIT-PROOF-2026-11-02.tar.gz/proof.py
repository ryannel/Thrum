#!/usr/bin/env python3
"""Exact stdlib-only first-hit rain candidate and independent analytic oracle."""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
WATER = "water:prescribed-sea"
BANK = "solid:bank"


def digest_bytes(data: bytes) -> str:
    return sha256(data).hexdigest()


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def qstr(value: Q) -> str:
    return str(value)


def quantity(value: Q) -> dict:
    return {"rational": qstr(value), "kg": float(value)}


def linear(t0: Q, y0: Q, t1: Q, y1: Q) -> tuple[Q, Q]:
    slope = (y1 - y0) / (t1 - t0)
    return y0 - slope * t0, slope


@dataclass(frozen=True)
class Fixture:
    case_id: str
    stage: tuple[tuple[Q, Q], ...]
    rain: tuple[tuple[Q, Q, Q, Q], ...]
    covers: tuple[dict, ...]
    slope: Q
    x0: Q
    x1: Q
    z0: Q
    z1: Q
    zero_receivers: tuple[str, ...]
    source_digest: str
    footprint: str = "rectangle"
    bank_receiver: str = BANK

    @property
    def start(self) -> Q:
        return self.stage[0][0]

    @property
    def end(self) -> Q:
        return self.stage[-1][0]

    @property
    def width(self) -> Q:
        return self.z1 - self.z0

    @property
    def area(self) -> Q:
        rectangle = (self.x1-self.x0)*self.width
        return rectangle/2 if self.footprint == "triangle-sw-se-nw" else rectangle

    @property
    def receivers(self) -> tuple[str, ...]:
        return tuple(sorted({WATER, self.bank_receiver, *self.zero_receivers,
                             *(c["receiver"] for c in self.covers)}))

    def stage_line(self, t: Q) -> tuple[Q, Q]:
        for (a, ya), (b, yb) in zip(self.stage, self.stage[1:]):
            if a <= t <= b:
                return linear(a, ya, b, yb)
        raise ValueError("stage outside support")

    def height(self, t: Q) -> Q:
        a, b = self.stage_line(t)
        return a + b * t

    def rain_line(self, t: Q) -> tuple[Q, Q]:
        for a, b, pa, pb in self.rain:
            if a <= t < b or (t == self.end == b):
                return linear(a, pa, b, pb)
        raise ValueError("rain outside support")

    def source_integral(self, lo: Q, hi: Q, counts: dict | None = None) -> Q:
        result = Q(0)
        for a, b, pa, pb in self.rain:
            if counts is not None:
                counts["source_segment_tests"] += 1
            l, r = max(lo, a), min(hi, b)
            if l < r:
                alpha, beta = linear(a, pa, b, pb)
                result += alpha * (r-l) + beta * (r*r-l*l) / 2
                if counts is not None:
                    counts["source_segment_integrals"] += 1
        return result

    def height_envelope(self, lo: Q, hi: Q) -> tuple[Q, Q]:
        values = [self.height(lo), self.height(hi)]
        values += [h for t, h in self.stage if lo < t < hi]
        return min(values), max(values)

    def reporting_windows(self) -> tuple[Q, ...]:
        return tuple(sorted({*(t for t, _ in self.stage),
                             *(t for a, b, _, _ in self.rain for t in (a, b))}))


def read_fixtures(raw: dict) -> list[Fixture]:
    domain = raw["domain"]
    fixtures = []
    for case in raw["cases"]:
        covers = tuple({**c, "x": tuple(map(Q, c["x"])),
                        **({"height": Q(c["height"])} if "height" in c else {})}
                       for c in case["covers"])
        f = Fixture(case["id"], tuple(tuple(map(Q, p)) for p in case["stage"]),
                    tuple(tuple(map(Q, p)) for p in case["rain"]), covers,
                    Q(domain["bank_slope"]), *map(Q, domain["x"]),
                    *map(Q, domain["z"]), tuple(raw["zero_receivers"]),
                    digest_bytes(canonical({"domain": domain, "case": case})),
                    case.get("footprint", "rectangle"), case.get("bank_receiver", BANK))
        assert f.slope > 0 and f.start == 0 and f.end > 0
        assert all(a[0] < b[0] for a, b in zip(f.stage, f.stage[1:]))
        assert f.rain[0][0] == f.start and f.rain[-1][1] == f.end
        assert all(a < b and min(pa, pb) >= 0 for a, b, pa, pb in f.rain)
        assert all(a[1] == b[0] for a, b in zip(f.rain, f.rain[1:]))
        ordered = sorted(covers, key=lambda c: c["x"][0])
        assert all(f.x0 <= c["x"][0] < c["x"][1] <= f.x1 for c in covers)
        assert all(a["x"][1] <= b["x"][0] for a, b in zip(ordered, ordered[1:]))
        assert f.footprint in ("rectangle", "triangle-sw-se-nw")
        assert f.footprint == "rectangle" or not covers, "triangle covers are outside this proof"
        assert all(c["kind"] == "export" or
                   c["height"] > max(f.slope*c["x"][0], f.slope*c["x"][1])
                   for c in covers), "cover must be strictly above bank at both footprint endpoints"
        assert all(c["kind"] == "export" or c["height"] > max(h for _, h in f.stage)
                   for c in covers), "this oracle admits only never-overtopped roofs"
        fixtures.append(f)
    return fixtures


# Candidate: immutable prepared triangle atoms, exact affine half-plane clipping.
@dataclass(frozen=True)
class Atom:
    vertices: tuple[tuple[Q, Q], ...]
    receiver: str
    solid_height: tuple[Q, Q, Q] | None


def polygon_area(points: tuple | list) -> Q:
    if len(points) < 3:
        return Q(0)
    return abs(sum(a[0]*b[1] - b[0]*a[1]
                   for a, b in zip(points, points[1:] + points[:1]))) / 2


def prepare(f: Fixture) -> tuple[Atom, ...]:
    if f.footprint == "triangle-sw-se-nw":
        atom = Atom(((f.x0,f.z0), (f.x1,f.z0), (f.x0,f.z1)),
                    f.bank_receiver, (f.slope,Q(0),Q(0)))
        assert polygon_area(atom.vertices) == f.area
        return (atom,)
    xs = sorted({f.x0, f.x1, *(x for c in f.covers for x in c["x"])})
    atoms = []
    for lo, hi in zip(xs, xs[1:]):
        mid = (lo+hi)/2
        cover = next((c for c in f.covers if c["x"][0] <= mid < c["x"][1]), None)
        receiver = cover["receiver"] if cover else f.bank_receiver
        plane = None if cover and cover["kind"] == "export" else (
            (Q(0), Q(0), cover["height"]) if cover else (f.slope, Q(0), Q(0)))
        sw, se, ne, nw = (lo, f.z0), (hi, f.z0), (hi, f.z1), (lo, f.z1)
        atoms.extend((Atom((sw, se, ne), receiver, plane), Atom((sw, ne, nw), receiver, plane)))
    assert sum(polygon_area(a.vertices) for a in atoms) == f.area
    return tuple(atoms)


def wet_clip(atom: Atom, stage: Q, counts: dict) -> Q:
    assert atom.solid_height is not None
    aa, bb, cc = atom.solid_height
    signed = lambda p: stage - (aa*p[0] + bb*p[1] + cc)
    out = []
    for a, b in zip(atom.vertices, atom.vertices[1:] + atom.vertices[:1]):
        counts["clip_edge_tests"] += 1
        fa, fb = signed(a), signed(b)
        # Boundary inclusion changes zero area only. Point query equality below is dry.
        inside_a, inside_b = fa >= 0, fb >= 0
        if inside_a:
            out.append(a)
        if inside_a != inside_b:
            t = fa / (fa-fb)
            out.append((a[0]+t*(b[0]-a[0]), a[1]+t*(b[1]-a[1])))
    counts["affine_triangle_clips"] += 1
    counts["area_evaluations"] += 1
    return polygon_area(out)


class PreparedPartition:
    def __init__(self, f: Fixture):
        self.fixture = f
        self.atoms = prepare(f)
        self.cache: dict[Q, dict[str, Q]] = {}
        self.counts = {"prepared_atoms": len(self.atoms), "partition_cache_hits": 0,
                       "partition_evaluations": 0, "affine_triangle_clips": 0,
                       "clip_edge_tests": 0, "area_evaluations": 0,
                       "source_segment_integrals": 0, "source_segment_tests": 0,
                       "source_primary_requests": 0, "source_reporting_window_requests": 0,
                       "source_integral_cache_hits": 0, "slices": 0}

    def areas(self, h: Q) -> dict[str, Q]:
        if h in self.cache:
            self.counts["partition_cache_hits"] += 1
            return self.cache[h]
        self.counts["partition_evaluations"] += 1
        area = dict.fromkeys(self.fixture.receivers, Q(0))
        for atom in self.atoms:
            total = polygon_area(atom.vertices)
            self.counts["area_evaluations"] += 1
            wet = Q(0) if atom.solid_height is None else wet_clip(atom, h, self.counts)
            assert 0 <= wet <= total
            area[atom.receiver] += total-wet
            area[WATER] += wet
        assert sum(area.values()) == self.fixture.area
        self.cache[h] = area
        return area


@dataclass
class Candidate:
    receipts: dict[str, Q]
    bounds: dict[str, Q]
    endpoint_only_bounds: dict[str, Q]
    windows: dict[str, dict[str, Q]]
    window_bounds: dict[str, dict[str, Q]]
    receipt_rows: tuple[tuple[str, str, str, Q], ...]
    counts: dict
    schedule: tuple[Q, ...]


def candidate(f: Fixture, requested_slices: int, mandatory_knots: bool = True) -> Candidate:
    part = PreparedPartition(f)
    source_cache: dict[tuple[Q,Q],Q] = {}

    def source(lo: Q, hi: Q, role: str) -> Q:
        part.counts["source_"+role+"_requests"] += 1
        key = lo,hi
        if key in source_cache:
            part.counts["source_integral_cache_hits"] += 1
            return source_cache[key]
        value = f.source_integral(lo,hi,part.counts)
        source_cache[key] = value
        return value

    schedule = {f.start + (f.end-f.start)*j/requested_slices for j in range(requested_slices+1)}
    if mandatory_knots:
        schedule.update(t for t, _ in f.stage)
    times = tuple(sorted(schedule))
    empty = lambda: dict.fromkeys(f.receivers, Q(0))
    mass, bound, naive = empty(), empty(), empty()
    report_times = f.reporting_windows()
    window_keys = [f"[{a},{b})" for a, b in zip(report_times, report_times[1:])]
    windows = {key: empty() for key in window_keys}
    window_bounds = {key: empty() for key in window_keys}
    rows = []
    for a, b in zip(times, times[1:]):
        part.counts["slices"] += 1
        start = part.areas(f.height(a))
        end = part.areas(f.height(b))
        hmin, hmax = f.height_envelope(a, b)
        amin, amax = part.areas(hmin), part.areas(hmax)
        j = source(a,b,"primary")
        window_plans = []
        for key,wa,wb in zip(window_keys,report_times,report_times[1:]):
            lo,hi=max(a,wa),min(b,wb)
            if lo < hi:
                jwindow=source(lo,hi,"reporting_window")
                low,high=f.height_envelope(lo,hi)
                window_plans.append((key,jwindow,part.areas(low),part.areas(high)))
        for receiver in f.receivers:
            m = j*start[receiver]
            mass[receiver] += m
            swept = abs(amax[receiver]-amin[receiver])
            bound[receiver] += j*swept
            naive[receiver] += j*abs(end[receiver]-start[receiver])
            rows.append((qstr(a), qstr(b), receiver, m))
            for key,jwindow,low_area,high_area in window_plans:
                windows[key][receiver] += jwindow*start[receiver]
                delta=max(abs(start[receiver]-low_area[receiver]),
                          abs(start[receiver]-high_area[receiver]))
                window_bounds[key][receiver] += jwindow*delta
        assert sum(j*start[r] for r in f.receivers) == j*f.area
    return Candidate(mass, bound, naive, windows, window_bounds, tuple(rows), part.counts, times)


# Independent oracle: authored 1D lengths and analytic polynomial integration.
# Does not call prepare(), wet_clip(), polygon_area(), or PreparedPartition.
def triangular_analytic_oracle(f: Fixture, lo: Q, hi: Q) -> tuple[dict[str,Q],int]:
    # Independent direct geometry: width at x is W*(1-(x-x0)/L).
    # Integral to normalized contour v gives A_wet=A_total*(2v-v^2).
    # This branch never calls prepared atoms, area interpolation or clipping.
    length=f.x1-f.x0
    events={lo,hi,*(t for t,_ in f.stage if lo<t<hi),
            *(t for a,b,_,_ in f.rain for t in (a,b) if lo<t<hi)}
    for (a,ha),(b,hb) in zip(f.stage,f.stage[1:]):
        if ha!=hb:
            alpha,beta=linear(a,ha,b,hb)
            for level in (f.slope*f.x0,f.slope*f.x1):
                t=(level-alpha)/beta
                if max(lo,a)<t<min(hi,b):
                    events.add(t)
    ordered=sorted(events)
    masses=dict.fromkeys(f.receivers,Q(0))
    for a,b in zip(ordered,ordered[1:]):
        mid=(a+b)/2
        h0,ht=f.stage_line(mid)
        p0,pt=f.rain_line(mid)
        v0=(h0/f.slope-f.x0)/length
        vt=ht/(f.slope*length)
        vmid=v0+vt*mid
        if vmid<=0:
            wet=(Q(0),Q(0),Q(0))
        elif vmid>=1:
            wet=(f.area,Q(0),Q(0))
        else:
            wet=(f.area*(2*v0-v0*v0),f.area*(2*vt-2*v0*vt),-f.area*vt*vt)
        dry=(f.area-wet[0],-wet[1],-wet[2])
        for receiver,coeffs in ((WATER,wet),(f.bank_receiver,dry)):
            # Independent polynomial antiderivative in absolute t.
            for degree,coefficient in enumerate(coeffs):
                masses[receiver]+=p0*coefficient*(b**(degree+1)-a**(degree+1))/(degree+1)
                masses[receiver]+=pt*coefficient*(b**(degree+2)-a**(degree+2))/(degree+2)
    assert sum(masses.values())==f.source_integral(lo,hi)*f.area
    assert all(m>=0 for m in masses.values())
    return masses,len(ordered)-1


def analytic_oracle(f: Fixture, lo: Q | None = None, hi: Q | None = None) -> tuple[dict[str, Q], int]:
    lo, hi = f.start if lo is None else lo, f.end if hi is None else hi
    if f.footprint=="triangle-sw-se-nw":
        return triangular_analytic_oracle(f,lo,hi)
    intervals = [(f.x0, f.x1)]
    fixed = []
    for cover in sorted(f.covers, key=lambda c: c["x"][0]):
        left, right = cover["x"]
        remaining = []
        for a, b in intervals:
            if b <= left or right <= a:
                remaining.append((a, b))
            else:
                if a < left:
                    remaining.append((a, left))
                if right < b:
                    remaining.append((right, b))
        intervals = remaining
        fixed.append((cover["receiver"], (right-left)*f.width))
    events = {lo, hi, *(t for t, _ in f.stage if lo < t < hi),
              *(t for a, b, _, _ in f.rain for t in (a, b) if lo < t < hi)}
    for (ta, ha), (tb, hb) in zip(f.stage, f.stage[1:]):
        if ha == hb:
            continue
        alpha, beta = linear(ta, ha, tb, hb)
        for a, b in intervals:
            for threshold in (f.slope*a, f.slope*b):
                t = (threshold-alpha)/beta
                if max(lo, ta) < t < min(hi, tb):
                    events.add(t)
    ordered = sorted(events)
    masses = dict.fromkeys(f.receivers, Q(0))
    for a, b in zip(ordered, ordered[1:]):
        mid = (a+b)/2
        h0, ht = f.stage_line(mid)
        p0, pt = f.rain_line(mid)
        water0, watert = Q(0), Q(0)
        for left, right in intervals:
            contour = (h0+ht*mid)/f.slope
            if contour >= right:
                water0 += (right-left)*f.width
            elif left < contour < right:
                water0 += (h0/f.slope-left)*f.width
                watert += ht/f.slope*f.width
        bank_area = sum((right-left)*f.width for left, right in intervals)
        areas = {WATER: (water0, watert), f.bank_receiver: (bank_area-water0, -watert)}
        for receiver, area in fixed:
            aa, bb = areas.get(receiver, (Q(0), Q(0)))
            areas[receiver] = aa+area, bb
        for receiver, (aa, bb) in areas.items():
            masses[receiver] += (p0*aa*(b-a) + (p0*bb+pt*aa)*(b*b-a*a)/2
                                 + pt*bb*(b*b*b-a*a*a)/3)
    expected = f.source_integral(lo, hi)*f.area
    assert sum(masses.values()) == expected
    assert all(m >= 0 for m in masses.values())
    return masses, len(ordered)-1


def exact_affine_time_candidate(f: Fixture) -> dict:
    """Prepared atom path: piecewise quadratic area × linear flux = cubic.

    Source/stage/atom-vertex crossings delimit those polynomials. Exact 3/8
    Newton-Cotes uses four samples per integration piece; these are algebraic
    integration nodes, not additional physical state updates.
    """
    part = PreparedPartition(f)
    events = {*(t for t, _ in f.stage),
              *(t for a, b, _, _ in f.rain for t in (a, b))}
    vertex_heights = set()
    for atom in part.atoms:
        if atom.solid_height is not None:
            aa, bb, cc = atom.solid_height
            vertex_heights.update(aa*x+bb*z+cc for x, z in atom.vertices)
    for (a, ha), (b, hb) in zip(f.stage, f.stage[1:]):
        if ha != hb:
            alpha, beta = linear(a, ha, b, hb)
            for height in vertex_heights:
                t = (height-alpha)/beta
                if a < t < b:
                    events.add(t)
    ordered = sorted(events)
    masses = dict.fromkeys(f.receivers, Q(0))
    windows = {f"[{a},{b})": dict.fromkeys(f.receivers, Q(0))
               for a, b in zip(f.reporting_windows(), f.reporting_windows()[1:])}
    weights = (1, 3, 3, 1)
    for a, b in zip(ordered, ordered[1:]):
        p0, pt = f.rain_line((a+b)/2)
        nodes = (a, a+(b-a)/3, a+2*(b-a)/3, b)
        areas = [part.areas(f.height(t)) for t in nodes]
        owner_window = next(key for key in windows
                            if Q(key[1:-1].split(',')[0]) <= a
                            and b <= Q(key[1:-1].split(',')[1]))
        for receiver in f.receivers:
            m = (b-a)/8*sum(Q(w)*(p0+pt*t)*ar[receiver]
                             for w, t, ar in zip(weights, nodes, areas))
            assert m >= 0
            masses[receiver] += m
            windows[owner_window][receiver] += m
    oracle, _ = analytic_oracle(f)
    assert masses == oracle, (f.case_id, masses, oracle)
    local_checks = []
    for key, received in windows.items():
        a, b = map(Q, key[1:-1].split(','))
        reference, _ = analytic_oracle(f, a, b)
        assert received == reference
        local_checks.append({"window": key,
                             "receipts": {r: quantity(m) for r, m in received.items()},
                             "all_local_errors_exact_zero": True})
    return {"operator": "prepared-atom exact affine time integration",
            "physical_state_updates_executed": 0, "source_receipt_batches": 1,
            "algebraic_integration_pieces": len(ordered)-1,
            "proof": "triangle affine-cut area quadratic between vertex crossings; linear rain product cubic; exact rational3/8 rule",
            "counts": {**part.counts, "integration_nodes_requested": 4*(len(ordered)-1)},
            "receipts": {r: quantity(m) for r, m in masses.items()},
            "local_windows": local_checks, "all_errors_exact_zero": True,
            "scope": "source integration only; algebraic pieces are not physical material/finite-water updates"}


def polynomial_time_candidate(f: Fixture) -> dict:
    """Offline exact quadratic products; runtime coefficient integration, no clips."""
    part = PreparedPartition(f)
    hmin, hmax = min(h for _, h in f.stage), max(h for _, h in f.stage)
    levels = {hmin, hmax}
    for atom in part.atoms:
        if atom.solid_height is not None:
            aa, bb, cc = atom.solid_height
            levels.update(aa*x+bb*z+cc for x, z in atom.vertices
                          if hmin < aa*x+bb*z+cc < hmax)
    levels = sorted(levels)
    products = []
    probes_verified = 0
    if len(levels) == 1:
        values = part.areas(levels[0])
        products.append((levels[0], levels[0], {r: (m,Q(0),Q(0)) for r,m in values.items()}))
    else:
        for lo, hi in zip(levels, levels[1:]):
            low, middle, high = part.areas(lo), part.areas((lo+hi)/2), part.areas(hi)
            coefficients = {}
            for r in f.receivers:
                c0 = low[r]
                c2 = 2*(high[r]+low[r]-2*middle[r])
                coefficients[r] = c0, high[r]-low[r]-c2, c2
            # Non-fit probes deliberately differ from 0,1/2,1.
            # Exact equality checks the claimed polynomial regime explicitly.
            for u in (Q(1,7), Q(2,7), Q(3,7), Q(4,7), Q(5,7), Q(6,7), Q(1,3), Q(2,3)):
                direct = part.areas(lo+u*(hi-lo))
                for r, (c0,c1,c2) in coefficients.items():
                    assert c0+c1*u+c2*u*u == direct[r], (f.case_id, lo, hi, r, u)
                    probes_verified += 1
            products.append((lo,hi,coefficients))
    offline_counts = part.counts.copy()
    events = {*(t for t,_ in f.stage), *(t for a,b,_,_ in f.rain for t in (a,b))}
    for (a,ha),(b,hb) in zip(f.stage,f.stage[1:]):
        if ha != hb:
            alpha,beta = linear(a,ha,b,hb)
            events.update((level-alpha)/beta for level in levels
                          if a < (level-alpha)/beta < b)
    times = sorted(events)
    masses = dict.fromkeys(f.receivers,Q(0))
    windows = {f"[{a},{b})":dict.fromkeys(f.receivers,Q(0))
               for a,b in zip(f.reporting_windows(),f.reporting_windows()[1:])}
    coefficient_integrations = 0
    cubic_terms_nonzero = 0
    zero_quadratic_mutant=dict.fromkeys(f.receivers,Q(0))
    quadratic_nonzero=sum(c2!=0 for _,_,cs in products for _,_,c2 in cs.values())
    for a,b in zip(times,times[1:]):
        ha,hb = f.height(a),f.height(b)
        hm=(ha+hb)/2
        lo,hi,coefficients = next(p for p in products if p[0] <= hm <= p[1])
        shift,scale = (Q(0),Q(0)) if lo==hi else ((ha-lo)/(hi-lo),(hb-ha)/(hi-lo))
        p0,pt=f.rain_line((a+b)/2)
        pa,pd=p0+pt*a,pt*(b-a)
        window=next(k for k in windows if Q(k[1:-1].split(',')[0])<=a and b<=Q(k[1:-1].split(',')[1]))
        for r,(c0,c1,c2) in coefficients.items():
            aa=c0+c1*shift+c2*shift*shift
            bb=c1*scale+2*c2*shift*scale
            cc=c2*scale*scale
            mass=(b-a)*(pa*aa+(pa*bb+pd*aa)/2+(pa*cc+pd*bb)/3+pd*cc/4)
            masses[r]+=mass
            windows[window][r]+=mass
            coefficient_integrations+=1
            cubic_terms_nonzero+=pd*cc!=0
            # Falsifying mutant keeps the fitted c0/c1 but deletes the area c2.
            mutant_aa=c0+c1*shift
            mutant_bb=c1*scale
            zero_quadratic_mutant[r]+=(b-a)*(pa*mutant_aa+(pa*mutant_bb+pd*mutant_aa)/2+pd*mutant_bb/3)
    oracle,_=analytic_oracle(f)
    assert masses==oracle
    if f.footprint=="triangle-sw-se-nw":
        assert quadratic_nonzero>0, "quadratic coverage vanished"
        assert cubic_terms_nonzero>0, "linear flux never exercised a cubic product"
        assert zero_quadratic_mutant!=oracle, "zero-quadratic mutant escaped the oracle"
    for key,received in windows.items():
        a,b=map(Q,key[1:-1].split(','))
        exact,_=analytic_oracle(f,a,b)
        assert received==exact
    return {"operator":"precomputed exact quadratic area coefficients and exact linear-source integration",
            "sorted_vertex_level_partition": [str(h) for h in levels],
            "quadratic_intervals":len(products),"non_fit_receiver_probe_assertions":probes_verified,
            "all_polynomial_probe_errors_exact_zero":True,
            "nonzero_quadratic_area_coefficients":quadratic_nonzero,
            "nonzero_cubic_integrand_terms":cubic_terms_nonzero,
            "zero_quadratic_mutant": {
                "exercised":f.footprint=="triangle-sw-se-nw",
                "rejected_by_local_oracle":zero_quadratic_mutant!=oracle,
                "receipts":{r:quantity(m) for r,m in zero_quadratic_mutant.items()},
                "absolute_errors":{r:quantity(abs(zero_quadratic_mutant[r]-oracle[r])) for r in f.receivers}},
            "offline_preparation_and_verification_counts":offline_counts,
            "runtime": {"physical_state_updates_executed":0,"source_receipt_batches":1,"algebraic_pieces":len(times)-1,
                        "coefficient_integrations":coefficient_integrations,
                        "affine_triangle_clips":0,"per_piece_point_samples":0},
            "all_receipt_and_local_window_errors_exact_zero":True,
            "receipts":{r:quantity(m) for r,m in masses.items()},
            "coefficients": [{"height_interval":[str(lo),str(hi)],
                              "normalized_height_polynomials":{r:[str(v) for v in cs] for r,cs in coeffs.items()}}
                             for lo,hi,coeffs in products],
            "scope":"offline polynomial proof; no runtime float coefficient/certificate, physical response or engine implementation"}


class TransactionLedger:
    """Scoped offline model, not an implementation of W1/C09 publication."""
    def __init__(self):
        self.total: dict[str, Q] = {}
        self.applied: dict[str, str] = {}
        self.tick = 0

    def snapshot(self) -> bytes:
        return canonical({"total": {k: str(v) for k, v in self.total.items()},
                          "applied": self.applied, "tick": self.tick})

    def commit(self, f: Fixture, n: int, absolute: Q, relative: Q,
               dependency_ready: bool) -> str:
        # The only public commit path recomputes/checks the numerical and slice
        # certificate before readiness can permit publication.
        c=candidate(f,n)
        certificate=evaluate(f,n,absolute,relative,c)
        if certificate["admission"]!="Accepted":
            return certificate["admission"]
        # Numerical partition and tolerance are evaluation choices, not new
        # physical deliveries. Equivalent partitions canonically aggregate to
        # the same receiver payload for this one source/stream/time interval.
        batch_id=digest_bytes(canonical({"stream":"proof-world/direct-rain/first-hit",
                                        "source_revision":f.source_digest,
                                        "physical_interval_world_s":[str(f.start),str(f.end)]}))
        payload=digest_bytes(canonical({r:str(m) for r,m in sorted(c.receipts.items())}))
        if batch_id in self.applied:
            return "AlreadyApplied" if self.applied[batch_id]==payload else "ReceiptIdentityConflict"
        if not dependency_ready:
            return "RejectedDependencyBeforeCommit"
        staged=self.total.copy()
        for receiver,mass in c.receipts.items():
            assert mass>=0
            staged[receiver]=staged.get(receiver,Q(0))+mass
        self.total,self.applied=staged,{**self.applied,batch_id:payload}
        self.tick+=1
        return "Committed"


def retry_check(valid: Fixture, over_budget: Fixture, source_off: Fixture, varying: Fixture,
                absolute: Q, relative: Q) -> dict:
    ledger=TransactionLedger()
    before=ledger.snapshot()
    error_reject=ledger.commit(over_budget,1,absolute,relative,True)
    assert error_reject=="RejectedErrorBudgetBeforeCommit"
    assert ledger.snapshot()==before
    slice_reject=ledger.commit(valid,32,absolute,relative,True)
    assert slice_reject=="RejectedSliceCapBeforeCommit"
    assert ledger.snapshot()==before
    dependency_reject=ledger.commit(valid,1,absolute,relative,False)
    assert dependency_reject=="RejectedDependencyBeforeCommit"
    assert ledger.snapshot()==before
    accepted=ledger.commit(valid,1,absolute,relative,True)
    expected=candidate(valid,1).receipts
    after=ledger.snapshot()
    duplicate=ledger.commit(valid,1,absolute,relative,True)
    assert accepted=="Committed" and duplicate=="AlreadyApplied"
    assert ledger.snapshot()==after and ledger.total==expected and ledger.tick==1
    cross_partition=ledger.commit(valid,2,absolute*2,relative*2,True)
    assert candidate(valid,1).receipts==candidate(valid,2).receipts
    assert cross_partition=="AlreadyApplied" and ledger.snapshot()==after
    tolerance_only=ledger.commit(valid,1,absolute*3,relative*3,True)
    assert tolerance_only=="AlreadyApplied" and ledger.snapshot()==after
    # Both slow-shore candidates satisfy numerical/slice admission, but their
    # aggregate receiver masses differ. Repartitioning cannot deposit again.
    conflict_ledger=TransactionLedger()
    varying_first=conflict_ledger.commit(varying,1,absolute,relative,True)
    conflict_before=conflict_ledger.snapshot()
    varying_next=conflict_ledger.commit(varying,2,absolute*2,relative*2,True)
    varying_one=candidate(varying,1).receipts
    varying_two=candidate(varying,2).receipts
    assert evaluate(varying,1,absolute,relative)["profile_accepted"]
    assert evaluate(varying,2,absolute*2,relative*2)["profile_accepted"]
    assert varying_one!=varying_two
    assert varying_first=="Committed" and varying_next=="ReceiptIdentityConflict"
    assert conflict_ledger.snapshot()==conflict_before and conflict_ledger.tick==1
    assert conflict_ledger.total==varying_one
    off_ledger=TransactionLedger()
    off_commit=off_ledger.commit(source_off,1,absolute,relative,True)
    off_after=off_ledger.snapshot()
    off_duplicate=off_ledger.commit(source_off,1,absolute,relative,True)
    assert off_commit=="Committed" and off_duplicate=="AlreadyApplied"
    assert off_ledger.tick==1 and sum(off_ledger.total.values())==0
    assert off_ledger.snapshot()==off_after
    return {"public_gate":"same evaluate numerical/slice certificate as results before dependency/publication",
            "ready_over_budget_candidate":error_reject,
            "ready_over_slice_cap_candidate":slice_reject,
            "valid_dependency_missing":dependency_reject,
            "valid_retry":accepted,"valid_duplicate":duplicate,
            "committed_tick_count":ledger.tick,
            "delivery_identity_fields":["stream","source_revision","physical_interval_world_s"],
            "payload_digest":"canonical aggregated exact per-receiver mass; independent of N and tolerance",
            "equivalent_cross_N_and_tolerance":{
                "fixture":valid.case_id,"first_N":1,"retry_N":2,
                "retry_outcome":cross_partition,"tolerance_only_retry":tolerance_only,
                "state_unchanged":True,"committed_total":quantity(sum(ledger.total.values())),
                "committed_tick_count":ledger.tick},
            "conflicting_cross_N_and_tolerance":{
                "fixture":varying.case_id,"first_N":1,"retry_N":2,
                "both_candidates_numerically_admitted":True,"retry_outcome":varying_next,
                "first_receipts":{r:quantity(m) for r,m in varying_one.items()},
                "retry_receipts":{r:quantity(m) for r,m in varying_two.items()},
                "state_unchanged":True,"committed_tick_count":conflict_ledger.tick},
            "all_rejections_preserve_state":True,"duplicate_preserves_state":True,
            "source_off_commit":off_commit,"source_off_duplicate":off_duplicate,
            "source_off_committed_ticks":off_ledger.tick,
            "scope":"single-thread offline gate/idempotence and cross-partition aggregate conflict model; no C09 runtime, concurrency, persistence or arbitrary wire-payload qualification"}


def evaluate(f: Fixture, n: int, absolute: Q, relative: Q, c: Candidate | None = None) -> dict:
    c = candidate(f, n) if c is None else c
    exact, oracle_pieces = analytic_oracle(f)
    receivers = {}
    for r in f.receivers:
        error = abs(c.receipts[r]-exact[r])
        tol = absolute+relative*exact[r]
        assert error <= c.bounds[r]
        receivers[r] = {"candidate": quantity(c.receipts[r]), "oracle": quantity(exact[r]),
                        "absolute_error": quantity(error), "certified_bound": quantity(c.bounds[r]),
                        "tolerance": quantity(tol), "actual_meets": error <= tol,
                        "bound_meets": c.bounds[r] <= tol}
    local = []
    for key, ca in c.windows.items():
        a, b = map(Q, key[1:-1].split(","))
        ea, _ = analytic_oracle(f, a, b)
        for r in f.receivers:
            err = abs(ca[r]-ea[r])
            bound = c.window_bounds[key][r]
            tol = absolute+relative*ea[r]
            assert err <= bound, (f.case_id, n, key, r, err, bound)
            local.append({"window": key, "receiver": r, "candidate": quantity(ca[r]),
                          "oracle": quantity(ea[r]), "absolute_error": quantity(err),
                          "bound": quantity(bound), "tolerance": quantity(tol),
                          "actual_meets": err <= tol, "bound_meets": bound <= tol})
    expected = f.source_integral(f.start, f.end)*f.area
    assert sum(c.receipts.values()) == expected
    error_met = all(v["bound_meets"] for v in receivers.values()) and all(v["bound_meets"] for v in local)
    slice_met = c.counts["slices"] <= 16
    return {"requested_slices": n, "actual_slices": c.counts["slices"],
            "receivers": receivers, "local_windows": local,
            "total_candidate_kg": quantity(sum(c.receipts.values())),
            "exact_partition_and_total": True,
            "actual_all_local_meets": all(v["actual_meets"] for v in receivers.values()) and all(v["actual_meets"] for v in local),
            "certified_all_local_meets": all(v["bound_meets"] for v in receivers.values()) and all(v["bound_meets"] for v in local),
            "profile_slice_cap": 16, "slice_cap_met": slice_met,
            "profile_accepted": error_met and slice_met,
            "admission": ("RejectedSliceCapBeforeCommit" if not slice_met else
                          "Accepted" if error_met else "RejectedErrorBudgetBeforeCommit"),
            "counts": {**c.counts, "oracle_analytic_pieces": oracle_pieces},
            "counter_scope":"candidate clipping/source work incl cached reporting-window integrals; excludes oracle, admission recomputation, formatting and I/O"}


def main() -> None:
    fixture_path = ROOT/"fixtures.json"
    raw = json.loads(fixture_path.read_text())
    fixtures = read_fixtures(raw)
    abs_tol, rel_tol = Q(raw["tolerance"]["absolute_kg"]), Q(raw["tolerance"]["relative_local_reference"])
    cases = []
    for f in fixtures:
        rows = [evaluate(f, n, abs_tol, rel_tol) for n in raw["slice_requests"]]
        cases.append({"id": f.case_id, "fixture_digest": f.source_digest, "runs": rows,
                      "first_certified_requested_N": next((r["requested_slices"] for r in rows if r["certified_all_local_meets"]), None),
                      "first_profile_accepted_N": next((r["requested_slices"] for r in rows if r["profile_accepted"]), None),
                      "interval_kind": "one 1/60s tick" if f.case_id.startswith("one-tick") else "stress/control proof window; not an F1 tick claim",
                      "exact_affine_time": exact_affine_time_candidate(f),
                      "polynomial_time": polynomial_time_candidate(f)})
    pulse = next(f for f in fixtures if f.case_id == "rise-fall-identical-endpoints")
    bad = candidate(pulse, 1, mandatory_knots=False)
    exact, _ = analytic_oracle(pulse)
    assert pulse.height(pulse.start) == pulse.height(pulse.end) == 0
    assert bad.endpoint_only_bounds[WATER] == 0
    assert bad.receipts[WATER] == 0 < exact[WATER]
    assert abs(bad.receipts[WATER]-exact[WATER]) <= bad.bounds[WATER]
    rejected_fixtures=[]
    for invalid in raw["rejected_cases"]:
        try:
            read_fixtures({**raw,"cases":[invalid]})
        except AssertionError as error:
            assert str(error)=="cover must be strictly above bank at both footprint endpoints"
            rejected_fixtures.append({"id":invalid["id"],"outcome":"RejectedSourceGeometry",
                                      "reason":str(error),"input_digest":digest_bytes(canonical(invalid))})
        else:
            raise AssertionError("falsifying lower/intersecting cover unexpectedly admitted")
    retry=retry_check(next(f for f in fixtures if f.case_id=="zero-area-bank-tie"),
                      next(f for f in fixtures if f.case_id=="planar-rise-constant"),
                      next(f for f in fixtures if f.case_id=="source-off-entire-interval"),
                      next(f for f in fixtures if f.case_id=="one-tick-slow-shore"),
                      abs_tol,rel_tol)
    tie = next(f for f in fixtures if f.case_id == "zero-area-bank-tie")
    assert tie.height(Q(0)) == tie.slope*Q(1)
    assert not tie.height(Q(0)) > tie.slope*Q(1)  # strict point ownership: dry bank
    checks = {"identical_endpoint_counterexample": {
        "start_end_height": "0", "candidate_water": quantity(bad.receipts[WATER]),
        "oracle_water": quantity(exact[WATER]), "local_water_error": quantity(abs(bad.receipts[WATER]-exact[WATER])),
        "incorrect_endpoint_only_bound": quantity(bad.endpoint_only_bounds[WATER]),
        "certified_interior_envelope_bound": quantity(bad.bounds[WATER]),
        "endpoint_only_bound_is_unsafe": True},
        "zero_area_tie_point": {"x": "1", "height": "1/20", "owner": BANK,
                                "area_mass_invariant": True},
        "actual_admission_retry_model":retry,
        "rejected_source_fixtures":rejected_fixtures,
        "coverage": "all exact triangle partitions sum to domain horizontal area",
        "source_off": "zero mass receipts still advance the once-only batch cursor",
        "scope": "first-hit offline model only; no finite-water/film/C09 runtime qualification"}
    result = {"schema": "moving-shore-first-hit-results-v1", "arithmetic": "exact fractions; no float comparison decides pass/fail",
              "candidate": "prepared triangle affine clipping; frozen-start; stage knots mandatory; exact source integrals",
              "oracle": "independent authored strip-length and triangular width-integral area laws; exact area-time polynomial integration",
              "tolerance": raw["tolerance"], "cases": cases, "checks": checks}
    (ROOT/"results.json").write_text(json.dumps(result, indent=2, sort_keys=True)+"\n")
    summary = ["# Offline moving-shore first-hit proof result", "", "Exact rational first-hit/identity proof only; no finite-water, film exchange or C09 runtime qualification.", "",
               "Candidate: prepared triangle atoms + affine spatial clipping + frozen-start temporal assignment. Oracle: independent analytic interval-length/area-time integration. All comparisons use fractions.", "",
               "Admission requires the conservative bound, not merely the observed signed error, to fit `1e-5 kg + 0.001 × local reference mass` for each receiver and each stage/source reporting window. The design cap stays 16 slices per tick: all N>16 runs are diagnostic and reject that profile, even if their mass error meets the request.", "",
               "| Fixture | First tested N whose bound meets every local request | Actual slices | Clips at that N |", "| --- | ---: | ---: | ---: |"]
    for case in cases:
        chosen = next((r for r in case["runs"] if r["certified_all_local_meets"]), None)
        summary.append(f"| {case['id']} | {case['first_certified_requested_N'] if chosen else 'none ≤2048'} | {chosen['actual_slices'] if chosen else '—'} | {chosen['counts']['affine_triangle_clips'] if chosen else '—'} |")
    summary += ["", "The 1s/2s full-shore sweeps are deliberately large proof windows, not ordinary 60 Hz motion. The one-tick slow-shore case advances stage by 0.1 mm over 1/60 s (0.006 m/s stage speed) and certifies N=1. The fast-heavy case sweeps 0.1 m over 1/60 s (6 m/s stage speed) at 100 mm/h: it requires N=128 and therefore **fails the 16-slice profile**. This does not authorize increasing that cap.", "",
                "The precomputed-polynomial variant explicitly verifies quadratic area laws on every sorted triangle-vertex height interval using 8 non-fit probes (exact fractions), and integrates the resulting coefficient×linear-flux product analytically. It also matches every oracle receiver/local window exactly, with 0 runtime triangle clips or point samples; preparation/verification and runtime coefficient counts are separate in results. This removes repeated clipping for the covered affine source regime, but no f64 product/error certificate is tested.", "", "The exact-affine-time alternative agrees exactly with the independent oracle for every receiver and every reporting window in all fixtures. It prepares the same triangle atoms, splits only integration algebra at source/stage/triangle-vertex crossing events, and uses an exact cubic3/8 rule. It computes one source receipt batch with bounded internal algebraic integration pieces, without requiring more physical updates for that calculation. It executes no physical material/water update and does not establish that one such update suffices across crossings. For planar affine stage this is the preferred source-integration direction rather than brute-force frozen-start slices. Results retain its operation counts and receipts.", "", "All tested runs conserve the complete source mass exactly and preserve roof/bridge/export identities. This does not imply local allocation accuracy: admitted N varies by fixture. Identical-endpoint rise/fall without interior stage knots gives water receipt 0 versus oracle 1/180 kg; its naive endpoint-only bound is incorrectly 0, while the certified interior envelope bound is 1/90 kg.", "",
                "Source-knot/off integration, zero-area strict point tie, exact partition coverage and numerically gated reject/retry/duplicate model checks pass. Equivalent cross-N/tolerance deliveries deduplicate, while numerically admitted changed aggregate receipts conflict before mutation; arbitrary wire-payload handling is not tested. Roof/bridge undersides and roof-covered floor receive zero direct rain. Their inundation/film behavior is outside this proof.", "",
                "Operation counts are scoped candidate counters, not full-program or runtime benchmarks. Source segment tests/integrals include cached reporting-window requests; validation/oracle, admission recomputation, formatting and I/O are excluded. Results include local window receipts so opposite rising/falling errors cannot cancel into a misleading full-interval success. A rejected error budget leaves the toy ledger untouched; successful retry commits once. This is not concurrency, persistence or engine-transaction validation.", "",
                "Reproduce with `python3 -B tmp/moving-shore-rain-proof/proof.py`. Manifest records exact editable source/fixture/result hashes and Python binary/version. No dependency downloads or cache output."]
    triangle=next(c for c in cases if c["id"]=="triangular-response-cubic")
    tp=triangle["polynomial_time"]
    summary += ["", "Audit follow-ups: two falsifying cover-below/intersects-bank fixtures are rejected before candidate/oracle preparation by checking the bank height at both cover endpoints. The admitted roof/bridge profile also remains above every stage, so this proof does not establish arbitrary overlapping/overtopped solids.", "",
                "The separately identified triangular response footprint has independently derived wet area `20H−100H²` on 0<H<0.1 m, total area 1 m², and linear varying rain. It crosses both vertex levels and source/stage knots. Two nonzero quadratic receiver coefficients and nonzero cubic integrand terms are asserted; deleting the quadratic coefficients is rejected by local oracle receipts. This corrects the earlier strip-only proof, whose aggregate quadratic coefficients were all zero.", "",
                f"Triangle exact receipts: water {tp['receipts'][WATER]['rational']} kg; triangular solid {tp['receipts']['solid:triangular-response']['rational']} kg. Its zero-quadratic mutant errors are in results. All other cases remain controls.", "",
                "The public toy commit function now executes the same numerical/slice gate used in results. A dependency-ready over-budget candidate and an over-cap candidate reject without advancing state; a numerically valid missing-dependency candidate then retries/duplicates with exactly one commit. Zero-input commit likewise advances once. Delivery identity is source revision + stream + physical interval, excluding N/tolerance; canonical aggregated per-receiver masses define the payload digest. The constant-mask N=1→N=2/tolerance retry retains total 1/180 kg and one commit. A slow-shore N=1→N=2 retry has two numerically admissible but different aggregate payloads and returns ReceiptIdentityConflict without mutation. This does not validate a concurrent/persistent engine transaction."]
    summary += ["", "| Fixture | Frozen N=16 clips | Frozen N=16 admission | Exact polynomial pieces / coefficient integrations |",
                "| --- | ---: | --- | ---: |"]
    for case in cases:
        coarse=next(r for r in case["runs"] if r["requested_slices"]==16)
        pc=case["polynomial_time"]["runtime"]
        summary.append(f"| {case['id']} | {coarse['counts']['affine_triangle_clips']} | {coarse['admission']} | {pc['algebraic_pieces']} / {pc['coefficient_integrations']} |")
    summary += ["", "Polynomial preparation and its non-fit verification use clipping offline; those counts are retained separately and are not hidden in runtime 0-clips claims. A future floating-point implementation must certify coefficient reconstruction and integration arithmetic before inheriting these exact-rational results."]
    (ROOT/"SUMMARY.md").write_text("\n".join(summary)+"\n")
    artifacts = ["proof.py", "fixtures.json", "results.json", "SUMMARY.md", "README.md"]
    executable = Path(sys.executable).resolve()
    manifest = {"schema": "moving-shore-proof-manifest-v1", "python": {"version": sys.version,
                "implementation": platform.python_implementation(), "executable": str(executable),
                "sha256": digest_bytes(executable.read_bytes())}, "dependencies": "Python standard library only",
                "artifacts": {name: {"sha256": digest_bytes((ROOT/name).read_bytes()), "bytes": (ROOT/name).stat().st_size} for name in artifacts},
                "source_provenance": "commissioned original offline prototype; fixture mathematical definitions in fixtures.json",
                "cache": "none; run with -B", "durability": "ignored scratch until root promotion"}
    (ROOT/"manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n")
    print("All exact assertions passed.")
    for case in cases:
        print(f"{case['id']}: first certified tested N={case['first_certified_requested_N']}; profile accepted N={case['first_profile_accepted_N']}; exact integration pieces={case['exact_affine_time']['algebraic_integration_pieces']}")
    print(f"Retained bytes: {sum(p.stat().st_size for p in ROOT.iterdir() if p.is_file())}")


if __name__ == "__main__":
    main()
