# Original author's f64 translation of the closed cohort update; no exact oracle calls.
from dataclasses import dataclass
from fractions import Fraction
import math

def Q(x=0):return float(Fraction(x)) if isinstance(x,str) else float(x)
def scalar(x):return Q(x)
WORK={"cohort_visits":0,"geometric_integrals":0}
KINDS=("solid-rain","direct-water-rain","refill","release","deposition")

@dataclass(frozen=True)
class L:
    c:Q=Q(0)
    m:Q=Q(0)
    def at(self,h):return self.c+self.m*h
    def __add__(self,b):
        b=b if isinstance(b,L) else L(scalar(b));return L(self.c+b.c,self.m+b.m)
    __radd__=__add__
    def __neg__(self):return L(-self.c,-self.m)
    def __sub__(self,b):return self+-aslin(b)
    def __rsub__(self,b):return aslin(b)+-self
    def __mul__(self,a):return L(self.c*a,self.m*a)
    __rmul__=__mul__
    def __truediv__(self,a):return self*(Q(1)/a)
    def root(self):
        if not self.m:return None
        r=-self.c/self.m
        if not math.isfinite(r):raise ArithmeticError("nonfinite candidate root")
        return r


def aslin(x):return x if isinstance(x,L) else L(scalar(x))


@dataclass(frozen=True)
class C:
    lo:Q
    hi:Q
    q:L


def polygon_area(v):
    return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(v,v[1:]+v[:1])))/2 if len(v)>2 else Q(0)


def geom_moments(vertices,H):
    # Candidate preparation: binary64 polygon clipping + fan first moments.
    out=[]
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        fa,fb=H-a[0]/20,H-b[0]/20
        if fa>=0:out.append(a)
        if (fa>=0)!=(fb>=0):
            t=fa/(fa-fb);out.append(tuple(x+t*(y-x) for x,y in zip(a,b)))
    if len(out)<3:return Q(0),Q(0)
    A=M=Q(0)
    for i in range(1,len(out)-1):
        tri=(out[0],out[i],out[i+1]);a=polygon_area(tri)
        A+=a;M+=a*sum(p[0]/20 for p in tri)/3
    return A,M


def integrate(vertices,lo,hi,q):
    WORK["geometric_integrals"]+=1
    a,m=geom_moments(vertices,lo);b,n=geom_moments(vertices,hi)
    return q.c*(b-a)+q.m*(n-m)


def normalized(pieces):
    out=[]
    for p in pieces:
        assert p.lo<p.hi
        assert min(p.q.at(p.lo),p.q.at(p.hi))>=0
        if out and out[-1].hi==p.lo and out[-1].q==p.q:
            out[-1]=C(out[-1].lo,p.hi,p.q)
        else:out.append(p)
    return out


def split_bounds(p,extra):
    return sorted({p.lo,p.hi,*[r for r in extra if r is not None and p.lo<r<p.hi]})


def advance(vertices,pieces,h0,h1,dt,P,K,cap,eligible=True):
    out=[];receipts={k:Q(0) for k in KINDS};v=(h1-h0)/dt;P=P*int(eligible)
    for p in pieces:
        WORK["cohort_visits"]+=1
        boundaries=split_bounds(p,(h0,h1))
        for a,b in zip(boundaries,boundaries[1:]):
            h=(a+b)/2;start_wet=h<h0;end_wet=h<h1
            if start_wet and end_wet:wet=L(dt)
            elif not start_wet and not end_wet:wet=L()
            elif v>0:wet=L(h1/v,-1/v)
            else:wet=L(h0/(-v),-1/(-v))
            dry=L(dt)-wet
            if not start_wet and end_wet:
                pre=p.q+P*dry;full=pre+K*wet
                roots=((pre-cap).root(),(full-cap).root())
                mode="rise"
            elif start_wet:
                full=p.q+K*wet;roots=((full-cap).root(),);mode="wet"
            else:full=p.q+P*dry;roots=();mode="dry"
            for x,y in zip((cuts:=split_bounds(C(a,b,p.q),roots)),cuts[1:]):
                m=(x+y)/2;released=L();refilled=L()
                if mode=="rise":
                    released=pre-cap if pre.at(m)>cap else L()
                    q=L(cap) if full.at(m)>cap else full
                    refilled=q-pre+released
                elif mode=="wet":
                    retained=L(cap) if full.at(m)>cap else full
                    refilled=retained-p.q;q=retained+P*dry
                else:q=full
                out.append(C(x,y,q))
                for kind,density in (("solid-rain",P*dry),("direct-water-rain",P*wet),
                                     ("refill",refilled),("release",released)):
                    receipts[kind]+=integrate(vertices,x,y,density)
    return normalized(out),receipts


def deposit(vertices,pieces,stage,lo,hi,density,cap):
    out=[];receipts={k:Q(0) for k in KINDS}
    for p in pieces:
        for a,b in zip((cuts:=split_bounds(p,(lo,hi,stage))),cuts[1:]):
            m=(a+b)/2;d=density if lo<=m<hi else L();full=p.q+d
            roots=((full-cap).root(),) if m<stage else ()
            for x,y in zip((more:=split_bounds(C(a,b,p.q),roots)),more[1:]):
                at=(x+y)/2;released=full-cap if at<stage and full.at(at)>cap else L()
                out.append(C(x,y,full-released))
                receipts["deposition"]+=integrate(vertices,x,y,d)
                receipts["release"]+=integrate(vertices,x,y,released)
    return normalized(out),receipts


def endpoints(vertices,pieces,stage):
    film=coating=Q(0)
    for p in pieces:
        if p.lo<min(p.hi,stage):coating+=integrate(vertices,p.lo,min(p.hi,stage),p.q)
        if max(p.lo,stage)<p.hi:film+=integrate(vertices,max(p.lo,stage),p.hi,p.q)
    return dict(film=film,coating=coating,total=film+coating)


