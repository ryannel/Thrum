# Restricted f64 cohort certificate experiment

Owner `/root/environment_research`, 3 November 2026. Scope: this directory and the f64 certificate research report. Original f64 candidate + outward-rounded interval-affine verifier; copied exact oracle is pinned to the selected true-area archive. Python stdlib only; expected retained disk below 2 MiB; no bulk assets or caches.

Run `python3 -B tmp/moving-shore-f64/proof.py`. Exact Q(sqrt401) is used only to falsify interval claims/results, never to build the acceptance envelope. This is bounded fresh-history verification, not a shipping f64 runtime, general saved-state certificate, waves, finite water or P7 proof. Keep failed/refused cases. Root owns evidence promotion. Ignored scratch is not a durable backup.
