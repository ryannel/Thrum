#!/usr/bin/env python3
"""A posteriori interval-affine certificate, exact oracle only as falsifier."""
from dataclasses import dataclass
from fractions import Fraction as Q
from pathlib import Path
from hashlib import sha256
import importlib.util
import json
import math
import heapq
import platform
import sys
import time

ROOT=Path(__file__).resolve().parent
KINDS=("solid-rain","direct-water-rain","refill","release","deposition")
COUNT={"interval_ops":0,"panels":0,"ambiguous_caps":0}
INF=float("inf")


class Refuse(Exception):pass


def module(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m


exact=module("f64_exact_reference",ROOT/"exact_reference.py")
fc=module("f64_candidate",ROOT/"float_candidate.py")


def dn(x):
    if not math.isfinite(x):raise Refuse("nonfinite interval operation")
    return math.nextafter(x,-INF)


def up(x):
    if not math.isfinite(x):raise Refuse("nonfinite interval operation")
    return math.nextafter(x,INF)


@dataclass(frozen=True)
class I:
    lo:float=0.
    hi:float=0.
    def __post_init__(self):
        if not math.isfinite(self.lo) or not math.isfinite(self.hi) or self.lo>self.hi:raise Refuse("invalid interval")
    @staticmethod
    def q(x):
        x=Q(x);f=float(x);r=Q.from_float(f)
        return I(f if r<=x else dn(f),f if r>=x else up(f))
    @staticmethod
    def point(x):return I(x,x)
    def __add__(self,b):
        b=iv(b);COUNT["interval_ops"]+=1
        if self.lo==self.hi==0:return b
        if b.lo==b.hi==0:return self
        return I(dn(self.lo+b.lo),up(self.hi+b.hi))
    __radd__=__add__
    def __neg__(self):return I(-self.hi,-self.lo)
    def __sub__(self,b):return self+-iv(b)
    def __rsub__(self,b):return iv(b)+-self
    def __mul__(self,b):
        b=iv(b);COUNT["interval_ops"]+=1
        if self.lo==self.hi==0 or b.lo==b.hi==0:return I()
        v=[a*c for a in (self.lo,self.hi) for c in (b.lo,b.hi)]
        return I(dn(min(v)),up(max(v)))
    __rmul__=__mul__
    def __truediv__(self,b):
        b=iv(b);COUNT["interval_ops"]+=1
        if b.lo<=0<=b.hi:raise Refuse("division interval contains zero")
        return self*I(dn(1/b.hi),up(1/b.lo))
    def __rtruediv__(self,b):return iv(b)/self
    @property
    def width(self):return up(self.hi-self.lo)


def iv(x):return x if isinstance(x,I) else I.q(x)


def beta_interval():
    s=math.sqrt(401.);lo,hi=s,s
    for _ in range(8):
        if Q.from_float(lo)**2<=401<=Q.from_float(hi)**2:return I(lo,hi)/20
        if Q.from_float(lo)**2>401:lo=dn(lo)
        if Q.from_float(hi)**2<401:hi=up(hi)
    raise Refuse("sqrt enclosure refinement exhausted")


BETA=beta_interval()


@dataclass(frozen=True)
class A:
    c:I=I()
    m:I=I()
    def at(self,h):return self.c+self.m*h
    def __add__(self,b):
        b=af(b);return A(self.c+b.c,self.m+b.m)
    __radd__=__add__
    def __neg__(self):return A(-self.c,-self.m)
    def __sub__(self,b):return self+-af(b)
    def __mul__(self,b):return A(self.c*iv(b),self.m*iv(b))
    __rmul__=__mul__
    def __truediv__(self,b):return A(self.c/iv(b),self.m/iv(b))


def af(x):return x if isinstance(x,A) else A(iv(x))


def amin(a,b,h):
    d=(a-b).at(h)
    if d.hi<=0:return a
    if d.lo>=0:return b
    COUNT["ambiguous_caps"]+=1
    aa,bb=a.at(h),b.at(h)
    return A(I(min(aa.lo,bb.lo),min(aa.hi,bb.hi)))


def compile_source(case):
    barriers={Q(d[0]) for d in case.get("deposits",[])};out=[]
    for row in case["segments"]:
        s=tuple(map(Q,row))
        if out:
            p=out[-1]
            if p[1]==s[0] and s[0] not in barriers and p[3]==s[2] and p[4:]==s[4:] and (p[3]-p[2])/(p[1]-p[0])==(s[3]-s[2])/(s[1]-s[0]):
                out[-1]=(p[0],s[1],p[2],s[3],p[4],p[5]);continue
        out.append(s)
    if len(out)>16:raise Refuse("fresh-history source span cap")
    return dict(case,segments=out)


def nominal(case,mutant=None):
    case=compile_source(case);vertices=tuple(tuple(float(Q(x)) for x in p) for p in case["vertices"])
    beta=math.sqrt(401.)/20
    material_beta=1. if mutant=="omit-material-metric" else beta
    lo,hi=min(x/20 for x,z in vertices),max(x/20 for x,z in vertices)
    pieces=[fc.C(lo,hi,fc.L(float(Q(case["initial"]))*material_beta))]
    totals={k:0. for k in KINDS};peak=1
    for ta,tb,ha,hb,P,K in case["segments"]:
        P=float(P)*(beta if mutant=="scale-rain-by-metric" else 1.)
        pieces,flow=fc.advance(vertices,pieces,float(ha),float(hb),float(tb-ta),P,float(K)*material_beta,float(Q(case["cap"]))*material_beta,case.get("eligible",True))
        for d in case.get("deposits",[]):
            when,a,b,c,m=map(Q,d)
            if when==tb:
                pieces,r=fc.deposit(vertices,pieces,float(hb),float(a),float(b),fc.L(float(c)*material_beta,float(m)*material_beta),float(Q(case["cap"]))*material_beta)
                for k in KINDS:flow[k]+=r[k]
        peak=max(peak,len(pieces))
        if peak>8:raise Refuse("candidate cohort cap")
        for k in KINDS:totals[k]+=flow[k]
    state=fc.endpoints(vertices,pieces,float(case["segments"][-1][3]))
    if mutant=="drop-release":totals["release"]=0.
    if any(not math.isfinite(x) or x<0 for x in [*state.values(),*totals.values()]):raise Refuse("candidate negative/nonfinite mass")
    return dict(state=state,flows=totals,pieces=pieces,peak=peak)


def point_affine(case,a,b):
    # Independent time-event replay with interval-affine values on this source
    # height panel. Geometric branches are proven from rational source cuts.
    h=I(I.q(a).lo,I.q(b).hi);H=A(I(),I.point(1.));q=A(BETA*Q(case["initial"]));C=A(BETA*Q(case["cap"]));flow={k:A() for k in KINDS}
    for ta,tb,ha,hb,P,K in case["segments"]:
        P=I.q(P)*int(case.get("eligible",True));K=BETA*K
        start_wet=b<=ha;end_wet=b<=hb
        if not(start_wet or a>=ha) or not(end_wet or a>=hb):raise Refuse("panel missed source height cut")
        times=[A(I.q(ta)),A(I.q(tb))]
        if start_wet!=end_wet:
            speed=I.q((hb-ha)/(tb-ta));times.insert(1,(H-ha)/speed+ta)
        mode=start_wet
        for j,(x,y) in enumerate(zip(times,times[1:])):
            if j:mode=end_wet
            dt=y-x
            if mode:
                if j and not start_wet:
                    retained=amin(q,C,h);flow["release"]+=q-retained;q=retained
                retained=amin(q+dt*K,C,h);flow["refill"]+=retained-q;q=retained
                flow["direct-water-rain"]+=dt*P
            else:q+=dt*P;flow["solid-rain"]+=dt*P
        for dep in case.get("deposits",[]):
            t,lo,hi,d0,dm=map(Q,dep)
            if t==tb and a>=lo and b<=hi:
                d=A(BETA*d0,BETA*dm);q+=d;flow["deposition"]+=d
                if end_wet:
                    retained=amin(q,C,h);flow["release"]+=q-retained;q=retained
    return q,flow


def width_pieces(vertices):
    (a,z0),(b,z1),(c,z2)=sorted((Q(x)/20,Q(z)) for x,z in vertices)
    w=abs(z1-(z0+(z2-z0)*(b-a)/(c-a)));out=[]
    if b>a:out.append((a,b,-20*w*a/(b-a),20*w/(b-a)))
    if c>b:out.append((b,c,20*w*c/(c-b),-20*w/(c-b)))
    return out


def integrate(q,a,b,w0,w1):
    # Positive source moments make integration sound even when min() returned
    # a pointwise affine enclosure rather than one fixed affine function.
    assert a>=0 and w0+w1*a>=0 and w0+w1*b>=0
    l=I.q(a);d=I.q(b-a);w=I.q(w0)+I.q(w1)*l
    M0=d*w+I.q(w1)*(d*d/2)
    M1=l*M0+d*d*w/2+I.q(w1)*(d*d*d/3)
    # These intersections use proved source geometry, not clipped mass.
    M0=I(max(0.,M0.lo),max(0.,M0.hi));M1=I(max(0.,M1.lo),max(0.,M1.hi))
    return q.c*M0+q.m*M1


def panel(case,a,b,w0,w1,candidate):
    q,flows=point_affine(case,a,b);end=case["segments"][-1][3]
    state=integrate(q,a,b,w0,w1)
    masses={k:integrate(f,a,b,w0,w1) for k,f in flows.items()}
    masses.update(film=state if a>=end else I(),coating=state if b<=end else I())
    # Compare nominal density function with the verified field on the entire
    # panel; all candidate boundaries are initial partition cuts.
    mid=(a+b)/2;p=next((p for p in candidate["pieces"] if Q.from_float(p.lo)<=mid<=Q.from_float(p.hi)),None)
    if p is None:raise Refuse("candidate source support mismatch")
    delta=A(I.point(p.q.c),I.point(p.q.m))-q
    d=delta.at(I(I.q(a).lo,I.q(b).hi));area=integrate(A(I.point(1.)),a,b,w0,w1)
    field_bound=up(max(abs(d.lo),abs(d.hi))*max(0.,area.hi))
    min_abs=d.lo if d.lo>0 else -d.hi if d.hi<0 else 0.
    field_lower=max(0.,dn(min_abs*max(0.,area.lo))) if min_abs else 0.
    width=sum(x.width for x in masses.values())
    return masses,field_bound,width,field_lower


def certificate(case,candidate,tolerance=1e-7,panel_cap=4096):
    case=compile_source(case);cuts={Q(x)/20 for x,z in case["vertices"]}
    lo,hi=min(cuts),max(cuts)
    cuts.update(h for s in case["segments"] for h in s[2:4] if lo<h<hi)
    cuts.update(Q(d[j]) for d in case.get("deposits",[]) for j in (1,2) if lo<Q(d[j])<hi)
    cuts.update(Q.from_float(x) for p in candidate["pieces"] for x in (p.lo,p.hi) if lo<Q.from_float(x)<hi)
    ordered=sorted(cuts);tasks=[];serial=0;evaluations=0
    for a,b in zip(ordered,ordered[1:]):
        middle=(a+b)/2
        w0,w1=next((c,d) for l,r,c,d in width_pieces(case["vertices"]) if l<=middle<=r)
        tasks.append((a,b,w0,w1))
    heap=[]
    def push(a,b,w0,w1):
        nonlocal serial,evaluations
        evaluations+=1;COUNT["panels"]+=1
        if evaluations>panel_cap:raise Refuse("certificate panel cap")
        masses,error,width,lower=panel(case,a,b,w0,w1,candidate)
        heapq.heappush(heap,(-(width+error),serial,a,b,w0,w1,masses,error,lower));serial+=1
    for args in tasks:push(*args)
    def summary():
        out={k:I() for k in (*KINDS,"film","coating")};field_error=0.
        for _,_,a,b,w0,w1,masses,error,lower in heap:
            for k in out:out[k]=out[k]+masses[k]
            field_error=up(field_error+error)
        return out,field_error
    while sum(-item[0] for item in heap)>tolerance/8:
        out,field_error=summary()
        # A provable mass gap can reject a numerical mutant immediately.
        gap=0.
        for k,v in out.items():
            m=candidate["flows"][k] if k in KINDS else candidate["state"][k]
            term=max(0.,dn(v.lo-m),dn(m-v.hi))
            gap=max(0.,dn(gap+term)) if term else gap
        for item in heap:
            if item[8]:gap=max(0.,dn(gap+item[8]))
        if gap>tolerance:break
        _,_,a,b,w0,w1,_,_,_=heapq.heappop(heap)
        if b-a<=Q(1,2**80):raise Refuse("certificate height refinement floor")
        mid=(a+b)/2;push(a,mid,w0,w1);push(mid,b,w0,w1)
    out,field_error=summary()
    mass_error=0.
    for k,v in out.items():
        nominal_mass=candidate["flows"][k] if k in KINDS else candidate["state"][k]
        term=up(max(abs(nominal_mass-v.lo),abs(nominal_mass-v.hi)))
        mass_error=up(mass_error+term)
    accepted=up(mass_error+field_error)<=tolerance
    return dict(intervals=out,mass_error_bound=mass_error,density_L1_bound=field_error,
                accepted=accepted,evaluations=evaluations,accepted_panels=len(heap),
                tolerance=tolerance,scope="fresh bounded source history only")


def exact_inside(x,interval):
    return exact.S(Q.from_float(interval.lo))<=x<=exact.S(Q.from_float(interval.hi))


def exact_field_L1(case,candidate):
    vertices=tuple(tuple(map(Q,p)) for p in case["vertices"])
    _,_,density=exact.oracle(case,vertices)
    lo,hi=min(Q(x)/20 for x,z in vertices),max(Q(x)/20 for x,z in vertices)
    cuts={exact.S(lo),exact.S(hi)}
    cuts.update(exact.S(Q.from_float(v)) for p in candidate["pieces"] for v in (p.lo,p.hi) if lo<Q.from_float(v)<hi)
    cuts.update(p.lo for p in density);cuts.update(p.hi for p in density)
    cuts=sorted(cuts);total=exact.S()
    for a,b in zip(cuts,cuts[1:]):
        h=(a+b)/2
        p=next(p for p in candidate["pieces"] if exact.S(Q.from_float(p.lo))<=h<=exact.S(Q.from_float(p.hi)))
        truth=next(p.q for p in density if p.lo<=h<=p.hi)
        delta=exact.L(exact.S(Q.from_float(p.q.c)),exact.S(Q.from_float(p.q.m)))-truth
        root=delta.root();parts=[a,b]
        if root is not None and a<root<b:parts.insert(1,root)
        for l,r in zip(parts,parts[1:]):
            signed=delta if delta.at((l+r)/2)>=0 else -delta
            total+=exact.oracle_integral(vertices,l,r,signed)
    return total


def encode(x):
    if isinstance(x,I):return [x.lo,x.hi]
    if isinstance(x,Q):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [encode(v) for v in x]
    return x


def main():
    assert sys.float_info.radix==2 and sys.float_info.mant_dig==53
    assert sys.float_info.min/2>0,"gradual underflow required"
    raw=json.loads((ROOT/"fixtures.json").read_text());rows=[];measurements=[]
    for case in raw["cases"]:
        began=time.perf_counter();before=dict(COUNT)
        reference=exact.run(case,tuple(tuple(map(Q,p)) for p in case["vertices"]))
        exact_seconds=time.perf_counter()-began
        folded=compile_source(case);began=time.perf_counter()
        folded_reference=exact.run(folded,tuple(tuple(map(Q,p)) for p in case["vertices"]))
        exact_folded_seconds=time.perf_counter()-began
        assert reference["state"]==folded_reference["state"] and reference["receipts"]==folded_reference["receipts"]
        start=time.perf_counter();candidate_before=dict(fc.WORK)
        try:
            c=nominal(case);candidate_seconds=time.perf_counter()-start;start=time.perf_counter()
            cert=certificate(case,c);certificate_seconds=time.perf_counter()-start
            result=dict(status="Certified" if cert["accepted"] else "RejectedErrorBudget",certificate=cert,
                        candidate_peak=c["peak"],candidate_state=c["state"],candidate_flows=c["flows"])
        except (Refuse,AssertionError,StopIteration,ArithmeticError) as e:
            result=dict(status="Refused",reason=str(e));candidate_seconds=certificate_seconds=None
        if "certificate" in result:
            for k,i in result["certificate"]["intervals"].items():
                value=reference["receipts"][k] if k in KINDS else reference["state"][k]
                assert exact_inside(value,i),(case["id"],k,value,i)
            field=exact_field_L1(case,c)
            assert field<=exact.S(Q.from_float(cert["density_L1_bound"])),(case["id"],"field bound false")
            actual_mass_error=exact.S()
            for k in cert["intervals"]:
                value=reference["receipts"][k] if k in KINDS else reference["state"][k]
                m=c["flows"][k] if k in KINDS else c["state"][k]
                actual_mass_error+=abs(exact.S(Q.from_float(m))-value)
            assert actual_mass_error<=exact.S(Q.from_float(cert["mass_error_bound"]))
        result.update(id=case["id"],exact_peak=reference["peak_cohorts"],exact_count_refusal=reference["first_eight_cohort_refusal"] is not None,
                      source_spans=len(case["segments"]),compiled_spans=len(folded["segments"]),
                      candidate_work={k:v-candidate_before[k] for k,v in fc.WORK.items()},
                      interval_operations=COUNT["interval_ops"]-before["interval_ops"],ambiguous_caps=COUNT["ambiguous_caps"]-before["ambiguous_caps"])
        measurements.append(dict(id=case["id"],exact_seconds=exact_seconds,exact_folded_seconds=exact_folded_seconds,
                                 candidate_seconds=candidate_seconds,certificate_seconds=certificate_seconds))
        rows.append(result);print(case["id"],result["status"],result.get("reason",result.get("certificate",{}).get("evaluations")),flush=True)
    mutants=[];case=next(c for c in raw["cases"] if c["id"]=="rise-fall-cap-deposition")
    for m in ("omit-material-metric","scale-rain-by-metric","drop-release"):
        try:
            c=nominal(case,m);r=certificate(case,c)
            assert not r["accepted"],m
            mutants.append(dict(mutant=m,status="RejectedErrorBudget"))
        except (Refuse,AssertionError) as e:
            if str(e)==m:raise
            mutants.append(dict(mutant=m,status="Refused",reason=str(e)))
    # Preserve exact total mass and all receipt rows while destroying local
    # density. Only the independently bounded field norm can reject this.
    case=next(c for c in raw["cases"] if c["id"]=="two-A");c=nominal(case)
    area=sum(float((b-a)*(w0+w1*(a+b)/2)) for a,b,w0,w1 in width_pieces(case["vertices"]))
    c["pieces"]=[fc.C(c["pieces"][0].lo,c["pieces"][-1].hi,fc.L(c["state"]["total"]/area))]
    r=certificate(case,c);assert not r["accepted"]
    mutants.append(dict(mutant="same-total-density-remix",status="RejectedFieldBudget"))
    guards=[]
    for label,thunk in (("zero-denominator",lambda:I.point(1.)/I(-1.,1.)),
                        ("nonfinite-operation",lambda:I.point(1e308)*I.point(1e308))):
        try:thunk()
        except Refuse:guards.append(dict(guard=label,status="Refused"))
        else:raise AssertionError(label)
    try:certificate(case,nominal(case),tolerance=1e-30,panel_cap=64)
    except Refuse as e:
        assert str(e)=="certificate panel cap"
        guards.append(dict(guard="tight-budget-panel-limit",status="Refused"))
    else:raise AssertionError("tight-budget-panel-limit")
    assert sum(r["status"]=="Certified" for r in rows)==9
    assert sum(r["status"]=="Refused" for r in rows)==2
    out=dict(schema="f64-cohort-certificate-v1",beta_interval=BETA,cases=rows,mutants=mutants,guards=guards,
             assumptions="binary64 correctly rounded basic ops, gradual underflow, math.nextafter adjacency",
             limitations="not arbitrary saved-state/incremental verification, no waves/finite water")
    (ROOT/"results.json").write_text(json.dumps(encode(out),indent=2,sort_keys=True)+"\n")
    (ROOT/"measurements.json").write_text(json.dumps(measurements,indent=2,sort_keys=True)+"\n")
    exe=Path(sys.executable).resolve();names=["README.md","proof.py","float_candidate.py","exact_reference.py","fixtures.json","results.json","measurements.json"]
    m=dict(python=sys.version,executable=str(exe),executable_sha256=sha256(exe.read_bytes()).hexdigest(),host=platform.platform(),
           exact_archive_sha256="897c5e41a3ccc5aefd3eb2f378d78bb5d234d44cb861191c46b666311d04c9a5",
           artifacts={n:dict(sha256=sha256((ROOT/n).read_bytes()).hexdigest(),bytes=(ROOT/n).stat().st_size) for n in names},
           durability="ignored scratch until review/promotion")
    (ROOT/"manifest.json").write_text(json.dumps(m,indent=2,sort_keys=True)+"\n")


if __name__=="__main__":main()
