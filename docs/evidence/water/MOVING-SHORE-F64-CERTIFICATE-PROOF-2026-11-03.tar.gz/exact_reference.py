#!/usr/bin/env python3
"""Exact source-height P1 cohorts, with independent symbolic point-history oracle."""
from dataclasses import dataclass
from functools import total_ordering
from fractions import Fraction as Q
from hashlib import sha256
from pathlib import Path
import json
import platform
import sys
import time

ROOT=Path(__file__).resolve().parent
KINDS=("solid-rain","direct-water-rain","refill","release","deposition")
WORK={"cohort_visits":0,"geometric_integrals":0,"oracle_point_histories":0}
FIELD_WORK={"operations":0,"order_comparisons":0,"nonrational_roots":0,"max_rational_bits":0}


def scalar(x):return x if isinstance(x,S) else Q(x)


@total_ordering
@dataclass(frozen=True,eq=False)
class S:
    """Canonical a+b*sqrt(401), exact rational pair; never float arithmetic."""
    a:Q=Q(0)
    b:Q=Q(0)
    def __post_init__(self):
        object.__setattr__(self,"a",Q(self.a));object.__setattr__(self,"b",Q(self.b))
        bits=max(abs(v).bit_length() for f in (self.a,self.b) for v in (f.numerator,f.denominator))
        FIELD_WORK["max_rational_bits"]=max(FIELD_WORK["max_rational_bits"],bits)
        if bits>4096:raise ArithmeticError("exact scalar 4096-bit validation cap")
    @staticmethod
    def coerce(x):
        if isinstance(x,S):return x
        if isinstance(x,(Q,int)):return S(Q(x))
        return NotImplemented
    def __add__(self,x):
        x=self.coerce(x)
        if x is NotImplemented:return NotImplemented
        FIELD_WORK["operations"]+=1;return S(self.a+x.a,self.b+x.b)
    __radd__=__add__
    def __neg__(self):return S(-self.a,-self.b)
    def __sub__(self,x):
        x=self.coerce(x)
        return NotImplemented if x is NotImplemented else self+-x
    def __rsub__(self,x):
        x=self.coerce(x)
        return NotImplemented if x is NotImplemented else x+-self
    def __mul__(self,x):
        x=self.coerce(x)
        if x is NotImplemented:return NotImplemented
        FIELD_WORK["operations"]+=1
        return S(self.a*x.a+401*self.b*x.b,self.a*x.b+self.b*x.a)
    __rmul__=__mul__
    def __truediv__(self,x):
        x=self.coerce(x)
        if x is NotImplemented:return NotImplemented
        norm=x.a*x.a-401*x.b*x.b
        if not norm:raise ZeroDivisionError("exact field zero divisor")
        FIELD_WORK["operations"]+=1
        return self*S(x.a/norm,-x.b/norm)
    def __rtruediv__(self,x):
        x=self.coerce(x)
        return NotImplemented if x is NotImplemented else x/self
    def __pow__(self,n):
        assert isinstance(n,int)
        if n<0:return S(1)/(self**(-n))
        out=S(1)
        for _ in range(n):out=out*self
        return out
    def __bool__(self):return bool(self.a or self.b)
    def __eq__(self,x):
        x=self.coerce(x)
        return False if x is NotImplemented else self.a==x.a and self.b==x.b
    def __hash__(self):return hash(self.a) if not self.b else hash((self.a,self.b,401))
    def sign(self):
        if not self.b:return (self.a>0)-(self.a<0)
        if not self.a:return (self.b>0)-(self.b<0)
        if (self.a>0)==(self.b>0):return 1 if self.a>0 else -1
        d=self.a*self.a-401*self.b*self.b
        assert d,"401 is nonsquare; rational pair cannot cancel except zero"
        return ((self.a>0)-(self.a<0)) if d>0 else ((self.b>0)-(self.b<0))
    def __lt__(self,x):
        x=self.coerce(x)
        if x is NotImplemented:return NotImplemented
        FIELD_WORK["order_comparisons"]+=1;return (self-x).sign()<0
    def __abs__(self):return -self if self<0 else self
    def __str__(self):return f"({self.a})+({self.b})*sqrt401"


BETA=S(0,Q(1,20))


def enc(x):
    if isinstance(x,S):return {"a":str(x.a),"b":str(x.b),"D":401}
    if isinstance(x,Q):return {"a":str(x),"b":"0","D":401}
    if isinstance(x,L):return [enc(x.c),enc(x.m)]
    if isinstance(x,C):return [enc(x.lo),enc(x.hi),enc(x.q)]
    if isinstance(x,dict):return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [enc(v) for v in x]
    return x


def canon(x):return json.dumps(enc(x),sort_keys=True,separators=(",",":")).encode()


@dataclass(frozen=True)
class L:
    c:Q=Q(0)
    m:Q=Q(0)
    def at(self,h):return self.c+self.m*h
    def __add__(self,b):
        b=b if isinstance(b,L) else L(scalar(b));return L(self.c+b.c,self.m+b.m)
    __radd__=__add__
    def __neg__(self):return L(-self.c,-self.m)
    def __sub__(self,b):return self+-aslin(b)
    def __rsub__(self,b):return aslin(b)+-self
    def __mul__(self,a):return L(self.c*a,self.m*a)
    __rmul__=__mul__
    def __truediv__(self,a):return self*(Q(1)/a)
    def root(self):
        r=-self.c/self.m if self.m else None
        if isinstance(r,S) and r.b:FIELD_WORK["nonrational_roots"]+=1
        return r


def aslin(x):return x if isinstance(x,L) else L(scalar(x))


@dataclass(frozen=True)
class C:
    lo:Q
    hi:Q
    q:L


def polygon_area(v):
    return abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(v,v[1:]+v[:1])))/2 if len(v)>2 else Q(0)


def geom_moments(vertices,H):
    # Candidate preparation: exact polygon clipping + fan first moments.
    out=[]
    for a,b in zip(vertices,vertices[1:]+vertices[:1]):
        fa,fb=H-a[0]/20,H-b[0]/20
        if fa>=0:out.append(a)
        if (fa>=0)!=(fb>=0):
            t=fa/(fa-fb);out.append(tuple(x+t*(y-x) for x,y in zip(a,b)))
    if len(out)<3:return Q(0),Q(0)
    A=M=Q(0)
    for i in range(1,len(out)-1):
        tri=(out[0],out[i],out[i+1]);a=polygon_area(tri)
        A+=a;M+=a*sum(p[0]/20 for p in tri)/3
    return A,M


def integrate(vertices,lo,hi,q):
    WORK["geometric_integrals"]+=1
    a,m=geom_moments(vertices,lo);b,n=geom_moments(vertices,hi)
    return q.c*(b-a)+q.m*(n-m)


def normalized(pieces):
    out=[]
    for p in pieces:
        assert p.lo<p.hi
        assert min(p.q.at(p.lo),p.q.at(p.hi))>=0
        if out and out[-1].hi==p.lo and out[-1].q==p.q:
            out[-1]=C(out[-1].lo,p.hi,p.q)
        else:out.append(p)
    return out


def split_bounds(p,extra):
    return sorted({p.lo,p.hi,*[r for r in extra if r is not None and p.lo<r<p.hi]})


def advance(vertices,pieces,h0,h1,dt,P,K,cap,eligible=True):
    out=[];receipts={k:Q(0) for k in KINDS};v=(h1-h0)/dt;P=P*int(eligible)
    for p in pieces:
        WORK["cohort_visits"]+=1
        boundaries=split_bounds(p,(h0,h1))
        for a,b in zip(boundaries,boundaries[1:]):
            h=(a+b)/2;start_wet=h<h0;end_wet=h<h1
            if start_wet and end_wet:wet=L(dt)
            elif not start_wet and not end_wet:wet=L()
            elif v>0:wet=L(h1/v,-1/v)
            else:wet=L(h0/(-v),-1/(-v))
            dry=L(dt)-wet
            if not start_wet and end_wet:
                pre=p.q+P*dry;full=pre+K*wet
                roots=((pre-cap).root(),(full-cap).root())
                mode="rise"
            elif start_wet:
                full=p.q+K*wet;roots=((full-cap).root(),);mode="wet"
            else:full=p.q+P*dry;roots=();mode="dry"
            for x,y in zip((cuts:=split_bounds(C(a,b,p.q),roots)),cuts[1:]):
                m=(x+y)/2;released=L();refilled=L()
                if mode=="rise":
                    released=pre-cap if pre.at(m)>cap else L()
                    q=L(cap) if full.at(m)>cap else full
                    refilled=q-pre+released
                elif mode=="wet":
                    retained=L(cap) if full.at(m)>cap else full
                    refilled=retained-p.q;q=retained+P*dry
                else:q=full
                out.append(C(x,y,q))
                for kind,density in (("solid-rain",P*dry),("direct-water-rain",P*wet),
                                     ("refill",refilled),("release",released)):
                    receipts[kind]+=integrate(vertices,x,y,density)
    return normalized(out),receipts


def deposit(vertices,pieces,stage,lo,hi,density,cap):
    out=[];receipts={k:Q(0) for k in KINDS}
    for p in pieces:
        for a,b in zip((cuts:=split_bounds(p,(lo,hi,stage))),cuts[1:]):
            m=(a+b)/2;d=density if lo<=m<hi else L();full=p.q+d
            roots=((full-cap).root(),) if m<stage else ()
            for x,y in zip((more:=split_bounds(C(a,b,p.q),roots)),more[1:]):
                at=(x+y)/2;released=full-cap if at<stage and full.at(at)>cap else L()
                out.append(C(x,y,full-released))
                receipts["deposition"]+=integrate(vertices,x,y,d)
                receipts["release"]+=integrate(vertices,x,y,released)
    return normalized(out),receipts


def endpoints(vertices,pieces,stage):
    film=coating=Q(0)
    for p in pieces:
        if p.lo<min(p.hi,stage):coating+=integrate(vertices,p.lo,min(p.hi,stage),p.q)
        if max(p.lo,stage)<p.hi:film+=integrate(vertices,max(p.lo,stage),p.hi,p.q)
    return dict(film=film,coating=coating,total=film+coating)


def point_history(case,h):
    """Space-first symbolic event loop; does not call cohort advance/deposit."""
    WORK["oracle_point_histories"]+=1
    roots=[]
    def positive(f):
        r=f.root()
        if r is not None:roots.append(r)
        return f.at(h)>0
    def minimum(a,b):return b if positive(a-b) else a
    q=L(BETA*Q(case["initial"]));flow={k:L() for k in KINDS};cap=BETA*Q(case["cap"])
    H=L(Q(0),Q(1));last_mode=Q(case["segments"][0][2])>h
    for ta,tb,ha,hb,P,K in case["segments"]:
        ta,tb,ha,hb,P,K=map(Q,(ta,tb,ha,hb,P,K));K=K*BETA;P*=int(case.get("eligible",True))
        speed=(hb-ha)/(tb-ta);events=[L(ta),L(tb)]
        if speed:
            crossing=(H-ha)/speed+ta
            if positive(crossing-ta) and positive(tb-crossing):events.append(crossing)
        events.sort(key=lambda t:t.at(h))
        for a,b in zip(events,events[1:]):
            dt=b-a;mid=(a+b)/2
            wet=positive(L(ha)+speed*(mid-ta)-H)
            if wet:
                if not last_mode:
                    kept=minimum(q,L(cap));flow["release"]+=q-kept;q=kept
                filled=minimum(q+K*dt,L(cap));flow["refill"]+=filled-q;q=filled
                flow["direct-water-rain"]+=P*dt
            else:q+=P*dt;flow["solid-rain"]+=P*dt
            last_mode=wet
        for dep in case.get("deposits",[]):
            when,lo,hi,d0,dm=map(Q,dep)
            if when==tb and positive(H-lo) and positive(hi-H):
                d=L(d0*BETA,dm*BETA);q+=d;flow["deposition"]+=d
                if positive(L(hb)-H):
                    kept=minimum(q,L(cap));flow["release"]+=q-kept;q=kept
    return q,flow,roots


def compact_driver(case):
    # Oracle source representation: merge collinear, equal-rate source spans,
    # never across a resolved deposition. Candidate still runs every F1 tick.
    barriers={Q(d[0]) for d in case.get("deposits",[])};out=[]
    for original in case["segments"]:
        s=tuple(map(Q,original))
        if out:
            p=out[-1]
            if p[1]==s[0] and s[0] not in barriers and p[3]==s[2] and p[4:]==s[4:] and (p[3]-p[2])/(p[1]-p[0])==(s[3]-s[2])/(s[1]-s[0]):
                out[-1]=(p[0],s[1],p[2],s[3],p[4],p[5]);continue
        out.append(s)
    return dict(case,segments=out)


def width_polys(vertices):
    # Independent source-height width, directly from triangle edges.
    (a,z0),(b,z1),(c,z2)=sorted((x/20,z) for x,z in vertices)
    height=abs(z1-(z0+(z2-z0)*(b-a)/(c-a)))
    out=[]
    if b>a:out.append((a,b,-20*height*a/(b-a),20*height/(b-a)))
    if c>b:out.append((b,c,20*height*c/(c-b),-20*height/(c-b)))
    return out


def oracle_integral(vertices,lo,hi,q):
    total=Q(0)
    for a,b,w0,w1 in width_polys(vertices):
        a,b=max(a,lo),min(b,hi)
        if a<b:total+=w0*q.c*(b-a)+(w0*q.m+w1*q.c)*(b*b-a*a)/2+w1*q.m*(b*b*b-a*a*a)/3
    return total


def oracle(case,vertices):
    case=compact_driver(case)
    lo,hi=min(x/20 for x,z in vertices),max(x/20 for x,z in vertices)
    cuts={lo,hi,*[Q(s[j]) for s in case["segments"] for j in (2,3) if lo<Q(s[j])<hi]}
    for d in case.get("deposits",[]):cuts.update(Q(x) for x in d[1:3] if lo<Q(x)<hi)
    # Discover every affine branch root from point-history comparisons; no
    # candidate cohort boundaries or fitted coefficients are consumed.
    while True:
        extra=set();ordered=sorted(cuts)
        for a,b in zip(ordered,ordered[1:]):
            _,_,roots=point_history(case,(a+b)/2)
            extra.update(r for r in roots if a<r<b)
        if not extra:break
        cuts.update(extra)
        assert len(cuts)<4096,"oracle branch cap"
    receipts={k:Q(0) for k in KINDS};film=coating=Q(0);density=[]
    end=Q(case["segments"][-1][3])
    for a,b in zip((ordered:=sorted(cuts)),ordered[1:]):
        q,f,_=point_history(case,(a+b)/2);mass=oracle_integral(vertices,a,b,q)
        if (a+b)/2<end:coating+=mass
        else:film+=mass
        density.append(C(a,b,q))
        for k in KINDS:receipts[k]+=oracle_integral(vertices,a,b,f[k])
    return dict(film=film,coating=coating,total=film+coating),receipts,density


def run(case,vertices,cap_count=8):
    lo,hi=min(x/20 for x,z in vertices),max(x/20 for x,z in vertices)
    pieces=[C(lo,hi,L(BETA*Q(case["initial"])))]
    receipts={k:Q(0) for k in KINDS};peak=1;first_refusal=None;prefix=[]
    initial=integrate(vertices,lo,hi,pieces[0].q)
    # Continue an unbounded diagnostic after cap refusal, without calling it
    # published state. Bounded publication freezes at the first rejected step.
    frozen=None;bounded_state=pieces;bounded_receipts=dict(receipts);ordering_witnesses=[]
    for ix,seg in enumerate(case["segments"]):
        ta,tb,ha,hb,P,K=map(Q,seg)
        candidate,flow=advance(vertices,pieces,ha,hb,tb-ta,P,K*BETA,BETA*Q(case["cap"]),case.get("eligible",True))
        for dep in case.get("deposits",[]):
            t,a,b,c,m=map(Q,dep)
            if t==tb:
                candidate,more=deposit(vertices,candidate,hb,a,b,L(c*BETA,m*BETA),BETA*Q(case["cap"]))
                for k in KINDS:flow[k]+=more[k]
        assert candidate[0].lo==lo and candidate[-1].hi==hi
        assert all(a.hi==b.lo for a,b in zip(candidate,candidate[1:]))
        for piece in candidate:
            if len(ordering_witnesses)<8 and isinstance(piece.hi,S) and piece.hi.b and piece.hi<hi:
                assert piece.lo<piece.hi<hi
                ordering_witnesses.append(dict(step=ix+1,left=piece.lo,algebraic_root=piece.hi,right=hi))
        peak=max(peak,len(candidate))
        if len(candidate)>cap_count and first_refusal is None:
            first_refusal=dict(step=ix+1,time_s=tb,required_cohorts=len(candidate));frozen=canon(dict(state=pieces,receipts=receipts))
        if first_refusal is None:
            bounded_state=candidate;bounded_receipts={k:receipts[k]+flow[k] for k in KINDS}
        else:
            assert canon(dict(state=bounded_state,receipts=bounded_receipts))==frozen
        pieces=candidate
        for k in KINDS:receipts[k]+=flow[k]
        state=endpoints(vertices,pieces,hb)
        assert state["total"]+receipts["release"]==initial+receipts["solid-rain"]+receipts["refill"]+receipts["deposition"]
        assert receipts["solid-rain"]+receipts["direct-water-rain"]==sum(Q(s[4])*(Q(s[1])-Q(s[0])) for s in case["segments"][:ix+1])*polygon_area(vertices)*int(case.get("eligible",True))
        prefix.append(len(pieces))
    state=endpoints(vertices,pieces,Q(case["segments"][-1][3]))
    reference,flows,reference_density=oracle(case,vertices)
    assert state==reference and receipts==flows,(case["id"],state,reference,receipts,flows)
    # Per-height field check on union of independent partitions.
    cuts=sorted({p.lo for p in pieces+reference_density}|{p.hi for p in pieces+reference_density})
    for a,b in zip(cuts,cuts[1:]):
        h=(a+b)/2
        assert next(p.q for p in pieces if p.lo<=h<p.hi)==next(p.q for p in reference_density if p.lo<=h<p.hi)
    return dict(state=state,receipts=receipts,cohorts=pieces,peak_cohorts=peak,prefix_counts=prefix,
        first_eight_cohort_refusal=first_refusal,provisional_bounded_pass=first_refusal is None,
        frozen_prefix_sha256=sha256(frozen).hexdigest() if frozen else None,
        bounded_prefix_state=bounded_state,bounded_prefix_receipts=bounded_receipts,
        bounded_committed_steps=first_refusal["step"]-1 if first_refusal else len(case["segments"]),
        post_refusal_output_scope="unbounded exact diagnostic, not committed bounded state" if first_refusal else "within eight-cohort profile",
        exact_ordering_witnesses=ordering_witnesses,
        oracle_independent=True)


def independent_sign(x):
    # Independent rational interval embedding of sqrt(401), not the squared
    # rational comparison used by S.sign(). Used only for scalar validation.
    if not x:return 0
    lo,hi=Q(20),Q(21)
    for _ in range(1024):
        a,b=sorted((x.a+x.b*lo,x.a+x.b*hi))
        if a>0:return 1
        if b<0:return -1
        m=(lo+hi)/2
        if m*m<401:lo=m
        else:hi=m
    raise ArithmeticError("independent sign validation refinement cap")


def scalar_checks():
    assert BETA*BETA==Q(401,400) and BETA>1
    tests=[S(),S(1),S(-1),S(-20,1),S(20,-1),S(-401,20),S(401,-20),BETA/10]
    lo,hi=Q(20),Q(21)
    for _ in range(220):
        m=(lo+hi)/2
        if m*m<401:lo=m
        else:hi=m
    tests.extend([S(-lo,1),S(-hi,1),S(0,Q(1,2**80)),S(0,-Q(1,2**80))])
    for x in tests:
        assert x.sign()==independent_sign(x)
        if x:assert x*(S(1)/x)==1
    try:S(1)/S()
    except ZeroDivisionError:pass
    else:raise AssertionError("zero scalar division was accepted")
    return dict(exact_sign_witnesses=len(tests),near_cancellation_root_interval_bits=220,
                beta_squared=BETA*BETA,zero_speed_division_avoided_by_operator=True)


def main():
    raw=json.loads((ROOT/"fixtures.json").read_text());results={};measurements=[]
    results["scalar_validation"]=scalar_checks()
    for case in raw["cases"]:
        vertices=tuple(tuple(map(Q,p)) for p in case["vertices"])
        assert Q(case["cap"])==Q(1,10) and Q(case["initial"])<=Q(case["cap"])
        start=time.perf_counter();before=dict(FIELD_WORK);work_before=dict(WORK)
        r=run(case,vertices);results[case["id"]]=r
        # The field identity itself compares true-density coefficients too.
        r["true_density_coefficients"]=[L(p.q.c/BETA,p.q.m/BETA) for p in r["cohorts"]]
        if "projected_refusal_time" in case:
            assert r["first_eight_cohort_refusal"]["time_s"]==Q(case["projected_refusal_time"])
        elif "projected_study_peak" in case:
            assert r["peak_cohorts"]==case["projected_study_peak"]
        measurements.append(dict(id=case["id"],seconds=time.perf_counter()-start,
            scalar_operations=FIELD_WORK["operations"]-before["operations"],
            order_comparisons=FIELD_WORK["order_comparisons"]-before["order_comparisons"],
            nonrational_roots=FIELD_WORK["nonrational_roots"]-before["nonrational_roots"],
            cumulative_max_rational_bits=FIELD_WORK["max_rational_bits"],
            work={k:WORK[k]-work_before[k] for k in WORK}))
        print(case["id"],r["peak_cohorts"],r["first_eight_cohort_refusal"],flush=True)
    assert results["two-A"]["state"]["coating"]==Q(1,40)+BETA/200
    assert results["two-B"]["state"]["film"]==Q(1,20)
    assert results["three-A"]["state"]["film"]==BETA*Q(19,600)
    assert results["three-B"]["state"]["coating"]==BETA/600
    assert results["three-C"]["state"]["total"]==0
    assert results["rise-fall-cap-deposition"]["state"]["coating"]==BETA/10
    eps=Q(1,2**80)
    assert results["near-cap-resolved-deposits"]["receipts"]["release"]==BETA*Q(9,8)*eps
    assert results["near-cap-resolved-deposits"]["receipts"]["refill"]==BETA*Q(3,4)*eps
    assert results["zero-speed-at-cap"]["receipts"]["release"]==0
    assert results["zero-speed-at-cap"]["receipts"]["refill"]==0
    assert FIELD_WORK["nonrational_roots"]>0
    assert results["rise-fall-cap-deposition"]["exact_ordering_witnesses"]
    results["scope"]="canonical true-area restricted tide law; exact scalar/geometry/point-history comparisons; no f64 runtime"
    results["canonical_parameter_conversion"]=dict(beta=BETA,cap=BETA/10,refill=BETA/50,rain_basis="horizontal projected kg/m2/s unchanged")
    (ROOT/"results.json").write_text(json.dumps(enc(results),indent=2,sort_keys=True)+"\n")
    (ROOT/"measurements.json").write_text(json.dumps(measurements,indent=2,sort_keys=True)+"\n")
    exe=Path(sys.executable).resolve();names=["README.md","proof.py","fixtures.json","results.json","measurements.json"]
    manifest=dict(python=sys.version,executable=str(exe),executable_sha256=sha256(exe.read_bytes()).hexdigest(),host=platform.platform(),
        parent_proof_sha256="ad5047ea97d1d8a4644eeacff28a6c20a669cf6a5e6c2f7b8dbce1a55cd4f92b",
        artifacts={n:dict(sha256=sha256((ROOT/n).read_bytes()).hexdigest(),bytes=(ROOT/n).stat().st_size) for n in names},
        arithmetic="rational pairs a+b*sqrt401, 4096-bit per integer validation cap",
        durability="ignored scratch until root promotion")
    (ROOT/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")


if __name__=="__main__":main()

