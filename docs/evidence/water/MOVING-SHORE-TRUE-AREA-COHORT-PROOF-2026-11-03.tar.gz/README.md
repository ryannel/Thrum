# Exact true-area height-cohort bridge

Owner `/root/environment_research`, 3 November 2026. Owns this directory and the true-area cohort research report only. Original stdlib Python validation experiment, based on the author's prior tide-only proof (SHA-256 recorded in manifest). Expected retained disk below 1 MiB; no external assets/code or caches.

Run `python3 -B tmp/moving-shore-true-area-cohort-proof/proof.py`. Scalars are exact rational pairs a+b sqrt(401); canonical true-area cap/refill/initial/deposition convert through beta=sqrt(401)/20, while rain stays per horizontal area. The independent point-history/width oracle is distinct from candidate cohort/moment integration; both share the tested algebraic scalar library. No f64 runtime, waves, finite water, absorption or P7 qualification is claimed.

Retain source, fixtures, semantic results, separate diagnostic measurements and manifest. Ignored scratch is not durable backup; root owns later promotion. Failed eight-cohort prefixes remain failures, with later exact output marked diagnostic.
