#!/usr/bin/env python3
"""Original exact-affine admission prototype; wave oracle is separately numerical."""
from dataclasses import dataclass
from fractions import Fraction as Q
from functools import cached_property
from hashlib import sha256
from pathlib import Path
import heapq
import json
import math
import platform
import resource
import sys
import time

ROOT=Path(__file__).resolve().parent
S=Q(1,20)
RATIO_UP=Q(1002,1000)  # sqrt(1+1/400) < 1.002, checked below.
assert RATIO_UP*RATIO_UP > 1+S*S
COUNTS={"area_calls":0,"clips":0}
ORACLE_COUNTS={"depth_exhaustions":0}


def enc(x):
    if isinstance(x,Q): return str(x)
    if isinstance(x,dict): return {k:enc(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)): return [enc(v) for v in x]
    return x


def canonical(x): return json.dumps(enc(x),sort_keys=True,separators=(",",":")).encode()


def area(v):
    return abs(sum(x*z2-x2*z for (x,z),(x2,z2) in zip(v,v[1:]+v[:1])))/2 if len(v)>2 else Q(0)


@dataclass(frozen=True)
class Tri:
    key:str
    v:tuple
    kind:str
    material:str
    rain:bool

    @cached_property
    def A(self): return area(self.v)
    @cached_property
    def x(self): return sum(p[0] for p in self.v)/3
    @cached_property
    def ratio(self): return RATIO_UP if self.kind=="bank" else Q(1)
    @cached_property
    def low(self): return min(p[0] for p in self.v)
    @cached_property
    def high(self): return max(p[0] for p in self.v)


def wet_area(tri,c):
    COUNTS["area_calls"]+=1
    low,high=tri.low,tri.high
    if c<=low:return Q(0)
    if c>=high:return tri.A
    COUNTS["clips"]+=1
    out=[]
    for a,b in zip(tri.v,tri.v[1:]+tri.v[:1]):
        fa,fb=c-a[0],c-b[0]
        if fa>=0:out.append(a)
        if (fa>=0)!=(fb>=0):
            u=fa/(fa-fb);out.append((a[0]+u*(b[0]-a[0]),a[1]+u*(b[1]-a[1])))
    return area(tuple(out))


def seed(L):
    assert 0<L<=64 and 3*S*L/4+Q(1,20)<10  # roof=10m, bridge=12m; never overtopped
    xs=sorted({Q(0),L/4,L/3,L/2,3*L/4,7*L/8,15*L/16,L})
    zs=[Q(0),L/4,L/2,3*L/4,L]
    triangles=[];exports=Q(0);roof=bridge=ground=Q(0)
    for i,(a,b) in enumerate(zip(xs,xs[1:])):
        for j,(c,d) in enumerate(zip(zs,zs[1:])):
            x,z=(a+b)/2,(c+d)/2
            if x>=15*L/16: exports+=(b-a)*(d-c);continue
            cover="roof" if L/4<x<L/2 and L/4<z<L/2 else "bridge" if 3*L/4<x<7*L/8 and L/2<z<3*L/4 else None
            mat="soil-A" if x<L/3 else "soil-B"
            quad=((a,c),(b,c),(b,d),(a,d))
            for k,v in enumerate(((quad[0],quad[1],quad[2]),(quad[0],quad[2],quad[3]))):
                triangles.append(Tri(f"bank:{i}:{j}:{k}",v,"bank",mat,not cover))
                ground+=area(v)
                if cover:
                    triangles.append(Tri(f"{cover}:{i}:{j}:{k}",v,cover,"roof-material",True))
                    if cover=="roof":roof+=area(v)
                    else:bridge+=area(v)
    assert sum(t.A for t in triangles if t.rain)+exports==L*L
    assert sum(t.A for t in triangles if t.kind=="bank")==15*L*L/16
    return triangles,dict(export_projected=exports,roof=roof,bridge=bridge,ground=ground,
                          eligible_rain=sum(t.A for t in triangles if t.rain),material_projected=sum(t.A for t in triangles))


def split(t):
    # Fixed fresh-cook partition: no runtime remap or state homogenization.
    pairs=[(abs(t.v[i][0]-t.v[j][0]),i,j) for i,j in ((0,1),(1,2),(2,0))]
    _,i,j=max(pairs);k=3-i-j
    m=tuple((a+b)/2 for a,b in zip(t.v[i],t.v[j]))
    a=Tri(t.key+"0",(t.v[i],m,t.v[k]),t.kind,t.material,t.rain)
    b=Tri(t.key+"1",(m,t.v[j],t.v[k]),t.kind,t.material,t.rain)
    assert a.A+b.A==t.A
    return a,b


def max_endpoint_mismatch(t,lo,hi):
    if t.kind!="bank":return Q(0)
    candidates=[lo,hi]
    if lo<=t.x<=hi:candidates.append(t.x)
    result=Q(0)
    for c in candidates:
        a=wet_area(t,c)
        if c==t.x:result=max(result,a,t.A-a)
        else:result=max(result,t.A-a if c>t.x else a)
    return result


def envelope(t,case,T,K):
    prior=Q(case["prior_error_density"])*t.A*t.ratio
    if t.kind!="bank":return prior
    L=Q(case["side_m"]);lo,hi=L/4,3*L/4
    if t.high<=lo or t.low>=hi:return prior
    P=Q(case["rain"]);rho=Q(case["initial_density"])+Q(case["prior_error_density"])+P+K  # one-second nonbinding envelope
    assert rho<Q(1,10)
    U=t.A*T
    return prior+2*P*U*int(t.rain)+2*(P*int(t.rain)+K*t.ratio)*U+2*rho*t.ratio*max_endpoint_mismatch(t,lo,hi)


def partition(case,T,K,cap,tol):
    ts,geometry=seed(Q(case["side_m"]));serial=0;heap=[]
    for t in ts:
        heapq.heappush(heap,(-envelope(t,case,T,K),serial,t));serial+=1
    while -heap[0][0]>tol and len(heap)<cap:
        _,_,t=heapq.heappop(heap)
        for c in split(t):heapq.heappush(heap,(-envelope(c,case,T,K),serial,c));serial+=1
    leaves=sorted((t for _,_,t in heap),key=lambda t:t.key)
    assert sum(t.A for t in leaves)==sum(t.A for t in ts)
    return leaves,geometry,dict(columns=len(leaves),seed_columns=len(ts),split_operations=(serial-len(ts))//2,
        worst_local_envelope=-heap[0][0],envelope_pass=-heap[0][0]<=tol,
        geometry_and_material_boundary_preserved=True)


def affine_candidate(t,c0,c1,T):
    if t.kind!="bank":return Q(0),Q(0),Q(0),0
    if max(p[0] for p in t.v)<=min(c0,c1):return Q(0),Q(0),t.A*T,1
    if min(p[0] for p in t.v)>=max(c0,c1):return Q(0),Q(0),Q(0),1
    speed=(c1-c0)/T
    events={Q(0),T}
    if speed:
        for x in [p[0] for p in t.v]+[t.x]:
            at=(x-c0)/speed
            if 0<at<T:events.add(at)
    U=I=Q(0);events=sorted(events)
    for a,b in zip(events,events[1:]):
        m=(a+b)/2;q=c0+speed*m>t.x
        vals=[wet_area(t,c0+speed*u) for u in (a,m,b)]
        integ=(b-a)*(vals[0]+4*vals[1]+vals[2])/6
        I+=integ;U+=(b-a)*t.A-integ if q else integ
    end=wet_area(t,c1);E=t.A-end if c1>t.x else end
    return U,E,I,len(events)-1


def width_pieces(t):
    p=sorted(t.v);(x0,z0),(x1,z1),(x2,z2)=p
    h=abs(z1-(z0+(z2-z0)*(x1-x0)/(x2-x0)))
    out=[]
    if x1>x0:out.append((x0,x1,-h*x0/(x1-x0),h/(x1-x0)))
    if x2>x1:out.append((x1,x2,h*x2/(x2-x1),-h/(x2-x1)))
    return out


def integral_product(a,b,u,v,w,y):
    return u*w*(b-a)+(u*y+v*w)*(b*b-a*a)/2+v*y*(b*b*b-a*a*a)/3


def affine_oracle(t,c0,c1,T):
    # Independent x-first integration. No clipping, wet-area values or fit.
    if t.kind!="bank":return Q(0),Q(0)
    if max(p[0] for p in t.v)<=min(c0,c1):return Q(0),t.A*T
    if min(p[0] for p in t.v)>=max(c0,c1):return Q(0),Q(0)
    v=(c1-c0)/T;tp=min(T,max(Q(0),(t.x-c0)/v)) if v else (Q(0) if c0>t.x else T)
    U=I=Q(0)
    for lo,hi,w0,w1 in width_pieces(t):
        events=sorted({lo,hi,*[x for x in (c0,c1,t.x) if lo<x<hi]})
        for a,b in zip(events,events[1:]):
            m=(a+b)/2
            if not v:ta,tb=(Q(0),Q(0)) if c0>m else (T,Q(0))
            elif (m-c0)/v<=0:ta,tb=Q(0),Q(0)
            elif (m-c0)/v>=T:ta,tb=T,Q(0)
            else:ta,tb=-c0/v,1/v
            sign=1 if ta+tb*m>=tp else -1
            U+=integral_product(a,b,w0,w1,sign*(ta-tp),sign*tb)
            I+=integral_product(a,b,w0,w1,ta,tb) if v<0 else integral_product(a,b,w0,w1,T-ta,-tb)
    return U,I


def certify_affine(leaves,case,c0,c1,T,K,prior):
    P=Q(case["rain"]);rho=Q(case["initial_density"])+Q(case["prior_error_density"])+P+K
    total=Q(0);panels=0;local_fail=0;next_prior={};source_error=Q(0)
    for t in leaves:
        previous=prior.get(t.key,Q(case["prior_error_density"])*t.A*t.ratio)
        if t.kind!="bank" or t.high<=min(c0,c1) or t.low>=max(c0,c1):
            # Independently trivial constant-mode oracle: point and every
            # source point share a fixed sign throughout this interval.
            next_prior[t.key]=previous;total+=previous;local_fail+=previous>Q(1,100000)
            panels+=2*int(t.kind=="bank")
            continue
        U,E,I,n=affine_candidate(t,c0,c1,T);uo,io=affine_oracle(t,c0,c1,T)
        assert U==uo and I==io,(t.key,U,uo,I,io)
        q0=min(T,max(Q(0),(t.x-c0)/((c1-c0)/T))) if c1!=c0 else (Q(0) if c0>t.x else T)
        point=t.A*(q0 if c1<c0 else T-q0) if t.kind=="bank" else Q(0)
        assert abs(point-I)<=U
        rain_bound=2*P*U*int(t.rain)
        increment=rain_bound+2*(P*int(t.rain)+K*t.ratio)*U
        carried=previous+increment
        next_prior[t.key]=carried
        error=carried+2*rho*t.ratio*E
        total+=error;source_error+=P*abs(point-I)*int(t.rain)
        local_fail+=error>Q(1,100000);panels+=n*2  # conservative two-classification charge
    return dict(total_bound=total,panels=panels,local_failures=local_fail,
                source_receiver_absolute_error=source_error),next_prior


def simpson(f,a,b,eps,depth=20):
    fa,fb,fm=f(a),f(b),f((a+b)/2);whole=(b-a)*(fa+4*fm+fb)/6
    def rec(a,b,fa,fm,fb,s,e,n):
        c=(a+b)/2;l=(a+c)/2;r=(c+b)/2;fl,fr=f(l),f(r)
        sl=(c-a)*(fa+4*fl+fm)/6;sr=(b-c)*(fm+4*fr+fb)/6
        if n==0:
            ORACLE_COUNTS["depth_exhaustions"]+=1
            return sl+sr+(sl+sr-s)/15
        if abs(sl+sr-s)<=15*e:return sl+sr+(sl+sr-s)/15
        return rec(a,c,fa,fl,fm,sl,e/2,n-1)+rec(c,b,fm,fr,fb,sr,e/2,n-1)
    return rec(a,b,fa,fm,fb,whole,eps,depth)


def wave_intervals(x,mid,T):
    w=math.pi/2;k=w*w/9.81;a=.05
    mean=.05*mid-a*math.cos(math.pi/480)
    z=(.05*x-mean)/a
    if z<=-1:return [(0.,T)]
    if z>=1:return []
    angle=math.acos(z);center=T/2+k*(x-mid)/w
    lo,hi=max(0.,center-angle/w),min(T,center+angle/w)
    return [(lo,hi)] if lo<hi else []


def xor_length(a,b):
    return sum(y-x for x,y in a)+sum(y-x for x,y in b)-2*sum(max(0.,min(y,v)-max(x,u)) for x,y in a for u,v in b)


def wave_check(leaves,case,T,K):
    # Certified conservative contour box uses cos(z) in [1-z²/2,1]
    # and |a*k*sin|<=a*k < bank slope. Rational pi enclosure [3.14159,3.14160].
    oracle_depth_before=ORACLE_COUNTS["depth_exhaustions"]
    mid=Q(case["side_m"])/2;P=Q(case["rain"]);pi_hi=Q(314160,100000)
    k_hi=(pi_hi/2)**2/Q(981,100)
    phase_bound=k_hi*Q(1,1000)+pi_hi*T/4
    dlo=S-Q(1,20)*k_hi*phase_bound;dhi=S+Q(1,20)*k_hi*phase_bound
    beta_lo=Q(314159,100000)/480;beta_hi=pi_hi/480
    # Fourth-order alternating series encloses cos(beta), without calling oracle cos.
    bed_lo=1-beta_hi**2/2;bed_hi=1-beta_lo**2/2+beta_lo**4/24
    def contour_band(a,b):
        abs_hi=max(abs(a-T/2),abs(b-T/2))*pi_hi/2
        abs_lo=Q(0) if a<=T/2<=b else min(abs(a-T/2),abs(b-T/2))*Q(314159,100000)/2
        f0lo=Q(1,20)*(1-abs_hi**2/2-bed_hi)
        f0hi=Q(1,20)*(1-abs_lo**2/2+abs_lo**4/24-bed_lo)
        cl=mid+f0lo/(dlo if f0lo<0 else dhi)
        ch=mid+f0hi/(dhi if f0hi<0 else dlo)
        # The global slope bound also brackets the root inside +/-1mm,
        # making the tighter local derivative bound above applicable.
        global_lo=mid+f0lo/(S-Q(1,20)*k_hi if f0lo<0 else S+Q(1,20)*k_hi)
        global_hi=mid+f0hi/(S+Q(1,20)*k_hi if f0hi<0 else S-Q(1,20)*k_hi)
        assert mid-Q(1,1000)<global_lo<=global_hi<mid+Q(1,1000)
        return a,b,cl,ch
    bands=[contour_band(T*j/16,T*(j+1)/16) for j in range(16)]
    _,_,end_cl,end_ch=contour_band(T,T)
    # Independent oracle breakpoints: solve actual cosine/bank intersections
    # at endpoint times, plus its interior crest threshold. These do not use
    # the candidate's conservative contour boxes.
    mf=float(mid);tf=float(T);w=math.pi/2;k=w*w/9.81
    def oracle_contour(at):
        a,b=mf-.001,mf+.001
        for _ in range(60):
            x=(a+b)/2
            f=.05*math.cos(k*(x-mf)-w*(at-tf/2))-.05*math.cos(math.pi/480)-.05*(x-mf)
            if f>0:a=x
            else:b=x
        return (a+b)/2
    critical=[oracle_contour(0.),oracle_contour(tf),mf+(1-math.cos(math.pi/480)),mf]
    candidate=Q(0);oracle=0.;coarse_oracle=0.;panels=0;active=0
    local_fail=0;total_error=Q(0);endpoint_unknown=0
    rho=Q(case["initial_density"])+Q(case["prior_error_density"])+P+K
    for t in leaves:
        if t.kind!="bank":
            error=Q(case["prior_error_density"])*t.A*t.ratio
            total_error+=error;local_fail+=error>Q(1,100000)
            continue
        low,high=min(p[0] for p in t.v),max(p[0] for p in t.v)
        if high<=min(c for _,_,c,_ in bands) or low>=max(c for _,_,_,c in bands):
            error=Q(case["prior_error_density"])*t.A*t.ratio
            total_error+=error;local_fail+=error>Q(1,100000)
            continue
        active+=1;U=Q(0)
        for a,b,cl,ch in bands:
            # If representative not certified against the common contour box,
            # charge the full footprint. This encloses actual point/area mismatch.
            U+=(b-a)*(wet_area(t,ch) if t.x>=ch else t.A-wet_area(t,cl) if t.x<cl else t.A)
            panels+=1
        q=wave_intervals(float(t.x),float(mid),float(T))
        def integrand(x):
            width=0.
            for lo,hi,w0,w1 in width_pieces(t):
                if float(lo)<=x<=float(hi):width=float(w0)+float(w1)*x;break
            return max(0.,width)*xor_length(wave_intervals(x,float(mid),float(T)),q)
        # Independent x-first double oracle; convergence check is not a rigorous error enclosure.
        points=sorted({float(p[0]) for p in t.v}|set(critical)|{float(t.x)})
        points=[x for x in points if float(low)<=x<=float(high)]
        fine=coarse=0.
        for a,b in zip(points,points[1:]):
            fine+=simpson(integrand,a,b,1e-12);coarse+=simpson(integrand,a,b,1e-10)
        assert fine<=float(U)+1e-9,(t.key,fine,float(U))
        candidate+=U;oracle+=fine;coarse_oracle+=coarse
        # Conservative endpoint label bound; ambiguous representative endpoint
        # refuses readiness rather than fabricating its wet flag.
        if t.x<end_cl:E=t.A-wet_area(t,end_cl)
        elif t.x>=end_ch:E=wet_area(t,end_ch)
        else:E=t.A;endpoint_unknown+=1
        error=Q(case["prior_error_density"])*t.A*t.ratio+2*P*U*int(t.rain)+2*(P*int(t.rain)+K*t.ratio)*U+2*rho*t.ratio*E
        total_error+=error;local_fail+=error>Q(1,100000)
    return dict(source_material_U_upper=candidate,x_first_numeric_U=oracle,
        oracle_refinement_difference=abs(oracle-coarse_oracle),active_columns=active,
        oracle_depth_exhaustions=ORACLE_COUNTS["depth_exhaustions"]-oracle_depth_before,
        time_slices=16,panels=panels,bank_slope=S,amplitude_m=Q(1,20),period_s=4,
        local_failures=local_fail,endpoint_point_unresolved=endpoint_unknown,
        total_error_bound=total_error,
        provisional_wave_budget_pass=local_fail==0 and endpoint_unknown==0 and panels<=262144 and total_error<=Q(1,1000),
        derivative_lower=dlo,geometric_band_is_not_mismatch=True,
        limitation="numeric independent oracle; not a formal bound on numerical quadrature error")


def main():
    raw=json.loads((ROOT/"fixtures.json").read_text());T=Q(raw["tick_s"]);K=Q(raw["refill_kg_m2_s"])
    assert Q(raw["slope"])==S and T==Q(1,60)
    results=[];timings=[]
    independent_tests=0
    for v in (((Q(0),Q(0)),(Q(1),Q(0)),(Q(0),Q(1))),
              ((Q(0),Q(0)),(Q(1),Q(1)),(Q(0),Q(1))),
              ((Q(-1),Q(0)),(Q(3,2),Q(1)),(Q(1,4),Q(7,8)))):
        tri=Tri("independent-test",v,"bank","test",True)
        for a,b in ((Q(0),Q(1)),(Q(1),Q(0)),(Q(-2),Q(2)),(Q(2),Q(-2)),(Q(1,3),Q(1,3))):
            U,E,I,_=affine_candidate(tri,a,b,Q(1));uo,io=affine_oracle(tri,a,b,Q(1))
            assert U==uo and I==io
            if a==0 and b==1:assert U>0  # zero-Taylor-band mutant cannot replace mismatch
            independent_tests+=1
    for case in raw["cases"]:
        began=time.perf_counter();before=dict(COUNTS)
        leaves,geom,prep=partition(case,T,K,raw["columns"],Q(raw["absolute_local_kg"]))
        elapsed=time.perf_counter()-began;prep_counts={k:COUNTS[k]-before[k] for k in COUNTS}
        L=Q(case["side_m"]);v=Q(raw["tide_speed_m_s"])/S
        # Qualification samples share this one prepared immutable partition.
        rejected=0;sample=[]
        for direction in (1,-1):
            for frac in (Q(11,40),Q(1,3),Q(17,40),Q(1,2)+Q(1,37),Q(23,40),Q(2,3),Q(29,40)):
                out,_=certify_affine(leaves,case,L*frac,L*frac+direction*v*T,T,K,{})
                accept=out["local_failures"]==0 and out["total_bound"]<=Q(raw["patch_incremental_kg"]) and out["panels"]<=262144
                rejected+=not accept;sample.append(dict(stage_x=L*frac,direction=direction,accepted=accept,**out))
        carried={};history=[]
        if prep["envelope_pass"]:
            for tick in range(raw["history_ticks"]):
                c0=L*(Q(1,2)+Q(1,37))+v*T*tick
                out,carried=certify_affine(leaves,case,c0,c0+v*T,T,K,carried)
                history.append(out)
        wave=wave_check(leaves,case,T,K)
        prior=sum(Q(case["prior_error_density"])*t.A*t.ratio for t in leaves)
        assert prior==Q(case["prior_error_density"])*(geom["ground"]*RATIO_UP+geom["roof"]+geom["bridge"])
        if history:
            start=L*(Q(1,2)+Q(1,37));duration=T*raw["history_ticks"]
            for t in leaves:
                U,_=affine_oracle(t,start,start+v*duration,duration)
                expected=Q(case["prior_error_density"])*t.A*t.ratio+(4*Q(case["rain"])*int(t.rain)+2*K*t.ratio)*U
                assert carried[t.key]==expected,(case["id"],t.key,"lost prior/prefix error")
        if prior>Q(raw["patch_accumulated_kg"]):reason="PriorPatchErrorBudget"
        elif not prep["envelope_pass"]:reason="ColumnCapBeforeLocalEnvelope"
        elif rejected:reason="RuntimeSampleBudget"
        elif history and (history[-1]["local_failures"] or history[-1]["total_bound"]>Q(raw["patch_accumulated_kg"])):reason="AccumulatedHistoryBudget"
        else:reason="ProvisionalOfflineAffinePass"
        assert reason==case["expected_outcome"],(case["id"],reason,case["expected_outcome"])
        results.append(dict(id=case["id"],side_m=L,source_area_m2=L*L,geometry=geom,
            preparation=prep,prior_patch_error=prior,admission=reason,
            prepared_partition_sha256=sha256(canonical([dict(key=t.key,v=t.v,kind=t.kind,material=t.material,rain=t.rain) for t in leaves])).hexdigest(),
            sample_rejections=rejected,sample_count=len(sample),samples=sample,
            history_ticks_executed=len(history),history_last=history[-1] if history else None,
            wave=wave,
            bytes=dict(column_product=104*len(leaves),four_state_owners=4*64*len(leaves),
                       two_old_new_products=2*(104+512)*len(leaves),certificate_scratch=64*len(leaves),
                       panel_scratch=4096*64)))
        timings.append(dict(id=case["id"],python_preparation_seconds=elapsed,
            preparation_counts=prep_counts,
            python_diagnostics_seconds=time.perf_counter()-began-elapsed,
            python_process_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=="darwin" else 1024),
            note="timing and counters cover fresh preparation only; Python, not runtime qualification"))
        print(case["id"],len(leaves),reason,"sample rejects",rejected,"wave active",wave["active_columns"],flush=True)
    (ROOT/"results.json").write_text(json.dumps(enc(dict(schema="spatial-admission-results-v1",independent_affine_unit_checks=independent_tests,cases=results)),indent=2,sort_keys=True)+"\n")
    (ROOT/"measurements.json").write_text(json.dumps(timings,indent=2,sort_keys=True)+"\n")
    exe=Path(sys.executable).resolve();names=["README.md","fixtures.json","proof.py","results.json","measurements.json"]
    manifest=dict(python=sys.version,executable=str(exe),executable_sha256=sha256(exe.read_bytes()).hexdigest(),
        host=dict(system=platform.system(),machine=platform.machine()),
        artifacts={n:dict(sha256=sha256((ROOT/n).read_bytes()).hexdigest(),bytes=(ROOT/n).stat().st_size) for n in names},
        dependencies="stdlib only",provenance="original commissioned experiment",durability="ignored scratch until root promotion")
    (ROOT/"manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")


if __name__=="__main__":main()
