# Fixed-column shore spatial admission experiment

Owner `/root/environment_research`, commissioned 2 November 2026. Owns this directory and the new spatial-admission research report only. Original Python stdlib experiment; expected peak retained disk below 2 MiB. No engine code, external assets, Broadsides files or shared contracts are changed.

Run `python3 -B tmp/moving-shore-spatial-admission/proof.py`. Semantic results/hashes are separate from variable Python preparation timings. Retain source, fixtures, results, measurements and manifest; ignored scratch is not a durable evidence backup. Root owns later evidence promotion. No general wave, finite-water, f64 interval, runtime or device qualification is claimed. No cache is generated with `-B`.
