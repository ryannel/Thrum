# Pairwise relative admission — design for review

3 November 2026. **Proposed private certificate only; no helper or source implementation, no new admission pass.** Governing input is `docs/design/modules/CLOUD-AUTHORED-SOURCE.md`, final section, and the frozen natural admission diagnosis. Existing input fields, source stepping, rendering, catalogue, scales and schedules remain unchanged. This document is the complete bounded next algorithm, including the discrete rather than continuous motion contract.

## Predicate and inputs

At an actual crown birth barrier t0, freeze the same finite all-old identity set as `oldMembers()`, including publication-retained IDs. No reference-only historical identity is added, and none is dropped because it reaches its nominal age endpoint. Freeze the current source states, rather than only the old helper's extrapolated endpoint poses. For each candidate and old identity require `{ID, role, C, u, K, Qcolumns, root, s, mu, tau, b}` plus exact source/math and metadata identities, common weather-cause identity, t0 and dt=.25. Candidate fresh K and inherited velocity are the existing values. The same eight sites/four certified heads and BODY/B scales4/6/5 apply.

Conditional future domain: 180 source intervals; shared arbitrary admitted binary64 control values per interval, `|S_n|<=.002`, `|mean_n|<=12`, `0<=U_n<=.3`. All crowns use that same U_n, BODY target0. Condensation remains healthy (`growthTarget=1`, no weather exposure), as required by the existing establishment promise. Do not inspect future queued commands. Off/dry revokes the healthy promise in the existing way; it does not rewind exposure. Retained old potential continues the ordinary healthy map for45s with age/weather loss suppressed for the cue comparison. The predicate is endpoint exterior development at45s, not absence of overlap throughout the growth path.

For at least one existing head, certify a world sphere contained in the candidate's local6m q>=.041 head ball at t0+45, outside every old q>.005 conservative BVH leaf for every such future. Use the **existing worst-case candidate singular-value/radius and four-native-voxel test** (outward evaluated); do not enlarge its positive radius or replace it with a nominal radius. At the worked370s candidates that lower sphere radius is34.4164315658m. This is thresholded cue separation, not separation from every positive optical tail.

## Exact discrete relative equation

Let h=.25, N=180. Treat the runtime's binary64 `e=Math.exp(-h/10)` and each fixed fractional-step response exponential as pinned constants, not a claim about a portable transcendental error specification. Let a=1-e, d=h-10a. Define coefficients with outward arithmetic; source-operation rounding is bounded separately below. For a material label use `v=D*(label-root)`, where D is the numerical dual of stored Q^T, **not an assumed perfect Q**. An interval inverse also encloses the exact inverse of the stored binary64 Q for the geometric guard.

Compute each pose's healthy response/growth sequence by the unchanged runtime functions and order: `ig_i,n = growthIntegral(p_i,1,h)` (five-node Simpson), response update, then b_i,n+1=s_i*growth(...). These are known binary64 values because healthy target1 is independent of S/U. Never substitute one45s call or a continuous growth integral. In the real shadow recurrence with those stored coefficients:

- I_i,n = h*Cy_i,n + 10*d*uy_i,n + beta*r_i*U_n, with beta=.5*h*h-10*d, r=1 for B and0 for BODY.
- Cy_i,n+1 = Cy_i,n + 10*a*uy_i,n + alpha*r_i*U_n, alpha=h-10*a.
- uy_i,n+1 = e*uy_i,n + (1-e)*r_i*U_n; uh_i,n+1=e*uh_i,n.
- Ch_i,n+1 = Ch_i,n + mean_n*h + S_n*(I_i,n-1500*h) +10*a*uh_i,n.
- Kh_i,n+1 = Kh_i,n + S_n*s_i*ig_i,n.

For new head-centre label c and any old leaf label o, define delta=new-old. Subtract the updates *before* bounding them. Common mean cancels; the exact horizontal future-shear coefficient is

`A_n(voy) = deltaI_n + s_c*ig_c,n*vcy - s_o*ig_o,n*voy`.

Known endpoint base separation uses the initial C/K, decaying known horizontal u, final known b, and a zero-future-S/zero-future-U continuation. It includes **all initial K**. The remaining horizontal displacement is `sum S_n*A_n`; there is no quadrature-error term because A uses the actual per-step Simpson weights. The relative vertical recurrence gives deltaI intervals. For B/B, the arbitrary future U cancels completely, including inherited uy differences (which decay normally). For B/BODY, retain the common nonnegative U response. Its sharp interval endpoints come from all U=0 and all U=.3 because a,d,alpha,beta are nonnegative. These are bounds, not a prediction of future U. No independent candidate/old centre balls are added.

For an old node, bound voy over its entire local box by interval dot products with D's Y row. Then

`R_h(node) = .002 * max_{z in [voyLo,voyHi]} sum_n max(|Alo_n(z)|, |Ahi_n(z)|)`

is a horizontal **norm** bound for all directions/changes of S. Separate interval choices of U inside this sum can overestimate the shared U sequence; that is safe. It is still tighter than treating two unrelated shear histories. Vertical endpoint uncertainty relative to zero-U is0 for B/B, and [0,V] for B/BODY. Do not add a second unrelated uplift radius. Roundoff residuals are additional, not cancelled.

## Executable leaf separation and amortization

Use conservative separating planes; no exact point-to-parallelepiped solver is required. For a node and the zero-S/U endpoint maps, form the base separation of new head centre from every point of the old mapped box. Test world X/Y/Z, the three old mapped-box face-normal directions, and the direction from old box centre to new head centre. Each is just a fixed nonzero binary64 direction m; it need not be exactly normalized or exactly perpendicular. Test both signs (or compute both projection gaps). Outward box support arithmetic gives L0, the minimum projected base separation. The sufficient test is

`lower(L0 + min(0,mY*V) - norm(mXZ)*R_h - E_projection) > upper(r*norm(m))`.

Here r is the fixed conservative positive world sphere radius, not a radius of the whole transformed head. Any passing direction excludes this node for the entire future domain. Otherwise recurse; a leaf that cannot be excluded is `uncertified`, not `occupied`. All nodes/leaves of every old ID must be excluded for one head to pass. Trying finitely many directions can cause false negatives, never a false pass. This test also uses each old node's actual spatial/growth relation; it does not inverse-map with an unrelated worst-case scale.

**Do not integrate180 steps per node.** For one candidate-head/old pair, write deltaI_n=[l_n,u_n], c_n=(l_n+u_n)/2+s_c*ig_c,n*vcy, q_n=s_o*ig_o,n>0 and r_n=(u_n-l_n)/2. Outward coefficient construction absorbs interval-dual and coefficient rounding into r_n using the old template's global |voy| bound. Then

`F(z)=sum r_n + sum q_n*abs(z-c_n/q_n)`.

F is convex, so the maximum over a node's voy interval is exactly bounded by max(F(lo),F(hi)). Precompute the180 weighted knots c_n/q_n and prefix sums of q_n and c_n. F(z) is one binary search plus prefix arithmetic; no180-step traversal is in an ordinary node query. Use deterministic bounded mergesort. Compare knot ratios through outward cross-products; an ambiguous comparator uses exact binary-rational comparison (or an explicit direct180-term fallback), never an unchecked order. Query cut ambiguity likewise falls back to the direct outward sum. Prefix evaluation is outward; do not sum products q*(rounded knot) instead of the original c.

A cheap root-node test may precede the other planes. Preparing another head/old pair replaces the same scratch; do not cache every pair or allocate per node. Direct180-term fallback remains a finite correctness reference. Work counters distinguish prepared terms, sorting comparisons, prefix queries, fallback terms, planes, nodes and old IDs.

## Numerical contract

The proof encloses the **implemented discrete binary64 map**, not only real ODEs. Fixed exponential outputs and growth operation order are pinned by the source/math identity and running JS environment. Known healthy growth histories are evaluated by the actual runtime functions; no speculative bound on Math.exp accuracy is needed. Q is finite/non-singular; interval inversion encloses both exact stored-Q inverse and the runtime dual. Rendering/storage coordinates are not changed.

Use binary64 nextDown/nextUp interval primitives for sums/products/division/sqrt, finite validation, and outward accumulation. A custom helper cannot silently assume JavaScript has directed rounding. Coefficient construction and geometric projection use those primitives, including norms, radius/scale, normalized-resolution comparison and final strict inequality. Equality, overflow, NaN, non-enclosing intervals or unsupported identity is uncertified.

For source-operation roundoff, enclose a shadow recurrence using the exact binary64 constants and exact-real arithmetic. One-step local errors can be bounded with gamma64=64u/(1-64u), u=2^-53, times the sum of absolute expanded monomials in the corresponding runtime expression, plus64*2^-1074.64 is a conservative bound on the inspected expression's arithmetic depth; future edits invalidate it. Absolute state envelopes include arbitrary admitted mean/S/U and current finite coordinates. Propagate errors componentwise, not by an exponentially loose whole-state norm. For example:

`Ey'=Ey+10*a*Euy+ry; Euy'=e*Euy+ruy;`

`Ex'=Ex+.002*(h*Ey+10*abs(d)*Euy)+10*a*Eux+rx; Eux'=e*Eux+rux; EK'=EK+rK`.

Local rx uses the absolute monomial sum of `Cx + mean*h + S*(Cy*h+.5*U*h*h+10*(uy-U)*d-1500*h)+10*ux*a`; ry/ruy/rK use their corresponding expressions above. Include both poses' terminal coordinate/K error projected onto the head/whole-node label domains, dual error, endpoint field-map operation error and all bound-calculation error in E_projection. Interval arithmetic calculates this allowance; a fixed hand-tuned epsilon is not the qualification. Common mean contributes to these local rounding envelopes even though its real recurrence cancels. Initial stored state is exact binary64 input, not an uncertain reconstructed endpoint.

The original conservative helper remains the fallback, with the same thresholds/metadata and no weakened decision. A new proof may only add passes. Its fallback pass is usable only inside the original certificate's verified discrete/numerical scope; if the new numerical checks identify a scope violation, report unsupported/numerically-uncertified rather than blessing it. The370s case already rejects under that fallback, so this condition cannot conceal a new success. Review must confirm legacy numerical coverage as well as the new interval evaluator before a combined helper is called sound.

## Cost and publication

Hard geometry counts remain8 sites,4 heads,8 old IDs,255 nodes/128 leaves,45s. At worst there are256 head/old preparations and65,280 node visits; seven directions/two signs give at most913,920 plane tests. Shared growth preparation is at most9*180=1,620 pose steps, not sites*heads*nodes*180. Pair preparation has46,080 coefficient terms and at most368,640 mergesort comparisons (180*8*256); prefix queries are O(log180), ordinarily two per node. Ambiguous direct fallback has an explicit worst-case11,750,400 terms; it is recorded separately, never hidden in a node-work count. No native voxel scans or extra control lattices occur.

Private scratch target <128KiB: 9*181*2 Float64 growth values26,064B; four common vertical-response sequences5,792B; old node Y intervals8*255*2 Float64=32,640B; one pair180 coefficients/prefix/sort scratch<16KiB; remaining state/frontier/error/work counters<16KiB. Prepared metadata is already resident and charged separately. Do not retain256 prefixes. These are logical costs, not measured process/GPU admission.

The proposed helper is a deterministic resumable job: `beginRelativeCertificate(input)` freezes the birth-barrier inputs; `advance(workBudget)` consumes bounded coefficient/sort/node units and returns pending/pass/uncertified. Each advance caps128 node units or512 coefficient/comparison units, checking a wall budget between bounded16-unit batches. Birth-barrier work uses private unpublished staging; the model must not expose a half-mutated current state. Source committed time stays at the barrier until the decision completes, while requested clock/backlog continues and the last immutable tuple remains renderable. No camera/view changes influence results, no dropped ticks, no partial child publication. This is a necessary private source-pump integration, not a new public weather queue. It must be tested before runtime adoption. If synchronous use is selected instead, it needs an actual worst-case duration gate first; fixed asymptotic size alone is not permission for a main-thread spike. No duration/CPU-budget pass is claimed here.

Output: `{status, headID?, referenceIDs, source/metadata hashes, t0, endpoint, minCertifiedMargin?, counters, numericalAllowance, reason, legacyResult}`. Retain the first failed leaf/oldID, plane margins and rounding contribution. `uncertified` reasons distinguish geometric possible-overlap, invalid healthy/common-cause assumptions, malformed input, numerical uncertainty and exhausted work/ownership lifetime. None means that actual q occupies the whole failed node. The source's existing genuine failed-birth path remains visible if neither certificate passes.

## Worked370s cases (not a new certificate run)

See `worked-cases.json` for pinned source/receipts and exact scalar inputs. All-old IDs remain[9,8,3,10,6,7]. Both shoulder6/head2 and admission3/head2 have native oldq0 at the nominal centre and all27 sphere samples, and pass the original nominal-zero-uncertainty BVH ablation. The original arbitrary-future certificate rejects them. Those observations do not prove the new arbitrary-future predicate.

For a fresh s6 crown, summing the180 actual growth weights gives125.29687500000001, while the single45s Simpson call gives124.85914012964119. The difference.437734870358824 times headVy36.9392943/22.1071386 and shear.002 gives.0323392/.0193541m of possible missed horizontal displacement. The new bound uses the180 weights. Maximum B/BODY unknown future uplift adds10.53332699m of vertical centre displacement and198.41673010m*s of integrated height (extra shear at most.39683346m), not independent13.5m balls for both poses.

For shoulder6/head2 the zero-U endpoint centre is[107.379507,1506.435766,-27.994732] in mean-removed coordinates. Actual BODY9 leaf102 has localY245..289 (voy12..56), world top1463.2. Its +Y projected gap43.235766m exceeds the unchanged34.416432m sphere by8.819334m even before considering horizontal separation; arbitrary nonnegative uplift raises that gap and shear has no Y component. Its discrete relative horizontal bound is about9.437590m, but the Y plane does not pay that term. This illustrates a useful correlation/direction; it is one leaf only and the outward numerical allowance has not been executed.

For admission3/head2 the zero-U centre is[460.458333,1407.842832,415.767943]. Actual BODY9 leaf216 has voy4..28 and maximumX336.624. The +X base gap123.834333m minus its discrete relative-shear bound7.736744m and unchanged radius34.416432m leaves81.681157m before numerical allowance. Again, this is one actual leaf, not an all-old result. No implication follows about the other heads: principal centres at admission6/7/5 have native nominal oldq .133984/.112008/.153496 from B10/8/7. Correlation cannot remove genuine occupied potential.

## Unchanged mechanisms and required proof

Attachment/burial, four-second seed ramp, actual parent q ball,11m separation guard,16m mature root/neck, chain<=16, conditional45s lease and existing native checks remain unchanged. Candidate pose construction, fresh K, inherited u, fixed scales, root/shoulder catalogue and source physics are not modified. Local6m head balls/chains remain the same field facts. The new algorithm proves only a head's exterior cue; it does not create density or authorize a detached head. Main/light/receiver/reflection use the original positive-support bounds and direct field; the .005 BVH is never render culling.

Before helper implementation is commissioned, independent review must close the discrete algebra, interval construction, factorization, numerical scope and bounded scheduling. The first executable proof then must reject injected independent causes, missing old7, mutable inputs, quarter/epoch mismatch and invalid finite frames; compare direct180-term vs prefix bounds at endpoints/knots and ambiguous cases; verify every excluded leaf against an independent interval/brute-force adversarial reference; test same-role cancellation, opposite-role uplift and arbitrary sign-changing/rotating shear. Include all-U0/.3, zero/alternating/bang-bang S, S aligned with coefficient sign, breakpoint-focused growth and randomized per-step admitted controls, nonzero inherited u/K, extreme finite coordinates, close/tangent planes and nextafter perturbations. Finite sampling cannot prove arbitrary forcing: it challenges a separately checked conservative enclosure. Any false exclusion is a stop. Understatement of the direct bound is a stop. Main-thread yield/backlog/immutable publication and complete all-old membership require integration tests.

Only after that: unchanged370s eight candidates, then the same six unchanged replays and actual motion. Real occupied heads must remain rejected. Continuous1200s renewal is an outcome to test, not a promised consequence. If the stronger proof still fails, report that field/catalogue/programme mismatch; do not tune the fixed controls inside this commission.
