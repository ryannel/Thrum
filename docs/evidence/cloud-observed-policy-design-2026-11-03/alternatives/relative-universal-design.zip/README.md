# Relative admission design

Owner: cloud_lifecycle_diagnosis. Purpose: bounded analytic contract for independent review. No executable helper/source changes, GPU work, asset cook or benchmark.

Read [PROPOSAL.md](PROPOSAL.md). [worked-cases.json](worked-cases.json) pins the actual370s ablation and discrete growth arithmetic; it records no new certificate pass. Inputs are read-only frozen natural admission and original reviewed source. The static input/data/source and threshold identities remain unchanged. This scratch proposal is not canonical adoption.
