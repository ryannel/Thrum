# Optimized exact candidate cost gate — FAIL

Root exclusive quiet grant; unchanged command `python3 tmp/cloud-observed-policy-cost-proof/run-guard.py observed-cost node --expose-gc tests/observed/cost.mjs`. Source freeze902f2608a776560b1b88a998a0555b1605db2ea2937f443cebdceb04ca00436d; evaluatorb4d2c2b54f523c2451714c2293190d70e644efacfac86bb5371e799d8e9895fe. Receiptb003d3080540385272698cd84f2f3ebf74989d4f50547766ac70b264596426ab. Source/evaluator did not change during run. Earlier SOURCE-PINS/functional notes correctly retain their pre-run status; this is the later gate result.

| Case | Matched legacy max ms | Optimized observed max ms | Observed p99 ms | New4ms gate |
|---|---:|---:|---:|---|
| Single wet1200 |2.092292|2.025709|.243166|PASS |
| Single dry900 |1.589959|4.462250|.317459|FAIL |
| Two wet1200 |2.872250|3.220583|.455750|PASS |

The single-wet maximum is first forecast70s; its420s step is1.670750ms. The two-wet maximum is420s, with820s2.457667ms. Single dry still fails at420s. Low percentiles and targeted improvements do not override the failed maximum. First failed f57 run is unchanged in cloud-observed-policy-proof; these are distinct trials/candidates, not a relabelled pass or a statistical end-to-end speedup claim.

622 GC events/max1.826750ms are retained. The byte-identical evaluator lacks individual step wall-start stamps, so exact GC overlap/cost attribution is unavailable. Do not delete the tail as “just GC.” Process-tree sampled peak161,366,016B passes224MiB early/256MiB hard. Six raw F64 duration arrays, all top tails, metadata/counters, process CPU, GC and hashes are retained in results/COST-HANDOFF. No reruns/filtering/budget changes.

The residual adverse case exercises active-front candidate midpoint checks; those still evaluate original numeric geometry under the held front. It is a code-level remaining-work observation, not proven attribution of4.462ms. A separately reviewed exact fixed-frame preparation for discarded midpoint queries might remove additional repeated dual work; it is not implemented or cost-qualified here. No async/deferred clock/birth, fewer sites, weakened safety, or altered audit fields follow from this result.

Functional exactness remains: all6 f57 states/publications/controls/references/predictions/observations/rejections/counters match; native/profile/endpoint/default source/world tests pass. Artwork and420/820 healthy opportunity failures remain unaccepted. This measured gate blocks runtime enablement of the exact optimized candidate.
