# Front midpoint exact work removal and owned observation capture

New candidate only;902f/b003 andf57/cf5 remain unchanged. No timing until review/quiet grant. All decision/state/counter/reason/publication values stay exact againstf57; new capture is on-demand, not inserted into ordinary metadata/steps.

## X-only health computation

The held-front health guard consumes only half-step Cx/Kx/b and matrix row0. With d=.125, e=exp(-d/10), target=(role BODY?0:c.uplift), uy=p.uY, retain the existing operation grouping:

`intY = Cy*d + .5*target*d*d + 10*(uy-target)*(d-10*(1-e))`

`CxHalf = Cx + (meanX*d + shearX*(intY-1500*d) + 10*ux*(1-e))`

`KxHalf = Kx + (shearX*s*halfIg)`; `bHalf=s*halfG`.

The K expression is the original left-associated multiplication. BODY parent override replaces **only** CxHalf with `regionAdvance(R,c,d)[0]`; it does not replace KxHalf. Actual full-step advancePose remains unchanged. Other half-step coordinates/velocities are discarded by this query and need not be computed. Supported scalar fast path requires proper finite ordinary pose/control vectors, known role/scale and finite growth work; otherwise execute the original half-midpoint path. Do not silently change malformed-state error behaviour.

At the first actual needMid, after half-coordinate work and at the original matrix evaluation point, compute `fieldColumns(Q)` directly, never by constructing matrix with unit b/zero K. For registered birth Q, the private dual was built by this same pure function on deeply frozen Q, so bits agree; nonregistered Q uses the same function. Cache is local to one forecast; guard Q/row identity and all9 values (Object.is, signed zero included). Mutation/identity mismatch falls back to original matrix path. Invalid Q throws only when the original matrix would be needed. There is no global/slot/generation cache.

Compute only `row0[j]=bHalf*D[j][0]+KxHalf*D[j][1]` and the original min-X reduction, preserving multiplication/addition/loop grouping and domain/root terms. This removes repeated numerical inverse, full3x3 arrays, and unused half-step Y/Z/u updates, without a looser weather bound, earlier geometric rejection or omitted health decision/node counter. One per-forecast dual/snapshot is <256B scalar payload; original reusable fallback midpoint remains available. Shared rawR16s are unchanged.

Proof tests must compare exact minX (Object.is) to original geometry+advancePose+matrix, across arbitrary held controls/states, BODY overrides, registered/nonregistered Q, signed zeros, boundary/near-invalid frames and mutation fallback, including exact error timing. Then all6 f57 full differentials and existing functional/native/source/world tests.

## On-demand world capture API

`world.captureObservations(presentationTime, explicitClockEpoch, {interruptionReason}={})`. Require explicit nonnegative safe-integer epoch (0 valid, omitted/undefined invalid), healthy world, and exact presentationTime within [world.previousTime,world.time]. Bounded reason is optional, nonempty<=128characters/no controls. No epoch enters step or model state.

Each cell returns enabled=false if legacy; otherwise `summary=observed.publication(presentationTime,epoch)`. Full latest detail is `presentedActual` only if detail.time<=presentationTime; otherwise explicitly unavailable-after-presentation. A separate `committedAudit` is labelled committed/not-presented. Optional interruption is a snapshot of the actual committed pending lease/time under the caller's OLD epoch, distinct from displayed outcome. Bind via existing qualifiedID while preserving local IDs; all data owned, no E/native buffers, no source mutation/journal owner. Capture before reset/seek externally; no automatic per-step snapshots.

Bound total serialized owned capture<=256KiB (2cells, <=8references each), report actual byte count; reject oversized captures explicitly. Tests cover explicit0/missing epoch, previous/current deadline split, future detail unavailable, owned data surviving step/mutation/reset, old-epoch interruption, legacy disabled and fault/stale/out-of-range rejection. SourceClock unchanged; new world/helper method is outside normal evaluator path. Align exact shape with core before freeze.

## Supplementary coupled dry gate

Keep original b4d2 evaluator byte-identical and all6 cases. Before timing, separately pin a supplementary case using TwoCellWorld, default dry controls, end900, rootsA[0,0]/B[2400,-1200]. Whole synchronous step+one publication, same4ms max, GC/raw F64/all tails/process guard. Gate requires both original and supplement. No filtering/retry/threshold changes or deferred clock/birth.
