# Front candidate original + coupled-dry cost gates — FAIL

Root exclusive quiet grant. Source12777301a56a54c3bcc0cf29b23b7a33eb3e3cfad186dc908d04b0b22f4715cf stayed fixed; both evaluators unchanged. Commands ran serially under the same224MiB early/256MiB hard tree guard:

```
python3 tmp/cloud-observed-policy-front-cost-proof/run-guard.py observed-cost node --expose-gc tests/observed/cost.mjs
python3 tmp/cloud-observed-policy-front-cost-proof/run-guard.py observed-cost-two-dry node --expose-gc tests/observed/cost-two-dry.mjs
```

Original evaluator SHA b4d2c2b54f523c2451714c2293190d70e644efacfac86bb5371e799d8e9895fe; new two-dry evaluator abc99b74242aef22f389354605a3ac844b35a388d6e5d8a1a3001102a26c9cd2 was pinned before timing. Results are separate, not substitutions.

| Protocol/case | Matched legacy max ms | Observed max ms | Observed p99 ms |4ms gate |
|---|---:|---:|---:|---|
| Original single wet1200 |2.724500|1.832583|.233542|PASS |
| Original single dry900 |2.314792|4.203417|.329625|FAIL |
| Original two wet1200 |2.619000|3.029750|.426625|PASS |
| Supplement two dry900 |3.378667|7.425500|.556250|FAIL |

Supplement uses defaultdry, fixed rootsA[0,0]/B[2400,-1200], whole synchronous source step+one publication, same4ms maximum. It exposes the consequential two-cell active-front cost omitted by the wet two-cell case. Both failed observed maxima are source420s. No tail filtering/retry/threshold change; lower typical times do not pass the gate.

Original result SHA65fff59a92f4bd858b09fc55760c0c9dee7e87d3ecc27cd3a2fd1995c48100cd, supplement27ccaf7381d086ab497cef03935569d4f4c103c64aeaed418d58bb27f094a47b. All8 rawF64 duration arrays, top tails/metadata/processCPU and GC entries retained/pinned in COST-HANDOFF.json. GC615/max1.924625ms and279/max2.469916ms are retained; unchanged evaluator lacks per-step wall-start stamps, so no exact tail/GC attribution is claimed. Sampled process-tree peaks169,803,776B and175,833,088B pass memory guards; no process/GPU/full-engine admission follows.

This preserves earlier f57/cf5 and902f/b003 failures unchanged. Exact CPU semantics/functional tests and independent code review pass; healthy420/820 admission deficits and source artwork remain unaccepted. On-demand capture API is implemented and tested but coupled runtime enablement remains blocked. No async/deferred birth, reduced candidate count, loosened cue/safety, or budget change is implied.
